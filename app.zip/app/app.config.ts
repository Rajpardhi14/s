import { ApplicationConfig, LOCALE_ID } from '@angular/core';
import { provideRouter, withViewTransitions } from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { SocialAuthServiceConfig, SocialAuthService } from '@abacritt/angularx-social-login';
import { provideOAuthConfig } from './core/config/oauth.config';
import localeIn from '@angular/common/locales/en-IN';
import { registerLocaleData } from '@angular/common';
// ✅ Register Indian locale 
registerLocaleData(localeIn);
export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withViewTransitions()),
    provideClientHydration(),
    provideAnimations(),
    provideHttpClient(withFetch()),
    {
      provide: 'SocialAuthServiceConfig',
      useFactory: provideOAuthConfig
    },
    SocialAuthService,
   { provide: LOCALE_ID, useValue: 'en-IN' },
  ],
};
