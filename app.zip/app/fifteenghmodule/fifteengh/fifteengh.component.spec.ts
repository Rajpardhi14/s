import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FifteenghComponent } from './fifteengh.component';

describe('FifteenghComponent', () => {
  let component: FifteenghComponent;
  let fixture: ComponentFixture<FifteenghComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FifteenghComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FifteenghComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
