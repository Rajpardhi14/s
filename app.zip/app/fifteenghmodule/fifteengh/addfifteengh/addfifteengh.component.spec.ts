import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddfifteenghComponent } from './addfifteengh.component';

describe('AddfifteenghComponent', () => {
  let component: AddfifteenghComponent;
  let fixture: ComponentFixture<AddfifteenghComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddfifteenghComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddfifteenghComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
