
import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnDestroy, NgZone, SimpleChanges, ChangeDetectorRef, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators, FormArray } from '@angular/forms';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { formatDatesend } from '../../../shared/utils/passmatch';
import { catchError, debounceTime, distinctUntilChanged, filter, map, merge, Observable, Subject, takeUntil, tap, throwError } from 'rxjs';
import { DatepickerComponent } from '../../../shared/components/datepicker/datepicker.component';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
interface Option { label: string; value: any; typeCode?: any; }

@Component({
  selector: 'app-addfifteengh',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, OutSideClickDirective, DatepickerComponent,AlertpoupComponent,],
  templateUrl: './addfifteengh.component.html',
  styleUrl: './addfifteengh.component.css'
})
export class AddfifteenghComponent {
  @ViewChild('datePicker') datePicker!: DatepickerComponent;
  @Input() removedFilter: any;
  detailsLoader: boolean = false;
  // isCertificateEnabled = false;
  @Input() selectedRowDetails: any;
  @Input() selectedRowId: any;
  @Output() close = new EventEmitter<void>();
  @Input() isDrawerOpen: any;
  fifteenghForm!: FormGroup;
  UserData: any;
  roleData: any;
  dynamicUserData: any;
  private destroy$ = new Subject<void>();
  tdsTypeCode: any;
  tdsRateTypeMastData: any;
  residentStatusMastData: any;
  gh15FlagMastData: any

  countryMastData: any;
  tdsReasonMastData: any;
  showRemittanceOptions = false;
  searchRemittance = '';
  selectedRemittanceLabel: string | null = null;
  selectedRemittanceValue: any
  tdsMastData: any;
  tdsSectionOptions: any[] = [];
  residentStatusOptions: any[] = [];

  // original data from API
  tdsRemittanceData: any[] = [];
  quarterNo: any;
  show194NInputs: boolean = false;
  isLoadingRates: boolean = false;
  isLoadingSpecialRates: boolean = false;
  // Certificate popup variables
  showCertificatePopup: boolean = false;
  certificateDetails: any[] = [];
  // Date restrictions for quarter
  quarterStartDate: string = '';
  quarterEndDate: string = '';
  maxDate: string = '';
  isLoadingPanData: boolean = false;
  panValidationStatus: {
    isValid: boolean | null;
    message: string;
  } = {
      isValid: null,
      message: ''
    };
  tdsRates = {
    tdsRate: 0,
    surchargeRate: 0,
    cessRate: 0
  };
  isEditMode: boolean = true;
  // filtered options
  filteredRemittanceOptions: any[] = [];
  activeSection: string = 'deductee'; // start with Deductee Details
  completedSections: string[] = [];
  deductee_panno_status: any;
  fyStartDate!: string;
  serverErrors: { [key: string]: string } = {}; // Store server errors separately
  private fieldMap: { [key: string]: string } = {
    deductee_panno_valid: 'deductee_panno',
    deductee_panno_verified: 'deductee_panno',
    tds_deduct_date: 'tds_deduct_date',
    tds_code: 'tds_code',
    deductee_panno: 'deductee_panno',
    deductee_name: 'deductee_name',
    tran_ref_date: 'tran_ref_date',
    tran_amt: 'tran_amt',
    cust_id: 'cust_id'
    // Add more mappings as needed for other fields
  };
  multiMast: any;
  firsttimetdsget: boolean = false;
  stateMastOptions: any;
  filteredStateOptions: any[] = [];
  selectedStateOptionLabel = '';
  selectedStateOptionValue: any;
  showErrorPopup = false;
  popupMessage = '';
  // keep previous total to restore if needed
  previousTotalForms = 0;
     localUserData: any;

  constructor(private userlocaldataService: UserdataService,
    private toastService: ToastService,
    private apiservice: ApiserviceService,
    private authservice: AuthService,
    private refreshdata: RefreshdataService,
    private fb: FormBuilder,
    private ngZone: NgZone,
    private userlocaldata: UserdataService,
    private cdr: ChangeDetectorRef,
    private apiService: ApiserviceService,
    private cd: ChangeDetectorRef
  ) {
    // this.createTransactionForm();
  }


  ngOnChanges(changes: SimpleChanges): void {
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.getsData();
    const challanRowId = this.selectedRowDetails?.tds_challan_rowid_seq;
    // this.isLoading = true;
    if (changes['selectedRowId'] && this.selectedRowId) {
      this.fetchUserDetails(this.selectedRowId);
      this.isEditMode = false;
      this.isDrawerOpen = true;
      this.createTransactionForm();

    } else {
      // this.isLoading = false;
      this.isEditMode = true;
      this.createTransactionForm();
    }
  }


  ngOnInit(): void {
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    // this.getsData();

    this.createTransactionForm();

    // 🔸 PIN code lookup

    if (!this.selectedRowId || this.isEditMode) {
      this.fifteenghForm.get('pin')?.valueChanges
        .pipe(
          debounceTime(300),
          distinctUntilChanged(),
          filter(value => /^\d{6}$/.test(value)),
          takeUntil(this.destroy$)
        )
        .subscribe(value => this.getPinCodeData(value));

      // Set date restrictions based on quarter
      this.setQuarterDateRestrictions();
    }
  }

  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
          this.multiMast = parsedData.multiMast;
          this.getHreaderData();
        } catch (e) {
          parsedData = response.data;
        }
        // console.log('Parsed Redis data:', parsedData);
      },
      error: (error: any) => {
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }


  private createTransactionForm() {
    const is26Q = this.tdsTypeCode == '26Q';
    this.fifteenghForm = this.fb.group({
      deductee_name: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(75)]],
      deductee_panno: ['', [Validators.required]],
      cust_id: ['', [Validators.maxLength(10)]],
      // deduction_ref_no: ['', [Validators.maxLength(10)]],
      deduction_ref_no: [
  '',
  [
    Validators.maxLength(16),
    Validators.pattern(/^[a-zA-Z0-9]*$/) // only letters and numbers
  ]
],
      resident_status: ['', Validators.required],

      gh15_flag: ['', Validators.required],
      pan_status: ['', Validators.required],
      certificate_no: [
        '',
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern(/^[A-Z0-9]+$/) // only letters & numbers
        ]
      ],
      dob: [''],
      assessed_tax_flag: ['', Validators.required],
      est_declaration_income: ['', [Validators.required,Validators.max(1000000000000)]],
      latest_assessment_year: [''],
      est_total_income: ['', [Validators.required,Validators.max(1000000000000)]],
      // total_no_form: ['', [Validators.required]],
      total_no_form: [null, [Validators.required, Validators.min(1)]],
      formArray: this.fb.array([]),
      income_amount_paid: ['', [Validators.required ,Validators.max(1000000000000)]],
      aggregate_income_amt: ['',[Validators.max(1000000000000)]],
      declaration_date: ['',[Validators.required]],
      income_paid_date: ['',[Validators.required]],

      add1: ['', Validators.required],
      add2: [''],
      add3: [''],
      add4: ['', Validators.required],
      city: ['', Validators.required],
      state_code: ['', Validators.required],
    pin: [
  '',
  [
    Validators.required,
    Validators.pattern(/^\d*$/), // only digits
    Validators.maxLength(6)
  ]
],

      // regex applied dynamically
      email_id: ['', Validators.required], // regex applied dynamically
      stdcode: ['', Validators.required],
      mobileno: ['', Validators.required], // regex applied dynamically
      phoneno: ['', Validators.required], // regex applied dynamically

      // account_no: ['', [Validators.maxLength(25)]],

    });
    this.subscribeToPanValueChanges();
    this.tdsTypeCode = this.dynamicUserData?.default_tds_type_code;

    // Watch for total_no_form changes
    this.fifteenghForm.get('total_no_form')?.valueChanges.subscribe((val) => {
      this.adjustFormArray(val);
      console.log('Form Value:', this.fifteenghForm.getRawValue());

      this.cd.detectChanges();
    });

    const numericFields = [
      'pin',
      'mobileno',
      'stdcode',
      'phoneno',
      'est_total_income',
      'income_amount_paid',
      'aggregate_income_amt',
      'total_no_form',
      'gh15_amount',
    ];

    numericFields.forEach(field => {
      this.fifteenghForm.get(field)?.valueChanges.subscribe(value => {
        if (value && !/^\d*$/.test(value)) {
          const cleaned = value.replace(/\D/g, ''); // remove non-digit chars
          this.fifteenghForm.get(field)?.setValue(cleaned, { emitEvent: false });
        }
      });
    });

  }


  private resetFormOnPanEdit() {
    // Clear name and other dependent fields
    // this.fifteenghForm.patchValue({
    //   deductee_name: '',
    // });

    // Reset validation status
    this.panValidationStatus = {
      isValid: null,
      message: ''
    };

    // If you want to reset all form fields:
    // this.fifteenghForm.reset();

    // Also reset PAN verification flags
    this.pannoVerified = null;
    console.log(this.roleData.deductee_panno_verified);
    if (this.roleData) {
      this.roleData.deductee_panno_verified = null;
    }

    this.isLoadingPanData = false;
  }


  goToNextSection(nextSection: string, currentSection: string) {
    if (this.isSectionValid(currentSection)) {
      if (!this.completedSections.includes(currentSection)) {
        this.completedSections.push(currentSection);
      }
      this.activeSection = nextSection;
    } else {
      this.fifteenghForm.markAllAsTouched();
    }
  }

  onKeyDown(event: KeyboardEvent, section: string, current: string) {
    if (event.key === 'Enter' || event.key === 'Tab') {
      event.preventDefault();

      let isSectionComplete = false;

      // Check completion based on the current section
      if (current === 'deductee') {
        isSectionComplete = this.isdeducteeDetailsComplete;
      } else if (current === 'deducteeAddress') {
        isSectionComplete = this.isdeducteeAddressComplete;
      }
      else if (current === 'income') {
        isSectionComplete = this.isincomeDetailsComplete;
      }
      else if (current === 'other') {
        isSectionComplete = this.isOtherDetailsComplte;
      }

      // Proceed only if the current section is complete
      if (isSectionComplete) {
        this.goToNextSection(section, current);
        this.onSaveAndNext();

        // Add the current section to completedSections
        if (!this.completedSections.includes(current)) {
          this.completedSections.push(current);
        }

        // Move to next section
        this.activeSection = section;
      } else {
        // Optionally, mark all fields as touched to show validation errors
        if (current === 'deductee') {
          this.markSectionFieldsAsTouched(['deductee_name', 'deductee_panno', 'resident_status']);
        } else if (current === 'deducteeAddress') {
          this.markSectionFieldsAsTouched(['add1', 'add4', 'pin', 'city', 'state_code', 'email_id', 'mobileno' ,'stdcode','phoneno']);
        } else if (current === 'income') {
          this.markSectionFieldsAsTouched(['gh15_flag', 'certificate_no', 'pan_status', 'assessed_tax_flag', 'est_total_income', 'est_declaration_income', 'total_no_form', 'declaration_date', 'income_amount_paid', 'income_paid_date' , ]);
        }
        // else if (current === 'other') {
        //   this.markSectionFieldsAsTouched([ 'gh15_flag', 'certificate_no', 'pan_status','assessed_tax_flag','est_total_income','est_declaration_income','total_no_form','declaration_date','income_amount_paid','income_paid_date']);
        // }
      }
    }
  }

  // Optional helper to mark fields as touched
  private markSectionFieldsAsTouched(fields: string[]) {
    fields.forEach(field => {
      const control = this.fifteenghForm.get(field);
      if (control) {
        control.markAsTouched();
        control.updateValueAndValidity();
      }
    });
  }


  onButtonNext(nextSection: string, currentSection: string) {
    // console.log('Transaction Form Value:', this.fifteenghForm.value);
    // Prevent moving beyond 'other'
    if (currentSection === 'other') {
      console.log('Reached last section: other');
      this.onSaveAndNext(); // optional: final save
      return;
    }

    this.goToNextSection(nextSection, currentSection);

    // Mark sections completed correctly
    if (currentSection && !this.completedSections.includes(currentSection)) {
      this.completedSections.push(currentSection);
    }
    if (nextSection && !this.completedSections.includes(nextSection)) {
      this.completedSections.push(nextSection);
    }
    this.onSaveAndNext();

    // Move to next section
    this.activeSection = nextSection;
  }

  // Helper: check validity for each section
  isSectionValid(section: string): boolean {
    switch (section) {
      case 'deductee':
        // Deductee section must have valid PAN and name
        return !!(
          this.fifteenghForm.get('resident_status')?.valid &&
          this.fifteenghForm.get('deductee_panno')?.valid &&
          this.fifteenghForm.get('deductee_name')?.valid
        );


      case 'deducteeAddress':
        // Transaction section must have valid TDS code and base amount
        return !!(
          this.fifteenghForm.get('add1')?.valid &&
          this.fifteenghForm.get('add4')?.valid &&
          this.fifteenghForm.get('pin')?.valid &&
          this.fifteenghForm.get('city')?.valid &&
          this.fifteenghForm.get('state_code')?.valid &&
          this.fifteenghForm.get('mobileno')?.valid &&
          this.fifteenghForm.get('email_id')?.valid &&
          this.fifteenghForm.get('phoneno')?.valid &&
          this.fifteenghForm.get('stdcode')?.valid 
        );

      case 'income':
        // Transaction section must have valid TDS code and base amount
        return !!(
          this.fifteenghForm.get('gh15_flag')?.valid &&
          this.fifteenghForm.get('certificate_no')?.valid &&
          this.fifteenghForm.get('pan_status')?.valid &&
          this.fifteenghForm.get('assessed_tax_flag')?.valid &&
          this.fifteenghForm.get('est_total_income')?.valid &&
          this.fifteenghForm.get('est_declaration_income')?.valid &&
          this.fifteenghForm.get('total_no_form')?.valid &&
          this.fifteenghForm.get('declaration_date')?.valid &&
          this.fifteenghForm.get('income_amount_paid')?.valid &&
          this.fifteenghForm.get('income_paid_date')?.valid
        );

      case 'other':
        // ✅ Validate each row inside formArray
        const formArray = this.fifteenghForm.get('formArray') as FormArray;
        if (!formArray || formArray.length === 0) return false;

        const allRowsValid = formArray.controls.every((group) =>
          group.get('account_no')?.valid &&
          group.get('gh15_amount')?.valid &&
          group.get('tds_code')?.valid
        );
        return allRowsValid;

      default:
        return true;
    }
  }


  closePopup() {
    this.close.emit(); // Emit event to parent
  }

  sanitizeValue(value: any, toUpper: boolean = false): string {
    if (!value) return '';
    let transformed = value.toString().trim();
    return toUpper ? transformed.toUpperCase() : transformed;
  }


  regexMap: { [key: string]: string } = {};

  private applyDynamicValidations(): void {
    if (!this.fifteenghForm || !this.regexMap) return;

    Object.entries(this.regexMap).forEach(([label, pattern]) => {
      const control = this.fifteenghForm.get(label);
      if (control) {
        const regexValidator = Validators.pattern(new RegExp(pattern));

        // ✅ Get all existing validators
        const existingValidators = control.validator ? [control.validator] : [];

        // ✅ Remove any existing pattern validators (optional)
        const cleanedValidators = existingValidators.filter(
          (fn) => fn.name !== 'patternValidator'
        );

        // ✅ Conditional validator (apply only if value exists)
        const conditionalValidator = (ctrl: AbstractControl) =>
          !ctrl.value ? null : regexValidator(ctrl);

        // ✅ Preserve "required" and merge with regex
        const isRequired = control.hasValidator(Validators.required);
        const validators = [
          conditionalValidator,
          ...(isRequired ? [Validators.required] : []),
        ];

        control.setValidators(validators);
        control.updateValueAndValidity({ emitEvent: false });
      }
    });
  }

  panStatusMastData: any;
  assesseTaxFlagMastData: any;
  accYearMastData: any;

  getHreaderData() {
    const validations = this.multiMast?.get_gmdt_regex_validation || [];
    this.regexMap = validations.reduce((acc: any, cur: any) => {
      acc[cur.label] = cur.value;
      return acc;
    }, {});

    // After fetching regex, re-apply validations
    this.applyDynamicValidations();

    const residentStatusMastData = this.multiMast?.get_gmdt_resident_type_mast;
    this.residentStatusMastData = residentStatusMastData;
    // console.log(this.residentStatusMastData);

    const gh15FlagMastData = this.multiMast?.get_gmdt_gh15_flag_mast;
    this.gh15FlagMastData = gh15FlagMastData;

    const panStatusMastData = this.multiMast?.get_gmdt_pan_status_mast;
    this.panStatusMastData = panStatusMastData;
    //console.log(this.panStatusMastData);

    const assesseTaxFlagMastData = this.multiMast?.get_gmdt_assessed_tax_flag_mast;
    this.assesseTaxFlagMastData = assesseTaxFlagMastData;
    // console.log(this.assesseTaxFlagMastData);

    const accYearMastData = this.multiMast?.get_gmdt_acc_year_mast;
    this.accYearMastData = accYearMastData;
    //console.log(this.accYearMastData);

    const countryMastData = this.multiMast?.get_gmdt_country_mast;
    this.countryMastData = countryMastData;

    const stateMastData =
      this.multiMast
        ?.get_gmdt_state_mast;

    const tdsMastData = this.multiMast?.get_gmdt_tds_mast;
    this.tdsMastData = tdsMastData;

    const fyStartYear = new Date().getFullYear(); // adjust if your FY doesn't align with calendar year
    const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

    this.tdsSectionOptions = (this.tdsMastData || []).filter((item: any) => {
      // condition 1: tds_type_code match
      const typeMatch = item.tds_type_code === this.tdsTypeCode;

      // condition 2: valid_to_date is null OR quarterEnd <= valid_to_date
      let dateValid = true;
      if (item.valid_to_date) {
        const validTo = this.parseDdMmYyyy(item.valid_to_date);
        dateValid = end <= validTo;
      }

      return typeMatch && dateValid;
    });

    // ✅ Only initialize if tdsSectionOptions is not empty
    if (this.tdsSectionOptions.length > 0 && this.formArray.length > 0) {
      this.initializeFilteredOptions();
    } else {
      // fallback to empty arrays
      this.filteredTdsSectionOptions = [];
    }



    this.stateMastOptions = stateMastData.map((item: any) => ({
      label: item.label, // or item.label
      value: item.value,
      state_Code: item.state_code, // <-- link with type
    }));

  this.filteredStateOptions = [...this.stateMastOptions];
    this.filteredResidentStatusOptions = this.residentStatusMastData || [];
    this.filtered15ghFlagOptions = this.gh15FlagMastData || [];
    this.filteredPanStatusOptions = this.panStatusMastData || [];
    this.filteredassesseTaxFlagOptions = this.assesseTaxFlagMastData || [];
    this.filteredaccYearOptions = this.accYearMastData || [];

  }

  private initializeFilteredOptions(): void {
    this.filteredTdsSectionOptions = this.formArray.controls.map(() => [...this.tdsSectionOptions]);
    console.log(this.filteredTdsSectionOptions);
  }

  showResidentStatusOption = false;
  selectedResidentStatusLabel = '';
  selectedResidentStatusValue: any;
  searchResidentStatus = '';
  filteredResidentStatusOptions: any[] = [];


  filterResidentStatusOptions() {
    const searchValue = this.searchResidentStatus.toLowerCase();
    this.filteredResidentStatusOptions = this.residentStatusMastData.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }



  clearSelectionResidentStatuInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedResidentStatusLabel = 'Select';
    this.selectedResidentStatusValue = null;
    this.fifteenghForm.patchValue({
      resident_status: '',
    });
    this.fifteenghForm.get('resident_status')?.markAsTouched();
  }

  selectResidentStatus(option: any) {
    this.selectedResidentStatusLabel = option.label;
    this.selectedResidentStatusValue = option.value;
    this.fifteenghForm.get('resident_status')?.setValue(option.value);
    this.showResidentStatusOption = false;
    this.searchResidentStatus = '';
    this.filteredResidentStatusOptions = [...(this.residentStatusMastData || [])];

  }

  onCloseResidentStatuSDropdown() {
    this.showResidentStatusOption = false;

    // Reset search and show all options
    this.searchResidentStatus = '';
    this.filteredResidentStatusOptions = [...(this.residentStatusMastData || [])];


    this.ngZone.run(() => {
      const control = this.fifteenghForm.get('resident_status');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }



  show15ghFlagOption = false;
  selected15ghFlagLabel = '';
  selected15ghFlagValue: any;
  search15ghFlag = '';
  filtered15ghFlagOptions: any[] = [];


  filter15ghFlagOptions() {
    const searchValue = this.search15ghFlag.toLowerCase();
    this.filtered15ghFlagOptions = this.gh15FlagMastData.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }



  clearSelection15ghFlagInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selected15ghFlagLabel = 'Select';
    this.selected15ghFlagValue = null;
    this.fifteenghForm.patchValue({
      gh15_flag: '',
    });
    this.fifteenghForm.get('gh15_flag')?.markAsTouched();
  }

  select15ghFlag(option: any) {
    this.selected15ghFlagLabel = option.label;
    this.selected15ghFlagValue = option.value;
    this.fifteenghForm.get('gh15_flag')?.setValue(option.value);
    this.show15ghFlagOption = false;
    this.search15ghFlag = '';
    this.filtered15ghFlagOptions = [...(this.gh15FlagMastData || [])];

  }

  onClose15ghFlagDropdown() {
    this.show15ghFlagOption = false;

    // Reset search and show all options
    this.search15ghFlag = '';
    this.filtered15ghFlagOptions = [...(this.gh15FlagMastData || [])];


    this.ngZone.run(() => {
      const control = this.fifteenghForm.get('gh15_flag');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }



  showPanStatusOption = false;
  selectedPanStatusLabel = '';
  selectedPanStatusValue: any;
  searchPanStatus = '';
  filteredPanStatusOptions: any[] = [];


  filterPanStatusOptions() {
    const searchValue = this.search15ghFlag.toLowerCase();
    this.filteredPanStatusOptions = this.panStatusMastData.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }



  clearSelectionPanStatusInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedPanStatusLabel = 'Select';
    this.selectedPanStatusValue = null;
    this.fifteenghForm.patchValue({
      pan_status: '',
    });
    this.fifteenghForm.get('pan_status')?.markAsTouched();
  }

  selectPanStatus(option: any) {
    this.selectedPanStatusLabel = option.label;
    this.selectedPanStatusValue = option.value;
    this.fifteenghForm.get('pan_status')?.setValue(option.value);
    this.showPanStatusOption = false;
    this.searchPanStatus = '';
    this.filteredPanStatusOptions = [...(this.panStatusMastData || [])];

  }

  onClosePanStatusDropdown() {
    this.showPanStatusOption = false;

    // Reset search and show all options
    this.searchPanStatus = '';
    this.filteredPanStatusOptions = [...(this.panStatusMastData || [])];


    this.ngZone.run(() => {
      const control = this.fifteenghForm.get('pan_status');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }

  showaccYearOption = false;
  selectedaccYearLabel = '';
  selectedaccYearValue: any;
  searchaccYear = '';
  filteredaccYearOptions: any[] = [];


  filteraccYearOptions() {
    const searchValue = this.searchaccYear.toLowerCase();
    this.filteredaccYearOptions = this.accYearMastData.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }



  clearSelectionaccYearInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedaccYearLabel = 'Select';
    this.selectedaccYearValue = null;
    this.fifteenghForm.patchValue({
      latest_assessment_year: '',
    });
    this.fifteenghForm.get('latest_assessment_year')?.markAsTouched();
  }

  selectaccYear(option: any) {
    this.selectedaccYearLabel = option.label;
    this.selectedaccYearValue = option.value;
    this.fifteenghForm.get('latest_assessment_year')?.setValue(option.value);
    this.showaccYearOption = false;
    this.searchaccYear = '';
    this.filteredaccYearOptions = [...(this.accYearMastData || [])];

  }

  onCloseaccYearDropdown() {
    this.showaccYearOption = false;

    // Reset search and show all options
    this.searchaccYear = '';
    this.filteredaccYearOptions = [...(this.accYearMastData || [])];


    this.ngZone.run(() => {
      const control = this.fifteenghForm.get('latest_assessment_year');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }



  showassesseTaxFlagOption = false;
  selectedassesseTaxFlagLabel = '';
  selectedassesseTaxFlagValue: any;
  searchassesseTaxFlag = '';
  filteredassesseTaxFlagOptions: any[] = [];


  filterassesseTaxFlagOptions() {
    const searchValue = this.searchassesseTaxFlag.toLowerCase();
    this.filteredassesseTaxFlagOptions = this.assesseTaxFlagMastData.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }



  clearSelectionassesseTaxFlagInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedassesseTaxFlagLabel = 'Select';
    this.selectedassesseTaxFlagValue = null;
    this.fifteenghForm.patchValue({
      assessed_tax_flag: '',
    });
    this.fifteenghForm.get('assessed_tax_flag')?.markAsTouched();
  }

  selectassesseTaxFlag(option: any) {
    this.selectedassesseTaxFlagLabel = option.label;
    this.selectedassesseTaxFlagValue = option.value;
    this.fifteenghForm.get('assessed_tax_flag')?.setValue(option.value);
    this.showassesseTaxFlagOption = false;
    this.searchassesseTaxFlag = '';
    this.filteredassesseTaxFlagOptions = [...(this.assesseTaxFlagMastData || [])];

  }

  onCloseassesseTaxFlagDropdown() {
    this.showassesseTaxFlagOption = false;

    // Reset search and show all options
    this.searchassesseTaxFlag = '';
    this.filteredassesseTaxFlagOptions = [...(this.assesseTaxFlagMastData || [])];


    this.ngZone.run(() => {
      const control = this.fifteenghForm.get('assessed_tax_flag');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }




  showTdsSectionOptionIndex: number | null = null;
  filteredTdsSectionOptions: any[][] = [];
  showTdsSectionOption = false;
  selectedTdsSectionLabel = '';
  selectedTdsSectionValue: any;
  searchTdsSection: string[] = [];

  // filteredTdsSectionOptions: any[] = [];


  // filterTdsSectionOptions(index: number): void {
  //   const searchValue =
  //     this.formArray.at(index).get('searchTdsSection')?.value?.toLowerCase() || '';

  //   if (!searchValue) {
  //     this.filteredTdsSectionOptions[index] = [...this.tdsSectionOptions];
  //   } else {
  //     this.filteredTdsSectionOptions[index] = this.tdsSectionOptions.filter((option: any) =>
  //       option.label.toLowerCase().includes(searchValue)
  //     );
  //   }
  // }

  filterTdsSectionOptions(index: number): void {
    const searchValue = this.searchTdsSection[index]?.toLowerCase() || '';

    // Filter from full master list, not previously filtered array
    this.filteredTdsSectionOptions[index] = this.tdsSectionOptions.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }


  // selectTdsSection(option: any, index: number): void {
  //   const rowGroup = this.formArray.at(index) as FormGroup;

  //   rowGroup.patchValue({
  //     tds_code: option.value,
  //     selectedTdsSectionLabel: option.label,
  //   });

  //   this.showTdsSectionOptionIndex = null;

  //   // Re-enable previously selected options in other rows
  //   this.refreshFilteredOptions();
  // }

  selectTdsSection(option: any, index: number): void {
    const rowGroup = this.formArray.at(index) as FormGroup;
    rowGroup.patchValue({
      tds_code: option.value,
      selectedTdsSectionLabel: option.label,
    });

    // Reset search input and dropdown
    this.searchTdsSection[index] = '';
    this.filteredTdsSectionOptions[index] = [...this.tdsSectionOptions];
    this.showTdsSectionOptionIndex = null;
  }


  // private refreshFilteredOptions(): void {
  //   const selectedValues = this.formArray.controls
  //     .map(group => group.get('tds_code')?.value)
  //     .filter(v => v);

  //   this.filteredTdsSectionOptions = this.formArray.controls.map(() => {
  //     return this.tdsSectionOptions.filter(opt => !selectedValues.includes(opt.value));
  //   });
  // }


  toggleTdsDropdown(index: number): void {
    this.showTdsSectionOptionIndex =
      this.showTdsSectionOptionIndex === index ? null : index;

    // initialize filtered list for that row
    if (this.showTdsSectionOptionIndex !== null) {
      this.filteredTdsSectionOptions[index] = [...this.tdsSectionOptions];
    }
  }

  closeTdsDropdown(index: number): void {
    if (this.showTdsSectionOptionIndex === index) {
      this.showTdsSectionOptionIndex = null;
    }
  }
  // Optional: mark touched if dropdown closed without selecting

  // onCloseTdsSectionDropdown() {
  //   this.showTdsSectionOption = false;

  //    // Reset search and show all options
  // this.searchTdsSection = '';
  // this.filteredTdsSectionOptions = [...(this.tdsSectionOptions || [])];


  //   this.ngZone.run(() => {
  //     const control = this.fifteenghForm.get('tds_code');
  //     if (!control?.value) {
  //       control?.markAsTouched();
  //       control?.updateValueAndValidity();
  //     }
  //   });
  // }

  onCloseTdsSectionDropdown(index: number) {
    this.showTdsSectionOptionIndex = null;

    // Reset search & filtered options for that row only
    this.searchTdsSection[index] = '';
    this.filteredTdsSectionOptions[index] = [...this.tdsSectionOptions];

    this.ngZone.run(() => {
      const control = (this.formArray.at(index) as FormGroup).get('tds_code');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }

  clearSelectionInput(event: Event, index: number): void {
    event.stopPropagation(); // prevent dropdown from reopening

    const rowGroup = this.formArray.at(index) as FormGroup;

    // Reset the selected label and tds_code for that row
    rowGroup.patchValue({
      tds_code: '',
      selectedTdsSectionLabel: '',
    });

    // Mark as touched for validation
    rowGroup.get('tds_code')?.markAsTouched();
  }


  // clearSelectionInput(event: Event) {
  //   event.stopPropagation(); // Prevent dropdown toggle
  //   this.selectedTdsSectionLabel = 'Select';
  //   this.selectedTdsSectionValue = null;
  //   this.fifteenghForm.patchValue({
  //     tds_code: '',
  //   });
  //   this.fifteenghForm.get('tds_code')?.markAsTouched();
  // }


  // helper to get quarter start and end date
  private getQuarterDateRange(quarterNo: number, fyStartYear: number) {
    let start: Date, end: Date;
    switch (quarterNo) {
      case 1:
        start = new Date(fyStartYear, 3, 1); // Apr 1
        end = new Date(fyStartYear, 5, 30); // Jun 30
        break;
      case 2:
        start = new Date(fyStartYear, 6, 1); // Jul 1
        end = new Date(fyStartYear, 8, 30); // Sep 30
        break;
      case 3:
        start = new Date(fyStartYear, 9, 1); // Oct 1
        end = new Date(fyStartYear + 1, 11, 31); // Dec 31
        break;
      case 4:
        start = new Date(fyStartYear + 1, 0, 1); // Jan 1
        end = new Date(fyStartYear + 1, 2, 31); // Mar 31
        break;
      default:
        start = new Date(fyStartYear, 3, 1);
        end = new Date(fyStartYear, 5, 30);
    }
    return { start, end };
  }


  private setQuarterDateRestrictions(): void {
    console.log('calender');
    // Get current quarter
    const currentQuarter = this.dynamicUserData?.default_quarter_no || 1;

    // Parse fiscal year
    const fyString = this.dynamicUserData?.default_acc_year || '24-25';
    // console.log(fyString);
    const fyStartYear = 2000 + parseInt(fyString.split('-')[0], 10);
    const fyEndYear = 2000 + parseInt(fyString.split('-')[1], 10);

    // Financial Year Start: 1-Apr-FYStart
    const fyStart = new Date(fyStartYear, 3, 1); // Apr 1
    this.fyStartDate = this.formatDateForInput(fyStart);


    // Get quarter start/end
    const { start, end } = this.getQuarterDateRange(currentQuarter, fyStartYear);
    this.quarterStartDate = this.formatDateForInput(start);
    console.log(this.quarterStartDate);
    this.quarterEndDate = this.formatDateForInput(end);

    // Max Date is today or quarter end (whichever is earlier)
    const today = new Date();
    const maxDateObj = today < end ? today : end;
    this.maxDate = this.formatDateForInput(maxDateObj);
       console.log(this.maxDate);

    // Set validators
    this.setDateValidators();
  }

  // Get current quarter based on today's date
  private getCurrentQuarter(): number {
    const today = new Date();
    const month = today.getMonth();

    if (month >= 3 && month <= 5) return 1;  // Apr-Jun
    if (month >= 6 && month <= 8) return 2;  // Jul-Sep
    if (month >= 9 && month <= 11) return 3; // Oct-Dec
    return 4; // Jan-Mar
  }

  // Format date for HTML date input
  // private formatDateForInput(date: Date): string {
  //   const year = date.getFullYear();
  //   const month = String(date.getMonth() + 1).padStart(2, '0');
  //   const day = String(date.getDate()).padStart(2, '0');
  //   return `${year}-${month}-${day}`;
  // }
  private formatDateForInput(date: Date): string {
    const yyyy = date.getFullYear();
    const mm = ('0' + (date.getMonth() + 1)).slice(-2);
    const dd = ('0' + date.getDate()).slice(-2);
    return `${yyyy}-${mm}-${dd}`;
  }

  // Set date validators for transaction and TDS deduction dates
  private setDateValidators(): void {
    const tranRefDateControl = this.fifteenghForm.get('tran_ref_date');
    const tdsDeductDateControl = this.fifteenghForm.get('tds_deduct_date');

    const tranRefDateValidator = (control: any) => {
      if (!control.value) return null;

      // Normalize both to local midnight (ignore time zone differences)
      const normalizeDate = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

      const selectedDate = normalizeDate(new Date(control.value));
      const fyStartDate = normalizeDate(new Date(this.fyStartDate));
      const maxDate = normalizeDate(new Date(this.maxDate));

      if (selectedDate < fyStartDate) return { beforeFYStart: true };
      if (selectedDate > maxDate) return { afterMaxDate: true };
      return null;
    };

    const tdsQuarterValidator = (control: any) => {
      if (!control.value) return null;

      const normalizeDate = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

      const selectedDate = normalizeDate(new Date(control.value));
      const quarterStart = normalizeDate(new Date(this.quarterStartDate));
      const maxDate = normalizeDate(new Date(this.maxDate));

      if (selectedDate < quarterStart) return { beforeQuarterStart: true };
      if (selectedDate > maxDate) return { afterMaxDate: true };
      return null;
    };


    tranRefDateControl?.setValidators([Validators.required, tranRefDateValidator]);
    tdsDeductDateControl?.setValidators([tdsQuarterValidator]);

    tranRefDateControl?.updateValueAndValidity();
    tdsDeductDateControl?.updateValueAndValidity();
  }


  // helper to parse dd-MMM-yyyy into Date
  private parseDdMmYyyy(dateStr: string): Date {
    const [day, mon, year] = dateStr.split('-');

    const months: { [key: string]: number } = {
      JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
      JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11
    };

    const monthIndex = months[mon.toUpperCase()] ?? -1; // fallback if not found
    return new Date(parseInt(year, 10), monthIndex, parseInt(day, 10));
  }


  // Helper method to get all form validation errors
  getFormValidationErrors() {
    const errors: any = {};
    const invalidFieldsDetails: any[] = [];

    Object.keys(this.fifteenghForm.controls).forEach(key => {
      const control = this.fifteenghForm.get(key);
      if (control && control.errors) {
        errors[key] = control.errors;
        invalidFieldsDetails.push({
          field: key,
          value: control.value,
          errors: control.errors
        });
      }
    });

    return { errors, invalidFieldsDetails };
  }


  private cleanDeducteeName(rawName: any): { name: string; verifiedStatus: string } {
    let cleanedName = '';
    let verifiedStatus = '';

    if (!rawName) {
      return { name: '', verifiedStatus: '' };
    }

    // Normalize input type
    if (typeof rawName === 'string') {
      cleanedName = rawName;
    } else if (Array.isArray(rawName)) {
      cleanedName = rawName.join(', ');
    } else if (typeof rawName === 'object') {
      cleanedName = rawName.label ?? JSON.stringify(rawName);
    } else {
      cleanedName = String(rawName);
    }

    cleanedName = cleanedName.trim();

    // Extract value if JSON-like structure with "label"
    const matchLabel = /"label"\s*:\s*"([^"]+)"/.exec(cleanedName);
    if (matchLabel) {
      cleanedName = matchLabel[1];
    }

    // ✅ Extract trailing ,Y or ,N or ,I or ,X (verification flag)
    const match = cleanedName.match(/,\s*([YyNnIiXx])$/);
    if (match) {
      verifiedStatus = match[1].toUpperCase(); // Store Y/N/I/X
      cleanedName = cleanedName.slice(0, match.index).trim(); // Remove suffix
    }

    // Remove unwanted brackets or quotes
    cleanedName = cleanedName.replace(/[\[\]{}"]/g, '').trim();

    return { name: cleanedName || '', verifiedStatus };
  }



  panDataDetails: any;
  panNo: any;
  panErrorMessage: string = '';
  pannoVerified: string | null = null;

  private clearPanDependentFields() {
    // this.fifteenghForm.patchValue({
    //   deductee_name: '',
    // });
    this.panValidationStatus = {
      isValid: null,
      message: ''
    };
  }

  deducteeName: any;
  // Fetch PAN master data from API
  private fetchPanMasterData(panNumber: string) {
    if (!panNumber || panNumber.length !== 10) return;

    // Clear previously filled dependent fields before fetching new PAN data
    this.clearPanDependentFields();

    this.isLoadingPanData = true;
    this.panNo = panNumber;

    this.authservice.getPanMasterData(panNumber).subscribe({
      next: (response) => {

        if (response?.body?.status === 1 && response?.body?.result) {
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          console.log(this.deductee_panno_status);

          // Handle validation status
          const isValid = panData.deductee_panno_valid === 'Y';
          this.panValidationStatus = {
            isValid: isValid,
            message: isValid ? 'Valid PAN' : 'Invalid PAN'
          };

          if (panData.deductee_name) {
            // console.log('PAN API deductee_name raw:', panData.deductee_name);
            const { name, verifiedStatus } = this.cleanDeducteeName(panData.deductee_name);
            this.deducteeName = this.cleanDeducteeName(panData.deductee_name).name;

            // this.fifteenghForm.patchValue({ deductee_name: name });
            this.pannoVerified = verifiedStatus; // ✅ update flag for UI
            // console.log('Cleaned Deductee Name:', name, ' | Status:', verifiedStatus);
          } else {
            console.warn('No deductee_name found in PAN data.');
            this.pannoVerified = '';
          }

          this.isLoadingPanData = false;

          if (isValid && this.isEditMode && !this.selectedRowId && this.deducteeName != '') {
            this.toastService.showSuccess('Valid PAN - Details fetched successfully');
          } else if (!isValid) {
            this.toastService.showError('PAN found but marked as invalid');
          }

        }
        else if (response?.body?.status === 0) {
          this.isLoadingPanData = true;
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          // console.log(this.deductee_panno_status);
          this.pannoVerified = 'N'

          this.authservice.getPanValidationData(panNumber).subscribe({
            next: (validationResponse) => {
              const result = validationResponse?.body;
              this.isLoadingPanData = true;

              if (result?.code == 0) {

                const panData = result.data;
                const parsePanData = JSON.parse(panData);
                this.panDataDetails = parsePanData.data[0];

                if (panData) {

                  const requestBody = {

                    a_session_seqno: "",
                    a_iud_seqno: "",
                    a_is_pen_flag: "",
                    a_login_type: "login_id",
                    a_module_type_code: this.dynamicUserData?.default_module_type_code,
                    a_sub_module_type_code: "R",
                    a_user_code: this.UserData.user_code,
                    a_entity_code: this.dynamicUserData.entity_code,
                    a_client_code: this.dynamicUserData.client_code,
                    a_acc_year: this.dynamicUserData.default_acc_year,
                    a_quarter_no: this.dynamicUserData.default_quarter_no,
                    a_tran_month: this.dynamicUserData.default_tran_month,
                    a_validation_client_level: this.dynamicUserData.client_code_level,
                    a_tran_from_date: this.dynamicUserData.default_from_date,
                    a_tran_to_date: this.dynamicUserData.default_to_date,
                    a_tds_type_code: this.dynamicUserData.default_tds_type_code,
                    a_first_level_client_code: this.dynamicUserData.first_level_client_code,
                    a_client_code_level: this.dynamicUserData.client_code_level,
                    a_user_level: this.dynamicUserData.user_level,
                    a_proc_error: "0",
                    a_db_total_records: '1000',
                    a_pagination_count: '0',
                    a_proc_type: 'get_miud_pan_mast',
                    a_process_seqno: "",
                    a_iud_type: "i",
                    a_process_status_code: "ZA",
                    pan_mast: {
                      panno: this.panDataDetails?.pan,
                      first_name: this.panDataDetails?.panName,
                      pan_allot_date: this.formatDate(this.panDataDetails?.panAlotmentDate),
                      pan_aadhar_status: this.panDataDetails?.panAadhaarLinkStatus,
                      ab206_status: "",
                      n194_status: "",
                      verifiedby_flag: ""
                    }

                  };
                  this.apiservice
                    .miudApi('/Dashboard/get_miud_pan_mast', requestBody)
                    .subscribe({
                      next: (response) => {

                        if (response.result[0].a_proc_error == 0) {

                          this.toastService.showSuccess(response.result[0].a_proc_error_message);
                          const upperVal = this.panNo.toUpperCase();
                          this.fetchPanMasterData(upperVal);
                        }
                        else {
                          this.toastService.showError(response.result[0].a_proc_error_message);
                          this.isLoadingPanData = true;
                        }
                      }
                    });

                }

              } else {
                const panerrorData = JSON.parse(result.data)?.errdata;
                this.isLoadingPanData = false;
                this.panErrorMessage = panerrorData?.errorMessage;

                this.toastService.showError('PAN not found in validation data');
              }
            },
            error: (error) => {
              console.error('Error fetching PAN validation data:', error);

              // Extract meaningful message safely
              const errorMessage =
                error?.error?.message ||
                error?.message ||
                'Something went wrong. Please try again.';

              // Show toast with extracted message
              // this.showError(errorMessage);
            }
          });
        }

        else {

          // Set status as unknown when no data found
          this.panValidationStatus = {
            isValid: null,
            message: 'PAN not found in master data'
          };
        }
        this.isLoadingPanData = false;
      },
      error: (error) => {
        this.isLoadingPanData = false;
        console.error('Error fetching PAN master data:', error);

        // Don't show error message as PAN API failure shouldn't block the form
      }
    });
  }


  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }


  onCloseDrawer() {
    this.showCertificatePopup = false;
  }

  errorMessage: string = '';

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  toggleEditMode() {
    this.isEditMode = !this.isEditMode;
  }

  private panManuallyChanged = false;
  roleArrayData: any[] = [];

  fetchUserDetails(roleCode: string) {
    this.detailsLoader = true;
    const requestBody = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: this.dynamicUserData.default_sub_module_type_code,
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: 'get_gmdt_deductee_mast_15gh',
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/Comman/dynamic', requestBody)
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_gmdt_deductee_mast_15gh
              ?.get_gmdt_deductee_mast_15gh_detail?.[0];
          this.roleData = roleData;

          const roleArrayData =
            response?.result?.get_gmdt_deductee_mast_15gh
              ?.get_gmdt_deductee_mast_15gh_tran_detail;
          this.roleArrayData = roleArrayData;
          console.log(this.roleArrayData)

          if (!roleData) {
            this.showError('No user data found.');
            return;
          }

          this.detailsLoader = false;


          this.fifteenghForm.patchValue(
            {

              deductee_name: roleData.deductee_name || '',
              deductee_panno: roleData.deductee_panno || '',
              cust_id: roleData.cust_id || '',
              deduction_ref_no: roleData.deduction_ref_no || '',
              resident_status: roleData.resident_status || '',

              gh15_flag: roleData.gh15_flag || '',
              pan_status: roleData.pan_status || '',
              certificate_no: roleData.certificate_no || '',
              dob: roleData.dob || '',
              assessed_tax_flag: roleData.assessed_tax_flag || '',
              est_declaration_income: roleData.est_declaration_income || '',
              latest_assessment_year: roleData.latest_assessment_year || '',
              est_total_income: roleData.est_total_income || '',

              total_no_form: roleData.total_no_form || '',
              // formArray: this.fb.array([]),
              income_amount_paid: roleData.income_amount_paid || '',
              aggregate_income_amt: roleData.aggregate_income_amt || '',
              declaration_date: roleData.declaration_date || '',
              income_paid_date: roleData.income_paid_date || '',

              add1: roleData.add1 || '',
              add2: roleData.add2 || '',
              add3: roleData.add3 || '',
              add4: roleData.add4 || '',
              city: roleData.city || '',
              state_code: roleData.state_code || '',
              pin: roleData.pin || '',
              // regex applied dynamically
              email_id: roleData.email_id || '',
              stdcode: roleData.stdcode || '',
              mobileno: roleData.mobileno || '',
              phoneno: roleData.phoneno || '',

            },
            { emitEvent: true } // ensures valueChanges is triggered
          );

        
          if (this.roleArrayData?.length > 0) {

            // Step 1: Clear existing FormArray
            const formArray = this.fifteenghForm.get('formArray') as FormArray;
            formArray.clear();


            // Step 2: Patch data dynamically from roleArrayData
            this.roleArrayData.forEach(item => {

              const matchedTds = this.tdsSectionOptions.find(
                t => t.value === item.tds_code
              );

            

              const row = this.fb.group({
                account_no: [item.account_no || ''],
                gh15_amount: [item.gh15_amt || ''],
                tds_code: [item.tds_code || ''],
                selectedTdsSectionLabel: [matchedTds ? matchedTds.label : ''], // if you want to set label later based on tds_code
                searchTdsSection: ['']
              });

              this.formArray.push(row);
            });
          }

          // Update labels
          this.updateDisplayLabels(roleData);

        },
        error: () => {
          this.showError('Failed to fetch User details.');
          this.detailsLoader = false;
        },
      });


  }

  private subscribeToPanValueChanges() {
    const panControl = this.fifteenghForm.get('deductee_panno');
    if (!panControl) return;

    panControl.valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((val: string) => {
        if (!val) {
          this.panValidationStatus = { isValid: null, message: '' };
          return;
        }
        if (val) {
          const upperVal = val.toUpperCase();
          if (upperVal !== val) {
            panControl.setValue(upperVal, { emitEvent: false });
          }

          const isValid = this.roleData?.deductee_panno_valid === 'Y';
          this.panValidationStatus = {
            isValid,
            message: isValid ? 'Valid PAN' : 'Invalid PAN',
          };

          if (upperVal.length < 10) {
            this.panValidationStatus = {
              isValid: null,
              message: ''
            };

            this.resetFormOnPanEdit();
            return;
          }

          if (upperVal.length === 10 && (this.panManuallyChanged || !this.selectedRowId) && this.isEditMode && !this.fifteenghForm.get('deductee_panno')?.hasError('pattern')) {
            // console.log('onpan');
            this.autoDetectPanStatusFromPAN();
            this.fetchPanMasterData(upperVal);

          }

        }
        else {
          // If cleared completely, reset the form
          this.resetFormOnPanEdit();
        }
      });

  }



  private autoDetectPanStatusFromPAN(): void {

    const panno = this.fifteenghForm.get('deductee_panno')?.value;
    console.log(panno)
    if (panno && panno.length >= 4 && this.panStatusMastData) {
      const panChar = panno.charAt(3).toUpperCase();
      console.log(panChar)
      const matchedPanStatus = this.panStatusMastData.find(
        (opt: any) => opt.pan_card_type?.toUpperCase() === panChar
      );
      console.log(matchedPanStatus)

      if (matchedPanStatus) {
        this.fifteenghForm.patchValue({
          pan_status: matchedPanStatus.status_code_15g

        });
        console.log(this.fifteenghForm.value)
        // ✅ Also update the display label
        this.selectedPanStatusLabel = matchedPanStatus.label || matchedPanStatus.pan_card_type;
        this.selectedPanStatusValue = matchedPanStatus.status_code_15g;

        console.log('Patched PAN status:', this.fifteenghForm.value);
      }
    }
  }

  // Utility: Convert any date string/Date to yyyy-MM-dd
  private formatRoleDateForInput(date: any): string | null {
    if (!date) return null;
    const d = new Date(date);
    if (isNaN(d.getTime())) return null; // invalid date safeguard
    return d.toISOString().split('T')[0]; // gives yyyy-MM-dd
  }

  // Helper to update labels after patch
  private updateDisplayLabels(roleData: any) {

    if (roleData?.tds_code) {
      console.log(roleData?.tds_code)
      const tdsOption = this.tdsSectionOptions.find(o => o.value === roleData.tds_code);
      this.selectedTdsSectionLabel = tdsOption ? tdsOption.label : '';
      this.selectedTdsSectionValue = roleData.tds_code;
    }

    if (roleData?.resident_status) {
      const residentOption = this.residentStatusMastData.find((o: any) => o.value === roleData.resident_status);
      this.selectedResidentStatusLabel = residentOption ? residentOption.label : '';
      this.selectedResidentStatusValue = roleData.resident_status;
    }
    if (roleData?.gh15_flag) {
      const gh15Option = this.gh15FlagMastData.find((o: any) => o.value === roleData.gh15_flag);
      this.selected15ghFlagLabel = gh15Option ? gh15Option.label : '';
      this.selected15ghFlagValue = roleData.gh15_flag;
    }
    if (roleData?.pan_status) {
      const panStatusOption = this.panStatusMastData.find((o: any) => o.value === roleData.pan_status);
      this.selectedPanStatusLabel = panStatusOption ? panStatusOption.label : '';
      this.selectedPanStatusValue = roleData.pan_status;
    }
    if (roleData?.latest_assessment_year) {
      const accYearOption = this.accYearMastData.find((o: any) => o.value === roleData.latest_assessment_year);
      this.selectedaccYearLabel = accYearOption ? accYearOption.label : '';
      this.selectedaccYearValue = roleData.latest_assessment_year;
    }
    if (roleData?.assessed_tax_flag) {
      const assesseTaxFlagOption = this.assesseTaxFlagMastData.find((o: any) => o.value === roleData.assessed_tax_flag);
      this.selectedassesseTaxFlagLabel = assesseTaxFlagOption ? assesseTaxFlagOption.label : '';
      this.selectedassesseTaxFlagValue = roleData.assessed_tax_flag;
    }
    if (roleData?.state_code) {
      const stateOption = this.stateMastOptions.find((o: any) => o.value === roleData.state_code);
      this.selectedStateOptionLabel = stateOption ? stateOption.label : '';
      this.selectedStateOptionValue = roleData.state_code;
    }

  }


  isDelete: boolean = false;
  isDeletePopupOpen = false;
  deleteFlag:any;

  deleteSingleDetails() {
    this.isDeletePopupOpen = false;
    this.isDelete = true;
    this.deleteFlag = 'Y';
    this.onSubmit();
  }

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false;
      this.detailsLoader =true;

  }
  deleteSingleDetailsCancel() {
    this.isDelete = false;
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
  }

  isSubmittingUpdateLoader: boolean = false;

  onSubmit() {

    this.isSubmittingUpdateLoader = true;
    if (this.fifteenghForm.invalid) {
      this.isSubmittingUpdateLoader = false;
      // Get detailed error information
      this.fifteenghForm.markAllAsTouched();
      const validationInfo = this.getFormValidationErrors();
      const invalidFields: string[] = [];

      Object.keys(this.fifteenghForm.controls).forEach(key => {
        const control = this.fifteenghForm.get(key);
        if (control && control.invalid) {
          invalidFields.push(key);
        }
      });

      // Create a more detailed error message
      let errorMessage = `Please fill the following required fields: ${invalidFields.slice(0, 5).join(', ')}`;
      if (invalidFields.length > 5) {
        errorMessage += ` and ${invalidFields.length - 5} more...`;
      }

      this.toastService.showError(errorMessage);
      return;
    }

    const formData = this.fifteenghForm.value;
    console.log(formData)

    const qData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_miud_deductee_mast_15gh",
      a_process_seqno: "",
      a_iud_type: this.isDelete && this.selectedRowId ? 'd' : this.selectedRowId ? 'u' : 'i',
      a_process_status_code: "ZA",
      a_db_total_records: "1000",
      a_pagination_count: "0",

      deductee_mast_15gh: {
        rowid_seq: this.selectedRowId ? this.roleData.rowid_seq : '',
        cust_id: this.sanitizeValue(formData.cust_id, true),
        deductee_panno: this.sanitizeValue(formData.deductee_panno, true),
        deductee_panno_valid: this.selectedRowId ? this.roleData.deductee_panno_valid : this.sanitizeValue(this.deductee_panno_status),
        deductee_panno_verified: this.selectedRowId ? this.roleData.deductee_panno_verified : this.sanitizeValue(this.pannoVerified),
        deductee_name: this.sanitizeValue(formData.deductee_name, true),
        deduction_ref_no: this.sanitizeValue(formData.deduction_ref_no, true),

        gh15_flag: this.sanitizeValue(formData.gh15_flag, true),
        certificate_no: this.sanitizeValue(formData.certificate_no, true),
        dob: formatDatesend(formData.dob),
        add1: this.sanitizeValue(formData.add1, true),
        add2: this.sanitizeValue(formData.add2, true),
        add3: this.sanitizeValue(formData.add3, true),
        add4: this.sanitizeValue(formData.add4, true),
        city: this.sanitizeValue(formData.city, true),
        pin: this.sanitizeValue(formData.pin),
        state_code: this.sanitizeValue(formData.state_code),
        stdcode: this.sanitizeValue(formData.stdcode),
        phoneno: this.sanitizeValue(formData.phoneno),
        mobileno: this.sanitizeValue(formData.mobileno),
        email_id: this.sanitizeValue(formData.email_id, true),
        income_status: "",
        resident_status: this.sanitizeValue(formData.resident_status),
        assessed_tax_flag: this.sanitizeValue(formData.assessed_tax_flag),
        latest_assessment_year: this.sanitizeValue(formData.latest_assessment_year),
        est_declaration_income: this.sanitizeValue(formData.est_declaration_income),
        est_total_income: this.sanitizeValue(formData.est_total_income),
        total_no_form: this.sanitizeValue(formData.total_no_form),
        aggregate_income_amt: this.sanitizeValue(formData.aggregate_income_amt),
        declaration_date: formatDatesend(formData.declaration_date),
        income_amount_paid: this.sanitizeValue(formData.income_amount_paid),
        income_paid_date: formatDatesend(formData.income_paid_date),
        pan_status: this.sanitizeValue(formData.pan_status),
        approvedby: "",
        approveddate: ""

      },
      deductee_tran_15gh: formData.formArray.map((row: any) => ({
        rowid_seq: this.selectedRowId ? this.roleData.rowid_seq : '',
        entity_code: this.dynamicUserData.entity_code,
        client_code: this.dynamicUserData.client_code,
        acc_year: this.dynamicUserData.default_acc_year,
        quarter_no: this.dynamicUserData.default_quarter_no,
        tran_month: this.dynamicUserData.default_tran_month,
        tran_from_date: this.dynamicUserData.default_from_date,
        tran_to_date: this.dynamicUserData.default_to_date,
        tds_type_code: this.dynamicUserData.default_tds_type_code,
        deductee_panno: this.sanitizeValue(formData.deductee_panno, true),
        certificate_no: this.sanitizeValue(formData.certificate_no, true),
        account_no: this.sanitizeValue(row.account_no, true),
        gh15_amt: this.sanitizeValue(row.gh15_amount),
        tds_code: row.tds_code,
        nature_of_income: null,
        bank_branch_code: this.dynamicUserData.bank_branch_code,
        deductee_mast_15gh_rowid_seq: this.selectedRowId ? this.roleData.deductee_mast_15gh_rowid_seq : '',
        approvedby: null,
        approveddate: null,
        deductee_tran_15gh_del_flag: this.isDelete? this.deleteFlag:'',
      }))
    };

    this.apiservice
      .miudApi('/Comman/dynamic', qData).subscribe({
        next: (response: any) => {
          // Stabilize getters before any modifications to avoid ExpressionChangedAfterItHasBeenCheckedError
          this.cdr.detectChanges();

          if (response?.result[0]?.a_proc_error == 0) {
            this.isSubmittingUpdateLoader = false;
            this.toastService.showSuccess(response?.result[0]?.a_proc_error_message || (this.selectedRowId ? '15GH Transaction Updated Successfully!' : '15GH Transaction Added Successfully!')
            );

            this.close.emit();
            this.refreshdata.trigerRefresh('gh15');
               this.detailsLoader = false;
          }
          else {
            this.isSubmittingUpdateLoader = false;
                this.detailsLoader = false;
            const result = response?.result?.[0];

            if (result?.a_errors && Array.isArray(result.a_errors) && result.a_errors.length > 0) {
              const errors = result.a_errors;
              const errorSections = new Set<string>();

              // Reset previous server errors
              this.serverErrors = {};

              // Iterate over backend errors
              errors.forEach((error: { field: string; message: string }) => {
                const backendField = error.field;
                const mappedField = this.fieldMap[backendField] || backendField;
                const control = this.fifteenghForm.get(mappedField);

                // Track which section the field belongs to
                const section = this.sectionFieldMap[mappedField];
                if (section) errorSections.add(section);
                // Store the error message for this field
                this.serverErrors[mappedField] = error.message;

                // console.log(this.serverErrors[mappedField]);

                // Set the error on the form control
                if (control) {
                  const existingErrors = control.errors || {};
                  control.setErrors({ ...existingErrors, serverError: error.message });
                  control.markAsTouched();
                  control.markAsDirty();
                }
              });

              // Open the first section with errors
              if (errorSections.size > 0) {
                const sectionPriority = ['deductee', 'deducteeAddress', 'income', 'other'];
                const firstErrorSection = sectionPriority.find(section => errorSections.has(section));
                if (firstErrorSection) this.activeSection = firstErrorSection;
              }

              // Do NOT show a_proc_error_message if a_errors exist
            } else {
              this.isSubmittingUpdateLoader = false;
                  this.detailsLoader = false;
              // Show global error if no field errors
              this.toastService.showError(result?.a_proc_error_message || 'Failed to add Transaction');
            }
          }


        },
        error: (error: any) => {
          console.error(error);
          this.isSubmittingUpdateLoader = false;
              this.detailsLoader = false;
        },
      });

  }

  // handleInput(controlName: string) {
  //   // Clear server error when user starts typing
  //   if (this.serverErrors[controlName]) {
  //     delete this.serverErrors[controlName];
  //   }
  // }
  handleInput(field: string) {
    if (this.serverErrors[field]) {
      this.serverErrors[field] = '';
      this.fifteenghForm.get(field)?.setErrors(null);
    }
  }


  // Helper method to check if field has errors (client or server)
  hasFieldError(fieldName: string): boolean {
    const control = this.fifteenghForm.get(fieldName);
    return (control?.touched && control?.invalid) || !!this.serverErrors[fieldName];
  }

  // Helper method to get error message for a field
  getFieldErrorMessage(fieldName: string): string | null {
    return this.serverErrors[fieldName] || null;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  get isdeducteeDetailsComplete(): boolean {
    // List of only required fields for Deductee Details
    const requiredFields = [
      'deductee_name',
      'deductee_panno',
      'resident_status',
    ];

    // Ensure each required field exists, is valid, and not empty
    return requiredFields.every(field => {
      const control = this.fifteenghForm.get(field);
      return control && control.valid && control.value !== null && control.value !== '';
    });
  }

  get isdeducteeAddressComplete(): boolean {
    // check all required text fields
    const requiredFields = [
      'add1', 'add4', 'pin', 'city', 'state_code', 'email_id', 'mobileno','stdcode' ,'phoneno'
    ];

    return requiredFields.every(field => {
      const control = this.fifteenghForm.get(field);
      return control && control.valid && control.value !== null && control.value !== '';
    });
  }

  // get isincomeDetailsComplete(): boolean {
  //   // check all required text fields
  //   const requiredFields = [
  //    'gh15_flag', 'certificate_no', 'pan_status','assessed_tax_flag','est_total_income','est_declaration_income','total_no_form','declaration_date','income_amount_paid','income_paid_date'
  //   ];

  //   return requiredFields.every(field => {
  //     const control = this.fifteenghForm.get(field);
  //     return control && control.valid && control.value !== null && control.value !== '';
  //   });
  // }

  get isincomeDetailsComplete(): boolean {
    const requiredFields = [
      'gh15_flag',
      'certificate_no',
      'pan_status',
      'assessed_tax_flag',
      'est_total_income',
      'est_declaration_income',
      'total_no_form',
      'declaration_date',
      'income_amount_paid',
      'income_paid_date'
    ];

    const missingFields: string[] = [];

    requiredFields.forEach(field => {
      const control = this.fifteenghForm.get(field);

      if (!control) {
        missingFields.push(field);
        return;
      }

      const value = control.value;

      // Log invalid or empty
      if (
        !control.valid ||
        value === null ||
        value === undefined ||
        String(value).trim() === ''
      ) {

        missingFields.push(field);
      } else {

      }
    });

    if (missingFields.length > 0) {

      return false;
    }

    return true;
  }

  get isOtherDetailsComplte(): boolean {
    const formArray = this.fifteenghForm.get('formArray') as FormArray;
    if (!formArray || formArray.length === 0) return false;

    // Check each row's required controls
    return formArray.controls.every((group) =>
      group.get('account_no')?.valid &&
      group.get('gh15_amount')?.valid &&
      group.get('tds_code')?.valid
    );
  }

  onSaveNextOtherSection() {
    const formArray = this.fifteenghForm.get('formArray') as FormArray;

    // Mark all controls as touched to ensure validation messages show if incomplete
    formArray.controls.forEach((group) => group.markAllAsTouched());

    if (this.isOtherDetailsComplte) {
      // Optional: trigger any save logic if needed
      this.onButtonNext('', 'other');

      // Collapse section & show summary
      this.activeSection = ''; // collapse form
      this.completedSections.push('other'); // mark as completed
    }
  }


  isCompleted = false;
  istransactionCompleted = false;

  // Field to section mapping for error handling
  sectionFieldMap: { [key: string]: string } = {
    // Deductee Details section

    'deductee_name': 'deductee',
    'deductee_panno': 'deductee',
    'cust_id': 'deductee',
    'deduction_ref_no': 'deductee',
    'resident_status': 'deductee',

    // Deductee Address Section

    'add1': 'deducteeAddress',
    'add2': 'deducteeAddress',
    'add3': 'deducteeAddress',
    'add4': 'deducteeAddress',
    'city': 'deducteeAddress',
    'state_code': 'deducteeAddress',
    'pin': 'deducteeAddress',
    'email_id': 'deducteeAddress',
    'stdcode': 'deducteeAddress',
    'mobileno': 'deducteeAddress',
    'phoneno': 'deducteeAddress',


    // Income Details section
    'gh15_flag': 'income',
    'pan_status': 'income',
    'certificate_no': 'income',
    'dob': 'income',
    'assessed_tax_flag': 'income',
    'est_declaration_income': 'income',
    'latest_assessment_year': 'income',
    'est_total_income': 'income',
    'total_no_form': 'income',
    'income_amount_paid': 'income',
    'aggregate_income_amt': 'income',
    'declaration_date': 'income',
    'income_paid_date': 'income',

    // Other Details section
    'formArray': 'other',
  };

  onSaveAndNext() {

    if (!this.isCompleted && this.isdeducteeDetailsComplete) {
      this.isCompleted = true;
      this.activeSection = 'deducteeAddress';
      if (!this.completedSections.includes('deductee')) {
        this.completedSections.push('deductee');
      }
      return;
    }
    if (this.isdeducteeAddressComplete) {
      // this.isCompleted = true;
      this.activeSection = 'income';
      if (!this.completedSections.includes('deducteeAddress')) {
        this.completedSections.push('deducteeAddress');
      }
      return;
    }
    if (this.isincomeDetailsComplete) {
      // this.isCompleted = true;
      this.activeSection = 'other';
      if (!this.completedSections.includes('income')) {
        this.completedSections.push('income');
      }
      return;
    }

    if (!this.isincomeDetailsComplete && this.isdeducteeAddressComplete && this.isdeducteeDetailsComplete) {
      // this.istransactionCompleted = true;
      this.activeSection = 'other';
      // Also mark 'other' as completed if form data exists
      if (!this.completedSections.includes('other')) {
        this.completedSections.push('other');
      }
      return;
    }


  }


  amountGreaterThanZeroValidator() {
    return (control: any) => {
      const value = parseFloat(control.value);
      if (isNaN(value) || value <= 0) {
        return { greaterThanZero: true };
      }
      return null;
    };
  }
  // allowNumbersOnly(event: KeyboardEvent) {
  //   const charCode = event.key.charCodeAt(0);
  //   if (charCode < 48 || charCode > 57) {
  //     event.preventDefault();
  //   }
  // }

  allowNumbersOnly(event: KeyboardEvent) {
    const allowedKeys = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', 'Backspace', 'ArrowLeft', 'ArrowRight', 'Delete', 'Tab'];

    if (!allowedKeys.includes(event.key)) {
      event.preventDefault();
    }

    // prevent multiple decimals
    const input = event.target as HTMLInputElement;
    if (event.key === '.' && input.value.includes('.')) {
      event.preventDefault();
    }
  }

  showPopup = false;

  togglePopup() {
    this.showPopup = !this.showPopup;
  }

  handleTabCloseCalendar(event: KeyboardEvent) {
    if (event.key === 'Tab') {
      this.datePicker?.closeSingleCalender(); // 👈 call child's close function
    }
  }

  onCalendarClosed() {
    // console.log('Calendar closed'); 
    // Optional: perform any additional UI logic here
  }

  pinCode: any;

  async getPinCodeData(pincode: string) {
    const qData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_gmdt_pin_code_mast",
      a_process_seqno: "",

      a_in_parameter_json: [
        {
          a_entity_code: this.dynamicUserData.entity_code,
          a_rowid_seq: pincode
        }
      ]
    };

    // const parseRequestData = {
    //   sdata: JSON.stringify(qData),
    // };

    await this.apiservice
      .pinCodeApi('/ClientMast/get_gmdt_pin_code_mast', qData).subscribe({
        next: (response: any) => {

          this.pinCode =
            response?.result?.get_gmdt_pin_code_mast.get_gmdt_pin_code_mast_detail || [];

          if (this.pinCode.length > 0) {
            const stateCode = this.pinCode[0].state_code;
            const cityName = this.pinCode[0].post_office_name;

            const matchedState = this.stateMastOptions?.find(
              (opt: any) => opt.state_Code == stateCode
            );


            if (matchedState) {

              if (this.pinCode.length > 0) {
                const stateCode = this.pinCode[0].state_code;

                const matchedState = this.stateMastOptions.find(
                  (opt: any) => opt.state_Code == stateCode
                );

                if (matchedState) {

                  // Keep full list
                  this.filteredStateOptions = [...this.stateMastOptions];

                  // Select the matched state
                  this.selectStateOption(matchedState);
                  this.fifteenghForm.patchValue({
                    state_code: matchedState.value,
                    city: cityName,

                  });

                  this.selectedStateOptionLabel = matchedState.label;

                }
              }

            }
          }

        },
        error: (error: any) => {
          console.error(error);
        },
      });
  }


  searchText = '';

  searchStateCode() {
    this.filteredStateOptions = this.stateMastOptions.filter((s: { label: string }) =>
      s.label.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  showStateOption: boolean = false;
  selectStateOption(option: any) {
    if (!option) return;

    this.selectedStateOptionLabel = option.label;
    this.selectedStateOptionValue = option.value;
    this.fifteenghForm.get('state_code')?.setValue(option.value);

    // ✅ close the dropdown after selection
    this.showStateOption = false;
    this.searchText = '';
    this.filteredStateOptions = [...(this.stateMastOptions || [])];
  }

  clearstatateInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedStateOptionLabel = 'Select';
    this.selectedStateOptionValue = null;
    this.fifteenghForm.patchValue({
      state_code: '',
    });
    this.fifteenghForm.get('state_code')?.markAsTouched();

  }

  get formArray(): FormArray {
    return this.fifteenghForm.get('formArray') as FormArray;
  }

  private adjustFormArray(val: number): void {
    const total = Number(val) || 0;
    const current = this.formArray.length;

    // if (total > current) {
    //   for (let i = current; i < total; i++) {
    //     this.formArray.push(this.createFormRow());
    //   }
    // }
    if (total > current) {
      for (let i = current; i < total; i++) {
        this.formArray.push(this.createFormRow());
        this.filteredTdsSectionOptions[i] = [...this.tdsSectionOptions]; // Copy
      }
    }
    else if (total < current) {
      for (let i = current - 1; i >= total; i--) {
        this.formArray.removeAt(i);
        this.filteredTdsSectionOptions.splice(i, 1);
      }
    }
  }

  // 1) row factory - use this everywhere so each row is identical
  private createFormRow(): FormGroup {
    return this.fb.group({
      // account_no: ['', Validators.required],
       account_no: [
      '',
      [
        Validators.required,
        Validators.maxLength(16),
        Validators.pattern(/^[a-zA-Z0-9]*$/) // only letters and numbers
      ],
    ],
      gh15_amount: ['', [Validators.required, Validators.max(1000000000000)]],
      tds_code: ['', Validators.required],
      selectedTdsSectionLabel: [''],
      searchTdsSection: [''],

    });
  }


  // private adjustFormArray(val: number): void {
  //   const total = Number(val) || 0;
  //   const current = this.formArray.length;

  //   if (total > current) {
  //     // Add new rows
  //     for (let i = current; i < total; i++) {
  //       this.formArray.push(this.createFormRow());
  //     }
  //   } else if (total < current) {
  //     // Remove extra rows
  //     for (let i = current - 1; i >= total; i--) {
  //       this.formArray.removeAt(i);
  //     }
  //   }
  // }

  // private createFormRow(): FormGroup {
  //   return this.fb.group({
  //     account_no: ['', Validators.required],
  //     gh15_amount: ['', Validators.required],
  //     tds_code: ['', Validators.required],
  //   });
  // }

  onRefresh(index: number): void {
    this.formArray.at(index).reset();
    this.refreshFilteredOptions();
  }

  // onDelete(index: number): void {
  //   // Remove the selected row
  //   this.formArray.removeAt(index);

  //   // Get current total_no_form value
  //   const totalForms = Number(this.fifteenghForm.get('total_no_form')?.value) || 0;

  //   // If rows are fewer than totalForms, add a new empty one
  //   if (this.formArray.length < totalForms) {
  //     this.addEmptyFormRow();
  //   }

  //   // Refresh dropdown options (if applicable)
  //   this.refreshFilteredOptions();
  // }

  // onTotalFormsChange(): void {
  //   const totalForms = Number(this.fifteenghForm.get('total_no_form')?.value) || 0;
  //   const currentCount = this.formArray.length;

  //   // Count filled rows (account_no, tds_code, and gh15_amount are all non-empty)
  //   const filledRows = this.formArray.controls.filter(group =>
  //     group.get('account_no')?.value ||
  //     group.get('tds_code')?.value ||
  //     group.get('gh15_amount')?.value
  //   ).length;

  //   // ✅ CASE 1: Entered total forms less than filled rows → show warning popup
  //   if (totalForms < filledRows) {
  //   this.popupMessage = `Please add valid number of forms. You already filled ${filledRows} rows.`;
  // this.showErrorPopup = true;

  //     // Restore total_no_form to current filled count
  //     this.fifteenghForm.patchValue({ total_no_form: filledRows });
  //     return;
  //   }

  //   // ✅ CASE 2: Add extra empty rows (if needed)
  //   if (totalForms > currentCount) {
  //     const toAdd = totalForms - currentCount;
  //     for (let i = 0; i < toAdd; i++) {
  //       this.formArray.push(this.createFormRow());
  //     }
  //   }

  //   // ✅ CASE 3: Do NOT remove rows automatically (keep filled data)
  //   // Only adjust totalForms variable
  //   this.totalForms = totalForms;
  //   this.refreshFilteredOptions();
  //   this.cdr.detectChanges();
  // }



  // 2) helper: add one empty row (keeps dropdown filtered arrays in sync)
  private addEmptyFormRow(): void {
    this.formArray.push(this.createFormRow());
    const idx = this.formArray.length - 1;
    this.filteredTdsSectionOptions[idx] = [...(this.tdsSectionOptions || [])];
  }

  // 3) count how many rows are considered "filled"
  // change criteria to require all fields if you want stricter
  private countFilledRows(): number {
    return this.formArray.controls.filter(g => {
      const acc = (g.get('account_no')?.value || '').toString().trim();
      const amt = (g.get('gh15_amount')?.value || '').toString().trim();
      const tds = (g.get('tds_code')?.value || '').toString().trim();
      return acc !== '' || amt !== '' || tds !== '';
    }).length;
  }

  // 4) delete row: remove index, then if rows < total_no_form add an empty row at the end
  onDelete(index: number): void {
    if (!confirm('Delete this row?')) return;

    this.formArray.removeAt(index);
    if (this.filteredTdsSectionOptions && this.filteredTdsSectionOptions.length > index) {
      this.filteredTdsSectionOptions.splice(index, 1);
    }

    const totalForms = Number(this.fifteenghForm.get('total_no_form')?.value) || 0;
    if (this.formArray.length < totalForms) {
      this.addEmptyFormRow();
    }

    this.refreshFilteredOptions();
    this.cdr.detectChanges();
  }


  // 5) refreshFilteredOptions - ensure one filtered list per row (do not mutate the master list)
  private refreshFilteredOptions(): void {
    this.filteredTdsSectionOptions = this.formArray.controls.map(() => [...(this.tdsSectionOptions || [])]);
  }

  // 6) Called on input change for total_no_form


  onTotalFormsChange(): void {
    const control = this.fifteenghForm.get('total_no_form');
    let totalForms = Number(control?.value) || 0;

    // avoid negative or invalid input
    if (totalForms < 0) totalForms = 0;

    const currentCount = this.formArray.length;

    // Count how many rows are filled
    const filledRows = this.formArray.controls.filter(group =>
      Object.values(group.value).some(v => v !== null && v !== '')
    ).length;

    // 🧠 Case 1: Trying to reduce below filled rows → show popup
    if (totalForms < filledRows) {
      this.popupMessage = `Please add valid number of forms. You already filled ${filledRows} rows.`;
      this.showPopup = true;

      // restore old valid value
      control?.setValue(this.previousTotalForms, { emitEvent: false });
      return;
    }

    // 🧠 Case 2: Increase total → add extra blank rows
    if (totalForms > currentCount) {
      const toAdd = totalForms - currentCount;
      for (let i = 0; i < toAdd; i++) {
        this.formArray.push(this.createFormRow());
      }
    }

    // 🧠 Case 3: Decrease total → remove only *extra empty* rows from bottom
    if (totalForms < currentCount) {
      for (let i = currentCount - 1; i >= totalForms; i--) {
        const row = this.formArray.at(i);
        const isFilled = Object.values(row.value).some(v => v !== null && v !== '');
        if (!isFilled) {
          this.formArray.removeAt(i);
        }
      }
    }

    // 🧠 Remember last valid count
    this.previousTotalForms = totalForms;

    this.cdr.detectChanges();
  }


  // get remainingAccounts(): number {
  //   const totalForms = this.fifteenghForm.get('total_no_form')?.value || 0;
  //   const currentForms = this.formArray?.length || 0;
  //   console.log(totalForms)
  //   console.log(currentForms)
  //   console.log(Math.max(totalForms - currentForms, 0))
  //   return Math.max(totalForms - currentForms, 0);
  // }

  get remainingAccounts(): number {
    const totalForms = Number(this.fifteenghForm.get('total_no_form')?.value) || 0;
    const currentForms = this.formArray?.length || 0;
    return Math.max(totalForms - currentForms, 0);
  }

  totalForms: any;
  // onTotalFormsChange() {
  //   const totalForms = Number(this.fifteenghForm.get('total_no_form')?.value) || 0;
  //   this.totalForms = totalForms;

  //   this.cdr.detectChanges();
  // }

  get totalGh15Amount(): number {
    if (!this.formArray?.controls?.length) return 0;
    return this.formArray.controls.reduce((sum, group: any) => {
      const value = parseFloat(group.get('gh15_amount')?.value) || 0;
      return sum + value;
    }, 0);
  }

  formatAmount(amount: any): string {
    const num = Number(amount) || 0;
    return new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  }

  isScrolled = false;

  onScroll(event: Event) {
    const target = event.target as HTMLElement;
    this.isScrolled = target.scrollTop > 0;
  }

  getLabel(options: Option[] | undefined, value: any): string {
    // safe guards
    if (!options || !options.length) return '-';
    if (value === null || value === undefined || value === '') return '-';

    // normalize types to avoid mismatches between number/string
    const match = options.find(o => String(o.value) === String(value));
    return match ? match.label : '-';
  }

}
