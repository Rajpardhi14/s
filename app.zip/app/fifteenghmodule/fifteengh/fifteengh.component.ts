import { Component, DestroyRef, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { skip, Subject, Subscription } from 'rxjs';

import { CommonModule } from '@angular/common';
import { RefreshdataService } from '../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../core/services/screensize/screensize.service';
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { ToastService } from '../../core/services/toaster/toast.service';
import { XldownloadService } from '../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
import { BasicFilterComponent } from '../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../shared/components/advance-filter/advance-filter.component';
import { GearboxComponent } from '../../shared/components/gearbox/gearbox.component';
import { TableskeletonComponent } from '../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../shared/components/nodata/nodata.component';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { capitalizeEachWord, formatDatesend, formatValue } from '../../shared/utils/passmatch';
import { AlertpoupComponent } from "../../shared/components/alertpoup/alertpoup.component";
import { DisplayValueUtilService } from '../../shared/utils/displayValue';
import { AddfifteenghComponent } from './addfifteengh/addfifteengh.component';
import { ButtoneventlisnerDirective } from '../../core/services/session/timer-session/buttoneventlisner.directive';

@Component({
  selector: 'app-fifteengh',
  standalone: true,
  imports: [BasicFilterComponent, AdvanceFilterComponent, GearboxComponent, TableskeletonComponent, NodataComponent, CommonModule, FormsModule, ReactiveFormsModule, AddfifteenghComponent,AlertpoupComponent,ButtoneventlisnerDirective],
  templateUrl: './fifteengh.component.html',
  styleUrl: './fifteengh.component.css'
})
export class FifteenghComponent {

   capatilizeEachword = capitalizeEachWord
    scrollPosition: number = 0;
    totalHeight: number = 0;
    visibleHeight: number = 0;
    localUserData: any;
    allUsersData: any[] = [];
  
    basic_filter: any[] = [];
    basic_filterPlaceholder: string = '';
    advance_filter: any[] = [];
    advance_filterPlaceholder: string = '';
    filterForm!: FormGroup;
    selectedFilter: string | null = null;
    filterClause: any;
    selectedFilterValue: string = '';
    filtercount: number = 0;
    usergrandtotal: number = 0;
    limit: number = 100;
    offset: number = 0;
    currentPage: number = 1;
    newOffset: any;
    isLoadingMoreData: boolean = false;
    isLoadingMore: boolean = false;
    paginatedList: any;
    totalcount: any;
    userData: any;
    Math = Math;
    // Table data variable
    headers: any[] = [];
    tableBody: any[] = [];
    excelheaders: any[] = [];
    exceltableBody: any[] = [];
    loginUserdata: any;
    loading = false;
    errorMessage = '';
    selectedFilters: { label: string; field?: string; value: string }[] = [];
    selectedUser: any;
    private refreshSubscription: Subscription | null = null;
    isLoading: boolean = false;
    menuOptions: {
      field: string;
      label: string;
      operator: string;
      alias: string;
      placeholder: string;
    }[] = [];
    selectedOption: {
      label: string;
      field: string;
      operator: string;
      alias: string;
      placeholder: string;
    } | null = null;
    searchTerm: string = '';
    matchingDependValue: any;
  
    // selectedMaster: string = 'USER_MASTER';
    activeFilterTab: string = '';
    defaultTabFilter: any;
    selectedValue: string[] = [];
    selectedLabel: any;
    isOpenAddUaser: boolean = false;
    selectedRoleCode: string | null = null;
    dropdownOpenselect = false;
    scrollTimeout: any = null;
    userHasScrolled: boolean = false;
    filtersSubmitted = false;
    showOptions: boolean = false;
    openInfoId: number | null = null;
    screenWidth: number = 0;
    screenHeight: number = 0;
    deviceType: string = '';
    fullScreenResolution: { width: number; height: number } = {
      width: 0,
      height: 0,
    };
    heightToSubtract: number = 460;
    remainingHeight: number = 0;
    skeletonList = Array(7);
    FYYear: string = "Yes";
    iudtype: string = 'ALL';
    private destroy$ = new Subject<void>();
    dynaUserData: any;
      multiMast:any;
      formatValue =formatValue;
  
    capitalizeEachWord = capitalizeEachWord;
    
  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  
    constructor(
      private refreshdata: RefreshdataService,
      private screenSizeService: ScreensizeService,
      private userlocaldataService: UserdataService,
      private fb: FormBuilder,
      private toastService: ToastService,
      private exceldownload: XldownloadService,
      private apiService: ApiserviceService,
      private displayValueUtil: DisplayValueUtilService
    ) {
  
    }
  
  ngOnInit(): void {
const headerMastString = localStorage.getItem('headermastertwo');

if (headerMastString) {
  const headerMast = JSON.parse(headerMastString);
  this.multiMast = headerMast;
} else {
  console.error('No header master found in localStorage');
}


    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

    // this.getsData();

    this.dynamicUserData$
      .pipe(
        skip(1),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(dynamicData => {

        this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
        this.offset = 0;
        this.fetchTable();
        this.fetchFilter();
        this.fetchGrandTotal();
      });

    this.fetchTable();
    this.fetchFilter();
    this.fetchGrandTotal();

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    this.refreshSubscription = this.refreshdata.onRefresh('gh15').subscribe(() => {
      this.fetchTable();
      this.fetchGrandTotal();

    });

  }

    ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }

    private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
        } catch (e) {
          parsedData = response.data;
        }
        console.log('Parsed Redis data:', parsedData);
      },
      error: (error: any) => {
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }



 // Check if all rows are selected
  isAllSelected(): boolean {
    return this.paginatedList?.every((row: any) => row.selected);
  }

  // Toggle all rows
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }

  // Get selected rows (optional helper)
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }


  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  buildMergeGroups() {
    this.headers?.forEach(header => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }


  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );

  }

  isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
    return dateFields.includes(field);
  }

  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }


  fetchTable(isClearAction = false) {

     // Ensure filterClause is always an array
  const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
  // console.log('User Filters:', userFilters);

  // Define default filters
  const defaultFilters = [
    {
      filter_col_field: 'quarter_no',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_quarter_no,
      filter_col_field_alias: 'a.',
    },
    {
      filter_col_field: 'tds_type_code',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_tds_type_code,
      filter_col_field_alias: 'a.',
    },
    // {
    //   filter_col_field: 'shord_deduction_remark_status',
    //   filter_col_depend_operator: 'wc',
    //   filter_col_value: 'and 1=1',
    //   filter_col_field_alias: 'a.',
    // },
  ];

  // ✅ Logic for which filters to use
  let finalFilterClause: any[] = [];

  if (isClearAction) {
    // If clearAllFilters was called → send empty array
    finalFilterClause = [];
  } else if (userFilters.length > 0) {
    // If user has applied filters → use user filters
    finalFilterClause = userFilters;
  } else {
    // Initial load → use default filters
    finalFilterClause = defaultFilters;
  }

  // console.log('Final Filter Clause:', finalFilterClause);


    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmdb_deductee_mast_15gh',
      this.localUserData,
      finalFilterClause, // always pass fresh filters
      // this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        // iudtype: this.iudtype
      },

    );
    
    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.get_gmdb_deductee_mast_15gh;
          if (userData?.get_gmdb_deductee_mast_15gh_header) {
            this.headers = userData?.get_gmdb_deductee_mast_15gh_header?.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,

              })
            );

          }
          // this.allUsersData = userData || {};
          this.mergeGroups = {};
          this.fieldToMergeGroup = {};
          this.tableBody = userData?.get_gmdb_deductee_mast_15gh_detail || [];
          this.buildMergeGroups()
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
          this.loading = false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
      },
    });


  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }



  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmfb_deductee_mast_15gh',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );



    this.apiService.getFilterData('/Comman/dynamic', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.get_gmfb_deductee_mast_15gh?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.get_gmfb_deductee_mast_15gh?.[1]?.advance_filter;
          setTimeout(() => {
            this.setDefaultFilters();
          }, 0);
          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage = response.result?.[0].a_proc_error_message || "Please Check Endpoint";
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion

  selectedTabFilter(filterField: string, value: any, label: any): void {
    this.selectedValue = value;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    //Always run logic even if the tab value is the same as previous
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 0) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
    this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();
      // console.log(this.filterClause);

      Promise.all([this.fetchTable(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }


   private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }


  // private buildFilterClause(): any[] {
  //   const filterClause: any[] = [];
  //   Object.keys(this.filterForm.controls).forEach((key) => {
  //     const controlValue = this.filterForm.get(key)?.value;
  //     const filterConfig = this.advance_filter?.find(
  //       (filter: any) => filter.filter_col_field === key
  //     );

  //     if (controlValue && controlValue !== 'ALL' && filterConfig) {

  //       let filterValue: string;
  //       const operator = filterConfig.filter_col_depend_operator;
  //       filterValue = controlValue.toString().trim();

  //       if (filterValue && filterValue !== '') {
  //         filterClause.push({
  //           filter_col_field: filterConfig.filter_col_field,
  //           filter_col_depend_operator: operator,
  //           filter_col_value: filterValue.toUpperCase(),
  //           filter_col_field_alias: filterConfig.filter_col_field_alias,
  //         });
  //       }
  //     }
  //   });
  //   if (
  //     this.searchTerm &&
  //     this.searchTerm.trim() !== '' &&
  //     this.selectedOption
  //   ) {
  //     filterClause.push({
  //       filter_col_field: this.selectedOption.field,
  //       filter_col_depend_operator: this.selectedOption.operator,
  //       filter_col_value: this.searchTerm.toUpperCase(),
  //       filter_col_field_alias: this.selectedOption.alias,
  //     });
  //   }
  //   return filterClause;
  // }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {
         
          // console.log(controlValue);
          // For "wc", find the condition based on selected value
          // console.log(filterConfig.filter_col_depend_value);
          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue.toUpperCase()
          );
          // console.log(selectedOption);
          filterValue = selectedOption ? selectedOption.condition : '';
          // console.log(filterValue);
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    // Include search term if present
    if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.trim().toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    
   const uniqueFilters = Array.from(
    new Map(
      filterClause.map((item) => [item.filter_col_field, item])
    ).values()
  );

  return uniqueFilters;
  }





  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value.trim();
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }



  // getSelectedFilters() {
  //   const selectedFilters: { label: string; field?: string; value: string }[] = [];

  //   if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //     this.advance_filter.forEach((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);

  //       if (control && control.value != null && control.value.toString().trim() !== '') {
  //         let label = field.filter_col_prompt;
  //         const dependValue = field.filter_col_depend_value?.find(
  //           (dv: any) => dv.value == control.value
  //         );
  //         if (dependValue?.label) {
  //           label = dependValue.label;
  //         }

  //         selectedFilters.push({
  //           label,
  //           field: field.filter_col_field,
  //           value: control.value.toString().trim(),
  //         });
  //         console.log(selectedFilters);
  //       }

  //       //  if (!(field.filter_col_external === 1)) {
  //       //     const control = this.filterForm.get(field.filter_col_field);

  //       //     if (
  //       //       control &&
  //       //       control.value &&
  //       //       !field.filter_col_external_default_value &&
  //       //       control.value.toString().trim() !== ''
  //       //     ) {
  //       //       this.matchingDependValue = field.filter_col_depend_value.find(
  //       //         (dependValue: any) => dependValue.value === control.value
  //       //       );

  //       //       if (this.matchingDependValue) {
  //       //         selectedFilters.push({
  //       //           label: this.matchingDependValue.label,
  //       //           value: control.value.toString().trim(),
  //       //         });
  //       //       } else if (!this.matchingDependValue) {
  //       //         selectedFilters.push({
  //       //           label: field.filter_col_prompt,
  //       //           value: control.value.toString().trim(),
  //       //         });
  //       //       }
  //       //     }
  //       //   }



  //     });
  //   }

  //   // // Add search term filter (if applicable)
  //   // if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
  //   //   selectedFilters.push({
  //   //     label: this.selectedOption.label,
  //   //     field: this.selectedOption.field,
  //   //     value: this.searchTerm.toUpperCase(),
  //   //   });
  //   // }

  //   return selectedFilters;
  // }
getSelectedFilters() {
  const selectedFilters: { label: string; field?: string; value: string }[] = [];

  if (this.advance_filter && Array.isArray(this.advance_filter)) {
    this.advance_filter.forEach((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);

      if (control && control.value != null && control.value.toString().trim() !== '') {
        let label: string;

        // If current value is the default, use prompt as label
        if (field._isDefaultValue !== undefined && control.value === field._isDefaultValue) {
          label = field.filter_col_prompt;
        } 
        // Otherwise, use depend_value label if available
        else {
          const dependValue = field.filter_col_depend_value?.find(
            (dv: any) => dv.value == control.value
          );
          label = dependValue?.label || field.filter_col_prompt;
        }

        selectedFilters.push({
          label,
          field: field.filter_col_field,
          value: control.value.toString().trim(),
        });
      }
    });
  }

  return selectedFilters;
}


removedFilter:any;

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );
    // console.log(filterToRemove);

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );

    // console.log(filterRemove);
    if (filterToRemove) {
      this.removedFilter = filterToRemove.filter_col_field;
      // console.log( this.removedFilter);
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
       this.removedFilter = filterRemove.filter_col_field;
      // console.log( this.removedFilter);
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    // console.log(this.filterClause);
     // ✅ If no filters left → pass empty array (not defaultFilters)
  const isLastFilterCleared = !this.filterClause || this.filterClause.length === 0;

  if (isLastFilterCleared) {
    this.fetchTable(true); // 'true' means clear action, same as clearAllFilters
  } else {
    this.fetchTable(); // normal behavior
  }

  this.fetchGrandTotal();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  // user grand total


  private fetchGrandTotal(): void {
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];

    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];

    // Always rebuild final filterClause fresh:
    const finalFilterClause = [
      ...newFilterClause,
      ...userFilters.filter(
        (uf: any) =>
          !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
      ),
    ];

    const sdata = this.apiService.generateSData(
      'get_gmdg_deductee_mast_15gh',
      this.localUserData,
      finalFilterClause,
      // this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { FYYear: this.FYYear }
    );

    this.apiService.getGrandTotal('/Comman/dynamic', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          // Success case
          this.gtdgData =
    response?.result?.get_gmdg_deductee_mast_15gh?.[0] || null;

  this.usergrandtotal = this.gtdgData?.rec || null;
          this.usergrandtotal =
            response?.result?.get_gmdg_deductee_mast_15gh?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
        
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        // console.error('Error fetching vendor data:', error);
        this.showError('Something Went Wrong');
      },
    });
  }

  // Remove all filter label values
  // clearAllFilters() {
  //        this.searchTerm = '';
  //   this.offset = 0;
  //   this.currentPage = 1;
  //   this.selectedFilters = [];
  //   this.filterClause = [];
  //   if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //     this.advance_filter.forEach((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);
  //       if (control) {
  //         control.setValue('');
  //       }
  //     });
  //   }
  //   this.filtercount = this.getSelectedFilterCount();
  //   this.fetchTable(true);
  //   this.fetchGrandTotal();
  // }


  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;

    // Check if user applied any filters different from defaults
    const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      const value = control?.value;
      const defaultVal = field._isDefaultValue ?? '';
      return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
    });

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (!control) return;

        const defaultVal = field._isDefaultValue ?? null;

        if (hasUserAppliedFilters) {
          // ✅ Keep default filters intact
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue(''); // clear user-only filters
          }
        } else {
          // ✅ If no user filters were applied — reset to defaults, not empty
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue('');
          }
        }
      });
    }

    // ✅ Rebuild filterClause including defaults
    this.selectedFilters = this.getSelectedFilters();
    this.filterClause = this.buildFilterClause();
    this.filtercount = this.getSelectedFilterCount();

    // 🚫 Don’t treat this as a full clear for fetchTable()
    this.fetchTable(false);
    this.fetchGrandTotal();
  }



  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  // exportToExcel(): void {
  //   this.exceldownload.downloadExcel(
  //     this.headers,
  //     this.tableBody,
  //     'transaction_data'
  //   );
  // }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }

  isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  selectedRowDetails: any;


  openDrawer(idTofetch?: string, details?: any) {
    this.selectedId = idTofetch ?? null;
    this.selectedRowDetails = details;  // store row if needed
    this.isDrawerOpen = true;
  }



  closeDrawer() {
    this.selectedId = null;
    this.isDrawerOpen = false;
  }


  handleClosePopup() {
    this.isDrawerOpen = false; // or any logic to close popup
  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  selectedIdsForDeletion: number = 0;
  // Count selected rows
  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }

  getSelectedRowIds(): number[] {
    return this.paginatedList
      ?.filter((row: any) => row.selected)
      ?.map((row: any) => row.rowid_seq);
  }

  isDeletePopupOpen = false;

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false;
    this.detailsLoader = true;
  
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.DeleteRecord();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
        this.detailsLoader = false;
    // this.isDrawerOpen=true;
  }


  onClear() {
    // Uncheck all rows 
    this.paginatedList?.forEach((r: any) =>
      r.selected = false);
  }


  DeleteRecord() {
    const selectedIds = this.getSelectedRowIds();
    if (selectedIds.length === 0) {
      this.showError('Please select at least one row to delete.');
      return;
    }

    const isAll = this.isAllSelected();

    let iudType: 'sd' | 'md';
    if (this.paginatedList.length === 1 && selectedIds.length === 1) {
      iudType = 'sd'; // single record → SD always
    } else {
      iudType = isAll ? 'md' : 'sd';
    }


    // Base request body
    const requestBody: any = {
      a_iud_seqno: '',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: '',
      a_session_seqno: '',
      a_proc_type: 'get_gmmd_deductee_mast_15gh',
      a_user_code: this.dynaUserData.user_code,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_seqno: '',
      a_iud_type: iudType,
    };

    if (iudType === 'md') {
      // Build dynamic filter clause
      this.filterClause = Array.isArray(this.filterClause)
        ? this.filterClause
        : [];

      const newFilterClause = [
        {
          filter_col_field: 'quarter_no',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_quarter_no,
          filter_col_field_alias: 'a.',
        },
        {
          filter_col_field: 'tds_type_code',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_tds_type_code,
          filter_col_field_alias: 'a.',
        },
      ];

      newFilterClause.forEach((nf) => {
        const exists = this.filterClause.some(
          (f: any) => f.filter_col_field === nf.filter_col_field
        );
        if (!exists) {
          this.filterClause.push(nf);
        }
      });

      requestBody.a_filter_clause = this.filterClause;
    } else {
      // Single delete → map selected IDs
      requestBody.deductee_mast_15gh = selectedIds.map((id: number) => ({
        rowid_seq: id,
      }));
    }

    this.apiService
      .createData('/Comman/dynamic', requestBody)
      .subscribe({
        next: (response) => {
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
             this.detailsLoader =false;
            this.showSuccess(result.a_proc_error_message);
            this.refreshdata.trigerRefresh('gh15');
          } else {
            this.showError(
              result.a_proc_error_message || 'Error while deleting rows.'
            );
             this.detailsLoader =false;
          }
        },
        error: () => {
          this.showError('Something went wrong! Please try again later.');
             this.detailsLoader =false;
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }



  // setDefaultFilters() {
  //   if (!this.advance_filter || !this.filterForm) return;

  //   this.advance_filter.forEach((field: any) => {
  //     // Set default for quarter_no
  //     if (field.filter_col_field === 'quarter_no') {
  //       const defaultQuarter = this.dynaUserData?.default_quarter_no || 'Q1';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultQuarter);
  //     }

  //     // Set default for tds_type_code
  //     if (field.filter_col_field === 'tds_type_code') {
  //       const defaultTdsType = this.dynaUserData?.default_tds_type_code || '26Q';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
  //     }

  //     if (field.filter_col_field === "shord_deduction_remark_status") {
  //       const dvs = field.filter_col_external_default_value
  //       this.filterForm.get(field.filter_col_field)?.setValue(dvs);
  //     }
  //   });


  //   this.selectedFilters = this.getSelectedFilters();
  // }

  
setDefaultFilters() {
  if (!this.advance_filter || !this.filterForm) return;

  this.advance_filter.forEach((field: any) => {
    let defaultValue: any;

    switch (field.filter_col_field) {
      case 'quarter_no':
        defaultValue = this.dynaUserData?.default_quarter_no || 'Q1';
        break;
      case 'tds_type_code':
        defaultValue = this.dynaUserData?.default_tds_type_code || '26Q';
        break;
      case 'shord_deduction_remark_status':
        defaultValue = field.filter_col_external_default_value;
        break;
      default:
        if (field.filter_col_external_default_value) {
          defaultValue = field.filter_col_external_default_value;
        }
    }

    if (defaultValue !== undefined) {
      this.filterForm.get(field.filter_col_field)?.setValue(defaultValue);

      // Store the default value itself to detect in getSelectedFilters
      field._isDefaultValue = defaultValue;
    }
  });

  this.selectedFilters = this.getSelectedFilters();
  // console.log(this.selectedFilter)
}





  getDisplayValue(header: any, row: any) {
    return this.displayValueUtil.getDisplayValue(header, row, this.multiMast);
  }

  showFooter: boolean = false; 
gtdgData:any;
  toggleFooter() {
  this.showFooter = !this.showFooter;
}

 asArray(val: unknown): any[] {
    return Array.isArray(val) ? val : [];
  }

  
  fetchTableExcel(isClearAction = false) {
    this.detailsLoader = true;
    // Ensure filterClause is always an array
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
    // console.log('User Filters:', userFilters);

    // Define default filters
    const defaultFilters = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },

    ];

    // ✅ Logic for which filters to use
    let finalFilterClause: any[] = [];

    if (isClearAction) {
      // If clearAllFilters was called → send empty array
      finalFilterClause = [];
    } else if (userFilters.length > 0) {
      // If user has applied filters → use user filters
      finalFilterClause = userFilters;
    } else {
      // Initial load → use default filters
      finalFilterClause = defaultFilters;
    }


    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmdb_deductee_mast_15gh',
      this.localUserData,
      finalFilterClause, // always pass fresh filters
      // this.limit,
      this.totalcount,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        // iudtype: this.iudtype
      },

    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.get_gmdb_deductee_mast_15gh;
          if (userData?.get_gmdb_deductee_mast_15gh_header) {
            this.excelheaders = userData?.get_gmdb_deductee_mast_15gh_header?.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,

              })
            );

          }

          this.exceltableBody = userData?.get_gmdb_deductee_mast_15gh_detail || [];
          this.detailsLoader = false;
          this.exceldownload.downloadExcel(
            this.excelheaders,
            this.exceltableBody,
            '15GH_data'
          );


        } else {
          this.loading = false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
          this.detailsLoader = false;
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
        this.detailsLoader = false;
      },
    });

  }

  exportToExcel() {


    if (this.totalcount > 10000) {
      this.showSuccess("The Report will available in Downloads Shortly...!");
      this.fetchGenerateTable()
    }
    else {
      this.showSuccess("Excel Download Process Start...!");
      this.fetchTableExcel(this.filterClause);
    }

  }

  detailsLoader: boolean = false;

  fetchGenerateTable(isClearAction = false) {

    // this.detailsLoader = true;
    // Ensure filterClause is always an array
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
    // console.log('User Filters:', userFilters);

    // Define default filters
    const defaultFilters = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },

    ];

    //  Logic for which filters to use
    let finalFilterClause: any[] = [];

    if (isClearAction) {
      // If clearAllFilters was called → send empty array
      finalFilterClause = [];
    } else if (userFilters.length > 0) {
      // If user has applied filters → use user filters
      finalFilterClause = userFilters;
    } else {
      // Initial load → use default filters
      finalFilterClause = defaultFilters;
    }


    const sdata: any = {
      a_iud_seqno: '',
      a_db_total_records: this.totalcount,
      // a_db_total_records: '100',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: this.dynaUserData.default_sub_module_type_code,
      a_session_seqno: '',
      a_proc_type: 'get_gmdb_deductee_mast_15gh',
      a_user_code: this.localUserData.user_code,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_seqno: '',
      a_iud_type: this.iudtype,
      a_filter_clause: finalFilterClause,
      // a_filter_clause: selectedFilterClause,
      a_rowid_seq: '',
      dashboard: 'View'
    };
    this.apiService.getTableData(`/Comman/generate_dynamic_report`, sdata).subscribe({
      next: (data) => {
        // this.detailsLoader = false;
        const firstResult = data?.result?.[0];
        // const fileName = firstResult?.s3FileUrl;
        // if (firstResult?.s3FileUrl) {

        //   this.downloadReportFile(fileName, 's3');
        //   this.detailsLoader = false;
        // }

        // Fetch details to refresh table
        // this.fetchDetails(rowId, selectedFilterClause);


        // ✅ Stop loader for this row
        // delete this.loadingFields[rowId];
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
        // this.detailsLoader = false;

        // Stop loader even if error
        // delete this.loadingFields[rowId];
      },
    });
  }


  // downloadReportFile(filename: string, source: string) {
  //   if (!filename) return;

  //   // Replace '#' → '/' and convert .zip → .xlsx
  //   let formattedFilename = filename
  //     .replace(/#/g, '/')
  //     .replace(/\.zip$/, '.xlsx'); // convert .zip to .xlsx

  //   console.log('Formatted Filename:', formattedFilename);
  //   const headerJson = {}

  //   this.apiService.reportFileDownload(formattedFilename, source, headerJson);
  // }

     sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";
   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }


}

