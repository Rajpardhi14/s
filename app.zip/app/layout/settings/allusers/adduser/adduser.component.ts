import { CommonModule } from '@angular/common';
import {
  Component,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import * as bcrypt from 'bcryptjs';
import { RefreshdataService } from '../../../../core/services/refreshdata/refreshdata.service';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { noWhitespaceValidator } from '../../../../shared/utils/passmatch';
import { ButtoneventlisnerDirective } from '../../../../core/services/session/timer-session/buttoneventlisner.directive';

@Component({
  selector: 'app-adduser',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule,ButtoneventlisnerDirective],
  templateUrl: './adduser.component.html',
  styleUrl: './adduser.component.css',
})
export class AdduserComponent {
  @Input() selectedId: string | null = null;
  @Input() isDrawerOpen: boolean = false;
  @Output() closeDrawer = new EventEmitter<void>();
  roleData: any;
  isSubmittingUpdate: boolean = false;
  originalPassword: string = '';
  userForm!: FormGroup;
  localUserData: any;
  isSubmitting = false;
  dynamicUserData: any;
  errorMessage: string = '';
  emailerr: string = '';
  detailsLoader: boolean = false;
   roles: Array<{ value: string; label: string }> = [];
     selectedRole: string = 'A1';

setRole(value: string) {
  this.selectedRole = value;
  this.userForm.patchValue({ role: value });
}

  constructor(
    private fb: FormBuilder,
    private refreshdata: RefreshdataService,
    private apiservice: ApiserviceService,
    private userlocaldata: UserdataService,
    private toastService: ToastService,
    private authservice: AuthService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedId'] && this.selectedId) {
      // ✅ Editing existing user
      console.log('Editing user:', this.selectedId);
      this.isEditMode = false; // ✅ must be true for editing
      this.fetchUserDetails(this.selectedId);
      this.isDrawerOpen = true;

      // Clear password for security
      if (this.userForm && this.userForm.get('password')) {
        this.userForm.get('password')?.setValue('');
      }
    } else {
      // ✅ Adding new user
      this.isEditMode = true;
      this.initializeForm();
      //  this.selectedRole = this.roles[0].value;
  
    this.selectedRole = 'A1';
    this.selectedStatus = 'A';

    }
    this.passwordVisibility.password = true;
console.log('Password visibility reset:', this.passwordVisibility.password);
  }

  ngOnInit(): void {
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
    this.initializeForm();
    // this.getrolecode();
    this.getsData()
    // this.userForm.get('email_id')?.valueChanges
    // .pipe(debounceTime(500), distinctUntilChanged())
    // .subscribe((email) => {
    //   if (email && this.userForm.get('email_id')?.valid) {
    //     this.checkEmailExists(email);
    //   }
    // });
    
  }

  initializeForm() {
    this.userForm = this.fb.group({
      user_name: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\S+$/),
          Validators.pattern(new RegExp(this.regexMap?.['user_name'])),
        ],
      ],
      lastName: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\S+$/),
          Validators.pattern(new RegExp(this.regexMap?.['lastName'])),
        ],
      ],
      email_id: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.pattern(new RegExp(this.regexMap?.['email_id'])),
        ],
      ],
      phone: [
        '',
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern(/^\d{10}$/),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d@#$!%*?&]{8,}$'
          ),
        ],
      ],
      bank_branch_code: ['', [Validators.required]],
      role: ['', Validators.required],
      status: ['', Validators.required],
    });

    // this.selectedRole = this.roles[0].value;
    // this.userForm.patchValue({ itc_flag: this.roles[0].value });
    // this.selectedRole = 'A1';

    if (!this.isEditMode) {
      this.userForm
        .get('password')
        ?.setValidators([
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
          ),
        ]);
      this.userForm.get('password')?.updateValueAndValidity();
    }
    // ✅ Skip password validation only in edit mode
    // if (this.selectedId && this.isEditMode) {
    //   const passwordControl = this.userForm.get('password');
    //   passwordControl?.clearValidators();
    //   passwordControl?.updateValueAndValidity();
    // }
  }

  // roles = [
  //   { value: 'A1', label: 'Admin' },
  //   { value: 'A2', label: 'Audit' },
  //   { value: 'A3', label: 'Viewer' },
  // ];


passwordVisibility = {
  password: true, // true = visible eye, false = hidden
};

togglePasswordVisibility(field: 'password'): void {
  this.passwordVisibility[field] = !this.passwordVisibility[field];
  console.log('toggled');
}

close() {
  this.userForm.reset();
  this.closeDrawer.emit();
  // Always reset to "closed eye" (hidden password)
  this.passwordVisibility.password = false;
}

  selectedStatus: string = 'A';

  selectStatus(flag: any) {
    this.selectedStatus = flag;
    this.userForm.patchValue({ status: this.selectedStatus });
  }

  isEditMode: boolean = false;
  toggleEditMode() {
    this.isEditMode = true;
  }

  //subbmit
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiservice
      .createData('/UserMast/get_miud_user_mast', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.close();
            this.togglePasswordVisibility('password');
            this.refreshdata.trigerRefresh('AllUsers');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                  if (this.userForm.controls[field]) {
                    this.userForm.controls[field].setErrors({
                      serverError: error.message,
                    });
                  }
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }

  regexMap: { [key: string]: string } = {};
  // private getrolecode(): void {
  //   // const uData = JSON.parse(this.userDataLogin);
  //   const requestBody = {
  //     sdata: JSON.stringify({
  //       a_session_seqno: '',
  //       a_iud_seqno: '',
  //       a_is_pen_flag: '',
  //       a_login_type: 'login_id',
  //       a_module_type_code: this.dynamicUserData?.default_module_type_code,
  //       a_sub_module_type_code: 'R',
  //       a_entity_code: this.localUserData?.entity_code,
  //       a_client_code: this.localUserData?.client_code,
  //       a_acc_year: this.localUserData?.default_acc_year,
  //       a_quarter_no: this.localUserData?.default_quarter_no,
  //       a_tran_month: this.localUserData?.default_tran_month,
  //       a_tran_from_date: this.localUserData?.default_from_date,
  //       a_tran_to_date: this.localUserData?.default_to_date,
  //       a_tds_type_code: this.localUserData?.default_tds_type_code,
  //       a_first_level_client_code: this.localUserData?.first_level_client_code,
  //       a_validation_client_level: this.localUserData.client_code_level,
  //       a_iud_type: '',
  //       a_db_total_records: '10',
  //       a_pagination_count: '0',
  //       a_proc_type: 'get_mmtx_multi_mast',
  //       a_user_code: this.localUserData.user_code,
  //       first_level_client_code: this.localUserData.first_level_client_code,
  //       a_process_seqno: '',
  //       a_proc_error: '0',
  //       a_filter_clause: [
  //         {
  //           filter_col_field: 'gd_proc_name',
  //           filter_col_depend_operator: 'wc',
  //           filter_col_value:
  //             'and gd_proc_name in (##get_mmtx_user_role_mast##,##get_mmtx_regex_validation##)',
  //           filter_col_field_alias: 'a.',
  //         },
  //       ],
  //     }),
  //   };

  //   this.authservice.fetchMultiMastData(requestBody).subscribe({
  //     next: (response: any) => {
  //       const validations =
  //         response?.body?.result?.get_mmtx_multi_mast
  //           ?.get_gmdt_regex_validation || [];
  //       this.regexMap = validations.reduce((acc: any, cur: any) => {
  //         acc[cur.label] = cur.value;
  //         return acc;
  //       }, {});

  //       console.log('Full response', response.body);
  //       const roleData =
  //         response?.body?.result?.get_mmtx_multi_mast?.get_gmdt_user_role_mast;

  //       // console.log(roleData)
  //       // if (yearData) {
  //       //   localStorage.setItem('yearData', JSON.stringify(yearData));
  //       // }
  //       // if (stateData && Array.isArray(stateData)) {
  //       //   localStorage.setItem('statedata', JSON.stringify(stateData));
  //       // } else {
  //       //   console.warn('State data not found in response.');
  //       // }
  //     },
  //     error: (error: any) => {
  //       console.error(error);
  //     },
  //   });
  // }
private getsData(): void {
  const requestBody = {
    usercode: this.localUserData?.user_code,
    clientcode: this.localUserData?.client_code,
  };

  this.apiservice.setRedisApi('/Comman/get_mmtx_data', requestBody)
    .subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
        } catch (e) {
          parsedData = response.data;
        }
  const validations =
          parsedData?.multiMast?.get_mmtx_multi_mast;
        this.regexMap = validations?.reduce((acc: any, cur: any) => {
          acc[cur.label] = cur.value;
          return acc;
        }, {});
        console.log(validations);
        const roleData = parsedData?.multiMast?.get_gmdt_user_role_mast;

        // Map roles from API
        this.roles = (roleData || []).map((role: any) => ({
          value: role.value,
          label: role.label
        }));

        // ✅ Set default selection AFTER roles exist
        if (this.roles.length && this.userForm) {
          this.selectedRole = this.roles[0].value;
          this.userForm.patchValue({ role: this.selectedRole });
        }
      },
      error: (error: any) => {
        console.error(error);
      },
    });
}




  onSubmit() {
    this.userForm.patchValue({
      role: this.selectedRole || 'A1',
      status: this.selectedStatus || 'A',
    });
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      // return;
      console.log('onSubmit() called ✅', this.userForm.value);
    }
    this.isSubmitting = true;
    const formData = this.userForm.value;

    this.userForm.patchValue({
      role: this.selectedRole,
      status: this.selectedStatus,
    });
    // Convert all string fields to uppercase
    Object.keys(formData).forEach((key) => {
      if (typeof formData[key] === 'string' && key !== 'password') {
        formData[key] = formData[key].toUpperCase();
      }
    });

    // let loginPwd: string | undefined;

    // if (!this.selectedId) {

    //   const saltRounds = 10;
    //   loginPwd = bcrypt.hashSync(formData.password, saltRounds);
    // } else {
    //   // Update mode
    //   if (formData.password && formData.password.trim() !== '') {
    //     // User entered new password → hash it
    //     const saltRounds = 10;
    //     loginPwd = bcrypt.hashSync(formData.password, saltRounds);
    //   } else {

    //     loginPwd = this.originalPassword;
    //   }
    // }

    const saltRounds = 10;
    const loginPwd = bcrypt.hashSync(formData.password, saltRounds);

    const fullname =
      formData.user_name && formData.lastName
        ? `${formData.user_name} ~ ${formData.lastName}`
        : formData.user_name || formData.lastName;
    const requestBody = {
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.localUserData.user_level,
      a_login_type: 'login_id',
      a_email_id: this.dynamicUserData.email_id,
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_iud_type: this.selectedId ? 'u' : 'i',
      a_proc_type: 'get_miud_user_mast',
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      user_mast: {
        user_code: this.selectedId ? this.roleData.user_code : '',
        entity_code: this.dynamicUserData.entity_code,
        bank_branch_code: formData.bank_branch_code,
        status_code: this.selectedStatus,
        parent_code: '',
        user_name: fullname,
        short_name: '',
        user_level: this.localUserData.user_level,
        login_id: '',
        phoneno: formData.phone,
        email_id: formData.email_id,
        // login_pwd: loginPwd,
        login_pwd: this.selectedId ? this.roleData.login_pwd : loginPwd,
        default_acc_year: this.dynamicUserData.default_acc_year,
        app_kpi_code_str: '',
        default_quarter_no: this.dynamicUserData.default_quarter_no,
        default_tds_type_code: this.dynamicUserData.default_tds_type_code,
        default_tran_month: this.dynamicUserData.default_tran_month,
        default_module_type_code: this.dynamicUserData.default_module_type_code,
        add_right: '',
        edit_right: '',
        delete_right: '',
        query_right: '',
        print_right: '1000',
        approve_right: '0',
        is_itms_ddo: '0',
        is_itms_user: '0',
        valuation_right: '',
        special_right: '',
        upload_file_name: '',
        user_role_code: this.selectedRole,
        default_color_palette: '',
        first_time_login: '0',
        default_font_family: '',
        sub_module_type_code_str: [
          {
            module_type_code: 'TAXCPC',
            sub_module_type_code: [
              { value: 'R', label: 'Regular' },
              { value: 'G', label: '15GH' },
              { value: 'CORR', label: 'Correction' },
            ],
          },
        ],
        approvedby: '',
        approveddate: '',
      },
    };

    this.submitRequest(
      requestBody,
      'User Mast  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
  }

  fetchUserDetails(roleCode: string) {
    this.detailsLoader = true;
    const requestBody = {
      a_proc_type: 'get_gmdt_user_mast',
      a_user_code: this.dynamicUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_login_type: 'login_id',
      a_email_id: this.dynamicUserData.email_id,
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/UserMast/get_gmdt_user_mast', requestBody)
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_gmdt_user_mast
              ?.get_gmdt_user_mast_detail?.[0];
          this.roleData = roleData;

          if (!roleData) {
            this.showError('No user data found.');
            return;
          }
          this.detailsLoader = false;
          let firstName = '';
          let lastName = '';
          if (roleData.user_name) {
            const parts = roleData.user_name
              .split('~')
              .map((p: string) => p.trim());
            firstName = parts[0] || '';
            lastName = parts[1] || '';
          }
          // this.originalPassword = roleData.login_pwd;
          this.userForm.patchValue({
            bank_branch_code: roleData.bank_branch_code || '',
            email_id: roleData.email_id || '',
            phone: roleData.phoneno || '',

            role: roleData.user_role_code || '',
            status:
              roleData.status_code === 'A' || roleData.status_code === 'ACTIVE'
                ? 'A'
                : 'I',
            user_name: firstName,
            lastName: lastName,
            password: roleData.login_pwd,
          });
          this.selectedRole = roleData.user_role_code || '';
          this.selectedStatus =
            roleData.status_code === 'A' || roleData.status_code === 'ACTIVE'
              ? 'A'
              : 'I';
        },
        error: () => {
          this.showError('Failed to fetch User details.');
          this.detailsLoader = false;
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  //   checkEmailExists(email: string): void {
  //   if (!email) return;

  //   const sdata = {
  //     a_process_seqno: "",
  //     a_proc_type: "get_gmdt_user_mast_email_id",
  //     a_proc_error: "0",
  //     a_db_total_records: "0",
  //     a_pagination_count: "0",
  //     a_page_from: "1",
  //     a_page_to: "1",
  //     a_process_status_code: "",
  //     a_in_parameter_json: [{ a_rowid_seq: email }],
  //   };

  //   const requestBody = {
  //     sdata: JSON.stringify(sdata)
  //   };

  //   this.authservice.checkEmail(requestBody).subscribe({
  //     next: (response) => {
  //       if (response?.status === 1) {
  //         // Email already exists
  //         this.emailerr = response?.msg || 'This email is already registered';
  //         this.showError('FThis email is already registered.');
  //         this.userForm.get('email_id')?.setErrors({ emailTaken: true });
  //       } else if (response?.status === 0) {
  //         // Email not present
  //         this.emailerr = '';
  //         this.userForm.get('email_id')?.setErrors(null);
  //       }
  //     },
  //     error: () => {
  //       this.emailerr = 'Unable to verify email at the moment';
  //     },
  //   });
  // }

  //   checkEmailExists(email: string): void {
  //   if (!email) return;

  //   const sdata = {
  //     a_process_seqno: "",
  //     a_proc_type: "get_gmdt_user_mast_email_id",
  //     a_proc_error: "0",
  //     a_db_total_records: "0",
  //     a_pagination_count: "0",
  //     a_page_from: "1",
  //     a_page_to: "1",
  //     a_process_status_code: "",
  //     a_in_parameter_json: [{ a_rowid_seq: email }],
  //   };

  //   const requestBody = {
  //     sdata: JSON.stringify(sdata),
  //   };

  //   this.authservice.checkEmail(requestBody).subscribe({
  //     next: (response) => {
  //       const emailControl = this.userForm.get('email_id');

  //       if (response?.status === 1) {
  //         // Email already exists
  //         emailControl?.setErrors({ emailTaken: true });

  //         // ✅ Only show toast once per same email
  //         if (this.emailerr !== response?.msg) {
  //           this.emailerr = response?.msg || 'This email is already registered.';
  //           this.showError(this.emailerr);
  //         }
  //       } else if (response?.status === 0) {
  //         // Email not present → clear errors
  //         this.emailerr = '';
  //         emailControl?.setErrors(null);
  //       }
  //     },
  //     error: () => {
  //       this.showError('Unable to verify email at the moment');
  //     },
  //   });
  // }

  allowNumbersOnly(event: KeyboardEvent) {
    const charCode = event.key.charCodeAt(0);
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }
  blockNumbers(event: KeyboardEvent) {
    // Block any number key (0-9)
    if (/[0-9]/.test(event.key)) {
      event.preventDefault();
    }
  }
  blockPasteNumbers(event: ClipboardEvent) {
    const pastedData = event.clipboardData?.getData('text') || '';
    if (/\d/.test(pastedData)) {
      event.preventDefault();
    }
  }
}
