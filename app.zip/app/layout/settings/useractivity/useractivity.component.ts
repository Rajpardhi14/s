import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { GearboxComponent } from "../../../shared/components/gearbox/gearbox.component";
import { BasicFilterComponent } from "../../../shared/components/basic-filter/basic-filter.component";
import { AdvanceFilterComponent } from "../../../shared/components/advance-filter/advance-filter.component";
import { NodataComponent } from "../../../shared/components/nodata/nodata.component";
import { TableskeletonComponent } from "../../../shared/components/tableskeleton/tableskeleton.component";
import { AlertpoupComponent } from "../../../shared/components/alertpoup/alertpoup.component";
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { capitalizeEachWord, formatDatesend } from '../../../shared/utils/passmatch';





@Component({
  selector: 'app-useractivity',
  standalone: true,
  imports: [CommonModule, FormsModule, GearboxComponent, BasicFilterComponent, AdvanceFilterComponent, NodataComponent, TableskeletonComponent, AlertpoupComponent],
  templateUrl: './useractivity.component.html',
  styleUrl: './useractivity.component.css'
})
export class UseractivityComponent {





  capitalizeEachWord = capitalizeEachWord;
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;

  localUserData: any;
  allUsersData: any[] = [];
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  a_dashboard_type: any =
    "GET_TIUD_IMPORT_TRAN"
  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
  FYYear: string = "Yes"
  approvedDate: any;
  selectedRoleId: string | null = null;
  isApprovemodalOpen: boolean = false;

  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false; // Loader state
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  isOpenBulkPopup: boolean = false;
  isOpenUpdatePopup: boolean = false;
  selectedMaster: string = 'USER_MASTER';
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);

  private destroy$ = new Subject<void>();

  constructor(
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private refreshdata: RefreshdataService,

  ) {
    this.filterForm = this.fb.group({});
  }

  dynaUserData: any
  userCode: any;
  clientCode: any
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();



    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.userCode = this.localUserData?.user_code
    this.clientCode = this.dynaUserData?.client_code,
      console.log(this.clientCode)
    this.fetchUsers();
    this.alluserFilter();
    this.allUserGrandTotal();


    this.refreshSubscription = this.refreshdata.onRefresh('useractivity').subscribe(() => {
      this.fetchUsers();
      this.allUserGrandTotal();
      ;
    });

    // Get initial screen size
    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();




  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  openAddUaser(roleCode?: string) {
    this.selectedRoleCode = roleCode ?? null;
    this.isOpenAddUaser = true;
  }

  closeedAddUaser() {
    this.selectedRoleCode = null;
    this.isOpenAddUaser = false;
  }


  firstAndLastName(user: any): any {
    if (!user || typeof user.user_name !== 'string') {
      return { ...user, user_name: '' };
    }
    const nameParts = user.user_name
      .trim()
      .replace(/-/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
    const firstInitial = nameParts[0]?.[0]?.toUpperCase() || '';
    return { ...user, user_name: firstInitial };
  }


  //alluser tabledata
  fetchUsers() {
    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtdb_user_activity_log',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        dashboardType: this.a_dashboard_type,
      }


    );
    this.apiService.getTableData('/Dashboard/get_gtdb_user_activity_log', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data.result?.get_gtdb_user_activity_log;
          if (userData?.get_gtdb_user_activity_log_header) {
            this.headers = userData?.get_gtdb_user_activity_log_header.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,
              })
            );
          }
          this.allUsersData = userData || {};
          this.tableBody = userData?.get_gtdb_user_activity_log_detail || [];
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
          this.loading = false;

          this.toastService.showError(data.result[0].a_proc_error_message);
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch .';
        this.toastService.showError(error.message || 'Failed to fetch .');
        this.loading = false;
        this.isLoadingMore = false;
      },
    });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchUsers();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }


  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private alluserFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_user_activity_log',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        // dashboardType: this.a_dashboard_type,
      }
    );



    this.apiService.getFilterData('/Dashboard/get_gtfb_user_activity_log', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error === '0') {
          this.basic_filter =
            response?.result?.get_gtfb_user_activity_log?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.get_gtfb_user_activity_log?.[1]?.advance_filter;



          const defaultAdvanceFilter = this.advance_filter?.find(f => f.filter_col_external_default_value);
          const defaultValue = defaultAdvanceFilter.filter_col_external_default_value;



          this.activeFilterTab = defaultValue
          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage = response.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion

  selectedTabFilter(filterField: string, value: any, label: any): void {
    this.selectedValue = value;
    console.log(this.selectedLabel)
    this.selectedLabel = label;
    this.activeFilterTab = value;
    //Always run logic even if the tab value is the same as previous
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase(); // Convert to lowercase
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
     this.syncBasicAndAdvanceFilters()
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchUsers(), this.allUserGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }


   private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }
  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {
        // <-- KEY CHANGE HERE
        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator || 'like';
        filterValue = controlValue.toString().trim();

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;

    // return filterClause;
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return [];
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  // user grand total


  private allUserGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gtdg_user_activity_log',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        // dashboardType: this.a_dashboard_type,
      }
    );

    this.apiService.getGrandTotal('/Dashboard/get_gtdg_user_activity_log', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          // Success case
          this.usergrandtotal =
            response?.result?.get_gtdg_user_activity_log?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        // console.error('Error fetching vendor data:', error);
        this.showError('Something Went Wrong')
      },
    });
  }

  // Remove all filter label values
  clearAllFilters() {
    this.offset = 0;
    this.currentPage = 1;
    this.selectedFilters = [];
    this.filterClause = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (control) {
          control.setValue('');
        }
      });
    }
    this.filtercount = this.getSelectedFilterCount();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  openApproveModal(roleId: string) {
    this.selectedRoleId = roleId;
    this.isApprovemodalOpen = true;
  }

  //single detail alluser
  userSingleDetails(rowCode: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const requestBody = {
        sdata: JSON.stringify({
          a_proc_type: 'get_gmdt_vc_user_mast',
          a_entity_code: this.dynaUserData.entity_code,
          a_client_code: this.dynaUserData.client_code,
          a_first_level_client_code: this.dynaUserData.first_level_client_code,
          a_bank_branch_code: this.dynaUserData.bank_branch_code,
          a_client_code_level: this.dynaUserData.client_code_level,
          a_acc_year: this.dynaUserData.default_acc_year,
          a_quarter_no: this.dynaUserData.default_quarter_no,
          a_tran_month: this.dynaUserData.default_tran_month,
          a_validation_client_level: this.dynaUserData.client_code_level,
          a_user_role_type_code: this.dynaUserData.user_role_type_code,
          a_user_role_code: this.localUserData.user_role_code,
          a_tran_from_date: this.dynaUserData.default_from_date,
          a_tran_to_date: this.dynaUserData.default_to_date,
          a_tds_type_code: this.dynaUserData.default_tds_type_code,
          a_in_parameter_json: [{ a_rowid_seq: rowCode }],
        }),
      };
      this.apiService.getGrandTotal('/businesssetting/get_gmdb_vc_user_mast', requestBody).subscribe({
        next: (response) => {
          const userData =
            response?.result?.get_gmdt_vc_user_mast
              ?.get_gmdt_vc_user_mast_detail?.[0];
          if (userData) {
            this.userData = userData;
            this.approvedDate = userData.approveddate;
            resolve(userData);
          } else {
            reject('No data found.');
          }
        },
        error: () => {
          this.showError('Failed to fetch User details.');
          reject('Failed to fetch User data.');
        },
      });
    });
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'users_data'



    );
  }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }



  ///






  isPopupOpen: boolean = false;

  openPopup() {
    this.isPopupOpen = true;
  }

  closePopup() {
    this.isPopupOpen = false;
  }

  handleUserAdded(newUser: any) {
    this.closePopup();
  }



  isDrawerOpen: boolean = false;
  selectedId: string | null = null;

  openDrawer(idTofetch?: string) {
    this.selectedId = idTofetch ?? null;
    this.isDrawerOpen = true;
  }

  closeDrawer() {
    this.selectedId = null;
    this.isDrawerOpen = false;
  }









  isDeletePopupOpen = false;
  rowToDelete: any;

  openDeletePopup(row: any) {
    this.rowToDelete = row;
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    if (this.rowToDelete) {
      this.deleteRecord(this.rowToDelete);
      this.rowToDelete = null;
    }
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
    this.rowToDelete = null;
  }



  // deleteRecord(row: any) {
  //   console.log(row)
  //   const sdataTemplate = this.apiService.generateSData(
  //     'get_tiud_import_template_excel_tdsb',
  //     this.localUserData,
  //     this.filterClause,
  //     this.limit,
  //     this.offset,
  //     this.currentPage,
  //     {
  //       FYYear: this.FYYear,
  //       // iudtype: this.iudtypeError,
  //       // processStatusCode: row.process_status_code,
  //       refnumber: row.process_seqno,
  //     }
  //   );



  //   this.apiService
  //     .miudApi('/dynamic-import/get_tiud_import_template_excel_tdsb', sdataTemplate)
  //     .subscribe({
  //       next: (response) => {

  //         const result = response?.result?.[0];
  //         if (!result) {
  //           this.showError('Unexpected response format from the server.');
  //           return;
  //         }
  //         if (result.a_proc_error === 0) {
  //           // this.showSuccess(result.a_proc_error_message);
  //           this.checkRefMumber(row.process_seqno)
  //           // this.refreshdata.trigerRefresh('Allclients');
  //         } else {
  //           this.showError(
  //             result.a_proc_error_message || 'Error while creating User.'
  //           );
  //         }
  //       },
  //       error: () => {

  //         this.showError('Something went wrong! Please try again later.');
  //         // this.isSubmitting = false;
  //       },
  //     });
  // }


  // checkRefMumber(refnumber: any) {

  //   const requestBody = {
  //     a_session_seqno: '',
  //     a_iud_seqno: '',
  //     a_process_seqno: '',
  //     a_login_type: 'login_id',
  //     a_iud_type: "i",
  //     a_user_level: this.localUserData.user_level,
  //     a_proc_type: 'get_tiud_app_process_download_log',
  //     a_user_code: this.localUserData.user_code,
  //     a_entity_code: this.dynaUserData.entity_code,
  //     a_client_code: this.dynaUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_process_status_code: 'ZA',
  //     a_db_total_records: '1000',
  //     a_pagination_count: '0',
  //     app_process_download_log: {
  //       a_ref_process_seqno: refnumber,
  //       download_proc_type: 'get_tiud_import_template_excel_tdsb',
  //       main_proc_type: 'get_gtdb_user_activity_log'

  //     }

  //   }

  //   this.apiService
  //     .miudApi('/Dashboard/get_tiud_app_process_download_log', requestBody)
  //     .subscribe({
  //       next: (response) => {

  //         const result = response?.result?.[0];
  //         if (!result) {
  //           this.showError('Unexpected response format from the server.');
  //           return;
  //         }
  //         if (result.a_proc_error === 0) {
  //           this.showSuccess(result.a_proc_error_message);
  //           this.refreshdata.trigerRefresh('useractivity');
  //         } else {
  //           this.showError(
  //             result.a_proc_error_message || 'Error while creating User.'
  //           );
  //         }
  //       },
  //       error: () => {

  //         this.showError('Something went wrong! Please try again later.');
  //         // this.isSubmitting = false;
  //       },
  //     });




  // }





  deleteRecord(row: any) {
    console.log(row);


    const procType = row.proc_type || 'get_tiud_import_template_excel_tdsb';

    const sdataTemplate = this.apiService.generateSData(
      procType,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: row.process_seqno,
      }
    );

    this.apiService
      .getTableData('/Comman/dynamic', sdataTemplate)
      .subscribe({
        next: (response) => {
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            // Success → check reference number
            this.checkRefNumber(row.process_seqno, procType);
          } else {
            this.checkRefNumber(row.process_seqno, procType);
            // this.showError(result.a_proc_error_message || 'Error while creating User.');
          }
        },
        error: () => {
          this.showError('Something went wrong! Please try again later.');
        },
      });
  }


  checkRefNumber(refnumber: any, procType: string) {

    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type: "i",
      a_user_level: this.localUserData.user_level,
      a_proc_type: 'get_tiud_app_process_download_log',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      app_process_download_log: {
        a_ref_process_seqno: refnumber,
        download_proc_type: procType,
        main_proc_type: 'get_gtdb_user_activity_log'
      }
    }

    this.apiService
      .miudApi('/Dashboard/get_tiud_app_process_download_log', requestBody)
      .subscribe({
        next: (response) => {
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message);
            this.refreshdata.trigerRefresh('useractivity');
          } else {
            this.showError(result.a_proc_error_message || 'Error while creating User.');
          }
        },
        error: () => {
          this.showError('Something went wrong! Please try again later.');
        },
      });
  }

  shouldCapitalize(field: string): boolean {
    // Skip capitalization for these fields
    const noCapFields = ['tds_type_code', 'upload_file_name', 'stream_name', 'process_status_code'];
    return !noCapFields.includes(field);
  }



  isDateField(field: string): boolean {
    const dateFields = ['process_start_timestamp', 'process_end_timestamp', 'tds_deduct_date'];
    return dateFields.includes(field);
  }


  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }



  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }


  downloadBtn(userCode: string, clientCode: string, filename: string) {
    console.log(userCode, clientCode, filename)
    this.apiService.fileDownloads(userCode, clientCode, filename);
  }

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }






}
