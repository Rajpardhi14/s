import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as bcrypt from 'bcryptjs';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import * as CryptoJS from 'crypto-js';




@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './change-password.component.html',
  styleUrl: './change-password.component.css'
})
export class ChangePasswordComponent {

  @Input() changePassword: boolean = false;
  @Output() ClosedChangePassword = new EventEmitter<void>();

  localUserData: any;
  changePasswordForm!: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';
  isLoading: boolean = false; // Added loading state
  userCode: any;
  passKey: any;

  constructor(
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private route: ActivatedRoute,
    private authService: AuthService,
    // private businessService: BusinesssettingService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    console.log(this.localUserData.login_id);
    this.route.queryParams.subscribe((params) => {
      if (params['token']) {
        try {
          // decode base64 JSON
          const decoded = JSON.parse(atob(params['token'].split('.')[0] || params['token']));
          console.log('Decoded token:', decoded);

          // this.email = decoded.email_id || '';
          this.userCode = decoded.user_code || '';
          // If backend includes pass_key in token, grab it
          this.passKey = decoded.pass_key || '';
        } catch (err) {
          console.error('Invalid token format', err);
        }
      }
    });

    this.changePasswordForm = this.fb.group({
      currentPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
          ),
          this.currentPasswordValidator(this.localUserData.old_pwd)
        ],
      ],

      newPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
          ),
        ],
      ],
      confirmPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
          ),
        ],
      ],
    });


    //  once localUserData is available, attach custom validator
    const control = this.changePasswordForm.get('currentPassword');
    console.log(control);
    control?.addValidators(this.currentPasswordValidator(this.localUserData.old_pwd));
    control?.updateValueAndValidity();
  }

  // custom validator
  currentPasswordValidator(actualPassword: string): ValidatorFn {
    console.log(actualPassword);

    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) return null; // let `required` handle empty case
      return control.value === actualPassword ? null : { incorrect: true };
    };
  }




  resetPass() {
    this.changePasswordForm.reset();
    this.ClosedChangePassword.emit();
  }

  //password visi svg
  passwordVisibility = {
    currentPassword: false,
    newPassword: false,
    confirmPassword: false,
  };
  togglePasswordVisibility(
    field: 'currentPassword' | 'newPassword' | 'confirmPassword'
  ): void {
    this.passwordVisibility[field] = !this.passwordVisibility[field];
  }

  get f() {
    return this.changePasswordForm.controls;
  }



  //   validateCurrentPassword(): boolean {
  //   const enteredPassword = this.changePasswordForm.value.currentPassword;

  //   if (!enteredPassword) {
  //     return false;
  //   }

  //   // Compare entered password with saved password
  //   const isMatch = bcrypt.compareSync(enteredPassword, this.localUserData.old_pwd);

  //   return isMatch;
  // }

  checkCurrentPassword(): void {
    const isValid = this.validateCurrentPassword();
    if (!isValid) {
      this.changePasswordForm.get('currentPassword')?.setErrors({ incorrect: true });
    } else {
      this.changePasswordForm.get('currentPassword')?.setErrors(null);
    }
  }



  validateCurrentPassword(): boolean {
    const enteredPassword = this.changePasswordForm.value.currentPassword;
    if (!enteredPassword) return false;

    try {
      // Decode Base64 combined data (IV + ciphertext)
      const combined = CryptoJS.enc.Base64.parse(this.localUserData.old_pwd);

      // Extract IV (first 16 bytes = 128 bits = 4 words)
      const iv = CryptoJS.lib.WordArray.create(
        combined.words.slice(0, 4),
        16
      );

      // Extract ciphertext (remaining bytes)
      const cipherText = CryptoJS.lib.WordArray.create(
        combined.words.slice(4),
        combined.sigBytes - 16
      );

      // Derive AES key = SHA-256(login_id)
      const key = CryptoJS.SHA256(this.localUserData.login_id);

      // Wrap ciphertext in a CipherParams object (fixes TS error)
      const cipherParams = CryptoJS.lib.CipherParams.create({
        ciphertext: cipherText,
      });

      // Decrypt using AES-CBC
      const decrypted = CryptoJS.AES.decrypt(cipherParams, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const originalPassword = decrypted.toString(CryptoJS.enc.Utf8);
      console.log('Decrypted password:', originalPassword);

      return enteredPassword === originalPassword;
    } catch (e) {
      console.error('Password decryption failed:', e);
      return false;
    }
  }



  onSubmit(): void {
    if (this.changePasswordForm.invalid) {
      this.changePasswordForm.markAllAsTouched();
      return;
    }

    if (!this.validateCurrentPassword()) {
      this.errorMessage = 'Current password is incorrect!';
      this.toastService.showError(this.errorMessage);
      return;
    }

    if (this.f['newPassword'].value !== this.f['confirmPassword'].value) {
      this.errorMessage = 'New password and confirm password must match!';
      this.toastService.showError(this.errorMessage);
      return;
    }
    const saltRounds = 10;
    const newPassword = this.changePasswordForm.value.newPassword;
    const hashedPassword = bcrypt.hashSync(newPassword, saltRounds);

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: '',
        a_iud_seqno: '',
        a_process_seqno: '',
        a_login_type: 'login_id',
        a_iud_type: 'rp',
        a_proc_type: 'get_miud_user_mast',
        a_user_code: '',
        a_entity_code: 'T1',
        a_client_code: '1686992',
        a_acc_year: '23-24',
        a_quarter_no: '4',
        a_tran_month: 'JAN',
        a_tran_from_date: '01-JAN-2024',
        a_tran_to_date: '31-MAR-2024',
        a_tds_type_code: '24Q',
        a_module_type_code: 'TAXCPC',
        a_first_level_client_code: '',
        a_process_status_code: 'ZA',
        a_db_total_records: '1000',
        a_pagination_count: '0',

        user_mast: {
          user_code: this.localUserData.user_code,
          login_pwd: hashedPassword
        }
      }),
    };
    this.authService.changepassword(requestBody).subscribe(
      (response: any) => {
        this.isLoading = false;
        // this.isSubmitting = false;
        if (response.result[0].a_proc_error == -1) {
          // Failure
          const message = response.result[0].a_proc_error_message || 'Password reset failed!';
          this.toastService.showError(message);
          // Success

        } else {
          const message = response.result[0].a_proc_error_message || 'Password reset successfully!';
          this.toastService.showSuccess(message);
          this.router.navigate(['/passresetsuccessful']);

        }

      },
      (error) => {
        this.isLoading = false;
        // this.isSubmitting = false;
        this.toastService.showError('An error occurred. Please try again.');
      }
    );

  }
}
