import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { FormsModule } from '@angular/forms';
import { ChangePasswordComponent } from './change-password/change-password.component';

import { Router } from '@angular/router';
import { SessionData, SessionService } from '../../../core/services/session/session/session.service';
import { BASE_API_URL } from '../../../core/constants/endpoint';

@Component({
  selector: 'app-security',
  standalone: true,
  imports: [CommonModule, FormsModule,ChangePasswordComponent,],
  templateUrl: './security.component.html',
  styleUrl: './security.component.css'
})
export class SecurityComponent implements OnInit {
  sessionData: SessionData[] = [];
  isLoading: boolean = false;
  isBrowser: boolean;
  twoFactorEnabled: boolean = false;
  currentSessionId: string = '';

  openPasswordPopup:boolean = false;
  


  // 2FA Setup
  show2FASetup: boolean = false;
  show2FADisable: boolean = false;
  twoFactorSecret: string = '';
  twoFactorQRCode: string = '';
  twoFactorBackupCodes: string[] = [];
  verificationCode: string = '';
  disableVerificationCode: string = '';
  isVerifying: boolean = false;
  show2FABackupCodes: boolean = false;
  userEmail: string = '';

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private http: HttpClient,
    private toastService: ToastService,
    private authService: AuthService,
    private sessionService: SessionService,
    private router: Router
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  ngOnInit(): void {
    if (this.isBrowser) {
      this.loadActiveSessions();
      this.loadSecuritySettings();
      this.getCurrentSessionId();
      this.getUserEmail();
    }
  }

  // Get current session ID from localStorage or sessionStorage
  getCurrentSessionId(): void {
    if (this.isBrowser) {
      const userData = sessionStorage.getItem('localUserData');
      if (userData) {
        const user = JSON.parse(userData);
        this.currentSessionId = user.sessionId || sessionStorage.getItem('sessionId') || '';
      }
    }
  }

  // Get user email for 2FA
  getUserEmail(): void {
    if (this.isBrowser) {
      const userData = sessionStorage.getItem('localUserData');
      if (userData) {
        const user = JSON.parse(userData);
        this.userEmail = user.email_id || user.login_id || 'user@example.com';
      }
    }
  }

  // Load active sessions from backend
  async loadActiveSessions(): Promise<void> {
    this.isLoading = true;
    
    try {
      // Get user data
      let userId = '';
      if (this.isBrowser) {
        const userData = sessionStorage.getItem('localUserData');
        if (userData) {
          const user = JSON.parse(userData);
          userId = user.user_code || user.entity_code || '';
        }
      }

      if (!userId) {
        console.warn('No user ID found');
        this.sessionData = [];
        return;
      }

      // Get active sessions from API
      this.sessionService.getActiveSessions(userId).subscribe({
        next: (sessions) => {
          this.sessionData = sessions;
          this.currentSessionId = this.sessionService.getCurrentSessionId();
          
          // Mark current session
          this.sessionData.forEach(session => {
            if (session.sessionId === this.currentSessionId) {
              session.isCurrentSession = true;
            }
          });
          
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error loading sessions:', error);
          this.toastService.showError('Failed to load active sessions');
          this.sessionData = [];
          this.isLoading = false;
        }
      });

    } catch (error) {
      console.error('Error loading sessions:', error);
      this.toastService.showError('Failed to load active sessions');
      this.isLoading = false;
    }
  }

  // Load security settings
  loadSecuritySettings(): void {
    if (this.isBrowser) {
      // First check from user data
      const userData = sessionStorage.getItem('localUserData');
      if (userData) {
        const user = JSON.parse(userData);
        // Check tfa_flag from login response
        this.twoFactorEnabled = user.tfa_flag === 'Y' || user.tfa_flag === 'y' || 
                               user.is_mfa === 'Y' || user.is_mfa === 'y';
      }
      
      // Also check local settings as fallback
      const settings = sessionStorage.getItem('securitySettings');
      if (settings && !this.twoFactorEnabled) {
        const parsed = JSON.parse(settings);
        this.twoFactorEnabled = parsed.twoFactorEnabled || false;
      }
    }
  }

  // Revoke/Logout a specific session
  async revokeSession(sessionId: string, isCurrentSession: boolean): Promise<void> {
    if (isCurrentSession) {
      const confirmed = confirm('This will log you out of your current session. Are you sure?');
      if (!confirmed) return;
    } else {
      const confirmed = confirm('Are you sure you want to revoke this session?');
      if (!confirmed) return;
    }

    try {
      // Get user code
      let userCode = '';
      if (this.isBrowser) {
        const userData = sessionStorage.getItem('localUserData');
        if (userData) {
          const user = JSON.parse(userData);
          userCode = user.user_code || user.entity_code || '';
        }
      }

      // Call API to revoke session with user code
      this.sessionService.revokeSession(sessionId, userCode).subscribe({
        next: (response) => {
          if (isCurrentSession) {
            // Logout current session
            this.toastService.showSuccess('Logging out...');
            setTimeout(() => {
              // Clear local storage and redirect to login
              if (this.isBrowser) {
                // sessionStorage.clear();
                sessionStorage.clear();
                this.router.navigate(['/']);
              }
            }, 1000);
          } else {
            // Remove session from list
            this.sessionData = this.sessionData.filter(s => s.sessionId !== sessionId);
            this.toastService.showSuccess('Session revoked successfully');
          }
        },
        error: (error) => {
          console.error('Error revoking session:', error);
          this.toastService.showError('Failed to revoke session. Please try again.');
        }
      });
      
    } catch (error) {
      console.error('Error revoking session:', error);
      this.toastService.showError('Failed to revoke session');
    }
  }

  // Revoke all other sessions
  async revokeAllOtherSessions(): Promise<void> {
    const confirmed = confirm('This will log out all other devices. Are you sure?');
    if (!confirmed) return;

    try {
      // Get user data
      let userId = '';
      if (this.isBrowser) {
        const userData = sessionStorage.getItem('localUserData');
        if (userData) {
          const user = JSON.parse(userData);
          userId = user.user_code || user.entity_code || '';
        }
      }

      if (!userId) {
        this.toastService.showError('User information not found');
        return;
      }

      // Use the revoke-all endpoint from C# API
      this.sessionService.revokeAllSessions(userId, true).subscribe({
        next: (response) => {
          if (response?.success) {
            // Update session list to show only current session
            this.sessionData = this.sessionData.filter(s => s.isCurrentSession);
            const revokedCount = response.data?.revoked_count || 0;
            this.toastService.showSuccess(`Successfully revoked ${revokedCount} session(s)`);
          } else {
            this.toastService.showError('Failed to revoke sessions');
          }
        },
        error: (error) => {
          console.error('Error revoking all sessions:', error);
          this.toastService.showError('Failed to revoke sessions. Please try again.');
        }
      });
      
    } catch (error) {
      console.error('Error revoking sessions:', error);
      this.toastService.showError('Failed to revoke sessions');
    }
  }

  // Toggle 2FA - Show setup or disable modal
  async toggle2FA(): Promise<void> {
    console.log('Toggle 2FA called, current state:', this.twoFactorEnabled);
    
    // If currently disabled, show setup modal
    if (!this.twoFactorEnabled) {
      console.log('Setting up 2FA...');
      await this.setup2FA();
    } else {
      // If currently enabled, show disable modal
      console.log('Showing disable modal...');
      this.show2FADisableModal();
    }
  }

  // Setup 2FA
  async setup2FA(): Promise<void> {
    console.log('setup2FA called');
    
    try {
      // IMPORTANT: In production, the secret should be generated by backend
      // For now, we generate it client-side but will send to backend for storage
      let secret = '';
      let otpauth = '';
      
      // Generate secret manually (browser-compatible)
      secret = this.generateBase32Secret();
      this.twoFactorSecret = secret;
      console.log('2FA Secret generated, length:', secret.length);
      
      // Generate otpauth URL manually
      const appName = 'TDS CPC';
      const accountName = this.userEmail || 'user@tdsolve.com';
      otpauth = `otpauth://totp/${encodeURIComponent(appName)}:${encodeURIComponent(accountName)}?secret=${secret}&issuer=${encodeURIComponent(appName)}&algorithm=SHA1&digits=6&period=30`;
      console.log('OTPAuth URL generated for:', accountName);

      // Generate QR code for the authenticator app
      console.log('Generating QR code...');
      const QRCode = await import('qrcode') as any;
      this.twoFactorQRCode = await QRCode.toDataURL(otpauth, {
        errorCorrectionLevel: 'M',
        type: 'image/png',
        quality: 0.92,
        margin: 1,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        },
        width: 256
      });
      console.log('QR Code generated successfully');

      // Generate backup codes
      this.generateBackupCodes();
      
      // IMPORTANT: Store the secret temporarily in session storage (not localStorage)
      // This will be cleared after verification
      sessionStorage.setItem('temp2FASecret', secret);
      
      // Show setup modal
      this.show2FASetup = true;
      console.log('2FA Setup modal should be visible now');

    } catch (error) {
      console.error('Error setting up 2FA - Full error:', error);
      this.toastService.showError('Failed to setup 2FA: ' + (error as any).message);
    }
  }

  // Generate random Base32 secret for 2FA (browser-compatible)
  private generateBase32Secret(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let secret = '';
    
    // Use crypto.getRandomValues for better randomness if available
    if (this.isBrowser && window.crypto && window.crypto.getRandomValues) {
      const array = new Uint8Array(32);
      window.crypto.getRandomValues(array);
      for (let i = 0; i < 32; i++) {
        secret += chars[array[i] % chars.length];
      }
    } else {
      // Fallback to Math.random
      for (let i = 0; i < 32; i++) {
        secret += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }
    
    return secret;
  }
  
  // Manual TOTP verification (simplified fallback)
  private verifyTOTPManually(token: string, secret: string): boolean {
   
    if (/^\d{6}$/.test(token)) {
      console.warn('Using simplified verification - NOT FOR PRODUCTION');
   
      return true;
    }
    
    return false;
  }


  // Generate backup codes
  generateBackupCodes(): void {
    this.twoFactorBackupCodes = [];
    
    // Use crypto.getRandomValues for better randomness if available
    if (this.isBrowser && window.crypto && window.crypto.getRandomValues) {
      for (let i = 0; i < 8; i++) {
        const array = new Uint8Array(4);
        window.crypto.getRandomValues(array);
        const code = Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('').toUpperCase();
        this.twoFactorBackupCodes.push(code);
      }
    } else {
      // Fallback to Math.random
      for (let i = 0; i < 8; i++) {
        const code = Math.random().toString(36).substring(2, 10).toUpperCase();
        this.twoFactorBackupCodes.push(code);
      }
    }
  }

  // Verify 2FA code and enable
  async verify2FACode(): Promise<void> {
    if (!this.verificationCode || this.verificationCode.length !== 6) {
      this.toastService.showError('Please enter a valid 6-digit code');
      return;
    }

    this.isVerifying = true;

    try {
      // Get user data
      const userData = JSON.parse(sessionStorage.getItem('localUserData') || '{}');
      const userCode = userData.user_code || userData.entity_code || '';
      
      // Get the temporary secret from session storage
      const tempSecret = sessionStorage.getItem('temp2FASecret') || this.twoFactorSecret;
      
      // Note: Verification is done server-side for security
      // The backend will verify the TOTP code against the secret

      // Call backend API to enable 2FA
      // The backend should store the secret securely
      const requestBody = {
        user_code: userCode,
        entity_code: userData.entity_code || '',
        verification_code: this.verificationCode,
        two_factor_secret: tempSecret, // Backend should encrypt this
        backup_codes: this.twoFactorBackupCodes,
        enabled_at: new Date().toISOString(),
        tfa_flag: 'Y' // Set the flag to Y when enabling
      };

      // Call your backend endpoint
      this.http.post(`${BASE_API_URL}/api/user/2fa/verify-enable`, requestBody).subscribe({
        next: (response: any) => {
          // Clear the temporary secret from session storage
          sessionStorage.removeItem('temp2FASecret');
          
          // Update local user data with new tfa_flag
          if (this.isBrowser) {
            const userData = sessionStorage.getItem('localUserData');
            if (userData) {
              const user = JSON.parse(userData);
              user.tfa_flag = 'Y'; // Update the flag
              user.is_mfa = 'Y'; // Also update MFA flag if present
              sessionStorage.setItem('localUserData', JSON.stringify(user));
            }
            
            // Store that 2FA is enabled (without secret)
            const settings = {
              twoFactorEnabled: true,
              // DO NOT store secret or backup codes in localStorage
              enabledAt: new Date().toISOString()
            };
            sessionStorage.setItem('securitySettings', JSON.stringify(settings));
          }

          this.twoFactorEnabled = true;
          this.show2FASetup = false;
          this.show2FABackupCodes = true;
          this.toastService.showSuccess('Two-factor authentication has been enabled successfully!');
        },
        error: (error) => {
          console.error('Error enabling 2FA:', error);
          this.toastService.showError('Failed to enable 2FA on server. Please try again.');
          this.isVerifying = false;
        }
      });
      
    } catch (error) {
      console.error('Error verifying 2FA:', error);
      this.toastService.showError('Failed to enable 2FA. Please try again.');
    } finally {
      this.isVerifying = false;
    }
  }

  // Show disable 2FA modal
  show2FADisableModal(): void {
    this.show2FADisable = true;
    this.disableVerificationCode = '';
  }

  // Disable 2FA after verification
  async disable2FA(): Promise<void> {
    if (!this.disableVerificationCode || this.disableVerificationCode.length !== 6) {
      this.toastService.showError('Please enter a valid 6-digit code');
      return;
    }

    this.isVerifying = true;

    try {
      // Get stored secret
      let storedSecret = '';
      if (this.isBrowser) {
        const settings = sessionStorage.getItem('securitySettings');
        if (settings) {
          const parsed = JSON.parse(settings);
          storedSecret = parsed.twoFactorSecret || '';
        }
      }

      // Note: Verification will be done server-side
      // The backend will verify the code before disabling 2FA

      // Get user data for the request
      const userData = JSON.parse(sessionStorage.getItem('localUserData') || '{}');
      const userCode = userData.user_code || userData.entity_code || '';
      
      // Call backend to disable 2FA
      const disableRequest = {
        user_code: userCode,
        entity_code: userData.entity_code || '',
        verification_code: this.disableVerificationCode,
        tfa_flag: 'N' // Set flag to N when disabling
      };
      
      this.http.post(`${BASE_API_URL}/user/2fa/disable`, disableRequest).subscribe({
        next: (response: any) => {
          // Update local user data with new tfa_flag
          if (this.isBrowser) {
            const userData = sessionStorage.getItem('localUserData');
            if (userData) {
              const user = JSON.parse(userData);
              user.tfa_flag = 'N'; // Update the flag
              user.is_mfa = 'N'; // Also update MFA flag if present
              sessionStorage.setItem('localUserData', JSON.stringify(user));
            }
            
            const settings = {
              twoFactorEnabled: false,
              twoFactorSecret: null,
              backupCodes: [],
              updatedAt: new Date().toISOString()
            };
            sessionStorage.setItem('securitySettings', JSON.stringify(settings));
          }

          this.twoFactorEnabled = false;
          this.show2FADisable = false;
          this.toastService.showSuccess('Two-factor authentication has been disabled');
        },
        error: (error) => {
          console.error('Error disabling 2FA:', error);
          this.toastService.showError('Failed to disable 2FA. Please try again.');
          this.isVerifying = false;
        }
      });
      
    } catch (error) {
      console.error('Error disabling 2FA:', error);
      this.toastService.showError('Failed to disable 2FA. Please try again.');
    } finally {
      this.isVerifying = false;
    }
  }

  // Close modals
  close2FASetup(): void {
    this.show2FASetup = false;
    this.verificationCode = '';
    this.twoFactorQRCode = '';
    this.twoFactorSecret = '';
  }

  close2FADisable(): void {
    this.show2FADisable = false;
    this.disableVerificationCode = '';
  }

  closeBackupCodes(): void {
    this.show2FABackupCodes = false;
  }

  // Copy text to clipboard
  copyToClipboard(text: string): void {
    if (this.isBrowser && navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        this.toastService.showSuccess('Copied to clipboard');
      }).catch(err => {
        console.error('Failed to copy:', err);
      });
    }
  }

  // Download backup codes
  downloadBackupCodes(): void {
    if (!this.isBrowser) return;
    
    const content = `Two-Factor Authentication Backup Codes
Generated: ${new Date().toLocaleString()}
Account: ${this.userEmail}

IMPORTANT: Keep these codes in a safe place. Each code can only be used once.

${this.twoFactorBackupCodes.map((code, i) => `${i + 1}. ${code}`).join('\n')}

Use these codes to access your account if you lose access to your authenticator app.`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tds-solve-backup-codes.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  // Format date for display
  formatDate(dateString: string): string {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    };
    return date.toLocaleString('en-IN', options);
  }

  // Get device icon based on device type
  getDeviceIcon(device: string): string {
    if (device.toLowerCase().includes('mobile') || device.toLowerCase().includes('android') || device.toLowerCase().includes('iphone')) {
      return '📱';
    } else if (device.toLowerCase().includes('tablet') || device.toLowerCase().includes('ipad')) {
      return '⬜';
    } else {
      return '💻';
    }
  }

  // Generate random session ID for demo
  private generateSessionId(): string {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  openChangePassword() {
this.openPasswordPopup = true;
}

closeChangePassword() {
  this.openPasswordPopup = false;
}


 
}
