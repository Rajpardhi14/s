import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-subscription',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './subscription.component.html',
  styleUrl: './subscription.component.css'
})
export class SubscriptionComponent {

 subscriptionDetails = [
  {
    planPeriod: '07 May 2025 - 21 May 2025',
    allotted: {
      users: '10 Users',
      storage: '50 GB'
    },
    status: 'Active'
  },
  {
    planPeriod: '01 Jan 2024 - 31 Dec 2024',
    allotted: {
      users: '5 Users',
      storage: '20 GB'
    },
    status: 'Inactive'
  }
];


}
