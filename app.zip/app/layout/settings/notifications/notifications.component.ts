import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { HttpClient } from '@angular/common/http';

interface NotificationSettings {
  email: boolean;
  desktop: boolean;
  security: boolean;
  updates: boolean;
}

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './notifications.component.html',
  styleUrl: './notifications.component.css'
})
export class NotificationsComponent implements OnInit {
  
  // Simplified notification settings
  notificationSettings: NotificationSettings = {
    email: true,
    desktop: true,
    security: true,
    updates: false
  };

  originalSettings: string = '';
  hasChanges: boolean = false;
  isLoading: boolean = false;
  isBrowser: boolean;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private toastService: ToastService,
    private authService: AuthService,
    private http: HttpClient
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  ngOnInit(): void {
    if (this.isBrowser) {
      this.loadSettings();
      this.checkNotificationPermission();
    }
  }

  // Load settings from localStorage
  loadSettings(): void {
    // Check if running in browser
    if (!this.isBrowser) {
      return;
    }
    
    try {
      const savedSettings = localStorage.getItem('notificationSettings');
      if (savedSettings) {
        this.notificationSettings = JSON.parse(savedSettings);
        this.originalSettings = savedSettings;
      } else {
        // Save default settings if none exist
        this.saveSettingsLocally(false);
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
      this.toastService.showError('Failed to load notification settings');
    }
  }

  // Save settings to localStorage only
  saveSettingsLocally(showToast: boolean = false): void {
    // Check if running in browser
    if (!this.isBrowser) {
      return;
    }
    
    try {
      const settingsJson = JSON.stringify(this.notificationSettings);
      localStorage.setItem('notificationSettings', settingsJson);
      
      if (showToast) {
        this.toastService.showSuccess('Settings saved locally!');
      }
    } catch (error) {
      console.error('Error saving notification settings:', error);
      this.toastService.showError('Failed to save notification settings');
    }
  }

  // Check if settings have changed
  checkForChanges(): void {
    const currentSettings = JSON.stringify(this.notificationSettings);
    this.hasChanges = currentSettings !== this.originalSettings;
  }

  // Toggle setting (only updates local state, doesn't save)
  async toggleSetting(setting: keyof NotificationSettings): Promise<void> {
    // Special handling for desktop notifications when enabling
    if (setting === 'desktop') {
      const currentValue = this.notificationSettings.desktop;
      
      if (!currentValue) {
        // User is trying to enable desktop notifications
        const permissionGranted = await this.requestNotificationPermission();
        if (!permissionGranted) {
          // Permission denied, don't enable the setting
          // Error message is already shown in requestNotificationPermission
          return;
        }
      }
    }
    
    // Toggle the setting
    this.notificationSettings[setting] = !this.notificationSettings[setting];
    this.checkForChanges(); // Check if there are changes to enable/disable Save button
  }

  // Save to database when Save button is clicked
  async saveToDatabase(): Promise<void> {
    if (!this.hasChanges || this.isLoading) {
      return;
    }

    this.isLoading = true;

    try {
      // Get user data from localStorage (with browser check)
      let userData: any = {};
      if (this.isBrowser) {
        const localUserData = localStorage.getItem('localUserData');
        userData = localUserData ? JSON.parse(localUserData) : {};
      }
      
      // Prepare data for API call
      const notificationData = {
        user_code: userData.user_code || userData.entity_code || '',
        entity_code: userData.entity_code || '',
        notification_settings: JSON.stringify(this.notificationSettings),
        email_notifications: this.notificationSettings.email,
        desktop_notifications: this.notificationSettings.desktop,
        security_alerts: this.notificationSettings.security,
        product_updates: this.notificationSettings.updates
      };

      // TODO: Replace with actual API endpoint when available
      // For now, simulate API call with timeout
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Uncomment and update when API endpoint is available:
      // const response = await this.http.post('/api/notifications/update', notificationData).toPromise();
      
      // Save to localStorage
      this.saveSettingsLocally(false);
      this.originalSettings = JSON.stringify(this.notificationSettings);
      this.hasChanges = false;
      
      this.toastService.showSuccess('Notification settings saved successfully!');
      
    } catch (error) {
      console.error('Error saving to database:', error);
      this.toastService.showError('Failed to save notification settings. Please try again.');
    } finally {
      this.isLoading = false;
    }
  }

  // Request browser notification permission
  async requestNotificationPermission(): Promise<boolean> {
    // Check if running in browser and browser supports notifications
    if (!this.isBrowser || !('Notification' in window)) {
      this.toastService.showError('Your browser does not support notifications');
      return false;
    }

    // Check current permission status
    if (Notification.permission === 'granted') {
      return true;
    }

    // If permission is denied, user needs to change it in browser settings
    if (Notification.permission === 'denied') {
      this.toastService.showError('Notifications are blocked. Click the lock icon in your address bar and allow notifications, then refresh the page.');
      return false;
    }

    // Request permission
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        // Show a test notification
        this.showTestNotification();
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }

  // Show a test notification when permission is granted
  showTestNotification(): void {
    if (this.isBrowser && Notification.permission === 'granted') {
      const notification = new Notification('Notifications Enabled!', {
        body: 'You will now receive desktop notifications.',
        icon: '/assets/icons/notification-icon.png', // You can add an icon if available
        badge: '/assets/icons/badge-icon.png', // You can add a badge if available
        tag: 'test-notification',
        requireInteraction: false
      });

      // Close notification after 3 seconds
      setTimeout(() => notification.close(), 3000);
    }
  }

  // Check notification permission status on load
  checkNotificationPermission(): void {
    // Check if running in browser
    if (this.isBrowser && 'Notification' in window) {
      // Only modify settings if permission is explicitly denied
      if (Notification.permission === 'denied') {
        // If notifications are blocked in browser, disable the setting
        if (this.notificationSettings.desktop) {
          this.notificationSettings.desktop = false;
          this.saveSettingsLocally(false);
          console.log('Desktop notifications disabled due to browser permission denial');
        }
      } else if (Notification.permission === 'granted' && this.notificationSettings.desktop) {
        // Permission is granted and setting is enabled
        console.log('Desktop notifications are enabled');
      } else if (Notification.permission === 'default') {
        // Permission not yet requested - don't show error, just log
        console.log('Notification permission not yet requested');
      }
    } else if (this.isBrowser) {
      // Browser doesn't support notifications
      console.log('Browser does not support notifications');
      if (this.notificationSettings.desktop) {
        this.notificationSettings.desktop = false;
        this.saveSettingsLocally(false);
      }
    }
  }

  // Get notification permission status for display
  getNotificationStatus(): string {
    if (!this.isBrowser || !('Notification' in window)) {
      return 'unsupported';
    }
    
    if (Notification.permission === 'denied') {
      return 'blocked';
    }
    
    if (Notification.permission === 'granted') {
      return 'granted';
    }
    
    return 'default';
  }

  // Cancel changes
  cancelChanges(): void {
    if (this.hasChanges) {
      if (confirm('Are you sure you want to discard your changes?')) {
        this.loadSettings();
        this.hasChanges = false;
      }
    }
  }

  // Utility method to send notifications (can be used throughout the app)
  sendNotification(title: string, options?: NotificationOptions): void {
    if (!this.notificationSettings.desktop) {
      console.log('Desktop notifications are disabled');
      return;
    }

    if (this.isBrowser && 'Notification' in window && Notification.permission === 'granted') {
      try {
        const notification = new Notification(title, {
          ...options,
          icon: options?.icon || '/assets/icons/notification-icon.png',
          badge: options?.badge || '/assets/icons/badge-icon.png',
        });

        // Auto close after 5 seconds if not specified
        const autoCloseTime = (options as any)?.autoClose || 5000;
        if (autoCloseTime > 0) {
          setTimeout(() => notification.close(), autoCloseTime);
        }

        // Handle notification click
        notification.onclick = () => {
          window.focus();
          notification.close();
          // You can add custom click handling here
          if ((options as any)?.onClick) {
            (options as any).onClick();
          }
        };
      } catch (error) {
        console.error('Error showing notification:', error);
      }
    }
  }
}