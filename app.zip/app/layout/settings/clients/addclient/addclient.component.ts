import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';

import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { OutSideClickDirective } from '../../../../core/services/outclick/outside-click.directive';
import { Router } from '@angular/router';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { debounceTime, distinctUntilChanged, filter, merge, Subject, takeUntil, tap, Observable, map, catchError, throwError } from 'rxjs';
import { RefreshdataService } from '../../../../core/services/refreshdata/refreshdata.service';
import { ButtoneventlisnerDirective } from '../../../../core/services/session/timer-session/buttoneventlisner.directive';

interface Option { label: string; value: any; typeCode?: any; }

interface FieldConfig {
  label: string;
  control: string;
  type: string;
  required?: boolean; //  optional
}

@Component({
  selector: 'app-addclient',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, OutSideClickDirective,ButtoneventlisnerDirective],
  templateUrl: './addclient.component.html',
  styleUrl: './addclient.component.css'
})
export class AddclientComponent {

  @Input() isDrawerOpen: any;
  @Input() selectedRowId: any;
  @Input() consoData: any = null; // Data from CONSO file to pre-fill form
  @Output() close = new EventEmitter<void>();
  @Output() closeaddpopup = new EventEmitter<void>();
  clientForm!: FormGroup;
  openInfoId: number | null = 1;
  currentStep = 1;
  pendingStepId: number | null = null;
  isEditMode: boolean = true;
  RentData: any;
  isEditingPreviousStep: boolean = false;
  showStateOption: boolean = false;
  showDeductorStateOption: boolean = false;
  isSubmittingUpdate = false;
  ClientDetailsStep: boolean = false;
  AddressStep: boolean = false;
  ResponsibleStep: boolean = false;
  addressDetails: any[] = [];
  showConfirmModal = false;
  localUserData: any;
  isCompleted = false;
  selectedClientLevelLabel: any;
  selectedClientLevelValue: any;
  // clientTypeOptions:any;
  codeLevelOptions: any;
  parentCodeOptions: any;
  stateMastOptions: any;
  // clientCategoryOptions:any;
  filteredCategoryOptions: { label: string; value: string; typeCode: string }[] = [];
  selectedClientType: string = '';
  clientTypeOptions: any[] = [];
  clientCategoryOptions: any[] = [];

  searchText = '';
  filteredStateOptions: any[] = [];
  filteredDeductorStateOptions: any[] = [];
  selectedStateOptionLabel = '';
  selectedStateOptionValue: any;
  selectedDeductorStateOptionLabel = '';
  selectedDeductorStateOptionValue: any;
  isaddCompleted = false;
  isResponsibleCompleted = false;
  iscredentialComplete = false;
  UserData: any;
  entity_code: any;
  pinCode: any;
  selectedParentCodeValue: any;
  filteredClientTypeOptions: any[] = [];
  isFetchingTanData: boolean = false;
  serverErrors: { [key: string]: string } = {}; // Store server errors separately

  private destroy$ = new Subject<void>();
  dynamicUserData: any;
    multiMast:any;
      localstoredClientTypeData: any;


        ngOnChanges(changes: SimpleChanges): void {
    // this.isLoading = true;
    if (changes['selectedRowId'] && this.selectedRowId) {

      // this.fetchUserDetails(this.selectedRowId);
      this.isEditMode = false;
      this.isDrawerOpen = true;
         this.initializeForm();

    } else {
      // this.isLoading = false;
      this.isEditMode = true;
      this.initializeForm();
    }
    if (!this.isEditMode) {
      this.openInfoId = null; // collapse all
    }

  }

  ngOnInit(): void {

    // this.initializeForm();
    // this.getLocalUserData();
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};

// this.getsData();
    this.initializeForm();

    if (this.selectedRowId) {
      this.detailsLoader = true;
    }

    this.getsData().subscribe({
      next: () => {
        if (this.selectedRowId) {
          this.fetchUserDetails(this.selectedRowId);
        }
           // Pre-fill form if CONSO data is provided
    if (this.consoData) {
      this.prefillFormWithConsoData();
    }
      },
      error: (err) => console.error(err),
    });



    // Subscribe to TANNO changes


    if (!this.selectedRowId || !this.isEditMode) {
      this.clientForm.get('tanno')?.valueChanges
        .pipe(
          debounceTime(500),
          distinctUntilChanged(),
          takeUntil(this.destroy$)
        )
        .subscribe((val: string) => {
          const tanControl = this.clientForm.get('tanno');
          
          this.clientForm.get('tanno')?.markAsTouched();
          this.clientForm.get('tanno')?.markAsDirty();
          if (val) {
            const upperVal = val.toUpperCase();
            if (upperVal !== val) {
              tanControl?.setValue(upperVal, { emitEvent: false });
            }

            //  When exactly 10 characters → valid TAN, fetch data
            if (upperVal.length === 10 && !this.isFetchingTanData) {
              //  tanControl?.setErrors(null); 
              if (!this.selectedRowId || this.isEditMode) {
                this.getTanPanData(upperVal);
              }
            }
            //  When 1–9 characters → show "Invalid TAN"
            else if (upperVal.length < 10) {

              this.resetClientFormExceptTan();
              tanControl?.setErrors({ invalidTan: true });
              tanControl?.markAsTouched();
              tanControl?.markAsDirty();
            }
          }
          //  When length = 0 → required error
          else {
            this.resetClientFormExceptTan();
            tanControl?.setErrors({ required: true });
            tanControl?.markAsTouched();
            tanControl?.markAsDirty();
          }
        });
      //       .subscribe((val: string) => {
      //         if (val) {
      //           // Convert to uppercase
      //           const upperVal = val.toUpperCase();
      //           if (upperVal !== val) {
      //             this.clientForm.get('tanno')?.setValue(upperVal, { emitEvent: false });
      //           }

      //           // Only call API when exactly 10 characters are entered and not already fetching
      //           if (upperVal.length === 10 && !this.isFetchingTanData) {
      //             this.getTanPanData(upperVal);
      //           }

      //     else if (upperVal.length < 10) {
      //       this.resetClientFormExceptTan();
      //        const tanControl = this.clientForm.get('tanno');
      // tanControl?.setErrors({ required: true });
      // tanControl?.markAsTouched(); 
      // tanControl?.markAsDirty();   
      //     }
      //         }
      //          else {
      //     this.resetClientFormExceptTan();
      //   }
      //       });

      this.clientForm.get('tanno')?.valueChanges.subscribe((val: string) => {
        if (val) {
          const upperVal = val.toUpperCase();
          this.clientForm.get('incometax_id')?.setValue(upperVal, { emitEvent: false });
        } else {
          this.clientForm.get('incometax_id')?.reset('', { emitEvent: false });
        }
      });

      this.setupAutoFill();  // enable live sync until user edits
      this.prefillResponsibleFields(); // prefill if form already has address values
    }

    // Subscribe to PAN field changes
    this.clientForm.get('panno')?.valueChanges.subscribe((value: string) => {
      if (value && value.length === 10) {
        // When PAN has full 10 characters, detect client type
        this.clientForm.get('panno')?.markAsTouched(); this.clientForm.get('panno')?.markAsDirty();
        this.autoDetectClientTypeFromPAN();
      } else if (!value || value.length < 10) {
        // Reset if even one char removed (less than 10)
        this.clientForm.patchValue({
          client_type_code: '',
          client_catg_code: ''
        });

        // Reset options to show "Select"
        this.filteredCategoryOptions = [];
      }
    });

    if (!this.selectedRowId || this.isEditMode) {
      this.clientForm.get('pin')?.valueChanges
        .pipe(
          debounceTime(300),
          distinctUntilChanged(),
          filter(value => /^\d{6}$/.test(value)),
          takeUntil(this.destroy$)
        )
        .subscribe(value => this.getPinCodeData(value, 'state'));

      this.clientForm.get('deductor_pin')?.valueChanges
        .pipe(
          debounceTime(300),
          distinctUntilChanged(),
          filter(value => /^\d{6}$/.test(value)),
          takeUntil(this.destroy$)
        )
        .subscribe(value => this.getPinCodeData(value, 'deductor_state_code'));
    }

    // Pre-fill form if CONSO data is provided
    // if (this.consoData) {
    //   this.prefillFormWithConsoData();
    // }

  }


private getsData(): Observable<any> {
  const requestBody = {
    usercode: this.UserData?.user_code,
    clientcode: this.UserData?.client_code,
  };

  return this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).pipe(
    map((response: any) => {
      let parsedData;
      try {
        parsedData = JSON.parse(response.data);
        this.multiMast = parsedData.multiMast;
    
        this.getHeaderData();
      } catch (e) {
        parsedData = response.data;
      }
      // console.log('Parsed Redis data:', parsedData);
      return parsedData;
    }),
    catchError((error) => {
      this.errorMessage = error.message || 'Failed to fetch header master data.';
      this.showError(this.errorMessage);
      return throwError(() => error);
    })
  );
}


  resetClientFormExceptTan() {
    // Preserve only the current TAN
    const currentTan = this.clientForm.get('tanno')?.value || '';

    // Reset the entire form
    // this.clientForm.reset();

    // Re-patch the TAN value back
    this.clientForm.patchValue({ tanno: currentTan });

    // Also clear UI labels or derived data if needed
    // this.selectedStateOptionLabel = '';
    // this.selectedDeductorStateOptionLabel = '';
    // this.filteredClientTypeOptions = [...this.clientTypeOptions]; // reset dropdowns
  }




  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete(); // Clean up memory
  }

  private prefillFormWithConsoData(): void {
    if (!this.consoData) return;


    // Pre-fill Client Details
    this.clientForm.patchValue({
      // Client Basic Details from CONSO BH record
      tanno: this.consoData.tanno || '',
      client_name: this.consoData.client_name || '',
      panno: this.consoData.panno || '',
      branch_division: this.consoData.branch_division || '',

      // Organization Address Details from CONSO BH record
      add1: this.consoData.add1 || '',
      add2: this.consoData.add2 || '',
      add3: this.consoData.add3 || '',
      add4: this.consoData.add4 || '',
      city: this.consoData.city || '',
      state: this.consoData.state || '',
      pin: this.consoData.pin || '',
      email_id: this.consoData.email_id || '',
      mobileno: this.consoData.mobileno || '',
      phoneno: this.consoData.phoneno || '',
      stdcode: this.consoData.stdcode || '',

      // Responsible Person Details from CONSO BH record
      deductor_name: this.consoData.deductor_name || '',
      deductor_desig: this.consoData.deductor_desig || '',
      deductor_panno: this.consoData.deductor_panno || '',
      deductor_email_id: this.consoData.deductor_email_id || '',
      deductor_mobileno: this.consoData.deductor_mobileno || '',
      deductor_phoneno: this.consoData.deductor_phoneno || '',
      deductor_stdcode: this.consoData.deductor_stdcode || '',

      // Responsible Person Address from CONSO BH record
      deductor_add1: this.consoData.deductor_add1 || '',
      deductor_add2: this.consoData.deductor_add2 || '',
      deductor_add3: this.consoData.deductor_add3 || '',
      deductor_add4: this.consoData.deductor_add4 || '',
      deductor_city: this.consoData.deductor_city || '',
      deductor_state_code: this.consoData.deductor_state_code || '',
      deductor_pin: this.consoData.deductor_pin || '',

      // Credentials (pre-fill TAN as Income Tax ID)
      incometax_id: this.consoData.incometax_id || this.consoData.tanno || ''
    },
      { emitEvent: true } //  ensures valueChanges triggers for pin & deductor_pin
    );

    // If PINs are available, trigger getPinCodeData explicitly (in case emitEvent missed due to same value)
    if (this.consoData.pin) {
      this.getPinCodeData(this.consoData.pin, 'state');
    }
    if (this.consoData.deductor_pin) {
      this.getPinCodeData(this.consoData.deductor_pin, 'deductor_state_code');
    }

    // Handle state selection if state code is provided
    if (this.consoData.state && this.stateMastOptions) {
      const matchedState = this.stateMastOptions.find(
        (opt: any) => opt.value === this.consoData.state || opt.state_Code === this.consoData.state
      );
      if (matchedState) {
        this.selectedStateOptionLabel = matchedState.label;
        this.filteredStateOptions = [matchedState];
      }
    }

    // Handle deductor state selection if state code is provided
    if (this.consoData.deductor_state_code && this.stateMastOptions) {
      const matchedDeductorState = this.stateMastOptions.find(
        (opt: any) => opt.value === this.consoData.deductor_state_code || opt.state_Code === this.consoData.deductor_state_code
      );
      if (matchedDeductorState) {
        this.selectedDeductorStateOptionLabel = matchedDeductorState.label;
        this.filteredDeductorStateOptions = [matchedDeductorState];
      }
    }

    // Auto-detect client type from PAN if available
    this.autoDetectClientTypeFromPAN();

    // Mark all steps as completed since we have comprehensive data
    // this.isCompleted = true;
    // this.isaddCompleted = true;
    // this.isResponsibleCompleted = true;

    // Start with the first step open for review
    this.openInfoId = 1;

    // Show success message with details
    this.toastService.showSuccess(`Form pre-filled with CONSO file data from ${this.consoData.sourceFile || 'CONSO file'}`);

    // Log the pre-filled data for debugging

  }

  private autoDetectClientTypeFromPAN(): void {
    const panno = this.clientForm.get('panno')?.value;
    if (panno && panno.length >= 4 && this.clientTypeOptions) {
      const panChar = panno.charAt(3).toUpperCase();
  
      const matchedClientType = this.clientTypeOptions.find(
        (opt: any) => opt.pan_card_type_code?.toUpperCase() === panChar
      );

      if (matchedClientType) {
        this.clientForm.patchValue({
          client_type_code: matchedClientType.code
        });

        // Filter and auto-select client category if only one option available
        this.filteredCategoryOptions = (this.clientCategoryOptions || []).filter(
          c => String(c.typeCode) === String(matchedClientType.code)
        );


        if (this.filteredCategoryOptions.length === 1) {
          this.clientForm.patchValue({
            client_catg_code: this.filteredCategoryOptions[0].value
          });
        }


      }
    }
  }


  // private initializeForm(): void {

  //   this.clientForm = this.fb.group({
  //     client_name: ['', Validators.required],
  //     tanno: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.pattern(/^[A-Z]{4}[0-9]{5}[A-Z]{1}$/)
  //       ]
  //     ],
  //     panno: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)
  //       ]
  //     ],

  //     branch_division: ['', Validators.required],
  //     bank_branch_code: ['', Validators.required],
  //     client_type_code: ['', Validators.required],
  //     client_catg_code: ['', Validators.required],

  //     // 👉 Address group

  //     add1: ['', Validators.required],
  //     add2: [''],
  //     add3: [''],
  //     add4: [''],
  //     city: ['', Validators.required],
  //     state: ['', Validators.required],
  //     pin: ['', [Validators.required, Validators.pattern(/^[0-9]{6}$/)]],
  //     email_id: ['', [Validators.required, Validators.email]],
  //     mobileno: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],

  //     //contact

  //     // alternate_email_id: ['', Validators.email],
  //     // alternate_mobileno: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
  //     // alternate_stdcode: ['', Validators.required],
  //     // stdcode: ['', Validators.required],
  //     // phoneno: ['', Validators.required],
  //     // alternate_phoneno: ['', Validators.required],

  //     alternate_email_id: ['', Validators.email], // optional, but must be valid email if entered
  //     alternate_mobileno: ['', Validators.pattern(/^[6-9]\d{9}$/)], // optional, pattern only if entered
  //     alternate_stdcode: [''], // optional
  //     stdcode: [''], // optional
  //     phoneno: [''], // optional
  //     alternate_phoneno: [''], // optional


  //     // responsible person

  //     deductor_panno: ['', Validators.required],
  //     deductor_desig: ['', Validators.required],
  //     deductor_name: ['', Validators.required],
  //     deductor_email_id: ['', [Validators.required, Validators.email]],
  //     deductor_mobileno: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
  //     deductor_add1: ['', Validators.required],
  //     deductor_add2: [''],  // Made optional - not all address lines are required
  //     deductor_add3: [''],  // Made optional
  //     deductor_add4: [''],  // Made optional
  //     deductor_pin: ['', [Validators.required, Validators.pattern(/^[0-9]{6}$/)]],
  //     deductor_city: ['', Validators.required],
  //     deductor_state_code: ['', Validators.required],

  //     deductor_alternate_email_id: ['', Validators.email], // optional, must be valid email if entered
  //     deductor_alternate_stdcode: [''], // optional
  //     deductor_phoneno: [''], // optional
  //     deductor_alternate_phoneno: [''], // optional, must be valid email if entered
  //     deductor_stdcode: [''],// optional


  //     // credentials
  //     traces_id: [''],
  //     traces_pwd: [''],
  //     incometax_id: [''],
  //     incometax_pwd: ['']


  //   });


  // }

  private initializeForm(): void {
    this.clientForm = this.fb.group({
      client_name: ['', Validators.required],

      // 👉 regex will be applied dynamically from API
      tanno: ['', Validators.required],
      panno: ['', Validators.required],

      branch_division: ['', Validators.required],
      bank_branch_code: ['', Validators.required],
      client_type_code: ['', Validators.required],
      client_catg_code: ['', Validators.required],

      // 👉 Address group
      add1: ['', Validators.required],
      add2: [''],
      add3: [''],
      add4: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pin: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d{6}$/) // Only allows exactly 6 digits
        ]
      ],
      // regex applied dynamically
      email_id: ['', Validators.required], // regex applied dynamically
      mobileno: ['', Validators.required], // regex applied dynamically

      // 👉 Contact
      alternate_email_id: [''], // regex applied dynamically
      alternate_mobileno: [''], // regex applied dynamically
      alternate_stdcode: [''],
      stdcode: [''],
      phoneno: [''], // regex applied dynamically
      alternate_phoneno: [''],

      // 👉 Responsible person
      deductor_panno: ['', Validators.required], // regex applied dynamically
      deductor_desig: ['', Validators.required],
      deductor_name: ['', Validators.required],
      deductor_email_id: ['', Validators.required], // regex applied dynamically
      deductor_mobileno: ['', Validators.required], // regex applied dynamically
      deductor_add1: ['', Validators.required],
      deductor_add2: [''],
      deductor_add3: [''],
      deductor_add4: [''],
      deductor_pin: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d{6}$/) // Only allows exactly 6 digits
        ]
      ],

      deductor_city: ['', Validators.required],
      deductor_state_code: ['', Validators.required],

      deductor_alternate_email_id: [''], // regex applied dynamically
      deductor_alternate_stdcode: [''],
      deductor_phoneno: [''], // regex applied dynamically
      deductor_alternate_phoneno: [''],
      deductor_stdcode: [''],

      // 👉 Credentials
      traces_id: [''],
      traces_pwd: [''],
      incometax_id: [''],
      incometax_pwd: ['']
    });
    this.clientForm.get('deductor_panno')?.valueChanges.subscribe(val => {
      if (val && val !== val.toUpperCase()) {
        this.clientForm.get('deductor_panno')?.setValue(val.toUpperCase(), { emitEvent: false });
      }
    });

    const numericFields = [
      'pin',
      'mobileno',
      'alternate_mobileno',
      'stdcode',
      'phoneno',
      'alternate_stdcode',
      'alternate_phoneno',
      'deductor_mobileno',
      'deductor_pin',
      'deductor_stdcode',
      'deductor_phoneno',
      'deductor_alternate_stdcode',
      'deductor_alternate_phoneno'
    ];

    numericFields.forEach(field => {
      this.clientForm.get(field)?.valueChanges.subscribe(value => {
        if (value && !/^\d*$/.test(value)) {
          const cleaned = value.replace(/\D/g, ''); // remove non-digit chars
          this.clientForm.get(field)?.setValue(cleaned, { emitEvent: false });
        }
      });
    });
  }



  regexMap: { [key: string]: string } = {};

  // private applyDynamicValidations(): void {
  //   Object.keys(this.regexMap).forEach(label => {
  //     const control = this.clientForm.get(label);
  //     if (control) {
  //       const regex = this.regexMap[label];
  //       console.log(regex);
  //       const dynamicValidator = Validators.pattern(new RegExp(regex));

  //       const validators = [dynamicValidator];
  //          console.log(validators);
  //       // Preserve required if already set
  //       if (control.hasValidator(Validators.required)) {
  //         validators.push(Validators.required);
  //       }

  //       // For optional fields → only validate if value exists
  //       control.setValidators([
  //         (ctrl) => !ctrl.value ? null : dynamicValidator(ctrl),
  //         ...(control.hasValidator(Validators.required) ? [Validators.required] : [])
  //       ]);

  //       control.updateValueAndValidity({ emitEvent: false });
  //     }
  //   });
  // }
  private applyDynamicValidations(): void {
    Object.keys(this.regexMap).forEach(label => {
      const control = this.clientForm.get(label);
      if (control) {
        let regexString = this.regexMap[label];

        // Fix escaped characters from JSON (e.g., \\d → \d)
        regexString = regexString.replace(/\\\\/g, '\\');

        // Create RegExp safely
        const regex = new RegExp(regexString);

        // Create validators
        const patternValidator = Validators.pattern(regex);
        const validators = control.hasValidator(Validators.required)
          ? [Validators.required, patternValidator]
          : [patternValidator];

        // Apply validators
        control.setValidators(validators);
        control.updateValueAndValidity({ emitEvent: false });

        // Revalidate live on input change
        control.valueChanges.subscribe(() => {
          control.updateValueAndValidity({ emitEvent: false });
        });
      }
    });
  }




  closePopup() {
    // this.isOpenAddRent = false;
    this.clientForm.reset();
    // this.closeAddRent.emit();
    // this.RentData = null;
    // this.ownerDetails = [];
    // this.previousOwnerDetails = null;
    // this.selectedFiles = [];
    // this.isEditMode = true;
    this.ClientDetailsStep = false;
    this.iscredentialComplete = false;
    this.AddressStep = false;
    this.ResponsibleStep = false;
    // this.selectedVendorOptionValue = null;
    // this.attachmentStep = false;
    this.openInfoId = 1; // Reset to first accordion
    // this.currentStep = 1; // Reset current step
    this.close.emit();
    this.closeaddpopup.emit();
  }



  constructor(
    private fb: FormBuilder,
    private userlocaldataService: UserdataService,
    private toastService: ToastService,
    private apiservice: ApiserviceService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private authservice: AuthService,
    private apiService: ApiserviceService,
    private refreshdata: RefreshdataService,
  ) {
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};


  }

  // getLocalUserData() {
  //   if (typeof window !== 'undefined') {

  //     const uData = localStorage.getItem('localUserData');
  //     if (uData) {
  //       this.UserData = JSON.parse(uData);

  //     }
  //   }
  // }


  // btnOpenTr(id: number): void {
  //   if (!this.isEditMode) {
  //     // In view mode, don't allow toggling
  //     return;
  //   }

  //   if (this.openInfoId === id) {
  //     this.openInfoId = null;
  //   } else {
  //     this.openInfoId = id;
  //   }
  // }

  btnOpenTr(step: number): void {
    // 1️⃣ Prevent toggling if not in edit mode
    if (!this.isEditMode) return;

    // 2️⃣ Prevent opening steps that aren’t yet allowed
    if (step === 2 && !this.canOpenAddress) return;
    if (step === 3 && !this.canOpenResponsible) return;
    if (step === 4 && !this.canOpenCredentials) return;

    // 3️⃣ Toggle accordion open/close
    this.openInfoId = this.openInfoId === step ? null : step;
  }



  goBack(): void {


    // Set flag to indicate we're editing a previous step
    this.isEditingPreviousStep = true;

    // Navigate to the previous step based on current openInfoId
    if (this.openInfoId === 5) {
      // From step 5 back to Credentials
      this.openInfoId = 4;
    } else if (this.openInfoId === 4) {
      // From Credentials back to Responsible Person Details
      this.openInfoId = 3;
    } else if (this.openInfoId === 3) {
      // From Responsible Person Details back to Address Details
      this.openInfoId = 2;
    } else if (this.openInfoId === 2) {
      // From Address Details back to Client Details
      this.openInfoId = 1;
    }

    // Form data is preserved in the FormGroup
    // The form will automatically show in edit mode since openInfoId matches the section
  }

  confirmStepChange(): void {
    // Navigate back without confirmation modal
    this.goBack();
    this.showConfirmModal = false;
  }

  closeConfirmModal(): void {
    this.pendingStepId = null;
    this.showConfirmModal = false;
  }


  textFields = [

    { label: 'TAN', control: 'tanno' },
    { label: 'Name', control: 'client_name' },
    { label: 'PAN', control: 'panno' },
    { label: 'Bank Branch Code', control: 'bank_branch_code' },
    { label: 'Branch or Division', control: 'branch_division' },
  ];


  requiredSelectFields = ['client_catg_code', 'client_type_code'];

  // get isClientFormComplete(): boolean {
  //   // check textFields
  //   const textFieldsComplete = this.textFields.every(field =>
  //     !!this.clientForm.get(field.control)?.value
  //   );

  //   // check selects
  //   const selectsComplete = this.requiredSelectFields.every(field =>
  //     !!this.clientForm.get(field)?.value
  //   );

  //   return textFieldsComplete && selectsComplete;
  // }

  get isClientFormComplete(): boolean {
    // check textFields are filled and valid
    const textFieldsComplete = this.textFields.every(field =>
      this.clientForm.get(field.control)?.valid
    );

    // check required selects are filled and valid
    const selectsComplete = this.requiredSelectFields.every(field =>
      this.clientForm.get(field)?.valid
    );

    return textFieldsComplete && selectsComplete;
  }



  addressFields: FieldConfig[] = [
    { label: 'Address', control: 'add1', type: 'text', required: true },
    { label: 'Street/road/lane', control: 'add2', type: 'text' },
    { label: 'Landmark', control: 'add3', type: 'text' },
    { label: 'Area/location', control: 'add4', type: 'text' },
    { label: 'Pincode', control: 'pin', type: 'text', required: true },
    { label: 'City/Town', control: 'city', type: 'text', required: true },
    { label: 'Email', control: 'email_id', type: 'text', required: true },
    { label: 'Mobile No.', control: 'mobileno', type: 'text', required: true },
  ];

  contactFields: FieldConfig[] = [
    { label: 'Alternate Email', control: 'alternate_email_id', type: 'text' },
    { label: 'Alternate Mobile No.', control: 'alternate_mobileno', type: 'text' },
    { label: 'STD Code', control: 'stdcode', type: 'text' },
    { label: 'Telephone NO', control: 'phoneno', type: 'text' },
    { label: 'Alternate STD Code', control: 'alternate_stdcode', type: 'text' },
    { label: 'Alternate Telephone NO', control: 'alternate_phoneno', type: 'text' },
  ];

  requiredAddressSelectFields = ['state'];

  get isAddressFormComplete(): boolean {
    // check all required text fields
    const fieldsComplete = this.addressFields
      .filter(f => f.required)
      .every(f => this.clientForm.get(f.control)?.valid);

    // check extra required selects
    const selectsComplete = this.requiredAddressSelectFields
      .every(field => this.clientForm.get(field)?.valid);

    return fieldsComplete && selectsComplete;
  }




  responsibleFields = [
    { label: 'PAN', control: 'deductor_panno', type: 'text', required: true },
    { label: 'Name', control: 'deductor_name', type: 'text', required: true },
    { label: 'Job Designation', control: 'deductor_desig', type: 'text', required: true },
    { label: 'Email', control: 'deductor_email_id', type: 'text', required: true },
    { label: 'Mobile No.', control: 'deductor_mobileno', type: 'text', required: true },
    { label: 'Address', control: 'deductor_add1', type: 'text', required: true },
    { label: 'Street/road/lane', control: 'deductor_add2', type: 'text' },
    { label: 'Landmark', control: 'deductor_add3', type: 'text' },
    { label: 'Area/location', control: 'deductor_add4', type: 'text' },
    { label: 'Pincode', control: 'deductor_pin', type: 'text', required: true },
    { label: 'City/Town', control: 'deductor_city', type: 'text', required: true },

  ];

  responsibleContactFields = [
    { label: 'Alternate Email', control: 'deductor_alternate_email_id', type: 'text' },
    // { label: 'Alternate Mobile No.', control: 'alternate_mobileno', type: 'text' },
    { label: 'STD Code', control: 'deductor_stdcode', type: 'text' },
    { label: 'Telephone NO', control: 'deductor_phoneno', type: 'text' },
    { label: 'Alternate STD Code', control: 'deductor_alternate_stdcode', type: 'text' },
    { label: 'Alternate Telephone NO', control: 'deductor_alternate_phoneno', type: 'text' },

  ];


  requiredResponsibleSelectFields = ['deductor_state_code'];

  get isResponsibleFormComplete(): boolean {
    // check required text fields
    const fieldsComplete = this.responsibleFields
      .filter(f => f.required)
      .every(f => this.clientForm.get(f.control)?.valid);

    // check extra required selects
    const selectsComplete = this.requiredResponsibleSelectFields
      .every(field => this.clientForm.get(field)?.valid);

    return fieldsComplete && selectsComplete;
  }

  tracesCredentialsFields = [
    { label: 'Traces Id', control: 'traces_id', type: 'text' },
    { label: 'Traces Password', control: 'traces_pwd', type: 'password' },

  ];

  IncometaxCredentialsFields = [
    { label: 'Incometax Id', control: 'incometax_id', type: 'text' },
    { label: 'Password', control: 'incometax_pwd', type: 'password' },

  ];

  // Password visibility state
  passwordVisibility: { [key: string]: boolean } = {
    traces_pwd: false,
    incometax_pwd: false
  };

  togglePasswordVisibility(field: string): void {
    this.passwordVisibility[field] = !this.passwordVisibility[field];
  }


  handleInput(controlName: string, event: Event) {
    let input = (event.target as HTMLInputElement).value;
    if (['tanno', 'client_name', 'panno'].includes(controlName)) {
      input = input.toUpperCase();
      this.clientForm.get(controlName)?.setValue(input, { emitEvent: false });
    }

    // Clear server error when user starts typing
    if (this.serverErrors[controlName]) {
      delete this.serverErrors[controlName];
    }
  }

  // Helper method to check if field has errors (client or server)
  // hasFieldError(fieldName: string): boolean {
  //   const control = this.clientForm.get(fieldName);
  //   return (control?.touched && control?.invalid) || !!this.serverErrors[fieldName];
  // }

  hasFieldError(controlName: string): boolean {
    const control = this.clientForm.get(controlName);
    return !!(control && control.invalid && (control.dirty || control.touched)) || !!this.serverErrors[controlName];
  }


  // Helper method to get error message for a field
  getFieldErrorMessage(fieldName: string): string | null {
    return this.serverErrors[fieldName] || null;
  }

  // ✅ add this line
  dropdownOpen: { [key: string]: boolean } = {};

  toggleDropdown(key: string) {
    this.dropdownOpen[key] = !this.dropdownOpen[key];

  }



  closeDropdown(key: string) {
    this.dropdownOpen[key] = false;
  }

  selectedclientValue: any;

  selectOption(key: string, option: Option) {
    const val = option?.value ?? option;
    this.selectedclientValue = option?.value
    this.clientForm.get(key)?.setValue(val);
    this.dropdownOpen[key] = false;

    // Clear server error when dropdown selection changes
    if (this.serverErrors[key]) {
      delete this.serverErrors[key];
    }

    // if client type changed, filter categories & reset the category form control
    if (key === 'client_type_code') {
      this.filteredCategoryOptions = (this.clientCategoryOptions || []).filter(
        c => String(c.typeCode) === String(val)
      );

      // reset the category selection so label updates correctly
      this.clientForm.get('client_catg_code')?.setValue(null);
    }
  }

  // key mapping between address and responsible fields
  addressToResponsibleMap: { [key: string]: string } = {
    add1: 'deductor_add1',
    add2: 'deductor_add2',
    add3: 'deductor_add3',
    add4: 'deductor_add4',
    pin: 'deductor_pin',
    city: 'deductor_city',
    email_id: 'deductor_email_id',
    mobileno: 'deductor_mobileno',
  };

  prefillResponsibleFields() {
    Object.keys(this.addressToResponsibleMap).forEach(addressKey => {
      const responsibleKey = this.addressToResponsibleMap[addressKey];

      const addressValue = this.clientForm.get(addressKey)?.value;
      if (addressValue) {
        this.clientForm.get(responsibleKey)?.setValue(addressValue, { emitEvent: false });
      }

    });
  }

  setupAutoFill() {
    Object.keys(this.addressToResponsibleMap).forEach(addressKey => {
      const responsibleKey = this.addressToResponsibleMap[addressKey];

      this.clientForm.get(addressKey)?.valueChanges.subscribe(value => {
        const responsibleControl = this.clientForm.get(responsibleKey);

        // only update if user hasn’t manually changed responsible field
        if (!responsibleControl?.dirty) {
          responsibleControl?.setValue(value, { emitEvent: false });
        }
      });
    });
  }




  // onSaveAndNext() {
  //   // Reset edit flag when moving forward
  //   this.isEditingPreviousStep = false;

  //   // Mark the current step as completed based on which step we're on
  //   if (this.openInfoId === 1 && this.isClientFormComplete) {
  //     this.isCompleted = true;
  //     this.ClientDetailsStep = false;
  //   } else if (this.openInfoId === 2 && this.isAddressFormComplete) {
  //     this.isaddCompleted = true;
  //     this.AddressStep = false;
  //   } else if (this.openInfoId === 3 && this.isResponsibleFormComplete) {
  //     this.isResponsibleCompleted = true;
  //     this.ResponsibleStep = false;
  //   } else if (this.openInfoId === 4) {
  //     this.iscredentialComplete = true;
  //   }
  //   // The btnOpenTr call in the button will handle opening the next section
  // }

  canOpenAddress = false;
  canOpenResponsible = false;
  canOpenCredentials = false;



  // onSaveAndNext() {


  //   this.isEditingPreviousStep = false;

  //   if (!this.isCompleted && this.isClientFormComplete) {
  //     this.isCompleted = true;
  //     this.ClientDetailsStep = false;
  //     return;
  //   }

  //   if (!this.isaddCompleted && this.isAddressFormComplete) {
  //     this.isaddCompleted = true;
  //     this.AddressStep = false;
  //     return;
  //   }

  //   if (!this.isResponsibleCompleted && this.isResponsibleFormComplete) {
  //     this.isResponsibleCompleted = true;
  //     this.ResponsibleStep = false;
  //     return;
  //   }

  //   if (!this.iscredentialComplete) {
  //     this.iscredentialComplete = true;
  //   }
  // }

  onSaveAndNext(accName: any) {
    this.isEditingPreviousStep = false;

    // Step 1: Client Details → unlock Address
    if (!this.isCompleted && this.isClientFormComplete && accName == 'clientForm') {

      this.initializeDropdownLabels();
      this.isCompleted = true;
      this.ClientDetailsStep = false;
      this.canOpenAddress = true; // ✅ allow next accordion
      this.btnOpenTr(2); // open next accordion automatically
      return;
    }

    // Step 2: Address Details → unlock Responsible Person
    if (!this.isaddCompleted && this.isAddressFormComplete && (accName == 'addressForm' && this.isClientFormComplete)) {

      this.isaddCompleted = true;
      this.AddressStep = false;
      this.canOpenResponsible = true; // ✅ allow next accordion
      this.btnOpenTr(3);
      return;
    }

    // Step 3: Responsible Person → unlock Credentials
    if (!this.isResponsibleCompleted && this.isResponsibleFormComplete && (accName == 'responsibleForm' && this.isClientFormComplete && this.isAddressFormComplete)) {
     
      this.isResponsibleCompleted = true;
      this.ResponsibleStep = false;
      this.canOpenCredentials = true; // ✅ allow next accordion
      this.btnOpenTr(4);
      return;
    }

    // Step 4: Final Step
    if (!this.iscredentialComplete && (accName == 'credentialForm' && this.isClientFormComplete && this.isAddressFormComplete && this.isResponsibleFormComplete)) {
     
      this.iscredentialComplete = true;
      return;
    }
  }



  onNext() {
    if (this.selectedRowId && !this.isEditMode && !this.isCompleted && this.isClientFormComplete) {
      this.isCompleted = true;
      this.ClientDetailsStep = false;
    }

    if (this.selectedRowId && !this.isEditMode && !this.isaddCompleted && this.isAddressFormComplete) {
      this.isaddCompleted = true;
      this.AddressStep = false;
    }

    if (this.selectedRowId && !this.isEditMode && !this.isResponsibleCompleted && this.isResponsibleFormComplete) {
      this.isResponsibleCompleted = true;
      this.ResponsibleStep = false;
    }

    if (this.selectedRowId && !this.isEditMode && !this.iscredentialComplete) {
      this.iscredentialComplete = true;
    }

  }


    getHeaderData(){
                const validations =  this.multiMast?.get_gmdt_regex_validation || [];
        this.regexMap = validations.reduce((acc: any, cur: any) => {
          acc[cur.label] = cur.value;
          return acc;
        }, {});

        // After fetching regex, re-apply validations
        this.applyDynamicValidations();

        const clientypeCodeData =
         this.multiMast?.get_gmdt_client_type_mast;

        const clientCategoryCodeData =
           this.multiMast
            ?.get_gmdt_client_catg_mast;

        const stateMastData =
         this.multiMast
            ?.get_gmdt_state_mast;

        const client_level_mast =  this.multiMast?.get_gmdt_client_level_mast;
        console.log(client_level_mast)


        if (client_level_mast && this.selectedRowId) {
          this.codeLevelOptions = client_level_mast.map((item: any) => ({
            label: item.label, // or item.label
            value: item.value // or item.value
          }));

          // Set the first item as default
          this.selectedClientLevelLabel = this.codeLevelOptions[0].label;
          this.selectedClientLevelValue = this.codeLevelOptions[0].value;

          if (!this.selectedRowId) {
            this.getclientParentData(this.selectedClientLevelValue);
          }
           //this.getclientParentData(this.selectedClientLevelValue);
        }

       
       else if (client_level_mast && !this.selectedRowId){
  // Filter based on client_code_level
  const filteredLevels = client_level_mast.filter(
    (item: any) => Number(item.value) > Number(this.dynamicUserData.client_code_level)
  );

  this.codeLevelOptions = filteredLevels.map((item: any) => ({
    label: item.label,
    value: item.value,
  }));

  // If filtered list not empty, set defaults
  if (this.codeLevelOptions.length > 0) {
    this.selectedClientLevelLabel = this.codeLevelOptions[0].label;
    this.selectedClientLevelValue = this.codeLevelOptions[0].value;

    if (!this.selectedRowId) {
      this.getclientParentData(this.selectedClientLevelValue);
    }
  } else {
    // Optional: handle no available options
    this.codeLevelOptions = [];
    this.selectedClientLevelLabel = '';
    this.selectedClientLevelValue = '';
  }
}
 this.filteredClientLevelOptions = [...this.codeLevelOptions];

        // Assign fetched data to dropdown options
        this.clientTypeOptions = clientypeCodeData.map((item: any) => ({
          label: item.label, // or item.label
          value: item.value,// or item.value
          code: item.client_type_code, // <-- store client_type_code
          pan_card_type_code: item.pan_card_type_code
        }));
        // Assign fetched data to dropdown options
        this.clientCategoryOptions = clientCategoryCodeData.map((item: any) => ({
          label: item.label, // or item.label
          value: item.value,
          typeCode: item.client_type_code, // <-- link with type
        }));

        this.stateMastOptions = stateMastData.map((item: any) => ({
          label: item.label, // or item.label
          value: item.value,
          state_Code: item.state_code, // <-- link with type
        }));

        // Now initialize filteredStateOptions
        //  this.filteredStateOptions = [...this.stateMastOptions];
        // Initially empty until a type is selected

        // ✅ Initialize filtered lists after fetching
        this.filteredClientTypeOptions = [...this.clientTypeOptions];
        this.filteredCategoryOptions = [...this.clientCategoryOptions];
  }


  getmmtxLabel(options: any[], value: any): string {
    if (!value) return '';
    const matched = options?.find(
      (opt) => opt.value?.toString() === value?.toString()
    );
    return matched ? matched.label : value;
  }

  initializeDropdownLabels() {
    const dropdowns = [
      { key: 'client_type_code', options: this.filteredClientTypeOptions },
      { key: 'client_catg_code', options: this.filteredCategoryOptions },
    ];

    dropdowns.forEach((dd) => {
      const value = this.clientForm.get(dd.key)?.value;
      if (value) {
        const matched = dd.options.find(
          (opt) => opt.value?.toString() === value?.toString()
        );
        if (matched) {
          this.clientForm.get(dd.key)?.setValue(matched.value);
        }
      }
    });
  }

  showClientLevelDropdown = false;

  toggleClientLevelDropdown() {
    if (this.selectedRowId) return; // ✅ prevent selecting new value
    this.showClientLevelDropdown = !this.showClientLevelDropdown;
     this.filteredClientLevelOptions = [...this.codeLevelOptions];
  }

  onClientLevelSelect(option: any) {
    if (this.selectedRowId) return; // ✅ prevent toggling in edit mode
    this.selectedClientLevelLabel = option.label;
    this.selectedClientLevelValue = option.value;

    // Close dropdown after selection
    this.showClientLevelDropdown = false;

     // Clear search after selection
  this.searchclientText = '';
 this.filteredClientLevelOptions = [...this.codeLevelOptions];

    // Fetch parent data based on newly selected level
    this.getclientParentData(this.selectedClientLevelValue);


  }

  // On Client Type change
  onClientTypeChange(selectedValue: string) {

    const selectedType = this.clientTypeOptions.find(
      (t) => t.code == selectedValue
    );
    if (selectedType) {
      this.filteredCategoryOptions = this.clientCategoryOptions.filter(
        (c) => c.typeCode == selectedType.code
      );
    } else {
      this.filteredCategoryOptions = [];
    }
  }

  getLabel(options: Option[] | undefined, value: any): string {
    // safe guards
    if (!options || !options.length) return 'Select';
    if (value === null || value === undefined || value === '') return 'Select';

    // normalize types to avoid mismatches between number/string
    const match = options.find(o => String(o.value) === String(value));
    return match ? match.label : 'Select';
  }

  isSelected(optionValue: any, formValue: any): boolean {
    return String(optionValue) === String(formValue);
  }


  searchStateCode() {
    this.filteredStateOptions = this.stateMastOptions.filter((s: { label: string }) =>
      s.label.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }


  // selectStateOption(option: any) {
  //   this.selectedStateOptionLabel = option.label;
  //   this.clientForm.get('state')?.setValue(option.value);
  //   this.showStateOption = false;
  // }

  selectStateOption(option: any) {
    if (!option) return;

    this.selectedStateOptionLabel = option.label;
    this.selectedStateOptionValue = option.value;
    this.clientForm.get('state')?.setValue(option.value);

    // ✅ close the dropdown after selection
    this.showStateOption = false;
        this.searchText = '';
  this.filteredStateOptions = [...(this.stateMastOptions || [])];
  }

  selectDeductorStateOption(option: any) {
    if (!option) return;

    this.selectedDeductorStateOptionLabel = option.label;
    this.selectedDeductorStateOptionValue = option.value;

    this.clientForm.get('deductor_state_code')?.setValue(option.value);

    // ✅ close the dropdown after selection
    this.showDeductorStateOption = false;
        this.searchText = '';
  this.filteredStateOptions = [...(this.stateMastOptions || [])];
  }

searchParentText: string = '';
filteredParentCodeOptions: any[] = [];

  private getclientParentData(selectedLevelValue: any): void {

    // if (!this.codeLevelOptions || !this.codeLevelOptions.length) return;
    // const selectedValue = this.codeLevelOptions[0].value;

    // if (!this.selectedClientLevelValue) return; // Ensure a selection exists
    if (!selectedLevelValue) return; // Ensure a selection exists

    // const selectedValue = this.selectedClientLevelValue;
    const selectedValue = selectedLevelValue;
    this.selectedParentCodeLabel = '';
    // this.selectedClientLevelValue = '';

    const requestBody = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.UserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.UserData.entity_code,
      a_client_code: this.UserData.client_code,
      a_acc_year: this.UserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.UserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.UserData.client_code_level,
      a_user_level: this.UserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_gmlb_client_parent_mast",
      a_process_seqno: "",
      a_process_status_code: "ZA",
      a_db_total_records: "1000",
      a_pagination_count: "0",
      a_filter_clause: [
        {
          filter_col_field: "code_level",
          filter_col_depend_operator: "wc",
          filter_col_value: `and a.code_level=(select max(c.client_level_code) from client_level_mast c where c.entity_code=a.entity_code and c.client_level_code < ${selectedValue})`
        }
      ],

    };
    this.apiservice.fetchparentmastLbData('/ClientMast/get_gmlb_client_parent_mast', requestBody).subscribe({
      next: (response: any) => {

        this.parentCodeOptions =
          response?.result?.get_gmlb_client_parent_mast;
  
          this.filteredParentCodeOptions = [...this.parentCodeOptions];
      
        if (this.roleData && this.parentCodeOptions) {
          const matchedParent = this.parentCodeOptions?.find(
            (opt: any) => opt.parent_code == this.roleData.parent_code.toString()
          );
       
          if (matchedParent) {
            // If found in the list
            this.selectedParentCodeLabel = matchedParent.parent_code_details;
            this.selectedParentCodeValue = matchedParent.parent_code;
          } else {
            // Otherwise, bind manually (assuming you want to show client_level_name)
            this.selectedParentCodeLabel = this.roleData.parent_code;
            this.selectedParentCodeValue = this.roleData.parent_code;
          }
        }
        else {
       
          this.selectedParentCodeLabel = this.parentCodeOptions[0]?.parent_code_details;
          this.selectedParentCodeValue = this.parentCodeOptions[0]?.parent_code;
        }

      },
      error: (error: any) => {
        console.error(error);
      },
    });
  }

  showParentDropdown = false;
  selectedParentCodeLabel: string = '';
  // selectedParentCodeValue: string = '';

  toggleParentDropdown() {
    if (this.selectedRowId) return; // ✅ prevent selecting new value
    this.showParentDropdown = !this.showParentDropdown;
     this.filteredParentCodeOptions = [...this.parentCodeOptions];
  }

  //  Filter function for parent dropdown
filterParentOptions() {
  const search = this.searchParentText.toLowerCase();
  this.filteredParentCodeOptions = this.parentCodeOptions.filter((p: any) =>
    p.parent_code_details?.toLowerCase().includes(search)
  );
}

  onParentSelect(parent: any) {
    if (this.selectedRowId) return; // ✅ prevent toggling in edit mode
    this.selectedParentCodeLabel = parent.parent_code_details;
    this.selectedParentCodeValue = parent.parent_code;

    this.showParentDropdown = false;

     // Clear search after selection
  this.searchParentText = '';
  this.filteredParentCodeOptions = [...this.parentCodeOptions];
  }


  async getPinCodeData(pincode: string, target: 'state' | 'deductor_state_code') {
    const qData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_gmdt_pin_code_mast",
      a_process_seqno: "",

      a_in_parameter_json: [
        {
          a_entity_code: this.dynamicUserData.entity_code,
          a_rowid_seq: pincode
        }
      ]
    };

    // const parseRequestData = {
    //   sdata: JSON.stringify(qData),
    // };

    await this.apiservice
      .pinCodeApi('/ClientMast/get_gmdt_pin_code_mast', qData).subscribe({
        next: (response: any) => {

          this.pinCode =
            response?.result?.get_gmdt_pin_code_mast.get_gmdt_pin_code_mast_detail || [];

          if (this.pinCode.length > 0) {
            const stateCode = this.pinCode[0].state_code;
            const cityName = this.pinCode[0].post_office_name;

            const matchedState = this.stateMastOptions?.find(
              (opt: any) => opt.state_Code == stateCode
            );


            if (matchedState) {
              // if (target === 'state') {
              //   this.filteredStateOptions = [matchedState];

              //   this.selectStateOption(matchedState); // client state
              //   this.clientForm.patchValue({
              //     deductor_state_code: this.filteredStateOptions[0].value
              //   })
              //   if (this.filteredStateOptions[0].value) {
              //     const matchedState = this.stateMastOptions?.find(
              //       (opt: any) => opt.value == this.filteredStateOptions[0].value
              //     );
              //     if (matchedState) {
              //       this.selectedDeductorStateOptionLabel = matchedState.label;
              //     }
              //   }
              // } else if (target === 'deductor_state_code') {
              //   this.filteredDeductorStateOptions = [matchedState];
              //   this.selectDeductorStateOption(matchedState); // deductor state
              // }

              if (this.pinCode.length > 0) {
                const stateCode = this.pinCode[0].state_code;

                const matchedState = this.stateMastOptions.find(
                  (opt: any) => opt.state_Code == stateCode
                );

                if (matchedState) {

                  if (target === 'state') {
                    // Keep full list
                    this.filteredStateOptions = [...this.stateMastOptions];

                    // Select the matched state
                    this.selectStateOption(matchedState);
                    this.clientForm.patchValue({
                      state: matchedState.value,
                      city: cityName,
                      deductor_state_code: matchedState.value
                    });
                    this.selectDeductorStateOption(matchedState);

                    this.selectedStateOptionLabel = matchedState.label;
                    this.selectedDeductorStateOptionLabel = matchedState.label;
                  } else if (target === 'deductor_state_code') {
                    this.filteredDeductorStateOptions = [...this.stateMastOptions]; // keep full list

                    this.selectDeductorStateOption(matchedState);
                    this.clientForm.patchValue({
                      deductor_state_code: matchedState.value,
                      deductor_city: cityName
                    });
                    this.selectedDeductorStateOptionLabel = matchedState.label;
                  }

                }
              }

            }
          }

        },
        error: (error: any) => {
          console.error(error);
        },
      });
  }

  async getTanPanData(tanno: string) {
    // Prevent multiple API calls
    if (this.isFetchingTanData) return;
    this.isFetchingTanData = true;

    const qData = {
      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_gmdt_tan_pan_mast",
      a_process_seqno: "",

      a_in_parameter_json: [
        {
          a_entity_code: this.dynamicUserData.entity_code,
          a_rowid_seq: tanno
        }
      ]
    };


    await this.apiservice
      .pinCodeApi('/ClientMast/get_gmdt_tan_pan_mast', qData).subscribe({
        next: (response: any) => {

          if (response?.result?.a_proc_error == 0) {
            const tanpanData =
              response?.result?.get_gmdt_tan_pan_mast.get_gmdt_tan_pan_mast_detail || [];


            if (tanpanData && tanpanData[0]) {
              const data = tanpanData[0];


              this.clientForm.patchValue({
                client_name: data.tanno_name || '',
                // Don't patch tanno to avoid triggering valueChanges again
                // tanno: data.tanno || '',
                panno: data.panno || '',
                add1: data.addline1 || '',
                add2: data.addline2 || '',
                add3: data.addline3 || '',
                add4: data.addline4 || '',
                city: data.city || '',
                pin: data.pin || '',
                state: data.statecd || '',
                stdcode: data.stdcd || '',
                phoneno: data.phonenum || '',
                email_id: data.emailid1 || '',

                deductor_name: data.tan_res_pn_name || '',
                deductor_panno: data.panno || '',

                deductor_add1: data.addline1 || '',
                deductor_add2: data.addline2 || '',
                deductor_add3: data.addline3 || '',
                deductor_add4: data.addline4 || '',
                deductor_city: data.city || '',
                deductor_pin: data.pin || '',
                deductor_state_code: data.statecd || '',
                deductor_stdcode: data.stdcd || '',
                deductor_phoneno: data.phonenum || '',
                deductor_email_id: data.emailid1 || '',
                traces_id :  data.traces_id || '',
                traces_pwd :  data.traces_pwd || '',
                incometax_id :  data.incometax_id || '',
                incometax_pwd :  data.incometax_pwd || '',
              });

              if (data.statecd) {
                const matchedState = this.stateMastOptions?.find(
                  (opt: any) => opt.value == data.statecd
                );
                if (matchedState) {
                  this.selectedStateOptionLabel = matchedState.label;

                  this.selectedDeductorStateOptionLabel = matchedState.label;

                }
              }

              const panChar = (data.panno || '').charAt(3);

              // Find the matching client type (but don't restrict dropdown options)
              const matchedClientType = this.clientTypeOptions.find(
                (opt: any) => opt.pan_card_type_code?.toUpperCase() === panChar.toUpperCase()
              );

              if (matchedClientType) {
                // Patch the matched client type as selected
                this.clientForm.patchValue({
                  client_type_code: matchedClientType.code
                });

                // Keep full list available for dropdown
                this.filteredClientTypeOptions = [...this.clientTypeOptions];

                // Trigger dependent logic if needed
                this.onClientTypeChange(matchedClientType.code);
              } else {
                // No match found → still show full list
                this.filteredClientTypeOptions = [...this.clientTypeOptions];
              }


            }
          } else {
            this.toastService.showSuccess(
              response.a_proc_error_message || "Failed to fetch TAN PAN Data"
            );
          }
          this.isFetchingTanData = false;
        },
        error: (error: any) => {
          console.error(error);
          this.isFetchingTanData = false;
        },
      });
  }

  sanitizeValue(value: any, toUpper: boolean = false): string {
    if (!value) return '';
    let transformed = value.toString().trim();
    return toUpper ? transformed.toUpperCase() : transformed;
  }



  // Helper method to get all form validation errors
  getFormValidationErrors() {
    const errors: any = {};
    const invalidFieldsDetails: any[] = [];

    Object.keys(this.clientForm.controls).forEach(key => {
      const control = this.clientForm.get(key);
      if (control && control.errors) {
        errors[key] = control.errors;
        invalidFieldsDetails.push({
          field: key,
          value: control.value,
          errors: control.errors
        });
      }
    });

    return { errors, invalidFieldsDetails };
  }


  accordionFieldMap: { [key: string]: number } = {
    // -----------------------------
    // Accordion 1: Client Info
    // -----------------------------
    tanno: 1,
    client_name: 1,
    panno: 1,
    bank_branch_code: 1,
    branch_division: 1,
    client_type_code: 1,
    client_catg_code: 1,

    // -----------------------------
    // Accordion 2: Address & Contact
    // -----------------------------
    add1: 2,
    add2: 2,
    add3: 2,
    add4: 2,
    pin: 2,
    city: 2,
    email_id: 2,
    mobileno: 2,
    alternate_email_id: 2,
    alternate_mobileno: 2,
    stdcode: 2,
    phoneno: 2,
    alternate_stdcode: 2,
    alternate_phoneno: 2,

    // -----------------------------
    // Accordion 3: Responsible Person
    // -----------------------------
    deductor_panno: 3,
    deductor_name: 3,
    deductor_desig: 3,
    deductor_email_id: 3,
    deductor_mobileno: 3,
    deductor_add1: 3,
    deductor_add2: 3,
    deductor_add3: 3,
    deductor_add4: 3,
    deductor_pin: 3,
    deductor_city: 3,
    deductor_alternate_email_id: 3,
    deductor_stdcode: 3,
    deductor_phoneno: 3,
    deductor_alternate_stdcode: 3,
    deductor_alternate_phoneno: 3,

    // -----------------------------
    // Accordion 4: Credentials
    // -----------------------------
    traces_id: 4,
    traces_pwd: 4,
    incometax_id: 4,
    incometax_pwd: 4,
  };

  isSubmittingUpdateLoader: boolean = false;

  onSubmit() {
    this.isSubmittingUpdateLoader = true;
    // Mark all fields as touched to show validation errors
    this.clientForm.markAllAsTouched();

    if (!this.selectedClientLevelValue || !this.selectedParentCodeValue) {
      this.toastService.showError('Error while getting Client Level or Parentcode ');
      this.isSubmittingUpdateLoader = false;
      return;
    }

    if (this.clientForm.invalid) {
      this.isSubmittingUpdateLoader = false;
      // Get detailed error information
      const validationInfo = this.getFormValidationErrors();
      const invalidFields: string[] = [];

      Object.keys(this.clientForm.controls).forEach(key => {
        const control = this.clientForm.get(key);
        if (control && control.invalid) {
          invalidFields.push(key);
        }
      });

      console.error('Form Validation Failed!');
      console.error('Invalid fields count:', invalidFields.length);
      console.error('Invalid fields:', invalidFields);
      console.error('Detailed errors:', validationInfo.invalidFieldsDetails);

      // Create a more detailed error message
      let errorMessage = `Please fill the following required fields: ${invalidFields.slice(0, 5).join(', ')}`;
      if (invalidFields.length > 5) {
        errorMessage += ` and ${invalidFields.length - 5} more...`;
      }

      this.toastService.showError(errorMessage);
      return;
    }


    const formData = this.clientForm.value;

    const qData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",

      a_proc_type: "get_miud_client_mast",
      a_process_seqno: "",
      a_iud_type: this.selectedRowId ? 'u' : 'i',
      a_process_status_code: "ZA",
      a_db_total_records: "1000",
      a_pagination_count: "0",
      client_mast: {
        entity_code: this.dynamicUserData.entity_code,
        client_code: this.selectedRowId ? this.roleData.client_code : '',
        client_name: this.sanitizeValue(formData.client_name, true),
        panno: this.sanitizeValue(formData.panno, true),
        tanno: this.sanitizeValue(formData.tanno, true),
        bank_branch_code: this.sanitizeValue(formData.bank_branch_code ,true),

        parent_code: this.selectedParentCodeValue,
        client_type_code: this.sanitizeValue(formData.client_type_code, true),

        add1: this.sanitizeValue(formData.add1, true),
        add2: this.sanitizeValue(formData.add2, true),
        add3: this.sanitizeValue(formData.add3, true),
        add4: this.sanitizeValue(formData.add4, true),
        city: this.sanitizeValue(formData.city, true),
        pin: this.sanitizeValue(formData.pin),

        state_code: this.sanitizeValue(formData.state),

        country_code: '',
        stdcode: this.sanitizeValue(formData.stdcode),
        phoneno: this.sanitizeValue(formData.phoneno),
        mobileno: this.sanitizeValue(formData.mobileno),
        email_id: this.sanitizeValue(formData.email_id),
        alternate_phoneno: this.sanitizeValue(formData.alternate_phoneno),
        alternate_mobileno: this.sanitizeValue(formData.alternate_mobileno),
        alternate_email_id: this.sanitizeValue(formData.alternate_email_id),
        alternate_stdcode: this.sanitizeValue(formData.alternate_stdcode),
        branch_division: this.sanitizeValue(formData.branch_division, true),
        ministry_code: '',
        sub_ministry_code: '',
        ain_no: '',
        client_catg_code: this.sanitizeValue(formData.client_catg_code, true),
        pao_code: '',
        pao_registration_no: '',
        ddo_code: '',
        ddo_registration_no: '',
        ministry_name_other: '',
        ministry_state_code: '',
        traces_id: this.sanitizeValue(formData.traces_id),
        traces_pwd: this.sanitizeValue(formData.traces_pwd),
        add_change: '',
        add_change_on: '',
        deductor_name: this.sanitizeValue(formData.deductor_name, true),
        deductor_desig: this.sanitizeValue(formData.deductor_desig, true),
        deductor_phoneno: this.sanitizeValue(formData.deductor_phoneno),
        deductor_mobileno: this.sanitizeValue(formData.deductor_mobileno),
        deductor_email_id: this.sanitizeValue(formData.deductor_email_id),
        deductor_panno: this.sanitizeValue(formData.deductor_panno, true),
        deductor_add1: this.sanitizeValue(formData.deductor_add1, true),
        deductor_add2: this.sanitizeValue(formData.deductor_add2, true),
        deductor_add3: this.sanitizeValue(formData.deductor_add3, true),
        deductor_add4: this.sanitizeValue(formData.deductor_add4, true),
        deductor_city: this.sanitizeValue(formData.deductor_city, true),
        deductor_pin: this.sanitizeValue(formData.deductor_pin),
        emp_code: '',
        user_role_code: '',
        deductor_state_code: this.sanitizeValue(formData.deductor_state_code),
        deductor_country_code: '',
        deductor_stdcode: this.sanitizeValue(formData.deductor_stdcode),
        deductor_alternate_stdcode: this.sanitizeValue(formData.deductor_alternate_stdcode),
        deductor_alternate_phoneno: this.sanitizeValue(formData.deductor_alternate_phoneno),
        deductor_alternate_email_id: this.sanitizeValue(formData.deductor_alternate_email_id),
        deductor_add_change: '',
        deductor_add_change_on: '',
        code_level: this.selectedClientLevelValue,
        approvedby: '',
        approveddate: ''
      }

    };

    this.apiservice
      .miudApi('/ClientMast/get_miud_client_mast', qData).subscribe({
        next: (response: any) => {
          // Stabilize getters before any modifications to avoid ExpressionChangedAfterItHasBeenCheckedError
          this.cdr.detectChanges();
          window.dispatchEvent(new Event('clientAdded'));

          if (response?.result[0]?.a_proc_error == 0) {
            this.isSubmittingUpdateLoader = false;
            this.toastService.showSuccess(response?.result[0]?.a_proc_error_message || (this.selectedRowId ? 'Client Updated Successfully!' : 'Client Added Successfully!')
            );

            this.close.emit();
            this.refreshdata.trigerRefresh('Clients');

            if (this.dynamicUserData.first_time_login == 1) {
              this.updateLoginstatus();
              const message = response?.result?.[0]?.a_proc_error_message;
              localStorage.setItem('lastSuccessMessage', message);
            }


          }
          else {
            // this.toastService.showError(response?.result[0]?.a_proc_error_message || 'Failed to add client');
            // if (response?.result[0]?.a_errors && Array.isArray(response?.result[0]?.a_errors)) {
            //   response?.result[0]?.a_errors.forEach(
            //     (error: { field: string; message: string }) => {
            //       const field = error.field;
            //       console.log(field)
            //       if (this.clientForm.controls[field]) {
            //         this.clientForm.controls[field].setErrors({
            //           serverError: error.message,
            //         });
            //       }
            //     }
            //   );
            //   this.showError(response?.result[0]?.a_proc_error_message);
            // }
            if (response?.result[0]?.a_errors && Array.isArray(response?.result[0]?.a_errors)) {
              this.isSubmittingUpdateLoader = false;
              const errors = response?.result[0]?.a_errors;
              const errorMessage = response?.result[0]?.a_proc_error_message;
              const errorSections = new Set<number>();

              errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                  const control = this.clientForm.get(field);

                  // Track which accordion sections have errors
                  const section = this.accordionFieldMap[field];
                  if (section) {
                    errorSections.add(section);
                  }

                  // Set error on form control
                  if (control) {
                    // Store server error separately (won't be cleared by validators)
                    this.serverErrors[field] = error.message;

                    // Also set on form control for invalid state
                    const existingErrors = control.errors || {};
                    const mergedErrors = {
                      ...existingErrors,
                      serverError: error.message
                    };
                    control.setErrors(mergedErrors);

                    // Mark as touched and dirty to show error immediately
                    control.markAsTouched();
                    control.markAsDirty();

                    // Log to verify error is set
                    // console.log(`Set error on ${field}:`, this.serverErrors[field], `Touched: ${control.touched}, Invalid: ${control.invalid}`);
                  }
                }
              );

              // Open the first accordion section with errors
              if (errorSections.size > 0) {
                const firstErrorSection = Math.min(...Array.from(errorSections));
                this.openInfoId = firstErrorSection;
                // console.log('Opened accordion:', firstErrorSection);
              }

              // Show global error toast
              this.showError(errorMessage);

              // Force change detection after setting all errors
              this.cdr.detectChanges();

              // Verify errors persist after a short delay
              setTimeout(() => {
                errors.forEach((error: { field: string; message: string }) => {
                  const control = this.clientForm.get(error.field);
                  // console.log(`After 2s - ${error.field}:`, control?.errors, `Touched: ${control?.touched}, Invalid: ${control?.invalid}`);
                });
              }, 2000);
            }

            else {
              this.isSubmittingUpdateLoader = false;
              this.showError(
                response?.result[0]?.a_proc_error_message || 'Error while creating User.'
              );
              // this.isSubmitting = false;
            }
          }

        },
        error: (error: any) => {
          this.isSubmittingUpdateLoader = false;
          console.error(error);
        },
      });

  }


  //   clearClientTypeCategInput(event: MouseEvent): void {
  //   event.stopPropagation(); // prevent dropdown from toggling

  //   // Identify which dropdown's clear icon was clicked
  //   const target = event.target as HTMLElement;
  //   const parentButton = target.closest('button');
  //   if (!parentButton) return;

  //   // Find which key belongs to this button by inspecting its index or form control
  //   const keys = ['client_type_code', 'client_catg_code'];
  //   for (const key of keys) {
  //     if (this.clientForm.get(key)) {
  //       // If this dropdown has a value, clear it
  //       if (this.clientForm.get(key)?.value) {
  //         this.clientForm.get(key)?.setValue('');
  //       }
  //     }
  //   }

  //   // Optional: mark as touched so validation messages show correctly
  //   this.clientForm.markAsTouched();
  // }

  // ✅ Clear selected value and trigger validation
  clearClientTypeCategInput(event: MouseEvent, key: string): void {
    event.stopPropagation(); // prevent dropdown from toggling

    const control = this.clientForm.get(key);
    if (control) {
      control.setValue('');               // clear the value
      control.markAsTouched();            // mark as touched for showing validation
      control.markAsDirty();              // mark as dirty for validation re-check
      control.updateValueAndValidity();   // re-run validators
    }
  }

  clearstatateInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedStateOptionLabel = 'Select';
    this.selectedStateOptionValue = null;
    this.clientForm.patchValue({
      state: '',
    });
    this.clientForm.get('state')?.markAsTouched();

  }

  cleardeductorStatateInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedDeductorStateOptionLabel = 'Select';
    this.selectedDeductorStateOptionValue = null;
    this.clientForm.patchValue({
      deductor_state_code: '',
    });
    this.clientForm.get('deductor_state_code')?.markAsTouched();
    this.clientForm.get('deductor_state_code')?.markAsDirty();
    this.clientForm.get('deductor_state_code')?.updateValueAndValidity();
  }

  roleData: any;
  detailsLoader: boolean = false;

  selectedClientTypeValue: any;
  selectedClientTypeLabel: string = '';
  selectedClientCategoryLabel: string = '';
  selectedClientCategoryValue: any;

  fetchUserDetails(roleCode: string) {
    //  this.detailsLoader =false;

    const requestBody = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: 'get_gmdt_client_mast',
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/ClientMast/get_gmdt_client_mast', requestBody)
      .subscribe({
        next: (response) => {

          if (response.result.a_proc_error == 0) {
            this.detailsLoader = false;
            const roleData =
              response?.result?.get_gmdt_client_mast
                ?.get_gmdt_client_mast_detail?.[0];
            this.roleData = roleData


            if (!roleData) {
              this.showError('No user data found.');
              return;
            }
            let firstName = '';
            let lastName = '';
            if (roleData.user_name) {
              const parts = roleData.user_name
                .split('~')
                .map((p: string) => p.trim());
              firstName = parts[0] || '';
              lastName = parts[1] || '';
            }

            const add1Value =
              roleData.add1;

            // console.log(add1Value);
            //   roleData.add2 ||
            //   roleData.add3 ||
            //   roleData.add4 ||
            //   ' ';

            this.tanManuallyChanged = false; // reset flag before patch
            this.clientForm.patchValue({
              // Client Basic Details from CONSO BH record

              tanno: roleData.tanno || '',
              client_name: roleData.client_name || '',
              panno: roleData.panno || '',
              branch_division: roleData.branch_division || '',
              bank_branch_code: roleData.bank_branch_code || '',
              client_catg_code: roleData.client_catg_code || '',
              client_type_code: roleData.client_type_code || '',

              // Organization Address Details from CONSO BH record
              add1: add1Value,
              add2: roleData.add2 || '',
              add3: roleData.add3 || '',
              add4: roleData.add4 || '',
              city: roleData.city || '',
              state: roleData.state_code || '',
              pin: roleData.pin || '',
              email_id: roleData.email_id || '',
              mobileno: roleData.mobileno || '',
              phoneno: roleData.phoneno || '',
              stdcode: roleData.stdcode || '',
              alternate_phoneno: roleData.alternate_phoneno || '',
              alternate_mobileno: roleData.alternate_mobileno || '',
              alternate_email_id: roleData.alternate_email_id || '',
              alternate_stdcode: roleData.alternate_stdcode || '',

              // Responsible Person Details from CONSO BH record
              deductor_name: roleData.deductor_name || '',
              deductor_desig: roleData.deductor_desig || '',
              deductor_panno: roleData.deductor_panno || '',
              deductor_email_id: roleData.deductor_email_id || '',
              deductor_mobileno: roleData.deductor_mobileno || '',
              deductor_phoneno: roleData.deductor_phoneno || '',
              deductor_stdcode: roleData.deductor_stdcode || '',

              // Responsible Person Address from CONSO BH record
              deductor_add1: roleData.deductor_add1 || '',
              deductor_add2: roleData.deductor_add2 || '',
              deductor_add3: roleData.deductor_add3 || '',
              deductor_add4: roleData.deductor_add4 || '',
              deductor_city: roleData.deductor_city || '',
              deductor_state_code: roleData.deductor_state_code || '',
              deductor_pin: roleData.deductor_pin || '',

              // Credentials (pre-fill TAN as Income Tax ID)
              incometax_id: roleData.incometax_id || roleData.tanno || ''
            },
              { emitEvent: true } //  ensures valueChanges triggers for pin & deductor_pin
            );
            // prevent API call during patching
            setTimeout(() => (this.tanManuallyChanged = true), 0);

            // this.validateTanAndReset(roleData.tanno);

            // Step 4: If roleData contains a preselected level, use it
            if (roleData?.code_level) {

              const matchedLevel = this.codeLevelOptions.find(
                (opt: any) => opt.value === roleData.code_level
              );

              if (matchedLevel) {
                // Match found → select it
                this.selectedClientLevelLabel = matchedLevel.label;
              
                this.selectedClientLevelValue = matchedLevel.value;
              } else {
                // No match → fallback using roleData.client_level_name (if available)
                this.selectedClientLevelLabel = roleData.client_level_name || '';
                this.selectedClientLevelValue = roleData.code_level;
              }
            }

            // Now, handle roleData.parent_code (example: 1)
            if (roleData?.parent_code && roleData?.code_level) {
              this.getclientParentData(roleData?.code_level);
            }

            if (roleData?.client_type_code) {

              const matchedParent = this.clientTypeOptions.find(
                (opt: any) => opt.value === roleData.client_type_code.toString()
              );

              if (matchedParent) {
             
                // If found in the list
                this.selectedClientTypeLabel = matchedParent.label;
                this.selectedClientTypeValue = matchedParent.value;
                   this.onClientTypeChange(this.selectedClientTypeValue)
              } else {
                // Otherwise, bind manually (assuming you want to show client_level_name)
                this.selectedClientTypeLabel = roleData.label;
                this.selectedClientTypeValue = roleData.value;
              }
            }
//             if (roleData?.client_catg_code) {

//               const matchedParent = this.clientCategoryOptions.find(
//                 (opt: any) => opt.value === roleData.client_catg_code.toString()
//               );

// console.log(matchedParent);
//               if (matchedParent) {
//                 // If found in the list
//                 this.selectedClientCategoryLabel = matchedParent.label;
//                 this.selectedClientCategoryValue = matchedParent.value;
//               } else {
//                 // Otherwise, bind manually (assuming you want to show client_level_name)
//                 this.selectedClientCategoryLabel = roleData.label;
//                 this.selectedClientCategoryValue = roleData.value;
//               }
//             }


            if (this.clientForm.value.state) {
              // Keep the full state list
              this.filteredStateOptions = [...this.stateMastOptions];
              this.filteredDeductorStateOptions = [...this.stateMastOptions];

              // Find the matched state
              const matchedState = this.stateMastOptions?.find(
                (opt: any) => opt.value == this.clientForm.value.state
              );

              if (matchedState) {
                // Set selected labels
                this.selectedStateOptionLabel = matchedState.label;
                this.selectedStateOptionValue = roleData.state;
                this.selectedDeductorStateOptionLabel = matchedState.label;
                this.selectedDeductorStateOptionValue = roleData.deductor_state_code;

                // Optionally patch form again if needed
                this.clientForm.patchValue({
                  state: matchedState.value,
                  deductor_state_code: matchedState.value,

                }, { emitEvent: false }); // avoid triggering valueChanges unnecessarily
              }

            }
          }
          else {

          }

        },
        error: () => {
          this.showError('Failed to fetch User details.');
          this.detailsLoader = false;
        },
      });
  }


  tanErrorMessage: any;

  // validateTanAndReset(tan: string) {
  //   const tanControl = this.clientForm.get('tanno');
  // if (tan) {
  //             const upperVal = tan.toUpperCase();
  //             if (upperVal !== tan) {
  //               tanControl?.setValue(upperVal, { emitEvent: false });
  //             }

  //             //  When exactly 10 characters → valid TAN, fetch data
  //             if (upperVal.length === 10 && !this.isFetchingTanData) {
  //               tanControl?.setErrors(null); 
  //               this.getTanPanData(upperVal);
  //             }
  //             //  When 1–9 characters → show "Invalid TAN"
  //             else if (upperVal.length < 10) {
  //               this.resetClientFormExceptTan();
  //               tanControl?.setErrors({ invalidTan: true });
  //               tanControl?.markAsTouched();
  //               tanControl?.markAsDirty();
  //             }
  //           }
  //           //  When length = 0 → required error
  //           else {
  //             this.resetClientFormExceptTan();
  //             tanControl?.setErrors({ required: true });
  //             tanControl?.markAsTouched();
  //             tanControl?.markAsDirty();
  //           }
  // }



  errorMessage: string = '';

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }
  private tanManuallyChanged = false;
  toggleEditMode() {
    this.openInfoId = 1;
    this.isEditMode = !this.isEditMode;

    // 👇 When toggled to edit mode, enable form logic
    if (this.isEditMode) {
      this.subscribeToFormChanges(); // function for TAN, PIN, etc.
    }
  }

  private subscribeToFormChanges() {
    // 🔸 TAN field uppercase and validation
    this.clientForm.get('tanno')?.valueChanges
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((val: string) => {
        if (!val) return;

        const upperVal = val.toUpperCase();
        if (upperVal !== val) {
          this.clientForm.get('tanno')?.setValue(upperVal, { emitEvent: false });
        }

        // ✅ Only call API when TAN is manually changed
        if (this.tanManuallyChanged && upperVal.length === 10 && !this.isFetchingTanData) {
          this.getTanPanData(upperVal);
        }
      });

    // 🔸 Auto-fill incometax_id
    this.clientForm.get('tanno')?.valueChanges.subscribe((val: string) => {
      if (val) {
        const upperVal = val.toUpperCase();
        this.clientForm.get('incometax_id')?.setValue(upperVal, { emitEvent: false });
      } else {
        this.clientForm.get('incometax_id')?.reset('', { emitEvent: false });
      }
    });

    // 🔸 PIN code lookup
    this.clientForm.get('pin')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        filter(value => /^\d{6}$/.test(value)),
        takeUntil(this.destroy$)
      )
      .subscribe(value => this.getPinCodeData(value, 'state'));

    this.clientForm.get('deductor_pin')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        filter(value => /^\d{6}$/.test(value)),
        takeUntil(this.destroy$)
      )
      .subscribe(value => this.getPinCodeData(value, 'deductor_state_code'));

    // 🔸 Prefill address & setup sync
    this.setupAutoFill();
    this.prefillResponsibleFields();
  }



  // call iud for update 

  updateLoginstatus() {
    const requestBody = {
      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_process_seqno: '',
      a_iud_type: "fl",
      a_proc_type: 'get_miud_user_mast',
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      user_mast: {
        user_code: this.dynamicUserData.user_code,
        user_name: this.dynamicUserData.user_name,
        user_role_code: this.dynamicUserData.user_role_code,
        email_id: this.dynamicUserData.email_id,
        entity_code: this.dynamicUserData.entity_code,
        bank_branch_code: this.dynamicUserData.bank_branch_code,
        user_level: this.dynamicUserData.user_level,
        default_acc_year: this.dynamicUserData.default_acc_year,
        login_id: this.dynamicUserData.login_id,
        login_pwd: this.dynamicUserData.login_pwd,
        default_quarter_no: this.dynamicUserData.default_quarter_no,
        default_tds_type_code: this.dynamicUserData.default_tds_type_code,
        default_tran_month: this.dynamicUserData.default_tran_month,
        default_module_type_code: this.dynamicUserData.default_module_type_code,
        first_time_login: '0',

      },
    };


    this.apiservice.miudApi("/UserMast/get_miud_user_mast", requestBody).subscribe({
      next: (res) => {

      },
      error: (err) => {
        console.error('Submit request error:', err);

      },
    });
  }


  searchclientText: string = '';
filteredClientLevelOptions: any[] = [];

filterClientLevelOptions() {
  const search = this.searchclientText.toLowerCase();
  this.filteredClientLevelOptions = this.codeLevelOptions.filter((option: any) =>
    option.label.toLowerCase().includes(search)
  );
}



}
