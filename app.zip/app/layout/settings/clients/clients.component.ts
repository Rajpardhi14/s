import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { BasicFilterComponent } from '../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../shared/components/advance-filter/advance-filter.component';
import { Subject, Subscription } from 'rxjs';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { GearboxComponent } from '../../../shared/components/gearbox/gearbox.component';
import { TableskeletonComponent } from '../../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../../shared/components/nodata/nodata.component';
import { ClientdrawerComponent } from './clientdrawer/clientdrawer.component';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { AddclientComponent } from './addclient/addclient.component';
import {
  capitalizeEachWord,
  capitalizeOnlyFirst,
  toLowerCaseValue,
} from '../../../shared/utils/passmatch';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';

@Component({
  selector: 'app-clients',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    BasicFilterComponent,
    AdvanceFilterComponent,
    AddclientComponent,
    GearboxComponent,
    TableskeletonComponent,
    NodataComponent,
    ClientdrawerComponent,
    OutSideClickDirective,
    ButtoneventlisnerDirective
  ],
  templateUrl: './clients.component.html',
  styleUrl: './clients.component.css',
})
export class ClientsComponent {
  capitalizeEachWord = capitalizeEachWord;
  capitalizeOnlyFirst = capitalizeOnlyFirst;
  toLowerCase = toLowerCaseValue;
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;

  localUserData: any;
  dynaUserData: any;
  allUsersData: any[] = [];
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;

  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';

  approvedDate: any;
  selectedRoleId: string | null = null;
  isApprovemodalOpen: boolean = false;

  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false; // Loader state
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  isOpenBulkPopup: boolean = false;
  isOpenUpdatePopup: boolean = false;
  // selectedMaster: string = 'USER_MASTER';
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenEditClient: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = "Yes";
  localstoredClientTypeData: any;
  localstoredCategData: any;
  localstoredStateData: any;
  addClientPopup: boolean = false;
  multiMast: any;
    excelheaders: any[] = [];
  exceltableBody: any[] = [];

  private destroy$ = new Subject<void>();

  constructor(
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private refreshdata: RefreshdataService
  ) {
    this.filterForm = this.fb.group({});
  }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
     this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.getsData();
    this.fetchUsers();
    this.alluserFilter();
    this.allUserGrandTotal();
    // this.refreshdata.fy$
    //   .pipe(distinctUntilChanged(), takeUntil(this.destroy$))
    //   .subscribe((fy) => {
    //     this.FYYear = fy;
    //     this.apiService.getFYYear(this.FYYear);
    //   });

    this.refreshSubscription = this.refreshdata
      .onRefresh('Clients')
      .subscribe(() => {
        this.fetchUsers();
        this.allUserGrandTotal();
      });

    // Get initial screen size
    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    // const data = DUMMY_USER_RESPONSE;
    // const userData = data.result?.get_gmdb_client_mast;
    // // this.paginatedList=data.result?.get_gmdb_client_mast
    // this.paginatedList = userData?.get_gmdb_client_mast_detail || [];

    // this.headers = userData?.get_gmdb_client_mast_header.map(
    //   (header: any) => ({
    //     ...header,
    //     visible: header.display === 1,
    //   })
    // );
  }

  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
          this.multiMast = parsedData.multiMast;
          const storedClientTypeData = this.multiMast.get_gmdt_client_type_mast;

          if (storedClientTypeData) {
            this.localstoredClientTypeData = storedClientTypeData;

          }
        } catch (e) {
          parsedData = response.data;
        }
        // console.log('Parsed Redis data:', parsedData);
      },
      error: (error: any) => {
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }

  // getLocalData() {
  //   if (typeof window !== 'undefined') {
  //     var storedTypeData = sessionStorage.getItem('clientTpeData');
  //     var storedCategData = sessionStorage.getItem('clientCatgData');
  //     var storedStateData = sessionStorage.getItem('stateData');
  //     console.log(storedTypeData);
  //     if (storedTypeData) {
  //       this.localstoredTypeData = JSON.parse(storedTypeData);
  //       console.log(this.localstoredTypeData);
  //     }
  //     if (storedCategData) {
  //       this.localstoredCategData = JSON.parse(storedCategData);
  //     }
  //     if (storedStateData) {
  //       this.localstoredStateData = JSON.parse(storedStateData);
  //       console.log(this.localstoredStateData);
  //     }
  //   }
  // }




  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  openAddClient(roleCode?: string) {
    this.selectedRoleCode = roleCode ?? null;
    this.addClientPopup = true;
    this.drawerOpen = false;
  }

  closeedAddClient() {
    this.selectedRoleCode = null;
    this.drawerOpen = false;
    this.addClientPopup = false;
  }

  firstAndLastName(user: any): any {
    if (!user || typeof user.user_name !== 'string') {
      return { ...user, user_name: '' };
    }
    const nameParts = user.user_name
      .trim()
      .replace(/-/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
    const firstInitial = nameParts[0]?.[0]?.toUpperCase() || '';
    return { ...user, user_name: firstInitial };
  }

  //alluser tabledata
  fetchUsers() {
    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmdb_client_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,

      },

    );
    this.apiService
      .getTableData('/ClientMast/get_gmdb_client_mast', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data.result?.get_gmdb_client_mast;
            if (userData?.get_gmdb_client_mast_header) {
              this.headers = userData?.get_gmdb_client_mast_header.map(
                (header: any) => ({
                  ...header,
                  visible: header.display === 1,
                })
              );
            }
            this.allUsersData = userData || {};
            this.tableBody = userData?.get_gmdb_client_mast_detail || [];
            this.mergeGroups = {};
            this.fieldToMergeGroup = {};
            this.buildMergeGroups();
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchUsers();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  buildMergeGroups() {
    this.headers.forEach((header) => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }

  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );
  }

  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private alluserFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmfb_client_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage
    );

    this.apiService
      .getFilterData('/ClientMast/get_gmfb_client_mast', sdata)
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error === '0') {
            this.basic_filter =
              response?.result?.get_gmfb_client_mast?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gmfb_client_mast?.[1]?.advance_filter;

            this.advance_filter?.forEach((field: any) => {
              if (
                field.filter_col_external === 1 &&
                field.filter_col_type === 'filter-select'
              ) {
                const allOption = { value: 'ALL', label: 'All' };
                const exists = field.filter_col_depend_value?.some(
                  (opt: any) => opt.value === 'ALL'
                );
                if (!exists) {
                  field.filter_col_depend_value?.unshift(allOption);
                }
              }
            });
            //Find the first external filter-select field
            const defaultField = this.advance_filter?.find(
              (field: any) =>
                field.filter_col_external === 1 &&
                field.filter_col_type === 'filter-select'
            );
            //Get the default option with value 'ALL'
            const defaultOption = defaultField?.filter_col_depend_value?.find(
              (opt: any) => opt.value === 'ALL'
            );
            //Store default tab info
            this.defaultTabFilter = defaultOption;
            this.activeFilterTab = defaultOption?.value;
            //Initialize form and menu
            this.initializeForm();
            this.menuOptions = this.basic_filter?.map((filter: any) => ({
              label: filter.filter_col_prompt,
              field: filter.filter_col_field,
              operator: filter.filter_col_depend_operator,
              alias: filter.filter_col_field_alias,
              placeholder: filter.filter_col_placeholder,
            }));
            this.selectedOption = this.menuOptions?.[0];
          } else {
            this.errorMessage = response.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }

          if (this.isFirstLoad) {
            this.isSkeletonshow = false;
            this.isFirstLoad = false;
          }
        },
        error: (error) => {
          console.error('Error user filter:', error);
          this.isSkeletonshow = false;
        },
      });
  }
  //#endregion

  selectedTabFilter(filterField: string, value: any, label: any): void {
    this.selectedValue = value;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    //Always run logic even if the tab value is the same as previous
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase(); // Convert to lowercase
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

      this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchUsers(), this.allUserGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }



  private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }
  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {
        // <-- KEY CHANGE HERE
        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator || 'like';
        filterValue = controlValue.toString().trim();

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.trim().toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value.trim();
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    const selectedFilters: { label: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }
  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  // user grand total

  private allUserGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gmdg_client_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,

      },
    );

    this.apiService
      .getGrandTotal('/ClientMast/get_gmdg_client_mast', sdata)
      .subscribe({
        next: (response) => {
          // this.loading = false;
          this.isLoadingMore = false;
          if (response?.result?.a_proc_error == 0) {
            // Success case
            this.usergrandtotal =
              response?.result?.get_gmdg_client_mast?.[0]?.rec || null;
            this.totalcount = this.usergrandtotal;
          } else {
            this.showError(this.errorMessage);
          }
        },
        error: (error) => {
          // this.loading = false;
          this.isLoadingMore = false;
          // console.error('Error fetching vendor data:', error);
          this.showError('Something Went Wrong');
        },
      });
  }

  // Remove all filter label values
  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.selectedFilters = [];
    this.filterClause = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (control) {
          control.setValue('');
        }
      });
    }
    this.filtercount = this.getSelectedFilterCount();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  openApproveModal(roleId: string) {
    this.selectedRoleId = roleId;
    this.isApprovemodalOpen = true;
  }

  //single detail alluser
  // userSingleDetails(rowCode: string): Promise<any> {
  //   return new Promise((resolve, reject) => {
  //     const requestBody = {
  //       sdata: JSON.stringify({
  //         a_proc_type: 'get_gmdt_vc_user_mast',
  //         a_entity_code: this.localUserData.entity_code,
  //         a_client_code: this.localUserData.client_code,
  //         a_first_level_client_code: this.localUserData.first_level_client_code,
  //         a_bank_branch_code: this.localUserData.bank_branch_code,
  //         a_client_code_level: this.localUserData.client_code_level,
  //         a_acc_year: this.FYYear,
  //         a_quarter_no: this.localUserData.default_quarter_no,
  //         a_tran_month: this.localUserData.default_tran_month,
  //         a_validation_client_level: this.localUserData.client_code_level,
  //         a_user_role_type_code: this.localUserData.user_role_type_code,
  //         a_user_role_code: this.localUserData.user_role_code,
  //         a_tran_from_date: '01-APR-2024',
  //         a_tran_to_date: '30-JUN-2024',
  //         a_tds_type_code: this.localUserData.default_tds_type_code,
  //         a_in_parameter_json: [{ a_rowid_seq: rowCode }],
  //       }),
  //     };
  //     this.apiService.getGrandTotal('/ClientMast/get_gmdb_client_mast', requestBody).subscribe({
  //       next: (response) => {
  //         const userData =
  //           response?.result?.get_gmdt_vc_user_mast
  //             ?.get_gmdt_vc_user_mast_detail?.[0];
  //         if (userData) {
  //           this.userData = userData;
  //           this.approvedDate = userData.approveddate;
  //           resolve(userData);
  //         } else {
  //           reject('No data found.');
  //         }
  //       },
  //       error: () => {
  //         this.showError('Failed to fetch User details.');
  //         reject('Failed to fetch User data.');
  //       },
  //     });
  //   });
  // }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  // exportToExcel(): void {
  //   this.exceldownload.downloadExcel(
  //     this.headers,
  //     this.tableBody,
  //     'users_data'
  //   );
  // }

  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }

  ///

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }

  isPopupOpen: boolean = false;

  openPopup() {
    // your existing single client popup
    // console.log('Open single client popup');
  }

  closePopup() {
    this.isPopupOpen = false;
  }

  handleUserAdded(newUser: any) {
    this.closePopup();
  }

  drawerOpen = false;
  isOpen = false;

  openDrawer() {
    this.drawerOpen = true;
  }

  onDrawerClosed() {
    this.drawerOpen = false;
  }

  onImportDrawerClosed() {
    this.drawerOpen = false; // or handle differently if needed
  }

  addSingleClient() {
    this.isOpen = false;
    this.drawerOpen = true; // open drawer
  }

  bulkImport() {
    this.isOpen = false;
    this.drawerOpen = true; // open drawer (bulk import flow)
  }

  selectedMenu: string = 'single'; // default selection

  setSelected(option: string) {
    this.selectedMenu = option;

    if (option === 'single') {
      this.addSingleClient();
    } else if (option === 'bulk') {
      this.bulkImport();
    }
  }



     sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";


   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }


    fetchTableExcel(isClearAction = false) {
    this.detailsLoader = true;

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
   'get_gmdb_client_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,

      },

    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.get_gmdb_client_mast;
          if (userData?.get_gmdb_client_mast_header) {
            this.excelheaders = userData?.get_gmdb_client_mast_header?.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,

              })
            );

          }

          this.exceltableBody = userData?.get_gmdb_client_mast_detail || [];
          this.detailsLoader = false;
          this.exceldownload.downloadExcel(
            this.excelheaders,
            this.exceltableBody,
            'clients_data'
          );


        } else {
          this.loading = false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
          this.detailsLoader = false;
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
        this.detailsLoader = false;
      },
    });

  }

  exportToExcel() {


    if (this.totalcount > 10000) {
      this.showSuccess("The Report will available in Downloads Shortly...!");
      this.fetchGenerateTable()
    }
    else {
      this.showSuccess("Excel Download Process Start...!");
      this.fetchTableExcel(this.filterClause);
    }

  }

    private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }


  detailsLoader: boolean = false;

  fetchGenerateTable(isClearAction = false) {

    // this.detailsLoader = true;
    // Ensure filterClause is always an array
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
    // console.log('User Filters:', userFilters);

    // Define default filters
    const defaultFilters = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },

    ];

    //  Logic for which filters to use
    let finalFilterClause: any[] = [];

    if (isClearAction) {
      // If clearAllFilters was called → send empty array
      finalFilterClause = [];
    } else if (userFilters.length > 0) {
      // If user has applied filters → use user filters
      finalFilterClause = userFilters;
    } else {
      // Initial load → use default filters
      finalFilterClause = defaultFilters;
    }


    const sdata: any = {
      a_iud_seqno: '',
      a_db_total_records: this.totalcount,
      // a_db_total_records: '100',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: this.dynaUserData.default_sub_module_type_code,
      a_session_seqno: '',
      a_proc_type: 'get_gmdb_client_mast',
      a_user_code: this.localUserData.user_code,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_seqno: '',
      a_iud_type: '',
      a_filter_clause: finalFilterClause,
      // a_filter_clause: selectedFilterClause,
      a_rowid_seq: '',
      dashboard: 'View'
    };
    this.apiService.getTableData(`/Comman/generate_dynamic_report`, sdata).subscribe({
      next: (data) => {
        // this.detailsLoader = false;
        const firstResult = data?.result?.[0];
        // const fileName = firstResult?.s3FileUrl;
        // if (firstResult?.s3FileUrl) {

        //   this.downloadReportFile(fileName, 's3');
        //   this.detailsLoader = false;
        // }

        // Fetch details to refresh table
        // this.fetchDetails(rowId, selectedFilterClause);


        // ✅ Stop loader for this row
        // delete this.loadingFields[rowId];
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
        // this.detailsLoader = false;

        // Stop loader even if error
        // delete this.loadingFields[rowId];
      },
    });
  }

}
