import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddclientComponent } from '../addclient/addclient.component';
import { ConsoParserService } from '../../../../core/services/conso/conso-parser.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { Router } from '@angular/router';
import { ButtoneventlisnerDirective } from '../../../../core/services/session/timer-session/buttoneventlisner.directive';


@Component({
  selector: 'app-clientdrawer',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, AddclientComponent, ButtoneventlisnerDirective],
  templateUrl: './clientdrawer.component.html',
  styleUrl: './clientdrawer.component.css'
})
export class ClientdrawerComponent {
  @Input() open: boolean = false;
  @Input() selectedRowId: any;
  @Input() consoData: any = null; // Data from CONSO file to pre-fill form
  @Output() close = new EventEmitter<void>();          // when main drawer closes
  @Output() closeImport = new EventEmitter<void>();    // when import drawer closes
  openImport: boolean = false;
  selectedFile: File | null = null;
  isProcessing: boolean = false;

  constructor(
    private consoParser: ConsoParserService,
    private toastService: ToastService,
    private router: Router
  ) { }


  closeDrawer() {
    this.openImport = false;
    this.close.emit();   // tell parent main drawer closed
  }


  ngOnInit() {
    // Don't auto-open on init - wait for proper navigation
  }

  ngOnChanges(changes: any) {
    console.log(this.selectedRowId);
    // Handle drawer opening
    if (changes['open'] && changes['open'].currentValue) {
      if (this.consoData) {
        // When drawer opens with CONSO data, go directly to Add Client
        this.addClientPopup = true;
        this.open = false;
      } else {
        // Normal manual opening - show options drawer
        this.addClientPopup = false;
        this.open = true;
      }
    }

    // Reset CONSO data when drawer closes
    if (changes['open'] && !changes['open'].currentValue) {
      this.consoData = null;
    }
  }


  navigateToReturns() {
    const code = 'CLIENT_MAST_02'
    this.router.navigate(['/home/returns'], {
      queryParams: { code: code },
    });
  }


  openDrawer() {
    this.open = true;
    this.openImport = false;
  }


  openImportDrawer() {
    this.open = false;        // close options drawer
    this.openImport = true;   // open import drawer
  }

  closeImportDrawer() {
    this.openImport = false;
    this.selectedFile = null;
    this.closeImport.emit();   // tell parent import drawer closed
  }

  // ----- File Upload Logic -----
  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      console.log('File selected:', this.selectedFile);
    }
  }

  allowDrop(event: DragEvent) {
    event.preventDefault(); // allow drop
  }

  onFileDrop(event: DragEvent) {
    event.preventDefault();
    if (event.dataTransfer && event.dataTransfer.files.length > 0) {
      this.selectedFile = event.dataTransfer.files[0];
      console.log('File dropped:', this.selectedFile);
      event.dataTransfer.clearData();
    }
  }

  removeSelectedFile() {
    this.selectedFile = null;
    console.log('File removed');
  }

  addClientPopup = false;

  openAddClient() {
    this.addClientPopup = true;
    this.openImport = false;
    this.open = false;
  }

  closeAddClient() {
    this.addClientPopup = false;
    this.consoData = null; // Clear CONSO data after closing
    // Don't reopen the drawer - just close everything
    this.close.emit();
  }

  // Process CONSO file and extract data
  processCONSOFile() {
    if (!this.selectedFile) {
      this.toastService.showError('Please select a CONSO file first');
      return;
    }

    // Check file extension
    if (!this.selectedFile.name.endsWith('.tds')) {
      this.toastService.showError('Please select a valid .tds CONSO file');
      return;
    }

    this.isProcessing = true;
    const reader = new FileReader();

    reader.onload = (e: any) => {
      try {
        const fileContent = e.target.result;

        // Parse the CONSO file
        const parsedData = this.consoParser.parseCONSOFile(fileContent, this.selectedFile!.name);

        if (!parsedData || !parsedData.batchHeader) {
          this.toastService.showError('Unable to parse CONSO file - invalid format');
          this.isProcessing = false;
          return;
        }

        // Extract BH data for pre-filling the form
        const bh = parsedData.batchHeader;


        const bhFields = parsedData.batchHeaderFields || [];

        // Create data object with CORRECT BH field mappings from your provided list
        this.consoData = {
          // Client Details - mapped according to your CONSO mapping list
          tanno: bhFields[12] || '',                              // Position 12: tanno
          client_name: bhFields[18] || '',                        // Position 18: client_name
          panno: bhFields[14] || '',                              // Position 14: panno
          branch_division: bhFields[19] || '',                    // Position 19: branch_division
          gstn_no: bhFields[68] || '',                            // Position 68: gstn_no

          // Organization Address (CORRECTED MAPPING)
          add1: bhFields[20] || '',                               // Position 20: add1
          add2: bhFields[21] || '',                               // Position 21: add2
          add3: bhFields[22] || '',                               // Position 22: add3
          add4: bhFields[23] || '',                               // Position 23: add4
          city: bhFields[24] || '',                               // Position 24: city
          state_code: bhFields[25] || '',                         // Position 25: state_code
          pin: bhFields[26] || '',                                // Position 26: pin

          // Contact Information (CORRECTED MAPPING)
          email_id: bhFields[27] || '',                           // Position 27: email_id
          stdcode: bhFields[28] || '',                            // Position 28: stdcode
          phoneno: bhFields[29] || '',                            // Position 29: phoneno
          mobileno: bhFields[47] || '',                           // Position 47: deductor_mobileno (used as mobileno)
          alternate_phoneno: bhFields[62] || '',                  // Position 62: alternate_phoneno
          alternate_email_id: bhFields[63] || '',                 // Position 63: alternate_email_id
          alternate_stdcode: bhFields[61] || '',                  // Position 61: alternate_stdcode

          // Responsible Person Details (CORRECTED MAPPING)
          deductor_name: bhFields[32] || '',                      // Position 32: deductor_name
          deductor_desig: bhFields[33] || '',                     // Position 33: deductor_desig
          deductor_panno: bhFields[58] || '',                     // Position 58: deductor_panno
          deductor_email_id: bhFields[41] || '',                  // Position 41: deductor_email_id
          deductor_mobileno: bhFields[47] || '',                  // Position 47: deductor_mobileno
          deductor_phoneno: bhFields[44] || '',                   // Position 44: deductor_phoneno
          deductor_stdcode: bhFields[43] || '',                   // Position 43: deductor_stdcode

          // Responsible Person Address (CORRECTED MAPPING)
          deductor_add1: bhFields[34] || '',                      // Position 34: deductor_add1
          deductor_add2: bhFields[35] || '',                      // Position 35: deductor_add2
          deductor_add3: bhFields[36] || '',                      // Position 36: deductor_add3
          deductor_add4: bhFields[37] || '',                      // Position 37: deductor_add4
          deductor_city: bhFields[38] || '',                      // Position 38: deductor_city
          deductor_state_code: bhFields[39] || '',                // Position 39: deductor_state_code
          deductor_pin: bhFields[40] || '',                       // Position 40: deductor_pin

          // Additional deductor contact (CORRECTED MAPPING)
          deductor_alternate_stdcode: bhFields[64] || '',         // Position 64: deductor_alternate_stdcode
          deductor_alternate_phoneno: bhFields[65] || '',         // Position 65: deductor_alternate_phoneno
          deductor_alternate_email_id: bhFields[66] || '',        // Position 66: deductor_alternate_email_id

          // Government related fields (CORRECTED MAPPING)
          ministry_code: bhFields[56] || '',                      // Position 56: ministry_code
          ministry_name_other: bhFields[57] || '',                // Position 57: ministry_name_other
          pao_code: bhFields[54] || '',                           // Position 54: pao_code
          pao_registration_no: bhFields[59] || '',                // Position 59: pao_registration_no
          ddo_code: bhFields[55] || '',                           // Position 55: ddo_code
          ddo_registration_no: bhFields[60] || '',                // Position 60: ddo_registration_no
          ain_no: bhFields[67] || '',                             // Position 67: ain_no

          // Status fields
          add_change: bhFields[30] || '',                         // Position 30: add_change
          deductor_add_change: bhFields[45] || '',                // Position 45: deductor_add_change
          client_catg_code: bhFields[31] || '',                   // Position 31: client_catg_code
          state_name: bhFields[53] || '',                         // Position 53: state_name

          // Credentials (TAN as income tax ID)
          incometax_id: bhFields[11] || '',                       // Position 11: tanno (used as income tax ID)

          // Additional metadata from parsed header
          formType: bh.formType,
          financialYear: bh.financialYear,
          assessmentYear: bh.assessmentYear,
          quarter: bh.quarter,
          sourceFile: this.selectedFile!.name,
          isFromCONSO: true,

          // Default values as per Excel mapping
          client_type_code: 'K',                                  // Default 'K' as per mapping
          status_code: 'R'                                        // Default 'R' as per mapping
        };

        console.log('Extracted CONSO data for form:', this.consoData);

        // Close import drawer and open Add Client form with pre-filled data
        this.openImport = false;
        this.addClientPopup = true;

        this.toastService.showSuccess('CONSO file processed successfully! Opening Add Client form...');

      } catch (error: any) {
        console.error('Error processing CONSO file:', error);
        this.toastService.showError('Error processing file: ' + (error.message || 'Unknown error'));
      } finally {
        this.isProcessing = false;
      }
    };

    reader.onerror = () => {
      this.toastService.showError('Error reading file');
      this.isProcessing = false;
    };

    reader.readAsText(this.selectedFile);
  }

}
