import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth/auth.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { LogindatahandlerService } from '../../../core/services/auth/logindatahandler.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';


@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

  personalInfoForm!: FormGroup;
  localUserData: any;
  errorMessage: string = '';
  successMessage: string = '';
  userInitials: any;
  isEditMode: boolean = false;
  isLoading: boolean = false;
  validationList: any[] = [];
  userData: any;
  selectedFile: File | null = null;
  uploadFilePath: string | null = null;
  profileImage: string | ArrayBuffer | null = null;
  myimage: string | ArrayBuffer | null = null;
  userRoleCode = '';
  showProfilePopup = false;
  imageUpdated: boolean = false;
  firstName: string = '';
  lastName: string = '';
  company: string = '';
  email: string = '';
  phone: string = '';
  constructor(
    private fb: FormBuilder,
    private authservice: AuthService,
    private userlocaldataService: UserdataService,
    private toastService: ToastService,
    private loginDataHandler: LogindatahandlerService,
    private apiService:ApiserviceService
  ) { }

  ngOnInit(): void {
    this.loadAllData();
    this.loadUserData();
    this.initializeForm();
  }

  private loadUserData(): void {
    // Get profile data using the login data handler service
    const profileData = this.loginDataHandler.getProfileData();
    const userData = this.loginDataHandler.getUserData();
    
    if (profileData) {
      // Use the properly parsed profile data
      this.firstName = profileData.firstName || '';
      this.lastName = profileData.lastName || '';
      this.company = profileData.company || '';
      this.email = profileData.email || '';
      this.phone = profileData.phone || '';
      this.userRoleCode = profileData.userRole || '';
      
      // Store the complete user data
      this.userData = userData || profileData;
      this.localUserData = this.userData;
      
      // Set user initials
      if (this.firstName) {
        const firstInitial = this.firstName.charAt(0).toUpperCase();
        const lastInitial = this.lastName ? this.lastName.charAt(0).toUpperCase() : '';
        this.userInitials = firstInitial + lastInitial;
      }
    } else if (userData) {
      // Fallback to raw user data if profile data not yet processed
      this.userData = userData;
      this.localUserData = userData;
      
      // Parse name from user_name field (handles special characters like ~)
      if (userData.user_name) {
        const cleanName = userData.user_name.replace(/~/g, ' ');
        const nameParts = cleanName.split(' ').filter((part: string) => part.length > 0);
        
        if (nameParts.length > 0) {
          this.firstName = nameParts[0];
          this.lastName = nameParts.slice(1).join(' ');
        }
      }
      
      this.company = userData.client_code_details || '';
      this.email = userData.login_id || '';
      this.phone = userData.mobileno || userData.phoneno || '';
      this.userRoleCode = userData.user_role_code || '';
      
      // Set user initials
      if (this.firstName) {
        const firstInitial = this.firstName.charAt(0).toUpperCase();
        const lastInitial = this.lastName ? this.lastName.charAt(0).toUpperCase() : '';
        this.userInitials = firstInitial + lastInitial;
      }
    }
  }

  private initializeForm(): void {
    this.personalInfoForm = this.fb.group({
      firstName: [
        this.firstName,
        [
          Validators.required,
          Validators.minLength(2),
          Validators.pattern(this.getValidationPattern('user_name') || '^[a-zA-Z ]+$'),
        ],
      ],
      lastName: [
        this.lastName,
        [Validators.pattern(this.getValidationPattern('user_name') || '^[a-zA-Z ]+$')],
      ],
      company: [
        this.company,
        [
          Validators.required,
          Validators.minLength(2),
        ],
      ],
      email: [
        this.email,
        [
          Validators.required,
          Validators.email,
          Validators.pattern(this.getValidationPattern('login_id') || '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'),
        ],
      ],
      mobileno: [
        this.phone,
        [
          Validators.required,
          Validators.pattern(this.getValidationPattern('mobileno') || '^[0-9]{10}$'),
        ],
      ],
    });
    this.personalInfoForm.disable();
  }
  //getDataByKey
  getDataByKey(key: string): any {
    const multimast = sessionStorage.getItem('multimast');
    if (multimast) {
      try {
        const parsedData = JSON.parse(multimast);
        return parsedData[key] ?? null;
      } catch (error) {
        console.error('Error parsing localStorage data:', error);
      }
    }
    return null;
  }

  //loadData
  loadData(key: string, property: string) {
    const data = this.getDataByKey(key);
    if (data) {
      (this as any)[property] = data;
    }
  }

  /// Call Loaders
  loadAllData() {
    const loaders = [
      { key: 'get_gmdt_regex_validation', property: 'validationList' },
    ];
    loaders.forEach(({ key, property }) => this.loadData(key, property));
  }

  getValidationPattern = (label: string): string | null => {
    const rule = this.validationList.find((v) => v.label === label);
    return rule ? rule.value : null;
  };

  //capitalname
  capitalizeText(controlName: string) {
    const control = this.personalInfoForm.controls[controlName];
    if (control && control.value) {
      const inputElement = document.getElementById(
        controlName
      ) as HTMLInputElement;
      if (inputElement) {
        const cursorPosition = inputElement.selectionStart; // Store cursor position
        // Capitalize first letter of each word, keep rest as typed
        const words = control.value.split(' ');
        const capitalizedWords = words.map((word: string) => {
          if (word.length > 0) {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
          }
          return word;
        });
        control.setValue(capitalizedWords.join(' '), { emitEvent: false });
        setTimeout(() => {
          inputElement.setSelectionRange(cursorPosition, cursorPosition); // Restore cursor position
        }, 0);
      }
    }
  }

  //firstAndLastName
  firstAndLastName(user: any) {
    if (user.user_name && user.user_name.includes(' ')) {
      const [firstName, lastName] = user.user_name.split(' ');
      const initials = `${firstName[0].toUpperCase()}${lastName[0].toUpperCase()}`;
      this.userInitials = initials;
    }
    if (user.user_name) {
      const initials = user.user_name.charAt(0).toUpperCase();
    }
    return user;
  }

  //inputtext
  private originalFormData: any = {};
  private isSaving: boolean = false;
  
  toggleEditMode(fromSave: boolean = false) {
    if (!this.isEditMode) {
      // Store original values before editing starts
      this.originalFormData = this.personalInfoForm.getRawValue();
      // Enable all form fields for editing
      this.personalInfoForm.enable();
      // Keep email disabled as it shouldn't be editable
      this.personalInfoForm.get('email')?.disable();
    } else {
      // Only restore original values if canceling (not saving)
      if (!fromSave) {
        this.personalInfoForm.patchValue(this.originalFormData);
      }
      // Disable all fields again
      this.personalInfoForm.disable();
    }
    this.isEditMode = !this.isEditMode;
  }

  fullName:any;

  // Add onSubmit method
  onSubmit(): void {
    if (this.personalInfoForm.invalid) {
      this.personalInfoForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    const formData = this.personalInfoForm.getRawValue();

      this.fullName =
      formData.firstName && formData.lastName
        ? `${formData.firstName} ~ ${formData.lastName}`
        : formData.firstName || formData.lastName;
  

try {

      const sdata = {
        a_process_seqno: '',
        a_iud_type: 'pu',
        a_proc_type: 'get_miud_user_mast',
        a_user_code: this.localUserData.user_code,
        a_entity_code: this.localUserData.entity_code,
        a_client_code: this.localUserData.client_code,
        a_bank_branch_code: this.localUserData.bank_branch_code,
        a_client_code_level: this.localUserData.client_code_level,
        a_first_level_client_code: this.localUserData.first_level_client_code,
        a_acc_year: this.localUserData.default_acc_year,
        a_quarter_no: '1',
        a_tran_month: this.localUserData.default_tran_month,
        a_tran_from_date: '01-APR-2024',
        a_tran_to_date: '30-JUN-2024',
        a_tds_type_code: this.localUserData.default_tds_type_code,
        user_mast: {
         user_name: this.fullName,
      client_name: formData.company,
      client_code_details:formData.company,
      email_id: formData.email,
      phoneno: formData.mobileno,
       user_code:this.localUserData.user_code,
      entity_code: this.localUserData.entity_code,
	     bank_branch_code: this.localUserData.bank_branch_code,
		"parent_code": "",
		"short_name": "",
		"user_level": "9",
		"login_id": "",
		"login_pwd": "",
		"default_acc_year": "24-25",
		"app_kpi_code_str": "",
		"default_quarter_no": "1",
		"default_tds_type_code": "26Q",
		"default_tran_month": "APR",
		"default_module_type_code": "TAXCPC",
		"add_right": "",
		"edit_right": "",
		"delete_right": "",
		"query_right": "",
		"print_right": "1000",
		"approve_right": 0,
		"is_itms_ddo": 0,
		"is_itms_user": 0,
		"valuation_right": "",
		"special_right": "",
		"upload_file_name": "",
		"user_role_code": "1708",
		"default_color_palette": "",
		"first_time_login": 0,
		"default_font_family": "",
		"sub_module_type_code_str": [
			{
				"module_type_code": "TAXCPC",
				"sub_module_type_code": [
					{
						"value": "R",
						"label": "Regular"
					},
					{
						"value": "G",
						"label": "15GH"
					},
					{
						"value": "CORR",
						"label": "Correction"
					}
				]
			}
		],
		"approvedby": "",
		"approveddate": ""
          
        },
      };

this.apiService.updateProfile('/UserMast/get_miud_user_mast',sdata).subscribe(
        (response: any) => {
          const result = response.result?.[0];
          if (result?.a_proc_error === 0) {
            // this.toastService.showSuccess(result.a_proc_error_message || 'Personal info updated!');
               this.toastService.showSuccess('Profile updated successfully!');
            const updatedData = {
              ...this.userlocaldataService.getLocalUserData(),
              ...sdata.user_mast,

            };
           
            sessionStorage.setItem('localUserData', JSON.stringify(updatedData));
            this.localUserData = this.userlocaldataService.getLocalUserData();
            
            // Update component properties with new values
            this.firstName = formData.firstName;
            this.lastName = formData.lastName;
            this.company = formData.company;
            this.email = formData.email;
            this.phone = formData.mobileno;
            
            // Update the form with new values
            this.personalInfoForm.patchValue({
              firstName: this.firstName,
              lastName: this.lastName,
              company: this.company,
              email: this.email,
              mobileno: this.phone
            });
            
            // Update user initials if name changed
            if (this.firstName) {
              const firstInitial = this.firstName.charAt(0).toUpperCase();
              const lastInitial = this.lastName ? this.lastName.charAt(0).toUpperCase() : '';
              this.userInitials = firstInitial + lastInitial;
            }
            
            // Update userData object
            this.userData = updatedData;
            
            // Also update the profile data in localStorage
            const updatedProfileData = {
              ...this.loginDataHandler.getProfileData(),
              firstName: this.firstName,
              lastName: this.lastName,
              fullName: this.fullName?.replace(/~/g, ' '),
              email: this.email,
              phone: this.phone,
              company: this.company
            };
            sessionStorage.setItem('userProfile', JSON.stringify(updatedProfileData));
            
            // Exit edit mode (only once) - pass true to indicate it's from save
            this.toggleEditMode(true);
            this.isLoading = false;
         
          } else {
            this.handleServerErrors(result);
            this.profileImage = null;
          }

          this.isLoading = false;
        },
        (error) => {
          console.error('Error updating info:', error);
          this.toastService.showError('Error updating personal info.');
          this.isLoading = false;
        }
      );
    } catch (error) {
      this.toastService.showError('Error updating info:');
      console.error(error);
      this.isLoading = false;
    }


  }

  

  private handleServerErrors(result: any) {
    if (Array.isArray(result.a_errors)) {
      result.a_errors.forEach((error: { field: string; message: string }) => {
        const field = error.field;
        if (this.personalInfoForm.controls[field]) {
          this.personalInfoForm.controls[field].setErrors({ serverError: error.message });
        }
      });
    }

    if (result.a_proc_error_message) {
      this.toastService.showError(result.a_proc_error_message);
    }
  }
  get f() {
    return this.personalInfoForm.controls;
  }






  // end
  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }

  onEditProfileImage() {
    // Trigger file input or other logic
  }





}
