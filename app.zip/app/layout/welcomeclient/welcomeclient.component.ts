import { Component, Renderer2 } from '@angular/core';
import { HeaderComponent } from "../header/header/header.component";
import { CommonModule } from '@angular/common';
import { RouterLink } from "@angular/router";
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { getFirstNameWithoutTilde } from '../../shared/utils/userinitials';
import { ClientdrawerComponent } from "../settings/clients/clientdrawer/clientdrawer.component";
import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
import { Observable } from 'rxjs';
import { AuthService } from '../../core/services/auth/auth.service';
interface Step {
  title: string;
  description: string;
  completed: boolean;
  loading?: boolean;
}
@Component({
  selector: 'app-welcomeclient',
  standalone: true,
  imports: [HeaderComponent, CommonModule, RouterLink, ClientdrawerComponent],
  templateUrl: './welcomeclient.component.html',
  styleUrl: './welcomeclient.component.css'
})
export class WelcomeclientComponent {
  localUserData: any;
  firstNameinitial: string = "";
  constructor(private renderer: Renderer2, private userlocaldataService: UserdataService, private apiService: ApiserviceService, private authService: AuthService,

  ) { }



  ngOnInit(): void {

    this.localUserData = this.userlocaldataService.getLocalUserData();
    const alreadyLoaded = sessionStorage.getItem('redisDataSet');
    if (!alreadyLoaded) {
      this.saveRedisData();
    } else {
      console.log('Redis data already set — skipping API call');
    }


    this.launchConfetti();
    this.firstNameinitial = getFirstNameWithoutTilde(this.localUserData.user_name);
    window.addEventListener('clientAdded', () => {
      console.log('Client added event detected!');
      this.addClient();
    });

  }

  launchConfetti(): void {
    const confettiArea = document.getElementById('confetti-area');
    if (!confettiArea) return;

    const shapes = ['circle', 'star', 'stream'];
    const colors = ['pink', 'blue', 'yellow', 'teal'];

    const totalConfetti = 40;

    for (let i = 0; i < totalConfetti; i++) {
      const confetti = this.renderer.createElement('div');
      this.renderer.addClass(confetti, 'confetti');

      const shape = shapes[Math.floor(Math.random() * shapes.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      this.renderer.addClass(confetti, shape);
      this.renderer.addClass(confetti, color);


      const isLeft = Math.random() < 0.5;
      const leftPercent = isLeft
        ? Math.random() * 30        // 0% - 30%
        : Math.random() * 30 + 70;  // 70% - 100%
      const left = leftPercent.toFixed(2) + '%';

      // Slow animation: 3s to 5s
      const duration = (Math.random() * 2 + 3).toFixed(2) + 's';
      const delay = (Math.random() * 0.5).toFixed(2) + 's';

      this.renderer.setStyle(confetti, 'left', left);
      this.renderer.setStyle(confetti, 'animationDuration', duration);
      this.renderer.setStyle(confetti, 'animationDelay', delay);

      this.renderer.appendChild(confettiArea, confetti);
    }

    // Cleanup after the longest duration
    setTimeout(() => {
      confettiArea.innerHTML = '';
    }, 6000);
  }


  steps: Step[] = [
    {
      title: 'Add Your First Client',
      description: 'Begin by adding at least one client to get started.',
      completed: false,
      loading: false,
    },
    {
      title: 'Take a Quick Tour',
      description: 'Explore key features to get familiar and started.',
      completed: false,
      loading: false,
    },
  ];

  // Computed values
  get completedCount(): number {
    return this.steps.filter(s => s.completed).length;
  }

  get totalSteps(): number {
    return this.steps.length;
  }

  addClient() {
    const step = this.steps[0];
    step.loading = true;
    setTimeout(() => {
      step.loading = false;
      step.completed = true;
    }, 1500);

  }

  getProgressOffset(): number {
    if (this.completedCount === 0) {
      return 90;
    }
    const total = this.totalSteps;
    const completed = this.completedCount;
    return 100 - (completed / total * 100);
  }






  drawerOpen = false;
  isOpen = false;

  openDrawer() {
    this.drawerOpen = true;
  }

  onDrawerClosed() {

    this.drawerOpen = false;
  }

  onImportDrawerClosed() {

    this.drawerOpen = false;
  }






  saveRedisData(): void {
    this.fetchmmtx().subscribe({
      next: (multiMastData) => {
        const mmtxdata = {
          multiMast: multiMastData,

        };
        const requestBody = {
          usercode: this.localUserData?.user_code,
          clientcode: this.localUserData?.client_code,
          mmtxdata: JSON.stringify(mmtxdata),
        };

        this.apiService.setRedisApi('/Comman/set_mmtx_data', requestBody).subscribe({
          next: (response) => {
            sessionStorage.setItem('redisDataSet', 'true');

          },
          error: (error) => {
            console.error(' Failed to set Redis data:', error);
          },
        });
      },
      error: (err) => {
        console.error('Failed to fetch statemast data before saving Redis:', err);
      },
    });
  }
  private fetchmmtx(): Observable<any> {
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_is_pen_flag: "",
        a_login_type: "login_id",
        a_module_type_code: this.localUserData?.default_module_type_code,
        a_sub_module_type_code: "R",
        a_entity_code: this.localUserData?.entity_code,
        a_client_code: this.localUserData?.client_code,
        a_acc_year: this.localUserData?.default_acc_year,
        a_quarter_no: this.localUserData?.default_quarter_no,
        a_tran_month: this.localUserData?.default_tran_month,
        a_tran_from_date: this.localUserData?.default_from_date,
        a_tran_to_date: this.localUserData?.default_to_date,
        a_tds_type_code: this.localUserData?.default_tds_type_code,
        a_first_level_client_code: this.localUserData?.first_level_client_code,
        a_validation_client_level: this.localUserData.client_code_level,
        a_iud_type: "",
        a_db_total_records: "10",
        a_pagination_count: "0",
        a_proc_type: "get_mmtx_multi_mast",
        a_filter_clause: [
          {
            filter_col_field: "gd_proc_name",
            filter_col_depend_operator: "wc",
            filter_col_value:
              "and gd_proc_name in ( ##get_mmtx_client_type_mast##,##get_mmtx_client_catg_mast##,##get_mmtx_state_mast##,##get_mmtx_client_level_mast##, ##get_mmtx_regex_validation##,  ##get_mmtx_tds_type_mast##,##get_mmtx_country_mast##,##get_mmtx_remittance_nature_mast##,##get_mmtx_tds_deduct_reason_mast##,##get_mmtx_tds_rate_type_mast##,##get_mmtx_tds_mast##,##get_mmtx_user_role_mast##,##get_mmtx_minor_head_mast##,##get_mmtx_gh15_flag_mast##,##get_mmtx_resident_type_mast##,##get_mmtx_assessed_tax_flag_mast##,##get_mmtx_pan_status_mast##,##get_mmtx_acc_year_mast##)",

            // filter_col_value:
            //   "and gd_proc_name in (##get_mmtx_acc_year_mast##, ##get_mmtx_client_level_mast##, ##get_mmtx_quarter_mast##, ##get_mmtx_regex_validation##, ##get_mmtx_app_parameters##, ##get_mmtx_module_type_mast##, ##get_mmtx_sub_module_type_mast##, ##get_mmtx_tds_type_mast##)",
            filter_col_field_alias: "a.",
          },
        ],
      }),
    };

    return new Observable((observer) => {
      this.authService.fetchMultiMastData(requestBody).subscribe({
        next: (response: any) => {
          const result = response?.body?.result;
          if (result?.a_proc_error == 0) {
            const multiMast = result?.get_mmtx_multi_mast;
            if (multiMast) {
              observer.next(multiMast);
              observer.complete();
            } else {
              observer.error(' No multiMast data found in API response');
            }
          } else {
            observer.error(result?.a_proc_error_message || 'Unknown process error');
          }
        },
        error: (error: any) => {
          observer.error(error.message || 'Failed to fetch header master data.');
        },
      });
    });
  }




}
