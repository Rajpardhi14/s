import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import * as pdfjsLib from 'pdfjs-dist';
import { RefreshdataService } from '../../../../core/services/refreshdata/refreshdata.service';
import { SafeUrlPipe } from '../../../../shared/pipes/safe-url.pipe';
import { AlertpoupComponent } from "../../../../shared/components/alertpoup/alertpoup.component";
import { DatepickerComponent } from "../../../../shared/components/datepicker/datepicker.component";


@Component({
  selector: 'app-updatefilling',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SafeUrlPipe, AlertpoupComponent, DatepickerComponent],
  templateUrl: './updatefilling.component.html',
  styleUrl: './updatefilling.component.css'
})
export class UpdatefillingComponent {
  @Input() selectedId: string | null = null;
  @Input() isDrawerOpen: boolean = false;
  @Input() rowData: any = "";
  @Output() closeDrawer = new EventEmitter<void>();
  localUserData: any;
  errorMessage: string = "";
  form!: FormGroup;
  isProcessingPDF: boolean = false;
  pdfValidationErrors: string[] = [];
  uploadedFile: File | null = null;
  pdfUrl: string | null = null;
  isEditMode: boolean = false;
  newdata: any
  constructor(private toastService: ToastService, private apiservice: ApiserviceService, private userlocaldata: UserdataService, private fb: FormBuilder, private refreshdata: RefreshdataService) {

  }



  // ngOnChanges(changes: SimpleChanges): void {
  //   if (this.form) {
  //     if (changes['selectedId'] && this.selectedId) {

  //       this.fetchUserDetails(this.selectedId);
  //     }
  //     else if (changes['rowData'] && this.rowData && !this.selectedId) {
  //       this.form.patchValue(this.rowData);
  //     }
  //   }
  // }


  ngOnChanges(changes: SimpleChanges): void {
    if (this.form) {
      if (changes['selectedId'] && this.selectedId) {
        this.isEditMode = false;
        this.fetchUserDetails(this.selectedId);
        if (this.rowData?.file_upload_ack_pdf_name) {
          this.uploadedFileData = {
            fileName: this.rowData.file_upload_ack_pdf_name,
            s3Key: this.rowData.file_upload_ack_pdf_path || ''
          };
        } else {
          this.uploadedFileData = null; // make sure it's null if no file
        }

        this.uploadedFile = null;
        this.pdfUrl = null;


      }

      else if (changes['rowData'] && this.rowData && !this.selectedId) {
        this.isEditMode = true;
        this.form.patchValue(this.rowData);
        this.initializeForm()
        this.uploadedFileData = null;
        this.uploadedFile = null;
        this.pdfUrl = null;


      }
    }
  }

  dynamicUserData: any;
  ngOnInit(): void {

    this.localUserData = this.userlocaldata.getLocalUserData();
    this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
    this.initializeForm()


  }

  initializeForm() {
    this.form = this.fb.group({
      acc_year: [this.rowData?.acc_year || '', Validators.required],
      quarter_no: [this.rowData?.quarter_no || '', Validators.required],
      tds_type_code: [this.rowData?.tds_type_code || '', Validators.required],
      ack_no: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[0-9]*$/),   // only digits

        ]
      ],

      ack_date: ['', Validators.required],
      file: [null]
    });

  }




  toggleEditMode() {
    this.isEditMode = true;
  }


  private mergeData(rowData: any, fileData: any) {
    return {
      acc_year: fileData?.acc_year ?? rowData?.acc_year ?? '',
      quarter_no: fileData?.quarter_no ?? rowData?.quarter_no ?? '',
      tds_type_code: fileData?.tds_type_code ?? rowData?.tds_type_code ?? '',
      tanno: fileData?.tanno ?? rowData?.tanno ?? this.newdata.tanno,
      ack_no: fileData?.ack_no ?? this.form.get('ack_no')?.value ?? '',
      ack_date: fileData?.ack_date ?? this.form.get('ack_date')?.value ?? ''
    };
  }

  /** File upload handler */
  async onFileSelected(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    // Check if the file is a PDF
    if (file.type === 'application/pdf') {
      this.isProcessingPDF = true; // Start loading
      try {
        // Use CDN for PDF.js worker to avoid MIME type issues on production server
        // Match the installed pdfjs-dist version (5.4.149)
        pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.4.149/pdf.worker.min.mjs`;

        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        this.uploadedFile = file;
        console.log(this.uploadedFile)
        this.pdfUrl = URL.createObjectURL(file);
        let fullText = '';

        // Extract text from all pages
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const textContent = await page.getTextContent();

          // Join text items with space to preserve separation
          const pageText = textContent.items
            .map((item: any) => item.str)
            .filter((str: string) => str.trim() !== '')
            .join(' ');

          fullText += pageText + ' ';
        }

        console.log('Extracted PDF text:', fullText);


        let rrrNumber = '';
        let eFilingDate = '';
        let pdfFinancialYear = '';
        let pdfQuarter = '';
        let pdfForm = '';


        const rrrPattern = /RRR\s+Number[:\s]*(\d{15})/i;
        const rrrMatch = fullText.match(rrrPattern);

        if (rrrMatch) {
          rrrNumber = rrrMatch[1];
          console.log('Found RRR Number:', rrrNumber);
        }


        const dateOfFilingPattern = /Date\s+of\s+e-?Filing[:\s]*(\d{1,2}-\s*[A-Za-z]{3}-\s*\d{4})/i;
        const dateMatch = fullText.match(dateOfFilingPattern);

        if (dateMatch) {
          eFilingDate = dateMatch[1].replace(/\s+/g, '');
          console.log('Found Date of e-Filing:', eFilingDate);
        }
        if (!rrrNumber) {
          const fallbackRRRPattern = /\b(77\d{13})\b/g;
          const fallbackMatches = fullText.match(fallbackRRRPattern);
          if (fallbackMatches && fallbackMatches.length > 0) {
            rrrNumber = fallbackMatches[0];
            console.log('Found RRR Number (fallback pattern):', rrrNumber);
          }
        }


        if (!eFilingDate) {
          const generalDatePattern = /(\d{1,2}-\s*[A-Za-z]{3}-\s*\d{4})/g;
          const dateMatches = fullText.match(generalDatePattern);
          if (dateMatches && dateMatches.length > 0) {
            // Take the first valid date found
            eFilingDate = dateMatches[0].replace(/\s+/g, '');
            console.log('Found date (fallback pattern):', eFilingDate);
          }
        }

        // Extract Financial Year (e.g., "Financial Year : 2025-26")
        const fyPattern = /Financial\s+Year\s*:\s*(\d{4}-\d{2})/i;
        const fyMatch = fullText.match(fyPattern);
        if (fyMatch) {
          pdfFinancialYear = fyMatch[1];
          console.log('Found Financial Year from PDF:', pdfFinancialYear);
        }

        // Extract Quarter (e.g., "Quarter : Q1")
        const quarterPattern = /Quarter\s*:\s*Q(\d)/i;
        const quarterMatch = fullText.match(quarterPattern);
        if (quarterMatch) {
          pdfQuarter = quarterMatch[1]; // Just the number, e.g., "1" from "Q1"
          console.log('Found Quarter from PDF:', pdfQuarter);
        }

        // Extract Form Number (e.g., "Form No. : Form 26Q")
        const formPattern = /Form\s+No\.\s*:\s*Form\s*(\d{2}[A-Z])/i;
        const formMatch = fullText.match(formPattern);
        if (formMatch) {
          pdfForm = formMatch[1];
          console.log('Found Form from PDF:', pdfForm);
        }

        // If we didn't get the date from the table pattern, try other patterns
        if (!eFilingDate) {
          // Extract Date of e-Filing (multiple possible formats)
          const datePatterns = [
            /(\d{1,2}-[A-Za-z]{3}-\d{4})/g,  // Format: 9-Jul-2025 or 29-Jul-2025
            /(\d{1,2}\/\d{1,2}\/\d{4})/g,   // Format: 9/7/2025 or 29/07/2025
            /(\d{1,2}-\d{1,2}-\d{4})/g,      // Format: 9-7-2025 or 29-07-2025
            /(\d{4}-\d{1,2}-\d{1,2})/g,      // Format: 2025-7-9 or 2025-07-29
          ];

          console.log('Searching for dates in PDF...');
          for (const pattern of datePatterns) {
            const dateMatches = fullText.match(pattern);
            console.log(`Pattern ${pattern}, matches:`, dateMatches);

            if (dateMatches && dateMatches.length > 0) {
              // Filter out invalid dates (like the 15-digit number)
              const validDates = dateMatches.filter(date => {
                // Check if it's a reasonable date and not just a number pattern
                if (date.includes('-') || date.includes('/')) {
                  const parts = date.split(/[-\/]/);
                  const hasValidMonth = parts.some(part => {
                    const num = parseInt(part);
                    return (num >= 1 && num <= 12) || ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].includes(part);
                  });
                  return hasValidMonth;
                }
                return false;
              });

              console.log('Valid dates found:', validDates);
              if (validDates.length > 0) {
                eFilingDate = validDates[0];
                break;
              }
            }
          }
        }

        // Look for specific patterns in the text
        if (!rrrNumber) {
          // Alternative pattern: Look for "RRR Number" followed by digits
          const rrrLabelPattern = /RRR\s*Number[:\s]*(\d{15})/i;
          const rrrMatch = fullText.match(rrrLabelPattern);
          if (rrrMatch) {
            rrrNumber = rrrMatch[1];
          }
        }

        if (!eFilingDate) {
          // Alternative pattern: Look for "Date of e-Filing" followed by date
          const dateLabelPattern = /Date\s*of\s*e-?Filing[:\s]*([^\s]+)/i;
          const dateMatch = fullText.match(dateLabelPattern);
          if (dateMatch) {
            eFilingDate = dateMatch[1];
          }
        }

        // Validate extracted PDF data against form values
        this.pdfValidationErrors = [];
        let hasValidationErrors = false;

        // Check Financial Year
        const formFY = this.form.get('acc_year')?.value;
        if (pdfFinancialYear && formFY) {
          // Convert form FY format (e.g., "25-26" to "2025-26" for comparison)
          const formFYFull = formFY.includes('-') && formFY.length <= 5 ? `20${formFY}` : formFY;
          if (formFYFull !== pdfFinancialYear) {
            this.pdfValidationErrors.push(`Financial Year mismatch: Form has "${formFY}" but PDF has "${pdfFinancialYear}"`);
            hasValidationErrors = true;
          }
        }


        const formQuarter = this.form.get('quarter_no')?.value?.toString();
        if (pdfQuarter && formQuarter) {
          if (formQuarter !== pdfQuarter) {
            this.pdfValidationErrors.push(`Quarter mismatch: Form has "Q${formQuarter}" but PDF has "Q${pdfQuarter}"`);
            hasValidationErrors = true;
          }
        }

        // Check Form Type
        const formType = this.form.get('tds_type_code')?.value;
        if (pdfForm && formType) {
          if (formType !== pdfForm) {
            this.pdfValidationErrors.push(`Form Type mismatch: Form has "${formType}" but PDF has "${pdfForm}"`);
            hasValidationErrors = true;
          }
        }

        // Show validation errors if any
        if (hasValidationErrors) {
          const errorMessage = 'PDF validation failed:\n' + this.pdfValidationErrors.join('\n');
          this.toastService.showError(errorMessage);
          console.error('PDF Validation Errors:', this.pdfValidationErrors);
        }

        // Update form fields if values were extracted
        if (rrrNumber || eFilingDate) {
          const updates: any = {};

          if (rrrNumber) {
            updates.ack_no = rrrNumber;
            console.log('Setting TDS Return Ack No (RRR Number):', rrrNumber);
          }

          if (eFilingDate) {
            // Convert date format if needed
            updates.ack_date = this.formatDate(eFilingDate);
            console.log('Setting TDS Return Ack Date:', eFilingDate);
          }

          this.form.patchValue(updates);

          if (!hasValidationErrors) {
            this.toastService.showSuccess("PDF data extracted and validated successfully!");
          } else {
            this.toastService.showSuccess("PDF data extracted but validation errors found. Please check the form details.");
          }

          if (!rrrNumber || !eFilingDate) {
            let missingFields = [];
            if (!rrrNumber) missingFields.push('RRR Number');
            if (!eFilingDate) missingFields.push('TDS Return Ack Date');
            this.toastService.showSuccess(`Partial data extracted. Please enter ${missingFields.join(' and ')} manually.`);
          }
        } else {
          this.toastService.showError("Could not extract data from PDF. Please enter details manually.");
        }

      } catch (err) {
        console.error('PDF parsing error:', err);
        this.errorMessage = "Error reading PDF file.";
        this.toastService.showError(this.errorMessage);
      } finally {
        this.isProcessingPDF = false; // Stop loading
      }
    } else {

      const reader = new FileReader();
      reader.onload = () => {
        try {
          const fileData = JSON.parse(reader.result as string);
          const merged = this.mergeData(this.rowData, fileData);
          this.form.patchValue(merged);
          this.toastService.showSuccess("File data applied successfully!");
        } catch (err) {
          this.errorMessage = "Invalid file format.";
          this.toastService.showError(this.errorMessage);
        }
      };
      reader.readAsText(file);
    }
  }

  /** Format date to a standard format */
  private formatDate(dateStr: string): string {
    try {
      if (!dateStr || dateStr.trim() === '') {
        return '';
      }

      // Handle different date formats
      let date: Date;

      if (dateStr.match(/\d{1,2}-[A-Za-z]{3}-\d{4}/)) {
        // Format: 9-Jul-2025 or 29-Jul-2025
        date = new Date(dateStr);
      } else if (dateStr.includes('/')) {
        // Format: DD/MM/YYYY -> 29/07/2025
        const parts = dateStr.split('/');
        if (parts.length === 3) {
          const day = parseInt(parts[0]);
          const month = parseInt(parts[1]) - 1; // JavaScript months are 0-based
          const year = parseInt(parts[2]);
          date = new Date(year, month, day);
        } else {
          return '';
        }
      } else if (dateStr.match(/\d{1,2}-\d{1,2}-\d{4}/)) {
        // Format: D-M-YYYY or DD-MM-YYYY -> 9-7-2025 or 29-07-2025
        const parts = dateStr.split('-');
        const day = parseInt(parts[0]);
        const month = parseInt(parts[1]) - 1; // JavaScript months are 0-based
        const year = parseInt(parts[2]);
        date = new Date(year, month, day);
      } else if (dateStr.match(/\d{4}-\d{1,2}-\d{1,2}/)) {
        // Format: YYYY-M-D or YYYY-MM-DD -> 2025-7-9 or 2025-07-29
        date = new Date(dateStr);
      } else {
        date = new Date(dateStr);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn('Invalid date:', dateStr);
        return '';
      }

      // Return in YYYY-MM-DD format
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');

      return `${year}-${month}-${day}`;
    } catch (err) {
      console.error('Error formatting date:', err, dateStr);
      return ''; // Return empty string if parsing fails
    }
  }

  isSubmitting = false;
  isSubmittingUpdate = false;
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiservice
      .createData('/Dashboard/get_tiud_tds_return_tran', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.onClose()
            this.refreshdata.trigerRefresh('Clients');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                  if (this.form.controls[field]) {
                    this.form.controls[field].setErrors({
                      serverError: error.message,
                    });
                  }
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }

  uploadedFileData: any
  async onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toastService.showError("Please fill all required fields.");
      console.log('onSubmit() called ✅', this.form.value);
      return;

    }


    if (this.pdfValidationErrors.length > 0) {
      this.toastService.showError(
        "PDF validation errors detected:\n" + this.pdfValidationErrors.join("\n")
      );
      return;
    }

    this.isSubmitting = true;
    const formData = this.form.value;


    if (this.uploadedFile) {
      try {
        this.uploadedFileData = await this.apiservice.fileUpload(
          this.localUserData.client_code,
          this.localUserData.user_code,
          [this.uploadedFile]
        );

        console.log("Upload Response ✅", this.uploadedFileData);
      } catch (err) {
        console.error("Upload failed ❌", err);
        this.toastService.showError("File upload failed.");
        this.isSubmitting = false;
        return;
      }
    }







    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type: this.selectedId ? 'u' : 'i',
      a_proc_type: 'get_tiud_tds_return_tran',
      a_user_code: this.localUserData.user_code,
      a_user_level: this.localUserData.user_level,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.localUserData.default_acc_year,
      a_quarter_no: this.localUserData.default_quarter_no,
      a_tran_month: this.localUserData.default_tran_month,
      a_first_level_client_code: this.localUserData.first_level_client_code,
      a_validation_client_level: this.localUserData.client_code_level,
      a_tran_from_date: this.localUserData.default_from_date,
      a_tran_to_date: this.localUserData.default_to_date,
      a_tds_type_code: this.localUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      tds_return_tran: {
        rowid_seq: this.selectedId ? this.rowData.rowid_seq : "",
        tanno: this.rowData?.tanno,
        client_code: this.rowData?.client_code,
        acc_year: this.rowData?.acc_year,
        quarter_no: this.rowData?.quarter_no,
        tds_type_code: this.rowData?.tds_type_code,
        stream_code: "#864#",
        file_upload_ack_no: formData?.ack_no,
        file_upload_ack_date: this.formatDatesend(formData?.ack_date),
        file_upload_ack_pdf_path: this.uploadedFileData?.s3Key || "",
        file_upload_ack_pdf_name: this.uploadedFileData?.fileName || "",
        tds_return_type: "R",
        tran_month: ""
      }

    };

    this.submitRequest(
      requestBody,
      'User Mast  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
  }

  onClose() {
    this.closeDrawer.emit();
  }



  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  removeFile() {
    this.uploadedFile = null;
    this.uploadedFileData = null;
    this.pdfValidationErrors = [];
    this.pdfUrl = null;
    this.form.patchValue({
      ack_no: null,
      ack_date: null
    });

  }



  fetchUserDetails(roleCode: string) {
    const requestBody = {
      a_proc_type: 'get_gtdt_tds_return_tran',
      a_user_code: this.localUserData.user_code,
      a_user_level: this.localUserData.user_level,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_first_level_client_code: this.localUserData.first_level_client_code,
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/Dashboard/get_gtdt_tds_return_tran', requestBody)
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_gtdt_tds_return_tran
              ?.get_gtdt_tds_return_tran_detail?.[0];
          this.rowData = roleData;
          this.newdata = roleData

          // console.log(this.rowData)

          if (!roleData) {
            this.showError('No user data found.');
            return;
          }


          this.form.patchValue({
            acc_year: roleData.acc_year || '',
            quarter_no: roleData.quarter_no || '',
            tds_type_code: roleData.tds_type_code || '',
            ack_no: roleData.file_upload_ack_no || '',
            ack_date: this.formatDate(roleData.file_upload_ack_date),
            file: roleData.file_upload_ack_pdf_name || ""
          });
        },
        error: () => {
          this.showError('Failed to fetch User details.');
        },
      });
  }


  formatDatesend(date: Date | string): string {
    const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = months[d.getMonth()];
    const year = d.getFullYear();
    console.log(`${day}-${month}-${year}`)
    return `${day}-${month}-${year}`;
  }




  async onDownload() {
    if (!this.uploadedFileData?.s3Key) {
      this.toastService.showError("No uploaded file found.");
      return;
    }
    await this.apiservice.fileDownload(this.uploadedFileData.s3Key);
  }



  isDeletePopupOpen = false;

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.DeleteRecord();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
  }

  DeleteRecord() {
    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type: "d",
      a_proc_type: 'get_tiud_tds_return_tran',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.localUserData.default_acc_year,
      a_quarter_no: this.localUserData.default_quarter_no,
      a_tran_month: this.localUserData.default_tran_month,
      a_validation_client_level: this.localUserData.client_code_level,
      a_tran_from_date: this.localUserData.default_from_date,
      a_tran_to_date: this.localUserData.default_to_date,
      a_tds_type_code: this.localUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_first_level_client_code: this.localUserData.first_level_client_code,
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      tds_return_tran: {
        rowid_seq: this.selectedId ? this.rowData.rowid_seq : "",

      }

    };
    this.apiservice
      .createData('/Dashboard/get_tiud_tds_return_tran', requestBody)
      .subscribe({
        next: (response) => {

          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message);
            this.onClose()
            this.refreshdata.trigerRefresh('Allclients');
          } else {
            this.showError(
              result.a_proc_error_message || 'Error while creating User.'
            );
          }
        },
        error: () => {

          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });


  }

}
