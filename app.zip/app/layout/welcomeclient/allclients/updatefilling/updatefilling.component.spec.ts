import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatefillingComponent } from './updatefilling.component';

describe('UpdatefillingComponent', () => {
  let component: UpdatefillingComponent;
  let fixture: ComponentFixture<UpdatefillingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdatefillingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UpdatefillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
