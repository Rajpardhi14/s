import { Component, DestroyRef, effect, inject } from '@angular/core';
import { HeaderComponent } from "../../header/header/header.component";
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { interval, merge, skip, Subject, Subscription, switchMap, takeWhile } from 'rxjs';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { BasicFilterComponent } from "../../../shared/components/basic-filter/basic-filter.component";
import { AdvanceFilterComponent } from "../../../shared/components/advance-filter/advance-filter.component";
import { GearboxComponent } from "../../../shared/components/gearbox/gearbox.component";
import { TableskeletonComponent } from "../../../shared/components/tableskeleton/tableskeleton.component";
import { NodataComponent } from "../../../shared/components/nodata/nodata.component";
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { UpdatefillingComponent } from "./updatefilling/updatefilling.component";
import { ClientdrawerComponent } from "../../settings/clients/clientdrawer/clientdrawer.component";
import { ImportConsoComponent } from "./import-conso/import-conso.component";
import { ConsoParserService } from '../../../core/services/conso/conso-parser.service';
import { capitalizeEachWord, capitalizeOnlyFirst, formatDatesend, formatValue } from '../../../shared/utils/passmatch';
import { CorrectionpoupComponent } from '../../../shared/components/correctionpoup/correctionpoup/correctionpoup.component';
import { GetstatusService } from '../../../core/services/statusService/getstatus.service';
import { HttpClient } from '@angular/common/http';
import { BASE_API_URL } from '../../../core/constants/endpoint';

@Component({
  selector: 'app-allclients',
  standalone: true,
  imports: [HeaderComponent, BasicFilterComponent, AdvanceFilterComponent, TableskeletonComponent, NodataComponent, ReactiveFormsModule, CommonModule, RouterLink, UpdatefillingComponent, ClientdrawerComponent, ImportConsoComponent, CorrectionpoupComponent, GearboxComponent],
  templateUrl: './allclients.component.html',
  styleUrl: './allclients.component.css'
})
export class AllclientsComponent {

  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;

  localUserData: any;
  allUsersData: any[] = [];
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;

  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';


  selectedFilters: { label: string; field: string; value: string }[] = [];

  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  capitalizeOnlyFirst = capitalizeOnlyFirst
  formatValue = formatValue
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  capitalizeEachWord = capitalizeEachWord;
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = "Yes"
  private destroy$ = new Subject<void>();


  groupedMonths: any[] = [];
  staticHeaders: any[] = [];
  lastHeaders: any[] = [];

  constructor(
    private refreshdata: RefreshdataService,
    private getStatusService: GetstatusService,
    private statusPoller: GetstatusService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private consoParser: ConsoParserService,
    private router: Router,
       private http: HttpClient,
  ) {
    this.filterForm = this.fb.group({});
  }

  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  UserdynamicData: any;
  client_level: string = "Yes"
  mymodules:string="" 

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.UserdynamicData = this.userlocaldataService.getAllDynamicUserData();


    if (
      sessionStorage.getItem('loginSuccess') &&
      this.UserdynamicData?.first_time_login === 0
    ) {
      this.toastService.showSuccess('Login successful!');
      sessionStorage.removeItem('loginSuccess');
    }

    this.dynamicUserData$
      .pipe(
        skip(1),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(dynamicData => {
        // if (!sessionStorage.getItem('loginSuccess')) return;
        this.offset = 0;
        this.fetchUsers();
        this.allUserGrandTotal();
      });

    this.fetchUsers();
    this.alluserFilter();
    this.allUserGrandTotal();
    this.refreshSubscription = this.refreshdata.onRefresh('Clients').subscribe(() => {
      this.fetchUsers();
      this.allUserGrandTotal();
      ;
    });

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();
    // this.getStatus()

  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }
  firstAndLastName(user: any): any {
    if (!user || typeof user.user_name !== 'string') {
      return { ...user, user_name: '' };
    }
    const nameParts = user.user_name
      .trim()
      .replace(/-/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
    const firstInitial = nameParts[0]?.[0]?.toUpperCase() || '';
    return { ...user, user_name: firstInitial };
  }
  buildMergeGroups() {
    this.headers.forEach(header => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }
  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );

  }

  fetchUsers() {
    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtdb_kpi_tan_tran_summ',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear
      }

    );
    this.apiService.getTableData('/ClientMast/get_gtdb_kpi_tan_tran_summ', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data.result?.get_gtdb_kpi_tan_tran_summ;
          if (userData?.get_gtdb_kpi_tan_tran_summ_header) {
            this.headers = userData?.get_gtdb_kpi_tan_tran_summ_header.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,

              })
            );

          }


          this.allUsersData = userData || {};
          const lastFields = [
            'tds_return_status',
            'tds_traces_conso_file_name',
            'tds_traces_default_file_name'
          ];

          this.tableBody = userData.get_gtdb_kpi_tan_tran_summ_detail;
          // this.staticHeaders = this.headers.filter(h => !h.field.startsWith("month") && h.field !== 'file_status');

          this.staticHeaders = this.headers.filter(
            h => !h.field.startsWith('month') && !lastFields.includes(h.field)
          );
          const monthHeaders = this.headers.filter(h => h.field.startsWith("month"));
          // this.lastHeaders = this.headers.filter(h => h.field === 'file_status');


          this.lastHeaders = lastFields
            .map(field => this.headers.find(h => h.field === field))
            .filter(Boolean); 
            // console.log(this.lastHeaders)

          this.mergeGroups = {};
          this.fieldToMergeGroup = {};

          const months: any = {};
          monthHeaders.forEach(h => {
            const match = h.headerName.match(/\((.*?)\)/);
            const monthName = match ? match[1] : 'Other';
            if (!months[monthName]) months[monthName] = { name: monthName, fields: [] };
            months[monthName].fields.push({
              field: h.field,
              label: h.headerName.replace(/\(.*?\)/, "").trim(),
              mergecolumn: h.mergeColumn
            });
          });




          // this.groupedMonths = Object.values(months);
          this.groupedMonths = Object.values(months).map((month: any) => {
            const mergeGroups: any = {};

            month.fields.forEach((f: any) => {
              if (f.mergecolumn) {
                if (!mergeGroups[f.mergecolumn]) mergeGroups[f.mergecolumn] = [];
                mergeGroups[f.mergecolumn].push(f);
              }
            });

            return {
              ...month,
              mergeGroups,
              // keep fields without mergecolumn
              plainFields: month.fields.filter((f: any) => !f.mergecolumn)
            };
          });

          this.isFirstInMergeGroup(this.staticHeaders);
          this.buildMergeGroups()
          // console.log('Grouped months:', this.groupedMonths)
          // console.log('Month headers:', monthHeaders)
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
          this.loading = false;
          // this.errorMessage = data.result[0].a_proc_error_message;
      // this.showError(data.result[0].a_proc_error_message);
             this.toastService.showError(data.result[0].a_proc_error_message);
        }
        this.loading = false;
      },
      error: (error) => {
        // this.errorMessage = error.message || 'Failed to fetch users.';
        // this.showError(error.message || 'Failed to fetch .');
        this.toastService.showError(error.message || 'Failed to fetch .');
        this.loading = false;
        this.isLoadingMore = false;
      },
    });


  }


  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchUsers();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }



  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private alluserFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_kpi_tan_tran_summ',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear
      }

    );



    this.apiService.getFilterData('/ClientMast/get_gtfb_kpi_tan_tran_summ', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.get_gtfb_kpi_tan_tran_summ?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.get_gtfb_kpi_tan_tran_summ?.[1]?.advance_filter;

          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          // this.errorMessage = response.result[0]?.a_proc_error_message;
          // this.showError(this.errorMessage);
          this.toastService.showError(response.result[0].a_proc_error_message);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        this.showError('Error user filter');
        // console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion



  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase(); 
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
      this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();


      Promise.all([this.fetchUsers(), this.allUserGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }

private buildFilterClause(): any[] {
  const filterClause: any[] = [];

  Object.keys(this.filterForm.controls).forEach((key) => {
    const controlValue = this.filterForm.get(key)?.value;
    const filterConfig = this.advance_filter?.find(
      (filter: any) => filter.filter_col_field === key
    );

    if (controlValue && controlValue !== 'ALL' && filterConfig) {
      const operator = filterConfig.filter_col_depend_operator || 'like';
      let filterValue: string | null = null;

      if (operator === 'wc') {
        const matchedCondition = filterConfig.filter_col_depend_value?.find(
          (item: any) =>
            item.value?.toLowerCase() === controlValue?.toLowerCase()
        );
        if (matchedCondition) {
          filterValue = matchedCondition.condition;
        }
      } else {
        filterValue = controlValue.toString().trim();
      }

      if (filterValue && filterValue !== '') {
        filterClause.push({
          filter_col_field: filterConfig.filter_col_field,
          filter_col_depend_operator: operator,
          filter_col_value: filterValue.toUpperCase(),
          filter_col_field_alias: filterConfig.filter_col_field_alias,
        });
      }
    }
  });

  if (this.searchTerm?.trim() && this.selectedOption) {
    filterClause.push({
      filter_col_field: this.selectedOption.field,
      filter_col_depend_operator: this.selectedOption.operator,
      filter_col_value: this.searchTerm.trim().toUpperCase(),
      filter_col_field_alias: this.selectedOption.alias,
    });
  }

        const uniqueFilters = Array.from(
    new Map(
      filterClause.map((item) => [item.filter_col_field, item])
    ).values()
  );

  return uniqueFilters;
    // return filterClause;

  // console.log('Generated Filter Clause:', filterClause);
  // return filterClause;
}



private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm;

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }




  onInput(event: Event): void {
      const inputValue = (event.target as HTMLInputElement).value.trim();
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return []; // If form is not submitted, return an empty list
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchUsers();
    this.allUserGrandTotal();
  }

  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }


showFooter: boolean = false; 
gtdgData:any;
toggleFooter() {
  this.showFooter = !this.showFooter;
}
  // user grand total
getVisibleHeaders() {
  return this.headers?.filter(h => h.visible) || [];
}

isArray(value: any): boolean {
  return Array.isArray(value);
}

  private allUserGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gtdg_kpi_tan_tran_summ',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear
      }
    );
    this.apiService.getGrandTotal('/ClientMast/get_gtdg_kpi_tan_tran_summ', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          // Success case
           this.gtdgData =
    response?.result?.get_gtdg_kpi_tan_tran_summ?.[0] || null;
console.log(this.gtdgData);
            this.usergrandtotal = this.gtdgData?.rec || null;
  this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        // console.error('Error fetching vendor data:', error);
        this.showError('Something Went Wrong');
      },
    });
  }

  // // Remove all filter label values
  // clearAllFilters() {
  //   this.offset = 0;
  //   this.currentPage = 1;
  //   this.selectedFilters = [];
  //   this.filterClause = [];
  //   if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //     this.advance_filter.forEach((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);
  //       if (control) {
  //         control.setValue('');
  //       }
  //     });
  //   }
  //   this.filtercount = this.getSelectedFilterCount();
  //   this.fetchUsers();
  //   this.allUserGrandTotal();
  // }



    clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.selectedFilters = [];
    this.filterClause = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (control) {
          control.setValue('');
        }
      });
    }
    this.filtercount = this.getSelectedFilterCount();
       this.fetchUsers();
    this.allUserGrandTotal();
  }



  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'All_Clients'
    );
  }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }



  ///

  isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  rowData: any
  parsedConsoData: any = {}; // Store complete parsed CONSO data by row ID
  consoFileCount: number = 0; // Track number of uploaded CONSO files

  // Import CONSO Modal
  isImportConsoOpen: boolean = false;
  selectedClientForConso: any = null;

  // Correction Popup Modal
  isShowCorrectionPopup: boolean = false;
  selectedProcType: string = '';

  openDrawer(idTofetch?: string, data?: any, redirect?: string) {



    // this.selectedId = idTofetch ?? null;
    // console.log(this.selectedId)
    // this.rowData = data ?? null
    // this.isDrawerOpen = true;

    if (redirect || redirect === null) {
      console.log('Redirecting to dashboard with data:', data);
      this.rowData = data ?? null
       console.log(this.rowData)
      this.userlocaldataService.setDynamicUserData('client_code', this.rowData.client_code);
      this.userlocaldataService.setDynamicUserData('validation_client_level', this.rowData.code_level);
      this.userlocaldataService.setDynamicUserData('client_code_level', this.rowData.code_level);
      // console.log(this.rowData.code_level)
      this.userlocaldataService.setDynamicUserData('traces_id', this.rowData.traces_id);
      this.userlocaldataService.setDynamicUserData('traces_pwd', this.rowData.traces_pwd);
   
      this.userlocaldataService.setDynamicUserData('client_code_details', this.rowData.client_name);
      this.userlocaldataService.setDynamicUserData('tanno', this.rowData.tanno);
      this.userlocaldataService.setDynamicUserData('bank_branch_code',this.rowData.bank_branch_code)
      this.router.navigate(["home/dashboard"], {
        state: { rowData: this.rowData }
      });
    } else {
      this.selectedId = idTofetch ?? null;
      // console.log(this.selectedId)
      this.rowData = data ?? null
      this.isDrawerOpen = true;
    }
  }

  closeDrawer() {
    this.selectedId = null;
    this.rowData = null
    this.isDrawerOpen = false;

    // Refresh the data to update the filing status and unlock file uploads
    this.fetchUsers();
  }


  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }





  isFileUploadLocked(row: any): boolean {
    return row['tds_return_status'] === 'Pending';
  }

  // Import CONSO Methods
  openImportConsoModal(clientData?: any) {
    this.selectedClientForConso = clientData || null;
    this.isImportConsoOpen = true;
  }

  closeImportConsoModal() {
    this.isImportConsoOpen = false;
    this.selectedClientForConso = null;
  }


// step 1 
    onFileUpload(event: any, field: string, row: any, refnumber?:any,) {
  console.log("Call")
    if (field === 'tds_traces_conso_file_name') {
      const file = event.target.files[0];
      if (file) {
        if (!file.name.endsWith('.tds')) {
          this.toastService.showError('Please select a valid .tds CONSO file');
          event.target.value = ''; 
          return;
        }
        const filenameValidation = this.consoParser.validateFileName(file.name);
        if (!filenameValidation.isValid) {
          this.toastService.showError(filenameValidation.error || 'Invalid CONSO file name format');
          event.target.value = ''; 
          return;
        }
  
        this.processCONSOFileForTable(file, row,refnumber);
      }
      event.target.value = ''; // Reset the file input
      return;
    }

  
    if (row['tds_return_status'] === 'Pending') {
      this.toastService.showError('File upload is locked while Filing Status is Pending');
      event.target.value = ''; // Reset the file input
      return;
    }

    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("field", field);
      formData.append("branchCode", row.bank_branch_code);
    }
  }


  // step 2

   processCONSOFileForTable(file: File, row: any, refnumber?:any) {
    const reader = new FileReader();

    reader.onload = (e: any) => {
      try {
        const fileContent = e.target.result;
        const parsedData = this.consoParser.parseCONSOFile(fileContent, file.name);
        const rawData = this.consoParser.parseCONSOFileRaw(fileContent, file.name); 

        if (!parsedData || !parsedData.batchHeader) {
          this.toastService.showError('Unable to parse CONSO file - invalid format');
          return;
        }

        const bh = parsedData.batchHeader;
        const tanField = Object.keys(row).find(key => key.toLowerCase().includes('tan') && !key.includes('month'));
        const rowTan = tanField ? row[tanField] : null;

        // Validate TAN
        if (rowTan && bh.tan !== rowTan) {
          this.toastService.showError(`Invalid file: TAN mismatch. Expected: ${rowTan}, Found: ${bh.tan}`);
          return;
        }

        // Try to find FY field
        const fyField = Object.keys(row).find(key => key.toLowerCase().includes('fy') || key.toLowerCase().includes('financial'));
        const rowFY = fyField ? row[fyField] : null;

        // Validate Financial Year
        if (rowFY && bh.financialYear !== rowFY) {
          this.toastService.showError(`Invalid file: Financial Year mismatch. Expected: ${rowFY}, Found: ${bh.financialYear}`);
          return;
        }
        const quarterField = Object.keys(row).find(key => key.toLowerCase().includes('quarter') || key.toLowerCase().includes('qtr'));
        const rowQuarter = quarterField ? row[quarterField] : null;
        if (rowQuarter) {
         
          const normalizedRowQuarter = String(rowQuarter).replace(/^Q/i, '');
          const normalizedBhQuarter = String(bh.quarter).replace(/^Q/i, '');

          if (normalizedBhQuarter !== normalizedRowQuarter) {
            this.toastService.showError(`Invalid file: Quarter mismatch. Expected: Q${normalizedRowQuarter}, Found: ${bh.quarter}`);
            return;
          }
        }
        const formTypeField = Object.keys(row).find(key =>
          key.toLowerCase().includes('return_type') ||
          key.toLowerCase().includes('form_type') ||
          key.toLowerCase().includes('form') && !key.includes('month')
        );
        const rowFormType = formTypeField ? row[formTypeField] : null;
        if (rowFormType && bh.formType !== rowFormType) {
          this.toastService.showError(`Invalid file: Return Type mismatch. Expected: ${rowFormType}, Found: ${bh.formType}`);
          return;
        }
        const rowId = row.rowid_seq || row.id || row.bank_branch_code;
        const completeConsoJson = rawData;
        this.parsedConsoData[rowId] = {
          data: completeConsoJson,
          row: row,
          batchHeader: bh,
          fileName: file.name,
          uploadedAt: new Date(),
           isUpdate: !!refnumber,   
        refnumber: refnumber || 0
        };


        
        // Update CONSO file count
        this.consoFileCount = Object.keys(this.parsedConsoData).length;
        row['tds_traces_conso_file_name'] = file.name;
        row['conso_data_available'] = true;
        row['conso_json_data'] = completeConsoJson;
        this.paginatedList = [...this.paginatedList];

         if (refnumber) {
        this.isShowCorrectionPopup = true;
      }

      } catch (error: any) {
        this.toastService.showError('Error processing CONSO file: ' + (error.message || 'Unknown error'));
      }
    };

    reader.onerror = () => {
      this.toastService.showError('Error reading file');
    };

    reader.readAsText(file);
  }
  //  step 3
  onUploadConsoClick() {
    if (this.consoFileCount === 0) {
      this.toastService.showError('No CONSO files uploaded. Please upload CONSO files first.');
      return;
    }
    this.isShowCorrectionPopup = true;
  }

  // Correction popup methods step 4
  onCorrectionProcess(selectedPurpose: string) {
    this.selectedProcType = selectedPurpose;
    this.isShowCorrectionPopup = false;
    Object.keys(this.parsedConsoData).forEach(rowId => {
      const storedData = this.parsedConsoData[rowId];
      if (storedData) {
        storedData.selectedPurpose = selectedPurpose;
      }
    });

    // Now send all CONSO data to API with the appropriate endpoint
    this.sendAllConsoToAPI();
  }
  // step 5
  sendAllConsoToAPI() {
  const consoDataKeys = Object.keys(this.parsedConsoData || {});

  if (consoDataKeys.length === 0) {
    this.toastService.showError('No CONSO files uploaded. Please upload CONSO files first.');
    return;
  }

  let successCount = 0;
  let errorCount = 0;
  const totalCount = consoDataKeys.length;

  this.toastService.showSuccess(`Sending ${totalCount} CONSO file(s) to API...`);

  consoDataKeys.forEach((rowId, index) => {
    const storedData = this.parsedConsoData[rowId];
    if (!storedData?.data) return; // Skip invalid entries safely

    // 🔹 Add slight delay to prevent server overload
    setTimeout(() => {
      this.sendIndividualConsoToAPI(
        storedData.data,
        storedData.row,
        storedData.batchHeader,
        storedData.fileName,
        storedData.selectedPurpose,
        storedData.refNumber, // Support for update case
        (success: boolean) => {
          if (success) {
            successCount++;

            // 🔹 Remove successfully sent file from memory
            delete this.parsedConsoData[rowId];
            this.consoFileCount = Object.keys(this.parsedConsoData).length;
          } else {
            errorCount++;
          }

          // 🔹 Final status after all uploads complete
          if (successCount + errorCount === totalCount) {
            if (successCount > 0) {
              this.toastService.showSuccess('Request accepted for processing.');
              

            }
            if (errorCount > 0) {
              this.toastService.showError(`Failed to send ${errorCount} CONSO file(s).`);
                
            }

            // 🔹 Refresh data after processing
            this.fetchUsers();
          }
        }
      );
    }, index * 500); // 500ms gap between uploads
  });
}
//  step 6
sendIndividualConsoToAPI(
  consoData: any,
  row: any,
  batchHeader: any,
  fileName: string,
  selectedPurpose: string,
  refNumber?: number,
  callback?: (success: boolean) => void
) {
  try {
    const apiEndpoint =
      selectedPurpose === 'correction'
        ? 'get_tiud_tds_traces_conso_tran_corr_ret'
        : 'get_tiud_tds_traces_conso_tran';

    // 🔹 Detect Add or Update
    this.refnumber=row?.tds_traces_conso_process_seqno || 0;
    
    const isUpdate = !!this.refnumber;
    const iudType =  'i';

    const sdataObj = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_proc_type: apiEndpoint,
      a_entity_code: this.UserdynamicData?.entity_code,
      a_client_code: row.client_code,
      a_acc_year: this.UserdynamicData.default_acc_year,
      a_quarter_no: this.UserdynamicData?.default_quarter_no,
      a_tran_month: this.UserdynamicData.default_tran_month,
      a_tran_from_date: this.UserdynamicData.default_from_date,
      a_tran_to_date: this.UserdynamicData.default_to_date,
      a_tds_type_code: this.UserdynamicData?.default_tds_type_code,
      a_filter_clause: this.filterClause,
      a_app_json_data_test_rowid_seq: row.rowid_seq,
      a_iud_type: iudType,
        a_user_code: this.localUserData.user_code,
      a_tds_traces_conso_file_date: this.formatTracesDate(new Date()),
      a_tds_traces_conso_file_name: fileName,

      // 🔹 Use ref number (update) or new rowid (insert)
      a_tds_traces_conso_process_seqno: row.rowid_seq,
      a_ref_process_seqno: isUpdate ? this.refnumber : "",

      a_validation_client_level: row.code_level,
      a_conso_json_data: consoData,
    };

    this.apiService.createData('/dynamic-import/data', sdataObj).subscribe({
      next: (response: any) => {
        const success =
          response?.status === 202 || response?.result?.a_proc_error === 0;

        if (success) {
          this.toastService.showSuccess(
            isUpdate
              ? `CONSO file updated successfully for ${row.client_code}`
              : `CONSO file uploaded successfully for ${row.client_code}`
          );
          if (callback) callback(true);
          // this.getStatus();
          this.getStatusService.startPolling();
        } else {
          const errorMessage =
            response?.result?.[0]?.a_proc_error_message ||
            response?.message ||
            'Failed to process CONSO data';
          this.toastService.showError(errorMessage);
          if (callback) callback(false);
        }
      },
      error: (error: any) => {
        this.toastService.showError('API Error while processing CONSO data');
        if (callback) callback(false);
      },
    });
  } catch (error: any) {
    console.error('Error preparing CONSO data for API:', error);
    this.toastService.showError('Unexpected error occurred while sending CONSO');
    if (callback) callback(false);
  }
}

  onCorrectionClose() {
    this.isShowCorrectionPopup = false;
    this.selectedProcType = '';
  }

  onConsoImportSuccess(data: any) {
    // console.log('CONSO import success:', data);
    this.closeImportConsoModal();

    // Refresh the table to show updated CONSO file status
    this.fetchUsers();

    // Show success message
    this.toastService.showSuccess(`CONSO file ${data.fileName} imported successfully`);
  }

  onCreateClientWithConsoData(consoData: any) {
   
    this.closeImportConsoModal();

    // Open Add Client drawer with pre-filled CONSO data
    this.openDrawertwo(consoData);
  }

  downloadFile(fileName: string) {
    // Example: trigger download
    // this.apiService.downloadFile(`/TDS/DownloadTracesFile/${fileName}`).subscribe((blob: Blob) => {
    //   const url = window.URL.createObjectURL(blob);
    //   const a = document.createElement("a");
    //   a.href = url;
    //   a.download = fileName;
    //   a.click();
    //   window.URL.revokeObjectURL(url);
    // });
  }


selectedRowForReplace: any = null;
refnumber: any = null;
showReplacePopup = false;

fileType: string | null = null
removeFile(field: string, row: any ,  type: string) {
  // console.log(type)
 this.fileType = type;
  this.refnumber = row.tds_traces_conso_process_seqno;
  this.justirefnumber=row.tds_traces_default_process_seqno
  this.selectedRowForReplace = row;
  this.showReplacePopup = true;
}

onReplaceCancel() {
  this.showReplacePopup = false;
  this.selectedRowForReplace = null;
}

// onReplaceConfirm() {
//   this.showReplacePopup = false;

//   if (!this.selectedRowForReplace) {
//     this.toastService.showError('No row selected for replacement.');
//     return;
//   }

 
//   const fileInput = document.createElement('input');
//   fileInput.type = 'file';
//   fileInput.accept = '.tds';
//   fileInput.onchange = (event: any) => {
//     this.onFileUpload(
//       event,
//       'tds_traces_conso_file_name',
//       this.selectedRowForReplace,
//       this.refnumber
//     );
//   };

//   fileInput.click();
// }


onReplaceConfirm() {
  this.showReplacePopup = false;

  if (!this.selectedRowForReplace) {
    this.toastService.showError('No row selected for replacement.');
    return;
  }

  // Create file selection input
  const fileInput = document.createElement('input');
  fileInput.type = 'file';

  // Accept file types based on mode
  fileInput.accept = this.fileType === 'C' ? '.tds' : '.txt';

  fileInput.onchange = (event: any) => {
    if (this.fileType === 'C') {
      // Replace CONSO
      this.onFileUpload(
        event,
        'tds_traces_conso_file_name',
        this.selectedRowForReplace,
        this.refnumber
      );
    } else {
      // Replace JUSTIFICATION
      this.onFileUploadjusti(
        event,
        'tds_traces_default_file_name',
        this.selectedRowForReplace
      );
    }
  };

  fileInput.click();
}

  drawerOpen = false;
  consoDataForClient: any = null; // Data from CONSO to pre-fill client form
  isOpen = false;



  onDrawerClosed() {
    this.drawerOpen = false;
    this.consoDataForClient = null; // Clear CONSO data when drawer closes
  }

  // Get CONSO data for a specific row
  getConsoDataForRow(rowId: string): any {
    return this.parsedConsoData[rowId] || null;
  }

  // Get all deductee records from CONSO data for a specific row
  getDeducteeRecords(rowId: string): any[] {
    const consoData = this.parsedConsoData[rowId];
    return consoData ? consoData.deducteeRecords : [];
  }

  // Export CONSO data as JSON
  exportConsoDataAsJson(rowId: string) {
    const consoData = this.parsedConsoData[rowId];
    if (consoData) {
      const jsonStr = JSON.stringify(consoData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `conso_data_${rowId}_${Date.now()}.json`;
      link.click();
      window.URL.revokeObjectURL(url);
    } else {
      this.toastService.showError('No CONSO data available for this row');
    }
  }

  // Get all stored CONSO data
  getAllConsoData(): any {
    return this.parsedConsoData;
  }

 

 




  onImportDrawerClosed() {

    this.drawerOpen = false;  // or handle differently if needed
  }

  openDrawertwo(consoData?: any) {
    this.consoDataForClient = consoData || null;
    this.drawerOpen = true;
  }

  // Process CONSO file to extract data for table display
 

  // Shared method to validate and store CONSO data
  performCONSOValidationAndStorage(file: File, row: any, parsedData: any, rawData: any) {
    try {
      const bh = parsedData.batchHeader;

     

      // Try to find the TAN field - could be tan, tan_no, tanno, etc.
      const tanField = Object.keys(row).find(key => key.toLowerCase().includes('tan') && !key.includes('month'));
      const rowTan = tanField ? row[tanField] : null;

      // Validate TAN
      if (rowTan && bh.tan !== rowTan) {
        this.toastService.showError(`Invalid file: TAN mismatch. Expected: ${rowTan}, Found: ${bh.tan}`);
        return;
      }

      // Try to find FY field
      const fyField = Object.keys(row).find(key => key.toLowerCase().includes('fy') || key.toLowerCase().includes('financial'));
      const rowFY = fyField ? row[fyField] : null;

      // Validate Financial Year
      if (rowFY && bh.financialYear !== rowFY) {
        this.toastService.showError(`Invalid file: Financial Year mismatch. Expected: ${rowFY}, Found: ${bh.financialYear}`);
        return;
      }

      // Try to find Quarter field
      const quarterField = Object.keys(row).find(key => key.toLowerCase().includes('quarter') || key.toLowerCase().includes('qtr'));
      const rowQuarter = quarterField ? row[quarterField] : null;

      // Validate Quarter - Handle both "1" and "Q1" formats
      if (rowQuarter) {
        // Normalize both values to remove "Q" prefix for comparison
        const normalizedRowQuarter = String(rowQuarter).replace(/^Q/i, '');
        const normalizedBhQuarter = String(bh.quarter).replace(/^Q/i, '');

        if (normalizedBhQuarter !== normalizedRowQuarter) {
          this.toastService.showError(`Invalid file: Quarter mismatch. Expected: Q${normalizedRowQuarter}, Found: ${bh.quarter}`);
          return;
        }
      }

      // Try to find Return Type/Form Type field
      const formTypeField = Object.keys(row).find(key =>
        key.toLowerCase().includes('return_type') ||
        key.toLowerCase().includes('form_type') ||
        key.toLowerCase().includes('form') && !key.includes('month')
      );
      const rowFormType = formTypeField ? row[formTypeField] : null;

      // Validate Return Type (Form Type)
      if (rowFormType && bh.formType !== rowFormType) {
        this.toastService.showError(`Invalid file: Return Type mismatch. Expected: ${rowFormType}, Found: ${bh.formType}`);
        return;
      }

      console.log('CONSO file validation passed:', {
        tan: bh.tan,
        fy: bh.financialYear,
        quarter: bh.quarter,
        formType: bh.formType,
        rowFields: { tanField, fyField, quarterField, formTypeField }
      });

      // Store the complete parsed CONSO data AS IS - no calculations
      const rowId = row.rowid_seq || row.id || row.bank_branch_code;

      // Use RAW data - exactly as in the CONSO file, no manipulation
      const completeConsoJson = rawData; // This contains FH, BH, CD[], DD[] with raw values

      // Store the complete JSON with metadata for later API submission
      this.parsedConsoData[rowId] = {
        data: completeConsoJson,
        row: row,
        batchHeader: bh,
        fileName: file.name,
        uploadedAt: new Date()
      };

      // Update CONSO file count
      this.consoFileCount = Object.keys(this.parsedConsoData).length;

      // Log the JSON data with exact names


      // Update row with file name and data flag
      row['tds_traces_conso_file_name'] = file.name;
      row['conso_data_available'] = true;
      row['conso_json_data'] = completeConsoJson; // Store directly in row

      // Trigger change detection
      this.paginatedList = [...this.paginatedList];

      // Show success with data counts
      this.toastService.showSuccess(
        `CONSO file processed successfully!\n` +
        `DD Records: ${completeConsoJson.DD.length}\n` +
        `CD Records: ${completeConsoJson.CD.length}`
      );

      // Store reference for easy access in console
      (window as any).consoData = completeConsoJson;


    } catch (error: any) {
      console.error('Error validating/storing CONSO file:', error);
      this.toastService.showError('Error processing CONSO file: ' + (error.message || 'Unknown error'));
    }
  }



  getColspan(month: any) {
    let mergeGroupFields = 0;
    for (const key of Object.keys(month.mergeGroups)) {
      mergeGroupFields += Array.isArray(month.mergeGroups[key])
        ? month.mergeGroups[key].length
        : 1;
    }
    return mergeGroupFields + month.plainFields.length;
  }


  asArray(val: unknown): any[] {
    return Array.isArray(val) ? val : [];
  }




  isDateField(field: string): boolean {
  return field.toLowerCase().includes('date');
}


  // ✅ Format date safely
  formatDate(value: Date | string | null | undefined): string {
    if (!value) return '-';
    try {
      return formatDatesend(value); // Use your existing formatter
    } catch {
      return '-';
    }
  }

// getStatus() {
//   const endpoint = '/dynamic-import/get_data_status'; 

//   this.apiService.getStatus(endpoint).subscribe({
//     next: (response) => {
//       console.log('Status response:', response);
//       // ✅ handle your data here
//     },
//     error: (error) => {
//       console.error('Error fetching status:', error);
//       // optionally show toast or handle error UI
//     }
//   });
// }





justiFiles: any = {}; 
justiFileCount: number = 0; 
 justirefnumber: any;




 // 🧩 Step 1: Handle file upload event
  onFileUploadjusti(event: any, field: string, row: any) {
    console.log('📂 Uploading JUSTI file for row:', row);
    const file = event.target.files[0];
    if (!file) return;

    // ✅ Allow only .txt files
    if (!file.name.endsWith('.txt')) {
      this.toastService.showError('Please select a valid .txt JUSTI file');
      event.target.value = '';
      return;
    }

    // 🚫 Prevent upload when return status is pending
    if (row['tds_return_status'] === 'Pending') {
      this.toastService.showError('File upload is locked while Filing Status is Pending');
      event.target.value = '';
      return;
    }

    // 📖 Read file content
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const fileContent = e.target.result;

      // 🧠 Step 2: Extract only HDR line details
      const hdrInfo = this.extractHDRDetails(fileContent);

      if (!hdrInfo) {
        this.toastService.showError('Invalid JUSTI file (HDR missing)');
        row.uploadStatus = 'Invalid JUSTI file (HDR missing)';
        return;
      }

      // 🧾 Step 3: Match TAN, Quarter, and AY with row data
      const tanMatch = hdrInfo.TAN === row.tanno;
      const quarterMatch = hdrInfo.Quarter.replace(/^Q/i, '') === String(row.quarter_no).replace(/^Q/i, '');
      const yearMatch = hdrInfo.AY.replace(/20/, '') === row.acc_year.replace(/20/, '');
     const formMatch = hdrInfo.Form.trim().toUpperCase() === (row.tds_type_code || '').trim().toUpperCase();
      console.log('🔍 HDR Info Extracted:', hdrInfo);
      console.log('Comparing with Row:', {
        tanRow: row.tanno,
        quarterRow: row.quarter_no,
        yearRow: row.acc_year,
        tdsTypeRow: row.tds_type_code

      });

      if (tanMatch && quarterMatch && yearMatch && formMatch) {
        row.uploadStatus = 'Matched ✅';
        this.toastService.showSuccess('JUSTI file matched successfully!');
        this.storeJustiFile(file, hdrInfo, row); // Step 4
      } else {
        row.uploadStatus = 'Not Matched ❌';
        this.toastService.showError('JUSTI file details do not match row data');
        console.table({
          'TAN (File)': hdrInfo.TAN,
          'TAN (Row)': row.tanno,
          'Quarter (File)': hdrInfo.Quarter,
          'Quarter (Row)': row.quarter_no,
          'AY (File)': hdrInfo.AY,
          'AY (Row)': row.acc_year,
            'TDS Type (File)': hdrInfo.Form,
        'TDS Type (Row)': row.tds_type_code
        });
      }
    };

    reader.onerror = () => {
      this.toastService.showError('Error reading JUSTI file');
      row.uploadStatus = 'File read error';
    };

    reader.readAsText(file);
  }

  // 🧠 Step 2: Extract HDR details
  extractHDRDetails(content: string) {
    const lines = content.split(/\r?\n/).map(l => l.trim());
    const hdrLine = lines.find(line => line.startsWith('HDR^'));
    if (!hdrLine) return null;

    const parts = hdrLine.split('^');
    
    return {
      TAN: parts[1] || '',
      Name: parts[2] || '',
      Account: parts[3] || '',
      Form: parts[4] || '',
      Quarter: parts[5] || '',
      AY: parts[6] || '',
      Type: parts[7] || ''
    };
  }


  storeJustiFile(file: File, hdrInfo: any, row: any) {
    const key = row.rowid_seq || `${row.tanno}_${row.quarter_no}_${row.acc_year}`;
    this.justiFiles[key] = { fileName: file.name, hdrInfo, row, file, uploadedAt: new Date() };
    this.justiFileCount = Object.keys(this.justiFiles).length;
    row.justi_file_name = file.name;

    console.log(`✅ Stored JUSTI file for ${key}`, this.justiFiles[key]);
  }

  // 🚀 Step 5: Send all stored JUSTI files to backend
  sendAllJustiToAPI() {
    const justiKeys = Object.keys(this.justiFiles || {});
    if (justiKeys.length === 0) {
      this.toastService.showError('No JUSTI files uploaded. Please upload at least one.');
      return;
    }

    this.toastService.showSuccess(`Sending ${justiKeys.length} JUSTI file(s) to API...`);

    justiKeys.forEach((key, index) => {
      const stored = this.justiFiles[key];
      setTimeout(() => {
        this.sendIndividualJustiToAPI(stored.file, stored.row, stored.hdrInfo, (success: boolean) => {
          if (success) {
            delete this.justiFiles[key];
            this.justiFileCount = Object.keys(this.justiFiles).length;
          }
        });
      }, index * 500); // Avoid overload
    });



  }


   formatTracesDate(date = new Date()) {
  const day = String(date.getDate()).padStart(2, '0');

  const monthNames = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
    'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
  ];
  const month = monthNames[date.getMonth()];

  const year = date.getFullYear(); // RRRR

  const hours = String(date.getHours()).padStart(2, '0');     // HH24
  const minutes = String(date.getMinutes()).padStart(2, '0'); // MI
  const seconds = String(date.getSeconds()).padStart(2, '0'); // SS

  return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
}


generateRandomSeq(): number {
  return Math.floor(1000 + Math.random() * 9000); // 4 digits
}


  // 📤 Step 6: Send a single JUSTI file to backend API
  sendIndividualJustiToAPI(file: File, row: any, hdrInfo: any, callback?: (success: boolean) => void) {
      const apiUrl = `${BASE_API_URL}/dynamic-import/file-upload-justy`;
      this.justirefnumber=row?.tds_traces_default_process_seqno ;
    
    try {
        const isUpdate = !!this.justirefnumber;
        const newSeq = isUpdate ? this.generateRandomSeq() : row.rowid_seq;
      // Prepare sdata payload
      const sdata = {
        a_session_seqno: "",
        a_iud_seqno: "",
        a_proc_type: 'get_tiud_tds_traces_default_tran',
        a_entity_code: this.UserdynamicData.entity_code,
        a_client_code: row.client_code,
        a_acc_year: row.acc_year,
        a_quarter_no: row.quarter_no,
           a_tran_month: this.UserdynamicData.default_tran_month,
         a_tran_from_date: this.UserdynamicData.default_from_date,
      a_tran_to_date: this.UserdynamicData.default_to_date,
        // a_tran_from_date: row.tran_from_date || '',
        // a_tran_to_date: row.tran_to_date || '',
        a_tds_type_code: row.tds_type_code,
        a_filter_clause: '[]',
        a_app_json_data_test_rowid_seq:newSeq,
        a_iud_type: 'i',
        a_user_code: this.localUserData.user_code,
    // a_tds_traces_default_file_date: this.formatTracesDate()
    a_tds_traces_default_file_date: this.formatTracesDate(new Date()),


        a_tds_traces_default_file_name: file.name,
        a_tds_traces_default_process_seqno:newSeq,
        a_ref_process_seqno: isUpdate ? this.justirefnumber : "",
         a_validation_client_level: row.code_level,
      };

      // Build form data
      const formData = new FormData();
      formData.append('file', file);
      formData.append('sdata', JSON.stringify({ sdata: JSON.stringify(sdata) }));

      // console.log('📤 Uploading JUSTI to API:', apiUrl);
      // console.log('🧩 Payload sdata:', sdata);

      row.uploadStatus = 'Uploading... ⏳';

      // Send POST request
      this.http.post(apiUrl, formData).subscribe({
        next: (res: any) => {
          console.log('✅ JUSTI API Response:', res);

          if (res?.status === 202 || res?.result?.a_proc_error == 0) {
            row.uploadStatus = 'Uploaded ✅';
            this.toastService.showSuccess(`JUSTI uploaded successfully for ${row.client_name}`);
            if (callback) callback(true);
          } else {
            const msg = res?.result?.a_proc_error_message || 'JUSTI upload failed';
            row.uploadStatus = 'Failed ';
            this.toastService.showError(msg);
            if (callback) callback(false);
          }
        },
        error: (err) => {
          console.error(' API Error:', err);
          row.uploadStatus = 'Error ';
          this.toastService.showError('API Error while uploading JUSTI file');
          if (callback) callback(false);
        }
      });

    } catch (err) {
      console.error('❌ Unexpected error in JUSTI upload:', err);
      row.uploadStatus = 'Error ❌';
      this.toastService.showError('Unexpected error during JUSTI upload');
      if (callback) callback(false);
    }
  }



}



  // <ng-container *ngFor="let h of staticHeaders">
  //                               <td [hidden]="!h.visible" [style.text-align]="h.headerAlign"
  //                                   *ngIf="!h.mergeColumn || isFirstInMergeGroup(h)"
  //                                   class="whitespace-nowrap border-t border-e dark:border-borderdark px-3 py-2 text-[13px]">

  //                                   <!-- Bank Branch Code -->
  //                                   <ng-container *ngIf="h.field === 'bank_branch_code'">
  //                                       <p class="odd:bg-[#F9FBFF] even:bg-[#F9FBFF] 
  //        dark:odd:bg-gray-800 dark:even:bg-gray-800 
  //        rounded-full inline-block px-5 py-1 
  //        border border-gray-200 dark:border-gray-600 
  //        font-medium text-[13px] 
  //        text-gray-700 dark:text-gray-200">
  //                                           {{ row[h.field] || '-' }}
  //                                       </p>
  //                                   </ng-container>



  //                                   <!-- Merged columns -->
  //                                   <ng-container
  //                                       *ngIf="h.mergeColumn && h.field !== 'bank_branch_code' && h.field !== 'tds_return_status' && h.field !== 'tds_traces_conso_file_name' && h.field !== 'tds_traces_default_file_name'">
  //                                       <div class="flex flex-col gap-y-[2px] max-w-[300px]">
  //                                           <ng-container *ngFor="
  //                           let subH of mergeGroups[h.mergeColumn];
  //                           let i = index
  //                         ">
  //                                               <!-- First line (name, capitalized) -->
  //                                               <p *ngIf="i === 0"
  //                                                   class="truncate text-headingpri dark:text-headingpridark font-medium text-[14px]">
  //                                                   {{ capitalizeEachWord(row[subH.field]) }}
  //                                               </p>

  //                                               <!-- Second line (PAN + badge side by side) -->
  //                                               <div (click)="openDrawer(undefined,row, row.rowid_seq)" *ngIf="i === 1"
  //                                                   class="flex items-center gap-2">
  //                                                   <span
  //                                                       class=" cursor-pointer text-primary text-[13px] dark:text-sky-400">
  //                                                       {{ row[subH.field] || "-" }}
  //                                                   </span>

  //                                                   <!-- Badge from third value -->

  //                                               </div>
  //                                           </ng-container>
  //                                       </div>
  //                                   </ng-container>

  //                                   <!-- Normal columns -->
  //                                   <ng-container
  //                                       *ngIf="!h.mergeColumn && h.field !== 'bank_branch_code' && h.field !== 'tds_return_status' && h.field !== 'tds_traces_conso_file_name' && h.field !== 'tds_traces_default_file_name'">
  //                                       {{capitalizeEachWord( row[h.field]) || '-' }}
  //                                   </ng-container>

  //                               </td>
  //                           </ng-container>