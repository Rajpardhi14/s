import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ConsoParserService, ParsedCONSOFile } from '../../../../core/services/conso/conso-parser.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';

@Component({
  selector: 'app-import-conso',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './import-conso.component.html',
  styleUrl: './import-conso.component.css'
})
export class ImportConsoComponent implements OnInit {
  @Input() isOpen: boolean = false;
  @Input() clientData: any = null;
  @Output() close = new EventEmitter<void>();
  @Output() importSuccess = new EventEmitter<any>();
  @Output() createClientWithData = new EventEmitter<any>();

  form!: FormGroup;
  isDragging: boolean = false;
  isProcessing: boolean = false;
  parsedData: ParsedCONSOFile | null = null;
  fileName: string = '';
  fileValidation: any = null;
  showPreview: boolean = false;
  selectedFile: File | null = null;
  localUserData: any;

  // Pagination for deductee records preview
  currentPage: number = 1;
  itemsPerPage: number = 10;

  constructor(
    private fb: FormBuilder,
    private consoParser: ConsoParserService,
    private toastService: ToastService,
    private apiService: ApiserviceService,
    private userDataService: UserdataService
  ) {}

  ngOnInit(): void {
    this.localUserData = this.userDataService.getLocalUserData();
    this.initForm();
  }

  initForm(): void {
    this.form = this.fb.group({
      file: [null, Validators.required],
      clientTAN: [''],
      clientName: [''],
      remarks: ['']
    });
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;

    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      this.handleFile(files[0]);
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.handleFile(file);
    }
  }

  private handleFile(file: File): void {
    // Validate file extension
    if (!file.name.endsWith('.tds')) {
      this.toastService.showError('Please select a valid .tds file');
      return;
    }

    // Validate file name format
    this.fileValidation = this.consoParser.validateFileName(file.name);
    if (!this.fileValidation.isValid) {
      this.toastService.showError(this.fileValidation.error || 'Invalid file name format');
      return;
    }

    this.selectedFile = file;
    this.fileName = file.name;
    this.form.patchValue({ file: file });

    // Read and parse file
    this.parseFile(file);
  }

  private parseFile(file: File): void {
    this.isProcessing = true;
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const fileContent = e.target?.result as string;

        // Validate file content
        if (!fileContent || fileContent.trim().length === 0) {
          throw new Error('File is empty or contains no data');
        }

        this.parsedData = this.consoParser.parseCONSOFile(fileContent, file.name);

        // Validate parsed data
        if (!this.parsedData || !this.parsedData.batchHeader) {
          throw new Error('Failed to parse CONSO file - invalid file format');
        }

        // Auto-fill form with parsed data
        this.form.patchValue({
          clientTAN: this.parsedData.batchHeader.tan,
          clientName: this.parsedData.batchHeader.organizationName
        });

        // Validate TAN match if client data exists
        if (this.clientData && this.clientData.tan) {
          if (this.clientData.tan !== this.parsedData.batchHeader.tan) {
            this.toastService.showError(`TAN mismatch: File TAN (${this.parsedData.batchHeader.tan}) does not match selected client TAN (${this.clientData.tan})`);
            return;
          }
        }

        // Validate minimum required data
        if (!this.parsedData.batchHeader.tan) {
          this.toastService.showError('Warning: TAN not found in CONSO file');
        }

        if (!this.parsedData.batchHeader.organizationName) {
          this.toastService.showError('Warning: Organization name not found in CONSO file');
        }

        this.showPreview = true;
        this.toastService.showSuccess(`CONSO file parsed successfully! Found ${this.parsedData.summary.totalDeductees} deductee records.`);
      } catch (error: any) {
        console.error('Error parsing CONSO file:', error);
        this.toastService.showError('Error parsing file: ' + (error.message || 'Unknown error occurred'));
        this.resetFile();
      } finally {
        this.isProcessing = false;
      }
    };

    reader.onerror = () => {
      this.toastService.showError('Error reading file - please try again');
      this.isProcessing = false;
      this.resetFile();
    };

    reader.readAsText(file);
  }

  resetFile(): void {
    this.selectedFile = null;
    this.fileName = '';
    this.parsedData = null;
    this.fileValidation = null;
    this.showPreview = false;
    this.form.patchValue({ file: null });
  }

  get paginatedDeductees(): any[] {
    if (!this.parsedData) return [];

    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.parsedData.deducteeRecords.slice(start, end);
  }

  get totalPages(): number {
    if (!this.parsedData) return 0;
    return Math.ceil(this.parsedData.deducteeRecords.length / this.itemsPerPage);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }

  createNewClientWithConsoData(): void {
    if (!this.parsedData) {
      this.toastService.showError('No CONSO data available');
      return;
    }

    const bh = this.parsedData.batchHeader;

    // Extract and format data for client creation with enhanced field mapping
    const clientData = {
      // Client Details from BH (Batch Header)
      tanno: bh.tan,
      client_name: bh.organizationName,
      panno: bh.organizationPAN || '',

      // Organization Address from BH (enhanced mapping)
      add1: bh.organizationAddress1 || bh.responsiblePersonAddress.split(' ')[0] || '',
      add2: bh.organizationAddress2 || bh.responsiblePersonAddress.split(' ')[1] || '',
      add3: bh.organizationAddress3 || bh.responsiblePersonAddress.split(' ')[2] || '',
      add4: bh.organizationAddress4 || bh.responsiblePersonAddress.split(' ')[3] || '',
      city: bh.organizationCity || '',
      state: bh.organizationState || '',
      pin: bh.organizationPin || '',
      email_id: bh.responsiblePersonEmail || '',
      mobileno: bh.responsiblePersonMobile || '',
      phoneno: bh.organizationPhone || '',
      stdcode: bh.organizationStdCode || '',

      // Branch/Division information
      branch_division: bh.branchDivision || '',

      // Responsible Person Details from BH (enhanced mapping)
      deductor_name: bh.responsiblePerson,
      deductor_desig: bh.responsiblePersonDesignation,
      deductor_panno: bh.responsiblePersonPAN || bh.organizationPAN || '',
      deductor_email_id: bh.responsiblePersonEmail,
      deductor_mobileno: bh.responsiblePersonMobile || '',
      deductor_phoneno: bh.responsiblePersonPhone || '',
      deductor_stdcode: bh.responsiblePersonStdCode || '',

      // Responsible Person Address (use organization address as fallback)
      deductor_add1: bh.organizationAddress1 || bh.responsiblePersonAddress.split(' ')[0] || '',
      deductor_add2: bh.organizationAddress2 || bh.responsiblePersonAddress.split(' ')[1] || '',
      deductor_add3: bh.organizationAddress3 || bh.responsiblePersonAddress.split(' ')[2] || '',
      deductor_add4: bh.organizationAddress4 || bh.responsiblePersonAddress.split(' ')[3] || '',
      deductor_city: bh.organizationCity || '',
      deductor_state_code: bh.organizationState || '',
      deductor_pin: bh.organizationPin || '',

      // Credentials (TAN same as income tax ID as per existing logic)
      incometax_id: bh.tan,

      // Additional metadata for reference
      formType: bh.formType,
      financialYear: bh.financialYear,
      assessmentYear: bh.assessmentYear,
      quarter: bh.quarter,
      rrnNumber: bh.rrnNumber,
      totalAmount: bh.totalAmount,
      sourceFile: this.fileName,

      // Summary for reference
      totalDeductees: this.parsedData.summary.totalDeductees,
      totalTDS: this.parsedData.summary.totalTDS,

      // Flag to indicate this is from CONSO
      isFromCONSO: true
    };

    console.log('Enhanced CONSO client data:', clientData);

    // Emit event to create client with this data
    this.createClientWithData.emit(clientData);
    this.onClose();
  }

  onSubmit(): void {
    if (!this.parsedData || !this.selectedFile) {
      this.toastService.showError('Please select and parse a valid CONSO file');
      return;
    }

    this.isProcessing = true;

    // Prepare data for API
    const formData = new FormData();
    formData.append('file', this.selectedFile);
    formData.append('tan', this.parsedData.batchHeader.tan);
    formData.append('formType', this.parsedData.batchHeader.formType);
    formData.append('financialYear', this.parsedData.batchHeader.financialYear);
    formData.append('quarter', this.parsedData.batchHeader.quarter);
    formData.append('entityCode', this.localUserData?.entity_code || '');
    formData.append('parsedData', JSON.stringify(this.parsedData));
    formData.append('remarks', this.form.get('remarks')?.value || '');

    // TODO: Call API to save CONSO data
    // this.apiService.importCONSOFile(formData).subscribe({
    //   next: (response) => {
    //     this.toastService.showSuccess('CONSO file imported successfully!');
    //     this.importSuccess.emit(response);
    //     this.onClose();
    //   },
    //   error: (error) => {
    //     this.toastService.showError('Failed to import CONSO file');
    //     this.isProcessing = false;
    //   }
    // });

    // For now, simulate success
    setTimeout(() => {
      this.toastService.showSuccess('CONSO file imported successfully!');
      this.importSuccess.emit({
        fileName: this.fileName,
        tan: this.parsedData?.batchHeader.tan,
        totalRecords: this.parsedData?.summary.totalDeductees,
        totalAmount: this.parsedData?.summary.totalTDS
      });
      this.isProcessing = false;
      this.onClose();
    }, 1500);
  }

  onClose(): void {
    this.resetFile();
    this.form.reset();
    this.currentPage = 1;
    this.close.emit();
  }
}