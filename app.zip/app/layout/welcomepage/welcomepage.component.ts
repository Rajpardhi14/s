import { Component } from '@angular/core';
import { ToastService } from '../../core/services/toaster/toast.service';
import { CommonModule } from '@angular/common';
import { SuccesstoastComponent } from "../../shared/components/toaster/successtoast/successtoast.component";
import { HeaderComponent } from "../header/header/header.component";

@Component({
  selector: 'app-welcomepage',
  standalone: true,
  imports: [CommonModule, SuccesstoastComponent, HeaderComponent],
  templateUrl: './welcomepage.component.html',
  styleUrl: './welcomepage.component.css'
})
export class WelcomepageComponent {

  constructor(private toastService: ToastService) { }
  ngOnInit(): void {
    if (sessionStorage.getItem('loginSuccess')) {
      this.toastService.showSuccess(
        'Login successful! Welcome to the application.'
      );
      sessionStorage.removeItem('loginSuccess');
    }

  }

}
