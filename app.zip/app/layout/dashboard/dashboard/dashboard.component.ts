import { Component } from '@angular/core';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { CommonModule } from '@angular/common';
import { SuccesstoastComponent } from "../../../shared/components/toaster/successtoast/successtoast.component";
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, SuccesstoastComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  localUserData: any;
  errorMessage: string = '';
  constructor(private toastService: ToastService,
    private authService: AuthService,
    private userlocaldataService: UserdataService,
    private apiService: ApiserviceService,

  ) { }
  ngOnInit(): void {

    this.localUserData = this.userlocaldataService.getLocalUserData();
    const alreadyLoaded = sessionStorage.getItem('redisDataSet');
    if (!alreadyLoaded) {
      this.saveRedisData();
    } else {
      console.log('Redis data already set — skipping API call');
    }



  }

















  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }












  saveRedisData(): void {
    this.fetchmmtx().subscribe({
      next: (multiMastData) => {
        const mmtxdata = {
          multiMast: multiMastData,

        };
        const requestBody = {
          usercode: this.localUserData?.user_code,
          clientcode: this.localUserData?.client_code,
          mmtxdata: JSON.stringify(mmtxdata),
        };

        this.apiService.setRedisApi('/Comman/set_mmtx_data', requestBody).subscribe({
          next: (response) => {
            sessionStorage.setItem('redisDataSet', 'true');

          },
          error: (error) => {
            console.error(' Failed to set Redis data:', error);
          },
        });
      },
      error: (err) => {
        console.error('Failed to fetch statemast data before saving Redis:', err);
      },
    });
  }
  private fetchmmtx(): Observable<any> {
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_is_pen_flag: "",
        a_login_type: "login_id",
        a_module_type_code: this.localUserData?.default_module_type_code,
        a_sub_module_type_code: "R",
        a_entity_code: this.localUserData?.entity_code,
        a_client_code: this.localUserData?.client_code,
        a_acc_year: this.localUserData?.default_acc_year,
        a_quarter_no: this.localUserData?.default_quarter_no,
        a_tran_month: this.localUserData?.default_tran_month,
        a_tran_from_date: this.localUserData?.default_from_date,
        a_tran_to_date: this.localUserData?.default_to_date,
        a_tds_type_code: this.localUserData?.default_tds_type_code,
        a_first_level_client_code: this.localUserData?.first_level_client_code,
        a_validation_client_level: this.localUserData.client_code_level,
        a_iud_type: "",
        a_db_total_records: "10",
        a_pagination_count: "0",
        a_proc_type: "get_mmtx_multi_mast",
        a_filter_clause: [
          {
            filter_col_field: "gd_proc_name",
            filter_col_depend_operator: "wc",
            filter_col_value:
              "and gd_proc_name in ( ##get_mmtx_client_type_mast##,##get_mmtx_client_catg_mast##,##get_mmtx_state_mast##,##get_mmtx_client_level_mast##, ##get_mmtx_regex_validation##,  ##get_mmtx_tds_type_mast##,##get_mmtx_country_mast##,##get_mmtx_remittance_nature_mast##,##get_mmtx_tds_deduct_reason_mast##,##get_mmtx_tds_rate_type_mast##,##get_mmtx_tds_mast##,##get_mmtx_user_role_mast##,##get_mmtx_minor_head_mast##,##get_mmtx_gh15_flag_mast##,##get_mmtx_resident_type_mast##,##get_mmtx_assessed_tax_flag_mast##,##get_mmtx_pan_status_mast##,##get_mmtx_acc_year_mast##)",

            // filter_col_value:
            //   "and gd_proc_name in (##get_mmtx_acc_year_mast##, ##get_mmtx_client_level_mast##, ##get_mmtx_quarter_mast##, ##get_mmtx_regex_validation##, ##get_mmtx_app_parameters##, ##get_mmtx_module_type_mast##, ##get_mmtx_sub_module_type_mast##, ##get_mmtx_tds_type_mast##)",
            filter_col_field_alias: "a.",
          },
        ],
      }),
    };

    return new Observable((observer) => {
      this.authService.fetchMultiMastData(requestBody).subscribe({
        next: (response: any) => {
          const result = response?.body?.result;
          if (result?.a_proc_error == 0) {
            const multiMast = result?.get_mmtx_multi_mast;
            if (multiMast) {
              observer.next(multiMast);
              observer.complete();
            } else {
              observer.error(' No multiMast data found in API response');
            }
          } else {
            observer.error(result?.a_proc_error_message || 'Unknown process error');
          }
        },
        error: (error: any) => {
          observer.error(error.message || 'Failed to fetch header master data.');
        },
      });
    });
  }
  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
        } catch (e) {
          parsedData = response.data;
        }
        console.log('Parsed Redis data:', parsedData);
      },
      error: (error: any) => {
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }






}
