import { CommonModule, isPlatformBrowser } from '@angular/common';
import {
  Component,
  DestroyRef,
  inject,
  Inject,
  PLATFORM_ID,
  SimpleChanges,
} from '@angular/core';
import {
  NavigationEnd,
  Router,
  RouterLink,
  RouterLinkActive,
} from '@angular/router';
import { DarklightthemeService } from '../../../core/services/theme/darklighttheme.service';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import {
  getFirstNameWithoutTilde,
  getFullNameWithoutTilde,
  getUserInitials,
} from '../../../shared/utils/userinitials';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { capitalizeEachWord } from '../../../shared/utils/passmatch';
import { filter, skip, Subscription } from 'rxjs';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { OverlayService } from '../../../core/services/LoaderService/overlay.service';
import { FiledOptionService } from '../../../core/services/session/timer-session/filed-option.service';
import { SessiontimerService } from '../../../core/services/session/timer-session/sessiontimer.service';
import { TracesService } from '../../../features/traces/services/traces.service';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, OutSideClickDirective, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  lastApiCallTime: number = 0;
  apiCallTimeSubscription!: Subscription;
  private lastApiCallTimeKey = 'lastApiCallTime';
  countdownInterval: any;
  remainingTime = 0;
  minutes = '03';
  seconds = '00';
  localUserData: any;
  switchState: boolean = false;
  userInitials: any;
  firstNameLastNameinitial: any;
  firstNameinitial: any;
  userName: any;
  fName: any;
  email_id: any;
  isOpen = false;
  themeMode: any;
  fySelectedValue = '';
  isOpenFyDropdown: boolean = false;
  fySelectedlable = 'Select';
  openDropdown: 'fy' | 'form' | null = null;
  selectedFY: { value: string; label: string } | null = null;
  fyYears: { value: string; label: string }[] = [];
  visibleFyYears: { value: string; label: string }[] = [];
  quarters: { value: string; label: string }[] = [];
  selectedQuarter: { value: string; label: string } | null = null;

  selectedCategory: { label: string; value: string } | null = null;
  selectedForm: { label: string; value: string } | null = null;

  // Arrays for dropdowns
  categories: { label: string; value: string }[] = [];
  forms: { label: string; value: string }[] = [];
  private isBrowser: boolean;

  isTracesConnected: boolean = false;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    protected theme: DarklightthemeService,
    private router: Router,
    private apiservice: ApiserviceService,
    private userlocaldataService: UserdataService,
    private loaderService: OverlayService,
    private apiService: ApiserviceService,
    private sessionTimer: SessiontimerService,
    private tracesService: TracesService
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  localuserData: string = '';

  clientid: string | number = '';
  clientname: string = '';
  capitalizeEachWord = capitalizeEachWord;
  dynamicUserData: any;

  mymodules: string = '';
  bankcode: string = '';
  isDropdownEnabled: boolean = false;
  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);

  ngOnChanges(changes: SimpleChanges): void {
    const lastApiCallTime = sessionStorage.getItem(this.lastApiCallTimeKey);
  }

  ngOnInit() {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        const url = event.urlAfterRedirects;

        this.isDropdownEnabled =
          url.includes('dashboard') || url.includes('clientslist');
      });
    const currentUrl = this.router.url;
    this.isDropdownEnabled =
      currentUrl.includes('dashboard') || currentUrl.includes('clientslist');

    if (!this.isBrowser) {
      return;
    }

    this.localUserData = this.userlocaldataService.getLocalUserData();
    const dynamicUserData = this.userlocaldataService.getAllDynamicUserData();

    if (this.router.url.includes('clientslist')) {
      this.clientid = '';
    } else {
      this.clientid = dynamicUserData.tanno;
    }
    this.clientname = dynamicUserData.client_code_details;
    this.dynamicUserData = dynamicUserData;
    this.bankcode = dynamicUserData.bank_branch_code;

    this.ReapplyData();

    const storedTheme = localStorage.getItem('theme');
    if (storedTheme === 'dark') {
      this.switchState = true;
      this.setDarkTheme();
    } else {
      this.switchState = false;
      this.setLightTheme();
    }
    this.getLocalUserData();

    if (this.userName) {
      this.firstNameinitial = getFirstNameWithoutTilde(this.userName);
      this.firstNameLastNameinitial = getFullNameWithoutTilde(this.userName);
      this.userInitials = getUserInitials(this.userName);
    }
    this.initializeDropdownData();
    window.addEventListener('storage', this.handleStorageChange.bind(this));

    this.dynamicUserData$
      .pipe(
        // skip(1),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe((dynamicData) => {});

    this.tracesService.sessionStatusChanged$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((status) => {
        this.isTracesConnected = status.isAuthenticated;
      });

    window.addEventListener('storage', this.handleStorageChange.bind(this));

    // ---------- ⭐ MOVE TIMER LOGIC LAST ⭐ ----------
    this.apiCallTimeSubscription = this.sessionTimer.lastApiCallTime$.subscribe(
      (time: number) => {
        if (time > 0) this.startReverseCountdown();
      }
    );

    const storedTime = Number(sessionStorage.getItem(this.lastApiCallTimeKey));
    if (storedTime) {
      this.startReverseCountdown();
    }
  }

  private handleStorageChange = (event: StorageEvent) => {
    if (
      event.key === 'yearData' ||
      event.key === 'quarterData' ||
      event.key === 'tdsData' ||
      event.key === 'CategoryData'
    ) {
      this.initializeDropdownData();
    }
  };

  private initializeDropdownData() {
    if (!this.isBrowser) {
      return;
    }

    const dynamicUserData = this.userlocaldataService.getAllDynamicUserData();
    const headerMaster = JSON.parse(
      sessionStorage.getItem('headermaster') || '{}'
    );
    const yearData = headerMaster?.get_gmdt_acc_year_mast || [];
    const quarterData = headerMaster?.get_gmdt_quarter_mast || [];
    const tdsData = headerMaster?.get_gmdt_tds_type_mast || [];
    const CategoryData = headerMaster?.get_gmdt_sub_module_type_mast;

    // ----- Year -----
    if (Array.isArray(yearData)) {
      this.fyYears = yearData.map((item: any) => ({
        value: item.value,
        label: item.label,
      }));
      this.visibleFyYears = this.fyYears.slice(0, 4);

      const defaultFY = dynamicUserData?.default_acc_year;
      this.selectedFY =
        this.fyYears.find((fy) => fy.value === defaultFY) || this.fyYears[0];
    }

    // ----- Quarter -----
    if (Array.isArray(quarterData)) {
      this.quarters = quarterData.map((q: any) => ({
        value: q.value,
        label: q.label,
      }));

      const defaultQuarter = dynamicUserData?.default_quarter_no;
      this.selectedQuarter =
        this.quarters.find((q) => q.value === defaultQuarter) ||
        this.quarters[0];
    }

    //     if (Array.isArray(tdsData)) {
    //   // 1️⃣ Fallback to "R" if sub_module_type is null/undefined
    //   const subModuleType = dynamicUserData?.default_sub_module_type_code || "R";

    //   // 2️⃣ Filter based on sub_module_type_code
    //   const filteredData = tdsData.filter(
    //     (item: any) => item.sub_module_type_code === subModuleType
    //   );

    //   // 3️⃣ Map filtered data to label/value
    //   this.forms = filteredData.map((item: any) => ({
    //     label: item.label,
    //     value: item.value
    //   }));

    //   // 4️⃣ Select default form (fallback to first one)
    //   const defaultForm = dynamicUserData?.default_tds_type_code;
    //   this.selectedForm =
    //     this.forms.find(f => f.value === defaultForm) || this.forms[0];
    // }

    this.filterTdsDataByCategory(
      dynamicUserData?.default_sub_module_type_code || 'R'
    );

    // ----- Category (from MMTX) -----
    if (Array.isArray(CategoryData)) {
      // Filter if only certain module type (optional)
      const filteredCategories = CategoryData.filter(
        (item: any) => item.module_type_code === 'TAXCPC'
      );

      this.categories = filteredCategories.map((cat: any) => ({
        label: cat.sub_module_type_name,
        value: cat.sub_module_type_code,
      }));

      const defaultCategory = dynamicUserData?.default_sub_module_type_code;
      this.selectedCategory =
        this.categories.find((cat) => cat.value === defaultCategory) ||
        this.categories[0];
    }

    // Retry if data not yet available
    if (!yearData.length || !quarterData.length || !tdsData.length) {
      setTimeout(() => {
        this.initializeDropdownData();
      }, 500);
    }
  }

  private filterTdsDataByCategory(subModuleType: string = 'R'): void {
    const headerMaster = JSON.parse(
      sessionStorage.getItem('headermaster') || '{}'
    );
    const tdsData = headerMaster?.get_gmdt_tds_type_mast || [];
    const dynamicUserData = this.userlocaldataService.getAllDynamicUserData();

    let filteredData = tdsData.filter(
      (item: any) => item.sub_module_type_code === subModuleType
    );

    if (filteredData.length === 0 && subModuleType !== 'R') {
      filteredData = tdsData.filter(
        (item: any) => item.sub_module_type_code === 'R'
      );
    }

    this.forms = filteredData.map((item: any) => ({
      label: item.label,
      value: item.value,
    }));

    const defaultForm = dynamicUserData?.default_tds_type_code;
    this.selectedForm =
      this.forms.find((f) => f.value === defaultForm) || this.forms[0];
  }

  login_id: any;

  getLocalUserData() {
    if (typeof window !== 'undefined') {
      var storedData = sessionStorage.getItem('localUserData');
      if (storedData) {
        this.localUserData = JSON.parse(storedData);

        this.userName = this.localUserData.user_name;
        this.email_id = this.localUserData.email_id;
        this.login_id = this.localUserData.login_id;
      }
    }
  }

  toggleNavbar(event: MouseEvent) {
    event.stopPropagation();
    this.isOpen = !this.isOpen;
  }
  closeUserCard() {
    this.isOpen = false;
  }

  toggleDropdown(type: 'fy' | 'form') {
    this.openDropdown = this.openDropdown === type ? null : type;
  }

  closeDropdown(type: 'fy' | 'form') {
    if (this.openDropdown === type) {
      this.openDropdown = null;
    }
  }

  selectFY(fy: { value: string; label: string }) {
    this.selectedFY = fy;
    // this.closeDropdown('fy');
  }

  selectQuarter(q: { value: string; label: string }) {
    this.selectedQuarter = q;
  }

  selectCategory(cat: { label: string; value: string }) {
    console.log(cat);
    this.selectedCategory = cat;
    this.filterTdsDataByCategory(cat.value);

    // this.closeDropdown('cat');
  }

  selectForm(form: { label: string; value: string }) {
    this.selectedForm = form;
    // this.closeDropdown('form');
  }

  showMoreFyYears() {
    this.visibleFyYears = this.fyYears;
  }

  showCategoryConfirmPopup = false; 
  private proceedAfterConfirm = false; 
  previousCategory: string | null = null;

  applySelection(type: 'fy' | 'form') {
    const previousCategory =
      this.userlocaldataService.getDynamicUserData(
        'default_sub_module_type_code'
      ) || 'R';
    console.log(previousCategory);
    this.previousCategory = previousCategory;
    if (
      this.selectedCategory &&
      this.selectedCategory.value !== previousCategory &&
      !this.proceedAfterConfirm
    ) {
      this.showCategoryConfirmPopup = true;
      return;
    }

    this.proceedAfterConfirm = false;

    const isCategoryChanged =
      this.selectedCategory && this.selectedCategory.value !== previousCategory;

    if (isCategoryChanged) {
      this.filterTdsDataByCategory(this.selectedCategory?.value);
      this.loaderService.show();
    }
    if (this.selectedFY) {
      this.userlocaldataService.setDynamicUserData(
        'default_acc_year',
        this.selectedFY.value
      );
    }

    if (this.selectedQuarter) {
      this.userlocaldataService.setDynamicUserData(
        'default_quarter_no',
        this.selectedQuarter.value
      );
    }

    if (this.selectedCategory) {
      this.userlocaldataService.setDynamicUserData(
        'default_sub_module_type_code',
        this.selectedCategory.value
      );
    }

    if (this.selectedForm) {
      this.userlocaldataService.setDynamicUserData(
        'default_tds_type_code',
        this.selectedForm.value
      );
    }

    if (this.selectedFY?.value && this.selectedQuarter?.value) {
      const fyVal = this.selectedFY.value;
      const [start, end] = fyVal.split('-');
      const startYear = +start + 2000;
      const endYear = +end + 2000;

      let fromDate = '';
      let toDate = '';
      let tranMonth = '';

      switch (+this.selectedQuarter.value) {
        case 1:
          fromDate = `01-APR-${startYear}`;
          toDate = `30-JUN-${startYear}`;
          tranMonth = 'JUN';
          break;
        case 2:
          fromDate = `01-JUL-${startYear}`;
          toDate = `30-SEP-${startYear}`;
          tranMonth = 'SEP';
          break;
        case 3:
          fromDate = `01-OCT-${startYear}`;
          toDate = `31-DEC-${startYear}`;
          tranMonth = 'DEC';
          break;
        case 4:
          fromDate = `01-JAN-${endYear}`;
          toDate = `31-MAR-${endYear}`;
          tranMonth = 'MAR';
          break;
      }

      if (fromDate && toDate) {
        this.userlocaldataService.setDynamicUserData(
          'default_from_date',
          fromDate
        );
        this.userlocaldataService.setDynamicUserData('default_to_date', toDate);
        this.userlocaldataService.setDynamicUserData(
          'default_tran_month',
          tranMonth
        );
      }
    }
    this.openDropdown = null;

    if (this.selectedCategory) {
      setTimeout(() => {
        this.loaderService.hide();
      }, 300);
    }
  }

  ReapplyData() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (this.router.url.includes('clientslist')) {
          this.clientid = '';
          if (this.localUserData) {
            this.userlocaldataService.setDynamicUserData(
              'client_code',
              this.localUserData.client_code
            );
            this.userlocaldataService.setDynamicUserData(
              'client_code_details',
              this.localUserData.client_code_details
            );
            this.userlocaldataService.setDynamicUserData(
              'first_level_client_code',
              this.localUserData.first_level_client_code
            );
            this.userlocaldataService.setDynamicUserData(
              'validation_client_level',
              this.localUserData.client_code_level
            );
            this.userlocaldataService.setDynamicUserData(
              'client_code_level',
              this.localUserData.client_code_level
            );
            //  this.userlocaldataService.setDynamicUserData('validation_client_level', this.rowData.code_level);
          } else {
            console.warn('localUserData not available yet');
          }
        }
      }
    });
  }

  toggleTheme() {
    if (this.switchState) {
      this.setLightTheme();
    } else {
      this.setDarkTheme();
    }
    this.switchState = !this.switchState;
  }

  setLightTheme() {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', 'light');
    console.log('Light theme activated');
  }

  setDarkTheme() {
    document.documentElement.classList.add('dark');
    localStorage.setItem('theme', 'dark');
    console.log('Dark theme activated');
  }

  onConfirmCategoryChange() {
    this.showCategoryConfirmPopup = false;
    this.proceedAfterConfirm = true;
    this.applySelection('fy');
  }

  onCancelCategoryChange() {
    this.showCategoryConfirmPopup = false;
    if (this.previousCategory) {
      const previous = this.categories?.find(
        (cat: { label: string; value: string }) =>
          cat.value === this.previousCategory
      );
      if (previous) {
        this.selectedCategory = previous;
      }
    }
  }

  //   onLogout() {
  //             this.userlocaldataService.clearLocalUserData();
  //         localStorage.clear();
  //         sessionStorage.clear();

  //         if ('caches' in window) {
  //           caches.keys().then((names) => {
  //             for (const name of names) {
  //               caches.delete(name);
  //             }
  //           });
  //         }
  //         this.router.navigate(['']);
  // //  this.router.navigate(['']);

  //     // this.onSubmit();

  //     // Call logout API, but do not rely on its success to continue
  //     // this.apiservice.userLogout().catch((err) => {
  //     //   console.error('Logout API failed:', err);
  //     // });
  //     // Proceed with clearing local data and navigating away
  //     // this.userlocaldataService.clearLocalUserData();
  //     // localStorage.clear();
  //     // sessionStorage.clear();

  //     // if ('caches' in window) {
  //     //   caches.keys().then((names) => {
  //     //     for (const name of names) {
  //     //       caches.delete(name);
  //     //     }
  //     //   });
  //     // }

  //     // this.router.navigate(['']);

  //   }

  // onSubmit() {
  //   const requestBody = {
  //     a_session_seqno: '',
  //     a_iud_seqno: '',
  //     a_process_seqno: '',
  //     a_login_type: 'login_id',
  //     a_iud_type: "u",
  //     a_proc_type: 'get_miud_user_mast',
  //     a_user_code: this.localUserData.user_code,
  //     a_entity_code: this.localUserData.entity_code,
  //     a_client_code: this.localUserData.client_code,
  //     a_acc_year: this.localUserData.default_acc_year,
  //     a_quarter_no: this.localUserData.default_quarter_no,
  //     a_tran_month: this.localUserData.default_tran_month,
  //     a_validation_client_level: this.localUserData.client_code_level,
  //     a_tran_from_date: this.localUserData.default_from_date,
  //     a_tran_to_date: this.localUserData.default_to_date,
  //     a_tds_type_code: this.localUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_first_level_client_code: this.localUserData.first_level_client_code,
  //     a_process_status_code: 'ZA',
  //     a_db_total_records: '1000',
  //     a_pagination_count: '0',
  //     user_mast: {
  //       user_code: this.dynamicUserData.user_code,
  //       user_name: this.dynamicUserData.user_name,
  //       user_role_code: this.dynamicUserData.user_role_code,
  //       email_id: this.dynamicUserData.email_id,
  //       entity_code: this.dynamicUserData.entity_code,
  //       bank_branch_code: this.dynamicUserData.bank_branch_code,
  //       user_level: this.dynamicUserData.user_level,
  //       default_acc_year: this.dynamicUserData.default_acc_year,
  //       login_id: this.dynamicUserData.login_id,
  //       login_pwd: this.dynamicUserData.login_pwd,
  //       default_quarter_no: this.dynamicUserData.default_quarter_no,
  //       default_tds_type_code: this.dynamicUserData.default_tds_type_code,
  //       default_tran_month: this.dynamicUserData.default_tran_month,
  //       default_module_type_code: this.dynamicUserData.default_module_type_code,
  //       first_time_login: '2',

  //     },
  //   };

  //   this.apiservice.miudApi("/UserMast/get_miud_user_mast", requestBody).subscribe({
  //     next: (res) => {
  //       // console.log('Response received:', res);

  //       this.userlocaldataService.clearLocalUserData();
  //       localStorage.clear();
  //       sessionStorage.clear();

  //       if ('caches' in window) {
  //         caches.keys().then((names) => {
  //           for (const name of names) {
  //             caches.delete(name);
  //           }
  //         });
  //       }
  //       this.router.navigate(['']);

  //     },
  //     error: (err) => {
  //       console.error('Submit request error:', err);

  //     },
  //   });

  // }
  async onLogout() {
    try {
      // Step 1: Call backend logout API first
      await this.apiService.logout().catch((err) => {
        console.error('Logout API failed:', err);
      });

      await this.deleteData();

      sessionStorage.clear();
      localStorage.clear();

      // Step 4: Clear caches
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((name) => caches.delete(name)));
      }

      // Step 5: Navigate to login/home
      await this.router.navigate(['']);

      window.location.reload();
    } catch (error) {
      console.error('Logout failed:', error);
      // Ensure clean state even on error
      window.location.reload();
    }
  }

  private deleteData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService
      .setRedisApi('/Comman/delete_mmtx_data', requestBody)
      .subscribe({
        next: (response: any) => {
          console.log(response);
        },
        error: (error: any) => {
          console.log(error);
        },
      });
  }

  startReverseCountdown() {
    const countdownDuration = 10 * 60 * 1000;
    const currentTime = Date.now();

    const lastApiCallTime = Number(
      sessionStorage.getItem(this.lastApiCallTimeKey)
    );

    if (!lastApiCallTime || isNaN(lastApiCallTime)) {
      console.warn('Invalid lastApiCallTime in storage');
      return;
    }

    const timePassed = currentTime - lastApiCallTime;
    const timeLeft = countdownDuration - timePassed;

    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
    }

    this.remainingTime = timeLeft > 0 ? Math.floor(timeLeft / 1000) : 0;
    this.updateFormattedTime();

    if (this.remainingTime <= 0) return;

    this.countdownInterval = setInterval(() => {
      this.remainingTime--;

      if (this.remainingTime <= 0) {
        this.remainingTime = 0;
        clearInterval(this.countdownInterval);
      }

      this.updateFormattedTime();
    }, 1000);
  }

  updateFormattedTime() {
    const m = Math.floor(this.remainingTime / 60);
    const s = this.remainingTime % 60;

    this.minutes = m.toString().padStart(2, '0');
    this.seconds = s.toString().padStart(2, '0');
  }

  ngOnDestroy() {
    if (this.isBrowser) {
      window.removeEventListener(
        'storage',
        this.handleStorageChange.bind(this)
      );
    }

    if (this.apiCallTimeSubscription) {
      this.apiCallTimeSubscription.unsubscribe();
    }
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
    }
  }

  navigateToTraces() {
    this.router.navigate(['/home/traces']);
  }
}
