import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/components/login/login.component';
import { DashboardComponent } from './layout/dashboard/dashboard/dashboard.component';
import { RegistrationComponent } from './features/auth/components/registration/registration.component';
import { AuthGuard } from './core/services/authguard/auth.guard';
import { WelcomeclientComponent } from './layout/welcomeclient/welcomeclient.component';
import { WelcomepageComponent } from './layout/welcomepage/welcomepage.component';
import { AlertpoupComponent } from './shared/components/alertpoup/alertpoup.component';
import { CorrectionpoupComponent } from './shared/components/correctionpoup/correctionpoup/correctionpoup.component';

export const routes: Routes = [

    {
        path: "w",
        component: CorrectionpoupComponent
    },
    {
        path: '',
        loadComponent: () =>
            import('./features/auth/components/login/login.component').then((m) => m.LoginComponent),
        title: 'TDSCPC | Login',
        data: { breadcrumb: 'Login' },
    },

    {
        path: 'registration',
        loadComponent: () =>
            import('./features/auth/components/registration/registration.component').then((m) => m.RegistrationComponent),
        title: 'TDSCPC | Registration',
        data: { breadcrumb: 'Registration' },
    },


    {
        path: 'otpverify',
        loadComponent: () =>
            import('./features/auth/components/otpverification/otpverification.component').then(
                (m) => m.OtpverificationComponent
            ),
        title: 'TDSCPC | Otp Verify',
    },
    {
        path: 'forgotpassword',
        loadComponent: () =>
            import('./features/auth/components/forgotpassword/forgotpassword.component').then(
                (m) => m.ForgotpasswordComponent
            ),
        title: 'TDSCPC | Forgot Password',
    },
    {
        path: 'changepassword',
        loadComponent: () =>
            import('./features/auth/components/changepassword/changepassword.component').then(
                (m) => m.ChangepasswordComponent
            ),
        title: 'TDSCPC | Change Password',
    },
    {
        path: 'passresetsuccessful',
        loadComponent: () =>
            import('./features/auth/components/passresetsuccessful/passresetsuccessful.component').then(
                (m) => m.PassresetsuccessfulComponent
            ),
        title: 'TDSCPC | Change Password',
    },
    {
        path: 'resetpasslinkexpired',
        loadComponent: () =>
            import('./features/auth/components/resetpasslinkexpired/resetpasslinkexpired.component').then(
                (m) => m.ResetpasslinkexpiredComponent
            ),
        title: 'TDSCPC | Reset Password',
    },
    {
        path: 'emailsendsuccessful',
        loadComponent: () =>
            import('./features/auth/components/emailsendsuccessful/emailsendsuccessful.component').then(
                (m) => m.EmailsendsuccessfulComponent
            ),
        title: 'TDSCPC | Email Send Successfully',
    },


    {
        path: 'aboutUs',
        loadComponent: () =>
            import('./features/auth/components/about-us/about-us.component').then((m) => m.AboutUsComponent),
        title: 'About us',
        data: { breadcrumb: 'About us' },
    },

    {
        path: 'privacypolicy',
        loadComponent: () =>
            import('./features/auth/components/privacy-policy/privacy-policy.component').then((m) => m.PrivacyPolicyComponent),
        title: 'Privacy/Policy',
        data: { breadcrumb: 'Privacy/Policy' },
    },

    {
        path: 'termsofuse',
        loadComponent: () =>
            import('./features/auth/components/terms-services/terms-services.component').then((m) => m.TermsServicesComponent),
        title: 'Terms/Conditions',
        data: { breadcrumb: 'Terms/Conditions' },
    },
    {
        path: 'welcomeclient',
        loadComponent: () =>
            import('./layout/welcomeclient/welcomeclient.component').then((m) => m.WelcomeclientComponent),
        title: 'Terms/Conditions',
        data: { breadcrumb: 'Terms/Conditions' },
    },





    {
        path: 'home',
        loadComponent: () =>
            import('./../app/layout/homepage/homepage.component').then((m) => m.HomepageComponent),
        title: 'TDSCPC | Home',
        data: { breadcrumb: 'Welcome' },
        canActivate: [AuthGuard],


        children: [
            {
                path: 'dashboard',
                loadComponent: () =>
                    import('../app/layout/dashboard/dashboard/dashboard.component').then(
                        (m) => m.DashboardComponent
                    ),
                title: 'TDSCPC | Dashboard',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },

            {
                path: 'trans',
                loadComponent: () =>
                    import('../app/features/transaction/transaction.component').then(
                        (m) => m.TransactionComponent
                    ),
                title: 'TDSCPC |  Transactions',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },
            {
                path: '15gh',
                loadComponent: () =>
                    import('../app/fifteenghmodule/fifteengh/fifteengh.component').then(
                        (m) => m.FifteenghComponent
                    ),
                title: 'TDSCPC |  15GH',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },


            {
                path: 'returns',
                loadComponent: () =>
                    import('../app/features/dataimport/dataimport.component').then(
                        (m) => m.DataimportComponent
                    ),
                title: 'TDSCPC |  Returns',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],
            },

            {
                path: 'challans',
                loadComponent: () =>
                    import('../app/features/challans/challans.component').then(
                        (m) => m.ChallansComponent
                    ),
                title: 'TDSCPC |  Challans',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },
             {
                path: 'challan_trace',
                loadComponent: () =>
                    import('../app/features/traceschallan/traceschallan.component').then(
                        (m) => m.TraceschallanComponent
                    ),
                title: 'TDSCPC |  Challans traces',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },
            {
                path: 'deductee',
                loadComponent: () =>
                    import('../app/features/deductee/deductee.component').then(
                        (m) => m.DeducteeComponent
                    ),
                title: 'TDSCPC |  Challans',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],

            },

            {
                path: 'traces',
                loadComponent: () =>
                    import('../app/features/traces/traces.component').then(
                        (m) => m.TracesComponent
                    ),
                title: 'TDSCPC |  Traces Connect',
                data: { breadcrumb: 'Traces' },
                canActivate: [AuthGuard],

                //     children: [
                //     {   
                //         path: 'defaultsummery',
                //         loadComponent: () =>
                //             import('../app/features/traces/defaultsummery/defaultsummery.component').then(
                //                 (m) => m.DefaultsummeryComponent
                //             ),
                //         title: 'TDSCPC | Default Summery',
                //         data: { breadcrumb: 'Default Summery' },    
                //     }
                // ]
            },
            {
                path: 'defaultsummery',
                loadComponent: () =>
                    import('../app/features/traces/defaultsummery/defaultsummery.component').then(
                        (m) => m.DefaultsummeryComponent
                    ),
                title: 'TDSCPC | Default Summery',
                data: { breadcrumb: 'Default Summery' },
            },
            {
                path: 'salary-details',
                loadComponent: () =>
                    import('../app/features/salary-details/salary-details.component').then(
                        (m) => m.SalaryDetailsComponent
                    ),
                title: 'TDSCPC |  Salary Details',
                data: { breadcrumb: 'Salary Details' },
                canActivate: [AuthGuard],

            },

            {
                path: 'reports',
                loadComponent: () =>
                    import('../app/features/reports&download/reports/reports.component').then(
                        (m) => m.ReportsComponent
                    ),
                title: 'TDSCPC |  Reports',
                data: { breadcrumb: 'Traces' },
                canActivate: [AuthGuard],

            },

            {
                path: 'request',
                loadComponent: () => import('../app/features/request/request.component').then((m) => m.RequestComponent),
                title: 'TDSCPC | Request',
                data: { breadcrumb: 'Request' },
                canActivate: [AuthGuard],
            },

            {
                path: 'justification',
                loadComponent: () => import('../app/currectionModule/currectionmodule/justification/justification.component').then((m) => m.JustificationComponent),
                title: 'TDSCPC | Justification',
                data: { breadcrumb: 'Justification' },
                canActivate: [AuthGuard],
            },

            {
                path: 'ldctraces',
                loadComponent: () => import('../app/currectionModule/currectionmodule/ldctraces/ldctraces.component').then((m) => m.LdctracesComponent),
                title: 'TDSCPC | LDC Traces',
                data: { breadcrumb: 'ldc Traces' },
                canActivate: [AuthGuard],
            },
            {
                path: 'default',
                loadComponent: () =>
                    import('../app/currectionModule/currectionmodule/default/default.component').then(
                        (m) => m.DefaultComponent
                    ),
                title: 'TDSCPC |  Default',
                data: { breadcrumb: 'Default' },
                canActivate: [AuthGuard],

            },
            {
                path: 'consotraces',
                loadComponent: () =>
                    import('../app/currectionModule/currectionmodule/consotraces/consotraces.component').then(
                        (m) => m.ConsotracesComponent
                    ),
                title: 'TDSCPC |  Conso Traces',
                data: { breadcrumb: 'Conso Traces' },
                canActivate: [AuthGuard],

            },
            {
                path: 'ldc',
                loadComponent: () =>
                    import('../app/features/ldc/ldc.component').then(
                        (m) => m.LdcComponent
                    ),
                title: 'TDSCPC |  Lower Deduction Certificate',
                data: { breadcrumb: 'Traces' },
                canActivate: [AuthGuard],

            },

            {
                path: 'setting',
                loadComponent: () =>
                    import('./layout/settings/settings.component').then((m) => m.SettingsComponent),
                title: 'TDSCPC | Business Settings',
                data: { breadcrumb: '' },
                canActivate: [AuthGuard],


                children: [
                    {
                        path: '',
                        pathMatch: 'full',
                        redirectTo: 'profile'   // 👈 default child
                    },
                    {
                        path: 'profile',
                        loadComponent: () =>
                            import('./layout/settings/profile/profile.component').then(
                                (m) => m.ProfileComponent
                            ),
                        title: 'TDSCPC | Profile',
                        data: { breadcrumb: 'Profile' },

                    },

                    {
                        path: 'security',
                        loadComponent: () =>
                            import('./layout/settings/security/security.component').then(
                                (m) => m.SecurityComponent
                            ),
                        title: 'TDSCPC | Security',
                        data: { breadcrumb: 'Security' },

                    },
                    {
                        path: 'notifications',
                        loadComponent: () =>
                            import('./layout/settings/notifications/notifications.component').then(
                                (m) => m.NotificationsComponent
                            ),
                        title: 'TDSCPC | Notification',
                        data: { breadcrumb: 'Notification' },

                    },
                    {
                        path: 'alluser',
                        loadComponent: () =>
                            import('./layout/settings/allusers/allusers.component').then(
                                (m) => m.AllusersComponent
                            ),
                        title: 'TDSCPC | Alluser',
                        data: { breadcrumb: 'Alluser' },

                    },

                    {
                        path: 'roles',
                        loadComponent: () =>
                            import('./layout/settings/rolepermission/rolepermission.component').then(
                                (m) => m.RolepermissionComponent
                            ),
                        title: 'TDSCPC | Roles & Permission',
                        data: { breadcrumb: 'Roles' },

                    },
                    {
                        path: 'clients',
                        loadComponent: () =>
                            import('./layout/settings/clients/clients.component').then(
                                (m) => m.ClientsComponent
                            ),
                        title: 'TDSCPC | All Clients',
                        data: { breadcrumb: 'Clients' },

                    },

                    {
                        path: 'useractivitylog',
                        loadComponent: () =>
                            import('./layout/settings/useractivity/useractivity.component').then(
                                (m) => m.UseractivityComponent
                            ),
                        title: 'TDSCPC | User Activity',
                        data: { breadcrumb: 'Roles' },

                    },

                    {
                        path: 'subscription',
                        loadComponent: () =>
                            import('./layout/settings/subscription/subscription.component').then(
                                (m) => m.SubscriptionComponent
                            ),
                        title: 'TDSCPC | Subscription',
                        data: { breadcrumb: 'Roles' },

                    },


                ]

            }
            //


        ]

    },

    {
        path: 'clients',
        loadComponent: () =>
            import('./../app/layout/welcomeclient/welcomeclient.component').then((m) => m.WelcomeclientComponent),
        title: 'TDSCPC | All Clients',
        data: { breadcrumb: 'Welcome' },
        // canActivate: [AuthGuard],
    }
    ,

    {
        path: 'clientslist',
        loadComponent: () =>
            import('./../app/layout/welcomeclient/allclients/allclients.component').then((m) => m.AllclientsComponent),
        title: 'TDSCPC | All Clients',
        data: { breadcrumb: 'Welcome' },
        // canActivate: [AuthGuard],
    }


];

