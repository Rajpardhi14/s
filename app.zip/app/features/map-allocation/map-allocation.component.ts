import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MapChalAllocationComponent } from './map-chal-allocation/map-chal-allocation.component';
import { MapTranAllocationComponent } from './map-tran-allocation/map-tran-allocation.component';
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
import { ToastService } from '../../core/services/toaster/toast.service';
import { RefreshdataService } from '../../core/services/refreshdata/refreshdata.service';
import { AlertpoupComponent } from '../../shared/components/alertpoup/alertpoup.component';
import { ButtoneventlisnerDirective } from '../../core/services/session/timer-session/buttoneventlisner.directive';
@Component({
  selector: 'app-map-allocation',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MapChalAllocationComponent,
    MapTranAllocationComponent,
    AlertpoupComponent,
    ButtoneventlisnerDirective
  ],
  templateUrl: './map-allocation.component.html',
  styleUrl: './map-allocation.component.css',
})
export class MapAllocationComponent {
  @Input() open: boolean = false;
  @Output() closeDrawer = new EventEmitter<void>();
  @Input() challanHeaders: any[] = [];
  @Input() challanTableBody: any[] = [];
  @Input() tranHeaders: any[] = [];
  @Input() tranTableBody: any[] = [];
  @Input() allocationFlag: any;
  @Input() challanRowselectedId: any;

  @Input() clientCodee: any;
  // @Input() Client_Code: any;
  TranselectedCount = 0;
  ChallanselectedCount = 0;
  challanBalenceAmt: any;
  tranTotalTdsAmt: any;
  challanselectedRowData: { rowid_seq: any; to_be_allocated_amt: any } | null =
    null;
  // TranselectedRowData: { rowid_seq: any } | null = null;
  TranselectedRowData: { rowid_seq: any }[] = [];

  dynamicUserData: any;
  isSubmitting: boolean = false;
  isSubmittingUpdate = false;
    isSubmittingGrp: boolean = false;
  isSubmittingUpdateGrp = false;
  errorMessage: string = '';
  UserData: any;
currentViewMode: string = 'list';
  isChallanSelected: boolean = false;
  showExceedPopup: boolean = false;
blockTransactionSelection: boolean = false;

  constructor(
    private userlocaldataService: UserdataService,
    private apiservice: ApiserviceService,
    private toastService: ToastService,
        private refreshdata: RefreshdataService,
  ) {}

  ngOnChanges() {

    // console.log(this.tranTableBody,'cvfd');
     console.log(this.clientCodee,'challan');
  }

  ngOnInit(): void {
    this.UserData = this.userlocaldataService.getLocalUserData();
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData();

    // For non-dataAllocationFlag flows, show transaction table by default
    if (this.allocationFlag !== 'dataAllocationFlag') {
      this.isChallanSelected = true;
    }
   
  }

  onSelectedCountChange(trancount: number) {
    this.TranselectedCount = trancount;
  }
  onChallanSelectedCountChange(challancount: number) {
    this.ChallanselectedCount = challancount;
  }

  onChallanBalanceAmount(challanBalenceAmt: number) {
    // You can store it in a variable or use it as needed
    this.challanBalenceAmt = challanBalenceAmt;
  }

  // onSelectedTranTotalTds(tranTotalTdsAmt: number) {
  //   //  console.log('Received balance amount from child:', tranTotalTdsAmt);
  //   this.tranTotalTdsAmt = tranTotalTdsAmt;
  // }
// onSelectedTranTotalTds(totalTds: number) {
//   this.tranTotalTdsAmt = totalTds;

//   if (this.tranTotalTdsAmt > this.challanBalenceAmt) {
//     // Show popup and block selection
//     this.blockTransactionSelection = true;
//     this.showExceedPopup = true;
//   } else {
//     // Allow selection again
//     this.blockTransactionSelection = false;
//   }
// }


onSelectedTranTotalTds(totalTds: number) {
  this.tranTotalTdsAmt = totalTds;

  if (this.tranTotalTdsAmt > this.challanBalenceAmt) {
    // Block further selections and show popup
    this.blockTransactionSelection = true;
    this.showExceedPopup = true;
  } else {
    this.blockTransactionSelection = false;
  }
}

// onPopupClose() {
//   this.showExceedPopup = false;
//   this.blockTransactionSelection = false;
// }




  close() {
    this.closeDrawer.emit();
  }
onPopupClose() {
  this.showExceedPopup = false;
  this.blockTransactionSelection = false;
}

  handleRowSelection(event: { rowid_seq: any; to_be_allocated_amt: any }) {
    // console.log('Single row data:', event.rowid_seq, event.to_be_allocated_amt);
    this.challanselectedRowData = event; // save for onsubmit()
    // Only apply conditional logic for Data Allocation flow
    if (this.allocationFlag === 'dataAllocationFlag') {
      this.isChallanSelected = !!event.rowid_seq; // Show transaction table when challan is selected
    }
  }
  // handleTranRowSelection(event:{rowid_seq:any}){
  // console.log('Single Tran row data:', event.rowid_seq);
  //   this.TranselectedRowData = event;
  // }

  handleTranRowSelection(event: { rowid_seq: any } | { rowid_seq: any }[]) {
    if (Array.isArray(event)) {
      // multi-select from child
      this.TranselectedRowData = event;
    } else {
      // single select
      this.TranselectedRowData = [event];
    }
    if (this.tranTotalTdsAmt > this.challanBalenceAmt) {
  this.showExceedPopup = true;
  this.blockTransactionSelection = true;
} else {
  this.showExceedPopup = false;
  this.blockTransactionSelection = false;
}

    // console.log('Selected Tran rows:', this.TranselectedRowData);
  }
fullSelectedRowsTran: any[] = [];
handleTranRowSelectionFull(fullRows: any[]) {
  this.fullSelectedRowsTran = fullRows; // store the full row objects
  console.log('Full rows:', this.fullSelectedRowsTran);
}




  iudType: any;
  filterValue: any;
  tiudfilterClause: any;

  onsubmit() {
    if (this.tranSelectedValue === 'A') {
      this.iudType = 'SELECTED-UN-ALLOC';
      this.filterValue = 'and a.tds_challan_rowid_seq is not null';
      this.tiudfilterClause = [
        {
          filter_col_field: 'tds_challan_rowid_seq',
          filter_col_depend_operator: '=',
          filter_col_value: this.challanselectedRowData?.rowid_seq,
          filter_col_field_alias: 'a.',
        },
        {
          filter_col_field: 'deductee_alloc_status',
          filter_col_depend_operator: 'wc',
          filter_col_value: this.filterValue,
          filter_col_field_alias: 'a.',
        },
      ];
    } else {
      this.iudType = 'SELECTED-ALLOC';
      this.filterValue = 'and a.tds_challan_rowid_seq is null';

      this.tiudfilterClause = [
        {
          filter_col_field: 'deductee_alloc_status',
          filter_col_depend_operator: 'wc',
          filter_col_value: this.filterValue,
          filter_col_field_alias: 'a.',
        },
      ];
    }

    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_is_pen_flag: '',
      a_login_type: 'login_id',
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: 'R',
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: '0',
      a_process_seqno: '',
      a_alloc_group_str: '',
      a_iud_type: this.iudType,
      a_proc_type: 'get_tiud_challan_alloc_line',
      a_process_status_code: '',
      // a_db_total_records: '1000',
      // a_pagination_count: '0',
      tds_challan_tran_load: [
        {
          rowid_seq: this.challanselectedRowData?.rowid_seq,
          to_be_allocated_amt: this.challanselectedRowData?.to_be_allocated_amt,
        },
      ],

      tds_tran_load: this.TranselectedRowData.map((row) => ({
        rowid_seq: row.rowid_seq,
      })),

      a_filter_clause: this.tiudfilterClause,
    };

    this.submitRequest(
      requestBody,
      'Challans  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
    this.onRebuild();
  }
  //subbmit
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiservice
      .createData('/Transaction/get_tiud_challan_alloc_line', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.close();
            this.refreshdata.trigerRefresh('Challans');
                 this.refreshdata.trigerRefresh('Transaction');

          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }


allocGroupValue: string = ""; // store the emitted value here

onAllocGrpSearch(value: string) {
  console.log('Received from child:', value);
  this.allocGroupValue = value; // ✅ save emitted value
}



//MERGE GROUP ON SUBMIT
    onsubmitGrp() {
      
     if(this.tranSelectedValue ==='A'){
      this.iudType = 'SELECTED-UN-ALLOC';
      this.filterValue = 'and a.tds_challan_rowid_seq is not null';
           this.tiudfilterClause = [
        {
            filter_col_field: "tds_challan_rowid_seq",
            filter_col_depend_operator: "=",
            filter_col_value: this.challanselectedRowData?.rowid_seq,
            filter_col_field_alias: "a."
        },
        {
            filter_col_field: "deductee_alloc_status",
            filter_col_depend_operator: "wc",
            filter_col_value:   this.filterValue ,
            filter_col_field_alias: "a."
        }
    ]
     } 
     else{
       this.iudType = 'SELECTED-ALLOC';
        this.filterValue = 'and a.tds_challan_rowid_seq is null';
    
          this.tiudfilterClause = [
        {
            filter_col_field: "deductee_alloc_status",
            filter_col_depend_operator: "wc",
            filter_col_value:   this.filterValue ,
            filter_col_field_alias: "a."
        }
    ]
     }
  
    const requestBody = {
        a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
        a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
       a_first_level_client_code: this.dynamicUserData.first_level_client_code,
       a_client_code_level: this.dynamicUserData.client_code_level,
       a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_process_seqno: '',
      a_alloc_group_str: this.allocGroupValue,
      a_iud_type:this.iudType,
      a_proc_type: 'get_tiud_challan_alloc_group',
      a_process_status_code: '',
      // a_db_total_records: '1000',
      // a_pagination_count: '0',
      tds_challan_tran_load: [
        {
        rowid_seq: this.challanselectedRowData?.rowid_seq,
        to_be_allocated_amt: this.challanselectedRowData?.to_be_allocated_amt,
      }
    ],

    tds_tran_load: this.fullSelectedRowsTran,

          a_filter_clause:  this.tiudfilterClause

    };

    this.submitRequestGrp(
      requestBody,
      'Challans  Record Created Successfully!',
      (value) => (this.isSubmittingUpdateGrp = value)
    
    );
      this.onRebuild();
  }
  //subbmit
  submitRequestGrp(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmittingGrp = true;
    this.apiservice
      .createData('/Transaction/get_tiud_challan_alloc_group', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmittingGrp = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
             this.close();
           this.refreshdata.trigerRefresh('Challans');
           this.refreshdata.trigerRefresh('Transaction');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                 
                
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmittingGrp = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmittingGrp = false;
        },
      });
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }
  tranSelectedValue: any;

  onTranTabChanged(selectedValue: string) {
    this.tranSelectedValue = selectedValue;
    // do whatever you need with transelectedTabValue
  }



onTranViewModeChange(mode: string): void {
  console.log('Child view mode:', mode);
  this.currentViewMode = mode; // 👈 store it

  if (mode === 'grid') {
    this.callGridApi();
  } else {
    this.callListApi();
  }
}


callGridApi() {
  console.log('Calling Grid API...');
  // your grid API logic
}

callListApi() {
  console.log('Calling List API...');
  // your list API logic
}

    onRebuild() { 
    const requestBody = {
        a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
        a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
       a_first_level_client_code: this.dynamicUserData.first_level_client_code,
       a_client_code_level: this.dynamicUserData.client_code_level,
       a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_process_seqno: '',
      a_alloc_group_str: "",
      a_iud_type:"REBUILD",
      a_proc_type: 'get_tiud_challan_alloc_rebuild',
      a_process_status_code: '',
      // a_db_total_records: '1000',
      // a_pagination_count: '0',
      tds_challan_tran_load: [
        {
        rowid_seq: this.challanselectedRowData?.rowid_seq,
        // to_be_allocated_amt: this.challanselectedRowData?.to_be_allocated_amt,
      }
    ],

    // tds_tran_load: this.fullSelectedRowsTran,

    //       a_filter_clause:  this.tiudfilterClause

    };

    this.submitRequestonRebuild(
      requestBody,
      'Challans  Record Created Successfully!',
      (value) => (this.isSubmittingUpdateGrp = value)
    );
  }
  //subbmit
  submitRequestonRebuild(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    // this.isSubmittingGrp = true;
    this.apiservice
      .createData('/Transaction/get_tiud_challan_alloc_rebuild', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          // this.isSubmittingGrp = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
             this.close();
          //  this.refreshdata.trigerRefresh('Challans');
          //  this.refreshdata.trigerRefresh('Transaction');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                 
                
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              // this.isSubmittingGrp = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          // this.isSubmittingGrp = false;
        },
      });
  }
selectedChallanDAValue: number | null = null;
// challanBalenceAmt: number | null = null;

handleSelectedRowChallanDA(selectedrowChallanDA: any) {
  console.log('Received from child:', selectedrowChallanDA);
  
  // ✅ Store challan row ID (if needed elsewhere)
  this.selectedChallanDAValue = selectedrowChallanDA?.rowid_seq;

  // ✅ Store challan balance amount (used for comparison in transaction child)
  this.challanBalenceAmt = selectedrowChallanDA?.challan_balance_amt ?? 0;

  console.log('Challan Balance Amt:', this.challanBalenceAmt);
}

onLimitExceeded() {
  this.showExceedPopup = true;
}


}
