import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MapAllocationComponent } from './map-allocation.component';

describe('MapAllocationComponent', () => {
  let component: MapAllocationComponent;
  let fixture: ComponentFixture<MapAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MapAllocationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MapAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
