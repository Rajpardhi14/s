import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { BasicFilterComponent } from '../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../shared/components/advance-filter/advance-filter.component';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { Subject, Subscription } from 'rxjs';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { capitalizeEachWord,formatValue } from '../../../shared/utils/passmatch';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';

// For clarity, define a type
interface ChallanRow {
  to_be_allocated_amt?: number;
  selected?: boolean;
  [key: string]: any;
}


@Component({
  selector: 'app-map-chal-allocation',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    BasicFilterComponent,
    AdvanceFilterComponent,
    FormsModule,
    ButtoneventlisnerDirective
  ],
  templateUrl: './map-chal-allocation.component.html',
  styleUrl: './map-chal-allocation.component.css'
})
export class MapChalAllocationComponent {
   @Output() challanbalanceAmountChange = new EventEmitter<number>();
     @Output() challanSelectedCountChange = new EventEmitter<number>();

 @Input() open: boolean = false;
  @Output() closeDrawer = new EventEmitter<void>();
  @Input() allocationFlag: any;
  @Input() challanHeaders: any[] = [];
   @Input() challanTableBody: any[] = [];
  @Output() selectedrowChallanDAChange = new EventEmitter<any>();
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;

  totalcount: any;
  userData: any;
  Math = Math;
  // Table data variable

  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = 'Yes';
  iudtype: string = 'p';
  dashboardType:string='ALLOC';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  isDeletePopupOpen = false;
  selectedIdsForDeletion: number = 0;
  isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  selectedRowDetails: any;
  myfilterfileds: any;
  values: any;

  headers:any;
  tableBody:any;
    paginatedList: any;

     ChaBalenceAmount:any;
  tds_amt:any;

  @Output() challanRowSelected = new EventEmitter<{
    rowid_seq: any;
    to_be_allocated_amt: any;
  }>();
    formatValue =formatValue;

    externalFilterTab  = [
          { value: 'All', label: 'All' },
    { value: 'O', label: 'Overbooked' },
    { value: 'PA', label: 'Partially allocated' },
    { value: 'U', label: 'Unallocated' },
    { value: 'A', label: 'Allocated' },

  ];
  
  capitalizeEachWord = capitalizeEachWord;


  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService
  ) {}

  ngOnChanges() {
    // console.log('Received headers:', this.headers);
  //   console.log('Received paginatedList:', this.paginatedList);
  //    if (this.paginatedList?.length) {
  //   this.ChaBalenceAmount = this.paginatedList[0].tds_amt; // first row's tds_amt
  // } else {
  //   this.ChaBalenceAmount = 0;
  // }

  // console.log('Balance amount:', this.ChaBalenceAmount);
  //  this.challanbalanceAmountChange.emit(this.ChaBalenceAmount);
  }


  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

      this.fetchFilter();

 if (this.externalFilterTab?.length) {
    const defaultTab = this.externalFilterTab.find(opt => opt.value == 'All');
    if (defaultTab) {
      this.activeFilterTab = defaultTab.value;

      // Only call if form exists
      if (this.filterForm) {
        this.selectedTabFilter('approved_status', defaultTab.value, defaultTab.label);
      }
    }
  }

if(this.allocationFlag !='challanFlag' || this.allocationFlag =='dataAllocationFlag'){
    this.fetchTable();
     console.log('called table from data allocatation');
}
else if(this.allocationFlag =='challanFlag')
{
  this.headers=this.challanHeaders;
  this.paginatedList = this.challanTableBody;

       if (this.paginatedList) {
    this.ChaBalenceAmount = this.paginatedList[0].tds_amt; 
           this.challanRowSelected.emit({
      rowid_seq:  this.paginatedList[0].rowid_seq,
      to_be_allocated_amt:  this.paginatedList[0].to_be_allocated_amt
    });
 
  } else {
    this.ChaBalenceAmount = 0;
  }
     this.challanbalanceAmountChange.emit(this.ChaBalenceAmount);
}

this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();
    // this.fetchFilter();
  }
  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }
  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_tds_challan_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage
    );

    this.apiService
      .getFilterData('/Transaction/get_gtfb_tds_challan_tran_load', sdata)
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error === '0') {
            this.basic_filter =
              response?.result?.get_gtfb_tds_challan_tran_load?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gtfb_tds_challan_tran_load?.[1]?.advance_filter;

            // this.advance_filter?.forEach((field: any) => {
            //   if (
            //     field.filter_col_external === 1 &&
            //     field.filter_col_type === 'filter-select'
            //   ) {
            //     const allOption = { value: 'ALL', label: 'All' };
            //     const exists = field.filter_col_depend_value?.some(
            //       (opt: any) => opt.value === 'ALL'
            //     );
            //     if (!exists) {
            //       field.filter_col_depend_value?.unshift(allOption);
            //     }
            //   }
            // });
            // //Find the first external filter-select field
            // const defaultField = this.advance_filter?.find(
            //   (field: any) =>
            //     field.filter_col_external === 1 &&
            //     field.filter_col_type === 'filter-select'
            // );
            // //Get the default option with value 'ALL'
            // const defaultOption = defaultField?.filter_col_depend_value?.find(
            //   (opt: any) => opt.value === 'ALL'
            // );
            // //Store default tab info
            // this.defaultTabFilter = defaultOption;
            // this.activeFilterTab = defaultOption?.value;
            //Initialize form and menu
            this.initializeForm();
            this.menuOptions = this.basic_filter?.map((filter: any) => ({
              label: filter.filter_col_prompt,
              field: filter.filter_col_field,
              operator: filter.filter_col_depend_operator,
              alias: filter.filter_col_field_alias,
              placeholder: filter.filter_col_placeholder,
            }));
            this.selectedOption = this.menuOptions?.[0];
          } else {
            this.errorMessage =
              response.result?.[0].a_proc_error_message ||
              'Please Check Endpoint';
            this.showError(this.errorMessage);
          }

          if (this.isFirstLoad) {
            this.isSkeletonshow = false;
            this.isFirstLoad = false;
          }
        },
        error: (error) => {
          console.error('Error user filter:', error);
          this.isSkeletonshow = false;
        },
      });
  }
  //#endregion

  newFilterclase(filterField: string, value: any) {
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    // this.filterClause = this.buildFilterClause();

    const selectedFilter = this.values.find(
      (v: any) => v.value === this.selectedValue
    );
    const condition = selectedFilter ? selectedFilter.condition : 'and 1=1';

    const newFilterClause = [
      {
        filter_col_field: 'tds_limit_amt_bal',
        filter_col_depend_operator: 'wc',
        filter_col_value: condition,
        filter_col_field_alias: 'a.',
      },
    ];
    this.filterClause = newFilterClause;
  }

  // selectedTabFilter(filterField: string, value: any, label: any): void {

  //   this.selectedValue = value;
  //   this.myfilterfileds = filterField;
  //   this.selectedLabel = label;
  //   this.activeFilterTab = value;
  //   if (this.activeFilterTab !== value) {
  //     this.activeFilterTab = value;
  //   } else {
  //     this.activeFilterTab = '';
  //     setTimeout(() => {
  //       this.activeFilterTab = value;
  //     }, 100);
  //   }
  //   this.filterClause = this.newFilterclase(filterField, value);
  //   // this.fetchData();
  //   // this.fetchGrandTotal();
  // }

  selectedTabFilter(filterField: string, value: any, label: any): void {
  this.selectedValue = value;
  this.selectedLabel = label;
  this.activeFilterTab = value;

      // Only update form if it exists
  if (this.filterForm && this.filterForm.get(filterField)) {
    this.filterForm.get(filterField)?.setValue(value, { emitEvent: true });

  const control = this.filterForm.get(filterField);
  if (control) {
    control.setValue(value, { emitEvent: true });
  }

  // Uppercase normalization
  Object.keys(this.filterForm.controls).forEach((key) => {
    const ctrl = this.filterForm.get(key);
    if (ctrl && typeof ctrl.value === 'string') {
      ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
    }
  });
}

  // Build filter + refresh table
  this.filterClause = this.buildFilterClause();
  this.fetchTable();
}

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => {});
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toUpperCase();      
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
      this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchTable()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim().toUpperCase(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value?.toUpperCase() !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value.toUpperCase() !== basicValue) {
      this.searchTerm = control.value.toUpperCase();
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }



clearAllFilters() {
  this.searchTerm = '';
  this.offset = 0;
  this.currentPage = 1;
 
  // Check if user applied any filters different from defaults
  const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
    const control = this.filterForm.get(field.filter_col_field);
    const value = control?.value;
    const defaultVal = field._isDefaultValue ?? '';
    return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
  });
 
  if (this.advance_filter && Array.isArray(this.advance_filter)) {
    this.advance_filter.forEach((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      if (!control) return;
 
      const defaultVal = field._isDefaultValue ?? null;
 
      if (hasUserAppliedFilters) {
        // ✅ Keep default filters intact
        if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
          control.setValue(defaultVal);
        } else {
          control.setValue(''); // clear user-only filters
        }
      } else {
        // ✅ If no user filters were applied — reset to defaults, not empty
        if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
          control.setValue(defaultVal);
        } else {
          control.setValue('');
        }
      }
    });
  }
 
  // ✅ Rebuild filterClause including defaults
 
  this.filterClause = this.buildFilterClause();
  this.filtercount = this.getSelectedFilterCount();
 
  // 🚫 Don’t treat this as a full clear for fetchTable()
  this.fetchTable();
}


  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {
        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator;
        filterValue = controlValue.toString().trim();

      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    return filterClause;
  }



  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return [];
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    // this.fetchData();
    // this.fetchGrandTotal();
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    // this.fetchData();
    // this.fetchGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }

  // Remove all filter label values
  // clearAllFilters() {
  //   this.offset = 0;
  //   this.currentPage = 1;
  //   this.selectedFilters = [];
  //   this.filterClause = [];
  //   if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //     this.advance_filter.forEach((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);
  //       if (control) {
  //         control.setValue('');
  //       }
  //     });
  //   }
  //   this.filtercount = this.getSelectedFilterCount();
  //   // this.fetchData();
  //   // this.fetchGrandTotal();
  // }

  // user grand total
  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }
  close() {
    this.closeDrawer.emit();
  }

    fetchTable() {
    this.filterClause = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
    const values = Array.isArray(this.selectedValue)
      ? this.selectedValue
      : [this.selectedValue];

    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) {
        this.filterClause.push(nf);
      }
    });

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtdb_tds_challan_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
        dashboardType:this.dashboardType,
      }
    );
    this.apiService
      .getTableData('/Transaction/get_gtdb_tds_challan_tran_load', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_challan_tran_load;
          
            if (userData?.get_gtdb_tds_challan_tran_load_header) {
              this.headers =
                userData?.get_gtdb_tds_challan_tran_load_header?.map(
                  (header: any) => ({
                    ...header,
                    visible: header.display === 1,
                  })
                );
          
            }
            // this.allUsersData = userData || {};
            this.tableBody =
              userData?.get_gtdb_tds_challan_tran_load_detail || [];
            // this.buildMergeGroups()
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
             
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }


   // Check if all rows are selected
//   isAllSelected(): boolean {
//     return this.paginatedList?.every((row: any) => row.selected);
//   }

//   // Toggle all rows
//   toggleAllSelection(event: any) {
//     const checked = event.target.checked;
//     this.paginatedList.forEach((row: any) => (row.selected = checked));
//      this.emitChallanSelectedCount(); 
//   }
//   onRowSelectionChange() {
//   this.emitChallanSelectedCount(); // <-- Emit count when a single row is toggled
// }
//    // Get selected rows (optional helper)
//   getSelectedRows() {
//     return this.paginatedList.filter((row: any) => row.selected);
//   }

  // Emit selected count to parent
// emitChallanSelectedCount() {
//   const count = this.getSelectedRows().length;
//   this.challanSelectedCountChange.emit(count);
// }

 // ====== COMMON FUNCTIONS ======
//   isAllSelected(): boolean {
//     if (!this.paginatedList?.length) return false;
//     return this.paginatedList.every((row:any) => row.selected);
//   }

//   // Toggle all (transactionFlag only)
//   toggleAllSelection(event: any) {
//     if (this.allocationFlag !== 'transactionFlag') return;

//     const checked = event.target.checked;
//     this.paginatedList.forEach((row:any) => (row.selected = checked));
//     this.emitChallanSelectionSummary();
//   }

//   // Row selection change
//   onRowSelectionChange() {
//     if (this.allocationFlag === 'transactionFlag') {
//       this.emitChallanSelectionSummary();
//     }
//   }

// // Get selected rows
// getSelectedRows() {
//   return this.paginatedList.filter((row: any) => row.selected);
// }


//   // Emit summary → handle both flags
//   emitChallanSelectionSummary() {
//     if (this.allocationFlag === 'transactionFlag') {
//       const selectedRows = this.getSelectedRows();
//       const count = selectedRows.length;
//       console.log(count);
//       const totalBalance = selectedRows.reduce(
//         (sum: number, row: any) => sum + (row.to_be_allocated_amt ?? 0),
//         0
//       );

//       this.challanSelectedCountChange.emit(count);
//       this.challanbalanceAmountChange.emit(totalBalance);
//     }

//     if (this.allocationFlag === 'challanFlag') {
//       // Always 1 row in challan mode (disabled selection)
//       if (this.paginatedList.length) {
//         this.challanSelectedCountChange.emit(1);
//         console.log(this.challanSelectedCountChange);
//         this.challanbalanceAmountChange.emit(this.paginatedList[0].to_be_allocated_amt ?? 0);
//       } else {
//         this.challanSelectedCountChange.emit(0);
//         this.challanbalanceAmountChange.emit(0);
//       }
//     }
//   }

// Check if all rows are selected (only for transactionFlag)
isAllSelected(): boolean {
  if (!this.paginatedList?.length) return false;
  if (this.allocationFlag !== 'transactionFlag' ) return false;

  return this.paginatedList.every((row: any) => row.selected);
}

// Toggle all rows (only for transactionFlag)
toggleAllSelection(event: any) {
  if (this.allocationFlag !== 'transactionFlag') return;

  const checked = event.target.checked;
  this.paginatedList.forEach((row: any) => (row.selected = checked));
  this.emitChallanSelectionSummary();
}



// onRowSelectionChange(selectedRow: any) {
//   if (this.allocationFlag !== 'transactionFlag') return;

//   // Unselect all rows
//   this.paginatedList.forEach((row: any) => (row.selected = false));

//   // Select only the clicked row
//   selectedRow.selected = true;

//   this.emitChallanSelectionSummary();
// }

//   onRowSelectionChange(selectedRow: any) {
//     if (this.allocationFlag !== 'transactionFlag') return;

//     // Unselect all rows
//     this.paginatedList.forEach((row: any) => (row.selected = false));

//     // Select only the clicked row
//     selectedRow.selected = true;
//     this.challanRowSelected.emit({
//       rowid_seq: selectedRow.rowid_seq,
//       to_be_allocated_amt: selectedRow.to_be_allocated_amt, // 👈 replace with actual property
//     });
// console.log(selectedRow.rowid_seq, selectedRow.to_be_allocated_amt);
//     this.emitChallanSelectionSummary();
//   }
// selectedrowChallanDA:any;
onRowSelectionChange(selectedRow: any) {
 

 if (this.allocationFlag !== 'transactionFlag' && this.allocationFlag !== 'dataAllocationFlag') return;
//  this.selectedrowChallanDA=selectedRow;
 console.log(selectedRow,'!==');
  this.selectedrowChallanDAChange.emit(selectedRow);
  if (!selectedRow.selected) {
    // User unchecked the row
    this.challanRowSelected.emit(undefined);
    this.emitChallanSelectionSummary();
     console.log(selectedRow,'!selectedRow.selected');
    return;
    
  }

  // Unselect all other rows
  this.paginatedList.forEach((row: any) => {
    if (row !== selectedRow) row.selected = false;
  });

  // selectedRow.selected is already true from checkbox
  this.challanRowSelected.emit({
    rowid_seq: selectedRow.rowid_seq,
    to_be_allocated_amt: selectedRow.to_be_allocated_amt,
  });

  this.emitChallanSelectionSummary();
}


// still needed for transactionFlag mode
getSelectedRows(): ChallanRow[] {
  return this.paginatedList.filter((row: ChallanRow) => row.selected);
}
// Emit summary → handle both flags
// emitChallanSelectionSummary() {
//   if (this.allocationFlag === 'transactionFlag') {
//     // normal checkbox multi-select
//     const selectedRows = this.getSelectedRows();
//     const count = selectedRows.length;
//     const totalBalance = selectedRows.reduce(
//       (sum: number, row: ChallanRow) => sum + (row.to_be_allocated_amt ?? 0),
//       0
//     );

//     this.challanSelectedCountChange.emit(count);
//     this.challanbalanceAmountChange.emit(totalBalance);
//   } 
//   else if (this.allocationFlag === 'challanFlag') {
//     // always single row case → force count=1 and balance=first row
//     if (this.paginatedList && this.paginatedList.length > 0) {
//       this.challanSelectedCountChange.emit(1);
//       this.challanbalanceAmountChange.emit(this.paginatedList[0].to_be_allocated_amt ?? 0);
//     } else {
//       this.challanSelectedCountChange.emit(0);
//       this.challanbalanceAmountChange.emit(0);
//     }
//   }
// }

 emitChallanSelectionSummary() {
    if (this.allocationFlag === 'transactionFlag'  || this.allocationFlag==='dataAllocationFlag' ) {
      // normal checkbox multi-select
      const selectedRows = this.getSelectedRows();
      const count = selectedRows.length;
      const totalBalance = selectedRows.reduce(
        (sum: number, row: ChallanRow) => sum + (row.to_be_allocated_amt ?? 0),
        0
      );

      this.challanSelectedCountChange.emit(count);
      this.challanbalanceAmountChange.emit(totalBalance);
      
    } else if (this.allocationFlag === 'challanFlag') {
      // always single row case → force count=1 and balance=first row
      
      if (this.paginatedList && this.paginatedList.length > 0) {
        this.challanSelectedCountChange.emit(1);
        this.challanbalanceAmountChange.emit(
          this.paginatedList[0].to_be_allocated_amt ?? 0
        );

         this.challanRowSelected.emit({ rowid_seq: this.paginatedList[0]?.rowid_seq,
        to_be_allocated_amt: this.paginatedList[0]?.to_be_allocated_amt
      });
      } else {
        this.challanSelectedCountChange.emit(0);
        this.challanbalanceAmountChange.emit(0);
         this.challanRowSelected.emit({
        rowid_seq: this.paginatedList[0]?.rowid_seq,
        to_be_allocated_amt: this.paginatedList[0]?.to_be_allocated_amt
      });
      }
    }
  }
  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

    loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();
        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }
}
