import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MapChalAllocationComponent } from './map-chal-allocation.component';

describe('MapChalAllocationComponent', () => {
  let component: MapChalAllocationComponent;
  let fixture: ComponentFixture<MapChalAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MapChalAllocationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MapChalAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
