import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MapTranAllocationComponent } from './map-tran-allocation.component';

describe('MapTranAllocationComponent', () => {
  let component: MapTranAllocationComponent;
  let fixture: ComponentFixture<MapTranAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MapTranAllocationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MapTranAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
