import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Input,
  Output,
  SimpleChanges,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { skip, Subject, Subscription } from 'rxjs';

import { CommonModule } from '@angular/common';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { BasicFilterComponent } from '../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../shared/components/advance-filter/advance-filter.component';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { capitalizeEachWord,formatValue,formatDatesend } from '../../../shared/utils/passmatch';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
import { NodataComponent } from '../../../shared/components/nodata/nodata.component';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';
// For clarity, define a type
interface TranRow {
  total_tds_amt?: number;
  selected?: boolean;
  [key: string]: any;
}

@Component({
  selector: 'app-map-tran-allocation',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    BasicFilterComponent,
    AdvanceFilterComponent,
    FormsModule,
    ReactiveFormsModule,
    AlertpoupComponent,
    NodataComponent,
    OutSideClickDirective,
    ButtoneventlisnerDirective
    
  ],

  templateUrl: './map-tran-allocation.component.html',
  styleUrl: './map-tran-allocation.component.css',
})
export class MapTranAllocationComponent {
  @Input() challanRowselectedId: any;
  @Input() clientCodee: any;
  // @Output() transelectedCountChange = new EventEmitter<number>();
  // @Output() TranTotalTdsChange=new EventEmitter<number>();

  @Input() allocationFlag: any;
  @Input() tranHeaders: any;
  @Input() selectedChallanDAValue:any;
  @Output() allocGrpSearch = new EventEmitter<string>();
  // @Input() tranTableBody:any;
  @Input() blockSelection: boolean = false;
  @Input() challanBalenceAmt: number | null = null;
@Output() limitExceeded = new EventEmitter<void>();

  capatilizeEachword = capitalizeEachWord;
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];

  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  // paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  tableBodyGrp: any[] = [];
  headersGrp: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;

  // selectedMaster: string = 'USER_MASTER';
  activeFilterTab: string = 'U';
  defaultTabFilter: any;
  selectedValue: string = '';
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  dashboardType: string = 'ALLOC';
    client_code_flag: string = "challanClientCode"
  alloc_group_str: string = '';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  // totalTDSAmount:any;
    formatValue =formatValue;
  externalFilterTab = [
    { value: 'U', label: 'Unallocated' },
    { value: 'A', label: 'Allocated' },
  ];

  // @Output() transRowSelected = new EventEmitter<{
  //     rowid_seq: any;
  //   }>();
  activeIcon: string = 'list';
  dynamicUserData: any;
  @Output() tranViewModeChange: EventEmitter<string> =
    new EventEmitter<string>();

  @Input() tranTableBody: any[] = [];
  @Output() transRowSelected = new EventEmitter<any>();
  @Output() transelectedCountChange = new EventEmitter<number>();
  @Output() TranTotalTdsChange = new EventEmitter<number>();
  @Output() transRowSelectedFull = new EventEmitter<any[]>();

  paginatedList: any[] = [];
  TranselectedRowData: { rowid_seq: any }[] = [];
  totalTDSAmount: number = 0;
  searchGroup: boolean = false;
  capitalizeEachWord = capitalizeEachWord;
clientLevel:any;
  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService
  ) {
    this.localUserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData =
      this.userlocaldataService.getAllDynamicUserData() || {};
  }
  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);

  //     ngOnChanges(changes: SimpleChanges): void {
  // console.log(this.tranHeaders);
  // console.log(this.tranTableBody);
  //  console.log(this.allocationFlag);

  //     if(this.allocationFlag !='transactionFlag'){
  //       this.fetchTable();
  //     }
  //     else if(this.allocationFlag =='transactionFlag'){

  //       this.headers= this.tranHeaders;
  //       console.log( this.headers);
  //       this.paginatedList= this.tranTableBody;
  //        console.log( this.paginatedList);

  //     }
  //     }
ngOnChanges(changes: SimpleChanges): void {
     this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.clientLevel= this.dynaUserData.client_code_level;
if (changes['selectedChallanDAValue']) {
      console.log('Received ChallanDA from parent:', this.selectedChallanDAValue);

      // When challan selection changes in dataAllocationFlag, refresh the transaction table
      if (this.allocationFlag === 'dataAllocationFlag' && this.selectedChallanDAValue) {
        // Build filter and fetch table with updated challan selection
        this.filterClause = this.buildFilterClause();
        this.fetchTable();
       
      }
    }
          this.fetchGrandTotal()

}
  ngOnInit(): void {
 
    // console.log(this.dynaUserData.default_quarter_no);
    // console.log(this.dynaUserData.default_tds_type_code);
    //this.initializeForm();
    this.fetchFilter();

    this.getGroupLbList();
    if (this.externalFilterTab?.length) {
      const defaultTab = this.externalFilterTab.find(
        (opt) => opt.value === 'U'
      );
      if (defaultTab) {
        this.activeFilterTab = defaultTab.value;
console.log(this.selectedTabFilter);
        // Only call if form exists
        if (this.filterForm) {
          this.selectedTabFilter(
            'approved_status',
            defaultTab.value,
            defaultTab.label
          );
        }
      }
        console.log(this.clientCodee,'challan');
        console.log(this.challanRowselectedId);
    }

    //   if(this.allocationFlag !='transactionFlag'){
    // if (this.activeFilterTab === 'U') {
    //   // 👉 Fetch with filterClause if tab is U
    //   const filterClause = this.buildFilterClause();
    //   this.fetchTable(filterClause);
    // } else {
    //   // 👉 Normal fetch
    //   this.fetchTable();
    // }
    //   }
    //   else if(this.allocationFlag =='transactionFlag'){
    //     console.log(this.allocationFlag);
    //     this.headers= this.tranHeaders;
    //    this.paginatedList= this.tranTableBody;

    //      if (this.paginatedList) {
    //   // this.totalTDSAmount = this.paginatedList[0].tds_amt;
    //   //   this.transRowSelected.emit({
    //   //   rowid_seq:  this.paginatedList[0].rowid_seq
    //   // });
    //   const firstRow = this.paginatedList[0];

    //   this.TranselectedRowData = [{ rowid_seq: firstRow.rowid_seq }];

    //   this.transRowSelected.emit(this.TranselectedRowData); // emit array
    //   this.transelectedCountChange.emit(1);
    //   this.TranTotalTdsChange.emit(firstRow.tds_amt ?? 0);
    //   console.log('Child emits total TDS on init:', firstRow.tds_amt ?? 0);

    // } else {
    //   this.totalTDSAmount = 0;
    // }
    //    this.TranTotalTdsChange.emit(this.totalTDSAmount);

    //   }
    console.log(this.searchGroup);
    if ((this.allocationFlag == 'transactionFlag' || this.allocationFlag == 'dataAllocationFlag') ) {
      console.log(this.searchGroup);
      console.log('called by dataallocaction 1');
      this.headers = this.tranHeaders;
      this.paginatedList = this.tranTableBody;
      console.log(this.headers);
      console.log(this.paginatedList);

      if (this.paginatedList?.length) {
        const firstRow = this.paginatedList[0];
        console.log('called by dataallocaction 2');
        this.TranselectedRowData = [{ rowid_seq: firstRow.rowid_seq }];
        this.totalTDSAmount = firstRow.tds_amt ?? 0;

        this.transRowSelected.emit(this.TranselectedRowData); // emit array
        this.transelectedCountChange.emit(1);
        this.TranTotalTdsChange.emit(this.totalTDSAmount);
      } else {
        this.TranselectedRowData = [];
        this.totalTDSAmount = 0;
        this.transRowSelected.emit([]);
        this.transelectedCountChange.emit(0);
        this.TranTotalTdsChange.emit(0);
          console.log('called by dataallocaction 3');
      }
    }
    

    //  this.activeFilterTab = 'U';
    // this.externalFilterTab  = [
    //   { value: 'U', label: 'Unallocated' },
    //   { value: 'A', label: 'Allocated' },
    // ];
    //   this.activeFilterTab = this.externalFilterTab?.[0]?.value || '';
    // this.fetchFilter();

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    this.refreshSubscription = this.refreshdata.onRefresh('AllocTran').subscribe(() => {
      this.fetchTable();
      this.fetchGrandTotal();

    });

    
  }

  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  buildMergeGroups() {
    this.headers?.forEach((header) => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }

  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );
  }

  fetchTable(filterClause?: any[]): void {
    console.log('called');
    // 🔹 Use passed filterClause if available, else fallback to existing this.filterClause
    this.filterClause = Array.isArray(filterClause)
      ? [...filterClause]
      : Array.isArray(this.filterClause)
      ? [...this.filterClause]
      : [];

    const values = Array.isArray(this.selectedValue)
      ? this.selectedValue
      : [this.selectedValue];

    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) {
        this.filterClause.push(nf);
      }
    });

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtdb_tds_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
       client_code_flag: this.clientCodee,
       client_code:this.clientCodee,
        dashboardType: this.dashboardType,
      }
    );
    console.log(this.clientCodee);  
    this.apiService
      .getTableData('/Dashboard/get_gtdb_tds_tran_load', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_tran_load;

            if (userData?.get_gtdb_tds_tran_load_header) {
              this.headers = userData?.get_gtdb_tds_tran_load_header?.map(
                (header: any) => ({
                  ...header,
                  visible: header.display === 1,
                })
              );
            }
            // this.allUsersData = userData || {};
            this.mergeGroups = {};
            this.fieldToMergeGroup = {};
            this.tableBody = userData?.get_gtdb_tds_tran_load_detail || [];
            this.buildMergeGroups();
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();
        this.fetchGrandTotal()
        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_tds_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage
    );

    this.apiService
      .getFilterData('/Dashboard/get_gtfb_tds_tran_load', sdata)
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error === '0') {
            this.basic_filter =
              response?.result?.get_gtfb_tds_tran_load?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gtfb_tds_tran_load?.[1]?.advance_filter;

            // this.advance_filter?.forEach((field: any) => {
            //   if (
            //     field.filter_col_external === 1 &&
            //     field.filter_col_type === 'filter-select'
            //   ) {
            //     const allOption = { value: 'ALL', label: 'All' };
            //     const exists = field.filter_col_depend_value?.some(
            //       (opt: any) => opt.value === 'ALL'
            //     );
            //     if (!exists) {
            //       field.filter_col_depend_value?.unshift(allOption);
            //     }
            //   }
            // });
            // //Find the first external filter-select field
            // const defaultField = this.advance_filter?.find(
            //   (field: any) =>
            //     field.filter_col_external === 1 &&
            //     field.filter_col_type === 'filter-select'
            // );
            // //Get the default option with value 'ALL'
            // const defaultOption = defaultField?.filter_col_depend_value?.find(
            //   (opt: any) => opt.value === 'ALL'
            // );
            //Store default tab info
            // this.defaultTabFilter = defaultOption;
            // this.activeFilterTab = defaultOption?.value;
            // //Initialize form and menu
            this.initializeForm();

            if (this.allocationFlag !== 'transactionFlag' ) {
              if (this.activeFilterTab === 'U') {
                // Build the normal filterClause
                const filterClause = this.buildFilterClause();

                // Ensure the 'tds_challan_rowid_seq is null' filter is included
                const challanExists = filterClause.some(
                  (f) => f.filter_col_field === 'tds_challan_rowid_seq'
                );

                if (!challanExists) {
                  filterClause.push({
                    filter_col_field: 'tds_challan_rowid_seq',
                    filter_col_depend_operator: 'wc',
                    filter_col_value: 'and a.tds_challan_rowid_seq is null',
                    filter_col_field_alias: 'a.',
                  });
                }

                this.fetchTable(filterClause);
                 this.fetchGrandTotal()
              } else {
                // Normal fetch
                this.fetchTable();
                this.fetchGrandTotal()
              }
            }

            this.menuOptions = this.basic_filter?.map((filter: any) => ({
              label: filter.filter_col_prompt,
              field: filter.filter_col_field,
              operator: filter.filter_col_depend_operator,
              alias: filter.filter_col_field_alias,
              placeholder: filter.filter_col_placeholder,
            }));
            this.selectedOption = this.menuOptions?.[0];
          } else {
            this.errorMessage =
              response.result?.[0].a_proc_error_message ||
              'Please Check Endpoint';
            this.showError(this.errorMessage);
          }

          if (this.isFirstLoad) {
            this.isSkeletonshow = false;
            this.isFirstLoad = false;
          }
        },
        error: (error) => {
          console.error('Error user filter:', error);
          this.isSkeletonshow = false;
        },
      });
  }
  //#endregion
  @Output() transelectedTabValue = new EventEmitter<string>();

  // selectedTabFilter(filterField: string, value: any, label: any): void {
  //   this.selectedValue = value;
  //   this.selectedLabel = label;
  //   this.activeFilterTab = value;

  //   // ✅ Emit to parent
  //   this.transelectedTabValue.emit(this.selectedValue);

  //   // Only update form if it exists
  //   if (this.filterForm && this.filterForm.get(filterField)) {
  //     this.filterForm.get(filterField)?.setValue(value, { emitEvent: true });

  //     const control = this.filterForm.get(filterField);
  //     if (control) {
  //       control.setValue(value, { emitEvent: true });
  //     }

  //     // Uppercase normalization
  //     Object.keys(this.filterForm.controls).forEach((key) => {
  //       const ctrl = this.filterForm.get(key);
  //       if (ctrl && typeof ctrl.value === 'string') {
  //         ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
  //       }
  //     });
  //   }

  //   // Build filter + refresh table
  //   this.filterClause = this.buildFilterClause();
  //   this.fetchTable();
  //   this.fetchGrandTotal()
  // }

selectedTabFilter(filterField: string, value: any, label: any): void {
  // 🧹 Step 1: Reset all selected rows & checkboxes
  this.TranselectedRowData = [];
  this.paginatedList?.forEach((row: any) => (row.selected = false));

  // 🧹 Step 2: Reset totals & emit cleared selection to parent
  this.transRowSelected.emit([]);
  this.transelectedCountChange.emit(0);
  this.TranTotalTdsChange.emit(0);

  // 🧹 Step 3 (optional): Uncheck Select All (if you have one)
  // this.isAllSelected = false;

  // ✅ Continue your existing logic
  this.selectedValue = value;
  this.selectedLabel = label;
  this.activeFilterTab = value;

  // ✅ Emit to parent
  this.transelectedTabValue.emit(this.selectedValue);

  // ✅ Update form if exists
  if (this.filterForm && this.filterForm.get(filterField)) {
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(value, { emitEvent: true });
    }

    // Uppercase normalization
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
  }

  // ✅ Refresh data
  this.filterClause = this.buildFilterClause();
  if(this.searchGroup==true && this.activeIcon == 'grid'){
console.log(this.searchGroup,'serach grp');
this.groupSearch()
  }else{
  this.fetchTable();
  this.fetchGrandTotal();
  }

}



  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => {});
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toUpperCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
            this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchTable(),, this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }

private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim().toUpperCase(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value?.toUpperCase() !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value.toUpperCase() !== basicValue) {
      this.searchTerm = control.value.toUpperCase();
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }



clearAllFilters() {
  this.searchTerm = '';
  this.offset = 0;
  this.currentPage = 1;
 
  // Check if user applied any filters different from defaults
  const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
    const control = this.filterForm.get(field.filter_col_field);
    const value = control?.value;
    const defaultVal = field._isDefaultValue ?? '';
    return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
  });
 
  if (this.advance_filter && Array.isArray(this.advance_filter)) {
    this.advance_filter.forEach((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      if (!control) return;
 
      const defaultVal = field._isDefaultValue ?? null;
 
      if (hasUserAppliedFilters) {
        // ✅ Keep default filters intact
        if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
          control.setValue(defaultVal);
        } else {
          control.setValue(''); // clear user-only filters
        }
      } else {
        // ✅ If no user filters were applied — reset to defaults, not empty
        if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
          control.setValue(defaultVal);
        } else {
          control.setValue('');
        }
      }
    });
  }
 
  // ✅ Rebuild filterClause including defaults
  this.filterClause = this.buildFilterClause();
  this.filtercount = this.getSelectedFilterCount();
 
  // 🚫 Don’t treat this as a full clear for fetchTable()
  this.fetchTable();
  this.fetchGrandTotal();
}


  private buildFilterClause(): any[] {
    if (!this.filterForm) {
      console.warn('⚠️ filterForm is not initialized yet.');
      return [];
    }

    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (!filterConfig) return;

      // 🔹 Special override when selectedValue is 'A'
      if (this.selectedValue === 'A' && key === 'tds_challan_rowid_seq') {
        // Use selectedChallanDAValue for dataAllocationFlag, otherwise use challanRowselectedId
        const challanId = this.allocationFlag === 'dataAllocationFlag'
          ? this.selectedChallanDAValue
          : this.challanRowselectedId;

        filterClause.push({
          filter_col_field: 'tds_challan_rowid_seq',
          filter_col_depend_operator: '=',
          filter_col_value: challanId,
          filter_col_field_alias: filterConfig.filter_col_field_alias,
        });
      } else if (
        this.selectedValue === 'U' &&
        key === 'tds_challan_rowid_seq'
      ) {
        filterClause.push({
          filter_col_field: 'tds_challan_rowid_seq',
          filter_col_depend_operator: 'wc',
          filter_col_value: `and a.tds_challan_rowid_seq is null`,
          filter_col_field_alias: filterConfig.filter_col_field_alias,
        });
      }
      // 🔹 Normal filter logic
      else if (controlValue && controlValue !== 'ALL') {
        filterClause.push({
          filter_col_field: filterConfig.filter_col_field,
          filter_col_depend_operator: filterConfig.filter_col_depend_operator,
          filter_col_value: controlValue.toString().trim().toUpperCase(),
          filter_col_field_alias: filterConfig.filter_col_field_alias,
        });
      }
    });

    // 🔹 Search filter
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
 const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return []; // If form is not submitted, return an empty list
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal()
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal()
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }

  // user grand total
  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }


  private fetchGrandTotal(): void {
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];

    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];

    // Always rebuild final filterClause fresh:
    const finalFilterClause = [
      ...newFilterClause,
      ...userFilters.filter(
        (uf: any) =>
          !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
      ),
    ];

    const sdata = this.apiService.generateSData(
      'get_gtdg_tds_tran_load',
      this.localUserData,
      finalFilterClause,
      // this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
          {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
       client_code_flag: this.clientCodee,
       client_code:this.clientCodee,
        dashboardType: this.dashboardType,
      }
    );

    this.apiService.getGrandTotal('/Dashboard/get_gtdg_tds_tran_load', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          // Success case
          this.usergrandtotal =
            response?.result?.get_gtdg_tds_tran_load?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        // console.error('Error fetching vendor data:', error);
        this.showError('Something Went Wrong');
      },
    });
  }



  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }
  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  getSelectedRows(): TranRow[] {
    return this.paginatedList.filter((row: TranRow) => row.selected);
  }

  isRowSelected(row: any): boolean {
    return this.TranselectedRowData.some((r) => r.rowid_seq === row.rowid_seq);
  }

  // toggleAllSelection(event: any) {
  //   if (this.allocationFlag === 'transactionFlag') return; // ignore

  //   const checked = event.target.checked;
  //   this.paginatedList.forEach((row: any) => (row.selected = checked));
  //   this.updateMultiSelection();
  // }
toggleAllSelection(event: any) {
  if (this.allocationFlag === 'transactionFlag') return; // ignore

  const checked = event.target.checked;

  if (checked) {
    // ✅ Calculate total TDS if all rows selected
    const totalTds = this.paginatedList.reduce(
      (sum, row) => sum + (row.tds_amt ?? 0),
      0
    );

    // 🚫 If total exceeds challan balance → show popup & revert checkbox
    if (this.challanBalenceAmt && totalTds > this.challanBalenceAmt) {
      console.warn('⚠️ Select All exceeds challan balance — not allowed');

      // 🔁 Revert checkbox immediately
      setTimeout(() => {
        event.target.checked = false;
      }, 0);

      // 🔥 Emit popup event to parent
      this.limitExceeded.emit();

      return;
    }

    // ✅ Within limit → mark all as selected
    this.paginatedList.forEach((row: any) => (row.selected = true));
  } else {
    // ✅ Uncheck all
    this.paginatedList.forEach((row: any) => (row.selected = false));
  }

  // ✅ Update selected rows in parent
  this.updateMultiSelection();
}
  isAllSelected(): boolean {
    if (!this.paginatedList || this.paginatedList.length === 0) return false;
    return this.paginatedList.every((row: any) => row.selected);
  }

  // updateSelection(row: any) {
  //     if (this.blockSelection) {
  //   // Prevent selection when parent blocks it
  //   // return;
  // }
  //   if (this.allocationFlag === 'transactionFlag') {
  //     // Single-select → always first row
  //     const firstRow = this.paginatedList[0];
  //     this.TranselectedRowData = [{ rowid_seq: firstRow.rowid_seq }];
  //   } else {
  //     // Multi-select → toggle one row
  //     const exists = this.TranselectedRowData.find(
  //       (r) => r.rowid_seq === row.rowid_seq
  //     );
  //     if (exists) {
  //       this.TranselectedRowData = this.TranselectedRowData.filter(
  //         (r) => r.rowid_seq !== row.rowid_seq
  //       );
  //     } else {
  //       this.TranselectedRowData.push({ rowid_seq: row.rowid_seq });
  //     }
  //   }

  //   this.emitSelection();
  // }

  // emitSelection() {
  //   this.transRowSelected.emit(this.TranselectedRowData);
  //   this.transelectedCountChange.emit(this.TranselectedRowData.length);

  //   const totalTDS = this.TranselectedRowData.reduce((sum, selected) => {
  //     const r = this.paginatedList.find(p => p.rowid_seq === selected.rowid_seq);
  //     return sum + (r?.tds_amt ?? 0);
  //   }, 0);

  //   this.TranTotalTdsChange.emit(totalTDS);
  // }





// updateSelection(row: any) {
//   // 🔒 If blocking is active, stop immediately
//   if (this.blockSelection) {
//     // prevent checkbox visual change
//     return;
//   }

//   // Store a copy before change
//   const alreadySelected = this.TranselectedRowData.find(
//     (r) => r.rowid_seq === row.rowid_seq
//   );

//   // Temporarily modify selection (simulate toggle)
//   let tempSelection = [...this.TranselectedRowData];

//   if (alreadySelected) {
//     tempSelection = tempSelection.filter(
//       (r) => r.rowid_seq !== row.rowid_seq
//     );
//   } else {
//     tempSelection.push({ rowid_seq: row.rowid_seq });
//   }

//   // 🔹 Calculate the total TDS for the new selection
//   const totalTDS = tempSelection.reduce((sum, selected) => {
//     const r = this.paginatedList.find(
//       (p) => p.rowid_seq === selected.rowid_seq
//     );
//     return sum + (r?.tds_amt ?? 0);
//   }, 0);

//   // 🔹 If totalTDS would exceed challan balance, block and prevent UI check
//   if (this.selectedChallanDAValue && totalTDS > this.selectedChallanDAValue) {
//     // Emit event to parent to show popup
//     this.TranTotalTdsChange.emit(totalTDS); // so parent can catch and show popup
//     return; // stop here → checkbox won’t toggle
//   }

//   // ✅ Apply selection normally if limit not exceeded
//   this.TranselectedRowData = tempSelection;
//   this.emitSelection();
// }

updateSelection(row: any) {
  // 🔒 Stop if blocked during popup
  if (this.blockSelection) return;

  const alreadySelected = this.TranselectedRowData.some(
    (r) => r.rowid_seq === row.rowid_seq
  );

  let tempSelection = [...this.TranselectedRowData];

  if (alreadySelected) {
    // ✅ UNSELECT case — always allowed
    tempSelection = tempSelection.filter(
      (r) => r.rowid_seq !== row.rowid_seq
    );
  } else {
    // ✅ SELECT case — check limit before adding
    const selectedRow = this.paginatedList.find(
      (p) => p.rowid_seq === row.rowid_seq
    );

    const newTotal =
      tempSelection.reduce(
        (sum, s) =>
          sum +
          (this.paginatedList.find((p) => p.rowid_seq === s.rowid_seq)?.tds_amt ??
            0),
        0
      ) + (selectedRow?.tds_amt ?? 0);

    // 🚫 If total exceeds challan balance → show popup and revert checkbox
    // if (this.challanBalenceAmt && newTotal > this.challanBalenceAmt) {
    //   console.warn('⚠️ Selection exceeds challan balance — not allowed');

    //   // 🔁 Visually revert checkbox immediately
    //   setTimeout(() => {
    //     const checkbox = document.querySelector(
    //       `input[type="checkbox"][data-row="${row.rowid_seq}"]`
    //     ) as HTMLInputElement;
    //     if (checkbox) checkbox.checked = false;
    //   }, 0);

    //   // ❌ Don’t update or emit anything to parent
    //   return;
    // }
    if (this.challanBalenceAmt && newTotal > this.challanBalenceAmt) {
  console.warn('⚠️ Selection exceeds challan balance — not allowed');

  setTimeout(() => {
    const checkbox = document.querySelector(
      `input[type="checkbox"][data-row="${row.rowid_seq}"]`
    ) as HTMLInputElement;
    if (checkbox) checkbox.checked = false;
  }, 0);

  // 🔥 Notify parent to show popup
  this.limitExceeded.emit();

  return;
}


    // ✅ Within limit → add normally
    tempSelection.push({ rowid_seq: row.rowid_seq });
  }

  // ✅ Apply final updated selection and emit
  this.TranselectedRowData = tempSelection;
  this.emitSelection();
}






  // emitSelection() {
  //   // Emit the current rowid_seq selection
  //   this.transRowSelected.emit(this.TranselectedRowData);
  //   this.transelectedCountChange.emit(this.TranselectedRowData.length);

  //   // Calculate total TDS
  //   const totalTDS = this.TranselectedRowData.reduce((sum, selected) => {
  //     const r = this.paginatedList.find(
  //       (p) => p.rowid_seq === selected.rowid_seq
  //     );
  //     return sum + (r?.tds_amt ?? 0);
  //   }, 0);
  //   this.TranTotalTdsChange.emit(totalTDS);

  //   // Emit full row objects in a different variable
  //   const fullRows = this.TranselectedRowData.map((selected) =>
  //     this.paginatedList.find((p) => p.rowid_seq === selected.rowid_seq)
  //   ).filter((r) => r); // remove undefined if not found

  //   this.transRowSelectedFull.emit(fullRows);
  // }



emitSelection() {
  const totalTDS = this.TranselectedRowData.reduce((sum, selected) => {
    const r = this.paginatedList.find(
      (p) => p.rowid_seq === selected.rowid_seq
    );
    return sum + (r?.tds_amt ?? 0);
  }, 0);

  // 🔹 Final safety check (just in case)
  if (this.challanBalenceAmt != null && totalTDS > this.challanBalenceAmt) {
    console.warn('⚠️ Skipping emit — total exceeds challan balance');
    return;
  }

  // ✅ Emit when within limit
  this.transRowSelected.emit(this.TranselectedRowData);
  this.transelectedCountChange.emit(this.TranselectedRowData.length);
  this.TranTotalTdsChange.emit(totalTDS);

  const fullRows = this.TranselectedRowData
    .map((selected) =>
      this.paginatedList.find((p) => p.rowid_seq === selected.rowid_seq)
    )
    .filter((r) => r);
  this.transRowSelectedFull.emit(fullRows);
}
  






  updateMultiSelection() {
    if (this.allocationFlag === 'transactionFlag') return; // ignore

    const selectedRows = this.paginatedList.filter((r) => r.selected);
    this.TranselectedRowData = selectedRows.map((r) => ({
      rowid_seq: r.rowid_seq,
    }));

    this.emitSelection();
  }
  selectedHierarchyLabel: string = '';
  selectedHierarchyValue: string = '';
  selectedTransactionGroupLabel: string = '';
  selectedTransactionGroupValue: string = '';
  selectedTransactionGroups: any[] = [];

  showHierarchyOptions = false;
  showTransactionGroupOptions = false;

  searchHierarchy = '';
  searchTransactionGroup = '';

  hierarchyOptions = [
    { label: 'Hierarchy 4', value: '4' },
    { label: 'Hierarchy 5', value: '5' },
  ];

  transactionGroupOptions = [
    { label: 'TDS Code', value: 'tds_code' },
    { label: 'TDS Deduct Reason', value: 'tds_deduct_reason' },
  ];

  // These arrays are filtered versions (for search)
  filteredHierarchyOptions = [...this.hierarchyOptions];
  filteredTransactionGroupOptions = [...this.transactionGroupOptions];

  // 🟢 Called when selecting a Hierarchy
  selectHierarchy(option: any) {
    this.selectedHierarchyLabel = option.label;
    this.selectedHierarchyValue = option.value;
    this.showHierarchyOptions = false;
    // console.log(this.selectedHierarchyLabel, 'value-' ,this.selectedHierarchyValue);
  }

  // 🟢 Called when selecting a Transaction Group
  selectTransactionGroup(option: any) {
    const index = this.selectedTransactionGroups.findIndex(
      (g) => g.value === option.value
    );

    if (index > -1) {
      // Already selected, remove it
      this.selectedTransactionGroups.splice(index, 1);
    } else {
      // Not selected, add it
      this.selectedTransactionGroups.push(option);
    }

    // Update the label to show selected items
    // if (this.selectedTransactionGroups.length === 0) {
    //   this.selectedTransactionGroupLabel = '';
    //   this.selectedTransactionGroupValue = '';
    // } else if (this.selectedTransactionGroups.length === 1) {
    //   this.selectedTransactionGroupLabel =
    //     this.selectedTransactionGroups[0].label;
    //   this.selectedTransactionGroupValue =
    //     this.selectedTransactionGroups[0].value;
    // } else {
    //   this.selectedTransactionGroupLabel = `${this.selectedTransactionGroups.length} items selected`;
    //   this.selectedTransactionGroupValue = this.selectedTransactionGroups
    //     .map((g) => g.value)
    //     .join('#');
    // }
// Update the label to show selected items
if (this.selectedTransactionGroups.length === 0) {
  this.selectedTransactionGroupLabel = '';
  this.selectedTransactionGroupValue = '';
} else if (this.selectedTransactionGroups.length === 1) {
  this.selectedTransactionGroupLabel = this.selectedTransactionGroups[0].label;
  this.selectedTransactionGroupValue = this.selectedTransactionGroups[0].value;
} else {
  // 👇 Instead of "3 items selected", show joined labels
  this.selectedTransactionGroupLabel = this.selectedTransactionGroups
    .map((g) => g.label)
    .join(', ');
  this.selectedTransactionGroupValue = this.selectedTransactionGroups
    .map((g) => g.value)
    .join('#');
}

    //  console.log('Selected Transaction Groups:', this.selectedTransactionGroups);
  }
removeTransactionGroup(group: any) {
  const index = this.selectedTransactionGroups.findIndex(
    (g) => g.value === group.value
  );
  if (index > -1) {
    this.selectedTransactionGroups.splice(index, 1);
  }

  // Update labels & values dynamically
  if (this.selectedTransactionGroups.length === 0) {
    this.selectedTransactionGroupLabel = '';
    this.selectedTransactionGroupValue = '';
  } else if (this.selectedTransactionGroups.length === 1) {
    this.selectedTransactionGroupLabel = this.selectedTransactionGroups[0].label;
    this.selectedTransactionGroupValue = this.selectedTransactionGroups[0].value;
  } else {
    this.selectedTransactionGroupLabel = this.selectedTransactionGroups
      .map((g) => g.label)
      .join(', ');
    this.selectedTransactionGroupValue = this.selectedTransactionGroups
      .map((g) => g.value)
      .join('#');
  }
}


  // Check if a transaction group is selected
  isTransactionGroupSelected(option: any): boolean {
    return this.selectedTransactionGroups.some((g) => g.value === option.value);
  }

  // 🟢 Search filters
  filterHierarchyOptions() {
    const search = this.searchHierarchy.toLowerCase();
    this.filteredHierarchyOptions = this.hierarchyOptions.filter((opt) =>
      opt.label.toLowerCase().includes(search)
    );
  }

  filterTransactionGroupOptions() {
    const search = this.searchTransactionGroup.toLowerCase();
    this.filteredTransactionGroupOptions = this.transactionGroupOptions.filter(
      (opt) => opt.label.toLowerCase().includes(search)
    );
  }

private getGroupLbList(): void { 
  const requestBody = {
    a_session_seqno: '',
    a_iud_seqno: '',
    a_is_pen_flag: '',
    a_login_type: 'login_id',
    a_module_type_code: this.dynamicUserData?.default_module_type_code,
    a_sub_module_type_code: 'R',
    a_user_code: this.localUserData.user_code,
    a_entity_code: this.dynamicUserData.entity_code,
    a_client_code: this.dynamicUserData.client_code,
    a_acc_year: this.dynamicUserData.default_acc_year,
    a_quarter_no: this.dynamicUserData.default_quarter_no,
    a_tran_month: this.dynamicUserData.default_tran_month,
    a_validation_client_level: this.dynamicUserData.client_code_level,
    a_tran_from_date: this.dynamicUserData.default_from_date,
    a_tran_to_date: this.dynamicUserData.default_to_date,
    a_tds_type_code: this.dynamicUserData.default_tds_type_code,
    a_first_level_client_code: this.dynamicUserData.first_level_client_code,
    a_client_code_level: this.dynamicUserData.client_code_level,
    a_user_level: this.dynamicUserData.user_level,
    a_proc_error: '0',
    a_proc_type: 'get_gmlb_deductee_alloc_group',
    a_process_seqno: '',
    a_process_status_code: 'ZA',
    a_db_total_records: '1000',
    a_pagination_count: '0',
  };

  this.apiService
    .fetchparentmastLbData(
      '/Transaction/get_gmlb_deductee_alloc_group',
      requestBody
    )
    .subscribe({
      next: (response: any) => {
        const data = response?.result?.get_gmlb_deductee_alloc_group;
        if (data && Array.isArray(data)) {
          const hierarchy = data.find(
            (x: any) => x.filter_col_field === 'code_level'
          );
          const transactionGroup = data.find(
            (x: any) => x.filter_col_field === 'transaction_group'
          );

          this.hierarchyOptions = hierarchy?.filter_col_depend_value || [];
          this.transactionGroupOptions =
            transactionGroup?.filter_col_depend_value || [];

          // ✅ Filter hierarchy options based on client_code_level
          const clientLevel = Number(this.dynamicUserData?.client_code_level || 0);
          this.filteredHierarchyOptions = this.hierarchyOptions.filter(
            (opt: any) => opt.value >= clientLevel
          );

          // Optional: keep transaction group same
          this.filteredTransactionGroupOptions = [
            ...this.transactionGroupOptions,
          ];
        }
      },
      error: (err) => {
        console.error('API error:', err);
      },
    });
}


  // allocGrpSearch:any;

  groupSearch() {
    this.searchGroup = true;
    // console.log(this.selectedHierarchyValue )
    // console.log(this.selectedTransactionGroups )

    if (
      !this.selectedHierarchyValue ||
      this.selectedTransactionGroups.length === 0
    ) {
      this.showError(
        'Please select both Hierarchy and Transaction Group before searching.'
      );
      return;
    }
    // console.log(this.selectedHierarchyValue, 'value-' ,this.selectedTransactionGroupValue);
        const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
   const newFilterClause  = [
      // {
      //   filter_col_field: 'a_alloc_group_str',
      //   filter_col_depend_operator: '=',
      //   filter_col_value: `#${this.selectedHierarchyValue}#${this.selectedTransactionGroupValue}#`,
      //   filter_col_field_alias: 'a.',
      // },
       {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    // this.allocGrpSearch = `#${this.selectedHierarchyValue}#${this.selectedTransactionGroupValue}#`;

      const allocValue = `#${this.selectedHierarchyValue}#${this.selectedTransactionGroupValue}#`;
      this.allocGrpSearch.emit(allocValue);




    // 🟢 Define the filter clause only for filterable columns
    // const filterClause = [
    //   {
    //     filter_col_field: 'deductee_alloc_status',
    //     filter_col_depend_operator: 'wc',
    //     filter_col_value: 'and a.tds_challan_rowid_seq is null',
    //     filter_col_field_alias: 'a.',
    //   },
    //   {
    //     filter_col_field: 'quarter_no',
    //     filter_col_depend_operator: '=',
    //     filter_col_value: this.dynaUserData.default_quarter_no,
    //     filter_col_field_alias: 'a.',
    //   },
    //   {
    //     filter_col_field: 'tds_type_code',
    //     filter_col_depend_operator: '=',
    //     filter_col_value: this.dynaUserData.default_tds_type_code,
    //     filter_col_field_alias: 'a.',
    //   },
    // ];

    // 🟢 Construct a_alloc_group_str separately
    // Always rebuild final filterClause fresh:
    const finalFilterClause = [
      ...newFilterClause,
      ...userFilters.filter(
        (uf: any) =>
          !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
      ),
    ];
    // 🟢 Generate sdata properly
    const sdata = this.apiService.generateSData(
      'get_gtdb_tds_tran_load_group_alloc',
      this.localUserData,
      finalFilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
        alloc_group_str: `#${this.selectedHierarchyValue}#${this.selectedTransactionGroupValue}#`,
        dashboardType: this.dashboardType,
      }
    );
    // console.log('API will be called with:', a_alloc_group_str);
    // 🟢 API call
    this.apiService
      .getTableData('/Transaction/get_gtdb_tds_tran_load_group_alloc', sdata)
      .subscribe({
        next: (data) => {

          console.log(data);

          this.loading = false;
  console.log(data?.result);
  console.log(data?.result?.a_proc_error);
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_tran_load_group_alloc;

             if (userData?.get_gtdb_tds_tran_load_group_alloc_header) {
              this.headersGrp = userData?.get_gtdb_tds_tran_load_group_alloc_header?.map(
                (header: any) => ({
                  ...header,
                  visible: header.display == 1,
                })
              );
            }
            console.log(this.headersGrp);

            this.tableBodyGrp =
              userData?.get_gtdb_tds_tran_load_group_alloc_detail || [];

            console.log(this.tableBodyGrp);
            this.paginatedList =
              this.offset > 0
                ? [...this.paginatedList, ...this.tableBodyGrp]
                : this.tableBodyGrp;
            console.log(this.paginatedList);
          } else {
            this.showError(data?.result?.a_proc_error_message);
          }
        },
        error: (err) => {
          this.loading = false;
          this.showError(err.message || 'Failed to fetch data.');
        },
      });
  }

//   setActiveIcon(mode: string): void {
//     this.activeIcon = mode;
//     this.tranViewModeChange.emit(this.activeIcon);
//     if(mode === 'list' && this.searchGroup == true) {    
//      this.fetchTable();
//       this.fetchGrandTotal()
//   }
// }
setActiveIcon(mode: string): void {
  this.activeIcon = mode;
  this.tranViewModeChange.emit(this.activeIcon);
  console.log('Mode:', mode, 'SearchGroup:', this.searchGroup);

  if (mode === 'list' ) {
    console.log('Fetching table data...');
    this.searchGroup = false;
    
    this.fetchTable();
    this.fetchGrandTotal();
     this.selectedHierarchyLabel = '';
  this.selectedHierarchyValue = '';
  this.selectedTransactionGroupLabel= '';
  this.selectedTransactionGroupValue= '';
  this.selectedTransactionGroups = [];
  }
}


    formatDate(value: Date | string | null | undefined): string {
      return formatDatesend(value);
    }
}
