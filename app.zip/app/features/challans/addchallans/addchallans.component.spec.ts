import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddchallansComponent } from './addchallans.component';

describe('AddchallansComponent', () => {
  let component: AddchallansComponent;
  let fixture: ComponentFixture<AddchallansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddchallansComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddchallansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
