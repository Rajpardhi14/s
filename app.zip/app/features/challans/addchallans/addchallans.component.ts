import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
  NgZone,
} from '@angular/core';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { DateservicesService } from '../../../core/services/dateservices/dateservices.service';
import { DatepickerComponent } from '../../../shared/components/datepicker/datepicker.component';
import { AuthService } from '../../../core/services/auth/auth.service';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
import { Router } from '@angular/router';
import { MapAllocationComponent } from '../../map-allocation/map-allocation.component';
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  merge,
  Observable,
  Subject,
  takeUntil,
  tap,
} from 'rxjs';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';

@Component({
  selector: 'app-addchallans',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OutSideClickDirective,
    DatepickerComponent,
    AlertpoupComponent,
    MapAllocationComponent,
    ButtoneventlisnerDirective
  ],
  templateUrl: './addchallans.component.html',
  styleUrl: './addchallans.component.css',
})
export class AddchallansComponent {
  @Output() close = new EventEmitter<void>();
  @Input() isDrawerOpen: any;
  @Input() clientCodee: any;
  @Input() selectedId: string | null = null;
  @Input() challan_alloc_status:string | null = null;
  @Input() nil_challan_flag: string | null = null;
  @Input() book_entry_flag: string | null = null;
  challanForm!: FormGroup;
  localUserData: any;
  roleData: any;
  userlocaldataService: any;
  dynamicUserData: any;
  tdsRateTypeMastData: any;
  countryMastData: any;
  tdsRemittanceData: any;
  tdsMastData: any;
  minorHeadMastData: any;
  quarterNo: any;
  tdsSectionOptions: any[] = [];
  minorHeadOptions: any[] = [];
  tdsTypeCode: any;
  disableOtherFlags: boolean = false;
  searchTdsSection = '';

  // Tab switch confirmation variables
  isTabSwitchConfirmationOpen: boolean = false;
  pendingTabValue: string | null = null;
  currentTabValue: string | null = null;

  //table veriables
  filterClause: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  challanHeaders: any[] = [];
  challanTableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  allocationFlag: string = '';
  isTabChange: boolean = false;
       detailsLoader:boolean =false;
       dashboardType: string = 'ALLOC';
  constructor(
    private userlocaldata: UserdataService,
    private apiservice: ApiserviceService,
    private toastService: ToastService,
    private refreshdata: RefreshdataService,
    private fb: FormBuilder,
    private authservice: AuthService,
    private ngZone: NgZone,
    private router: Router
  ) {}
  ngOnChanges(changes: SimpleChanges): void {
        // console.log('ngonchanges');
  
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
        this.getsData()
    this.quarterNo = this.dynamicUserData.default_quarter_no;
    this.tdsTypeCode = this.dynamicUserData.default_tds_type_code;
    console.log(this.tdsTypeCode);
    // this.isLoading = true;
    // this.getstatemast().subscribe(() => {
    //   if (this.challanForm) {
    //     this.applyDynamicValidations();
    //   }
    // });

    if (changes['selectedId'] && this.selectedId) {
      this.fetchChallanDetails(this.selectedId);
      this.isEditMode = false;
      this.isDrawerOpen = true;
      this.challanForm
        ?.get('challan_entry_flag')
        ?.valueChanges.subscribe(() => {
          this.updateRadioState();
        });
    } else {
      // this.isLoading = false;
      this.isEditMode = true;
      this.updateRadioState();
    }

    // if (changes['clientCode'] && this.clientCode) {
    // }
    this.initializeForm();

  }
  ngOnInit(): void {
 
  
        // if (this.selectedId) {
        //   this.fetchChallanDetails(this.selectedId);
        // }
  //  console.log('ngOnInit');
    this.initializeForm();
    // this.updateRadioState();

    // console.log(this.tdsTypeCode)
    // Also call once on init
    this.updateRadioState();
    // console.log(this.book_entry_flag, 'book');
    // console.log(this.nil_challan_flag, 'n');
    const defaultMinorHead = this.minorHeadOptions.find(
      (option) => option.label === 'Normal Tax'
    );

    if (defaultMinorHead) {
      this.selectedMinorHeadLabel = defaultMinorHead.label;
      this.selectedMinorHeadValue = defaultMinorHead.value; // ✅ store numeric code (e.g., 200)
    } else {
      this.selectedMinorHeadLabel = 'Normal Tax';
      this.selectedMinorHeadValue = '200'; // ✅ manually assign fallback value
    }
        console.log(this.challanForm);
  }

  closeDrawer() {
    this.close.emit(); // tell parent main drawer closed
  }
  closeMapAllocation() {
    this.isMapAllocation = false;
    this.close.emit();
  }
  flags = [
    { value: '1', label: 'Challan Entry Flag' },
    { value: '2', label: 'Nil Challan Flag' },
    { value: '3', label: 'Book Entry Flag' },
  ];

  disableOtherFlagsMap: { [key: string]: boolean } = {
    '1': false,
    '2': false,
    '3': false,
  };

  // initializeForm() {
  //   const initialFlag = this.getInitialFlag();
  //   this.challanForm = this.fb.group({
  //     challan_entry_flag: [initialFlag],
  //     bank_bsr_code: [
  //   '',
  //   [Validators.required, Validators.pattern('^[0-9]{7}$')]
  // ],
  // challan_no: [
  //   '',
  //   [Validators.required, Validators.pattern('^[0-9]{1,5}$')]
  // ],
  //     challan_date: ['', Validators.required],
  //     tds_challan_minor_head: ['', Validators.required],
  //     tds_amt: ['', [Validators.required]],
  //     int_amt: [''],
  //     other_amt: [''],
  //     nil_challan_flag: [this.nil_challan_flag || 'N'],
  //     book_entry_flag: [this.book_entry_flag || 'N'],
  //     tds_code: [''],
  //   });

  //   // Store current tab value
  //   this.currentTabValue = initialFlag;
  //   console.log(this.currentTabValue);

  //   this.challanForm
  //     .get('challan_entry_flag')
  //     ?.valueChanges.subscribe((val) => this.handleTabSwitch(val));

  //   this.applyFlagLogic(initialFlag);
  //   this.updateRadioState();
  // }

initializeForm() {
const initialFlag = this.getInitialFlag();

  this.challanForm = this.fb.group({
    challan_entry_flag: [initialFlag],
    // bank_bsr_code: [
    //   '',
    //   [
    //     Validators.required,
    //     Validators.pattern('^[0-9]{7}$'), // Only 7 digits allowed
    //     Validators.minLength(5),
    //     Validators.maxLength(7),
    //   ],
    // ],
 bank_bsr_code: [
  '',
  [
    Validators.required,
    Validators.minLength(5),
    Validators.maxLength(7),
    Validators.pattern(/^\d+$/), // only digits allowed
  ],
],

    challan_no: [
      '',
      [
        Validators.required,
        Validators.minLength(5),
    Validators.maxLength(5),
    Validators.pattern(/^\d+$/),,  
      ],
    ],
    challan_date: ['', Validators.required],
    tds_challan_minor_head: ['', Validators.required],
    tds_amt: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\d+(\.\d{1,2})?$/), // Only positive numbers with max 2 decimals
      Validators.max(1000000000),
      ],
    ],
    int_amt: [
      '',
      [
        Validators.pattern(/^\d+(\.\d{1,2})?$/), // Optional number with max 2 decimals
      Validators.max(1000000000),],
    ],
    other_amt: [
      '',
      [
        Validators.pattern(/^\d+(\.\d{1,2})?$/), // Optional number with max 2 decimals
      Validators.max(1000000000),],
    ],
    nil_challan_flag: [this.nil_challan_flag || 'N'],
    book_entry_flag: [this.book_entry_flag || 'N'],
    tds_code: ['', ],
  });

  this.currentTabValue = initialFlag;

  // Track value changes for tab switching
  this.challanForm
    .get('challan_entry_flag')
    ?.valueChanges.subscribe((val) => this.handleTabSwitch(val));

  this.applyFlagLogic(initialFlag);
  this.updateRadioState();
}



handleTabSwitch(newTabValue: string) {
  // console.log('handleTabSwitch');
  // console.log(this.currentTabValue, 'currentTabValue');

  // Step 1: Initialize if null
  if (!this.currentTabValue) {
    this.currentTabValue = newTabValue;
    this.applyFlagLogic(newTabValue);
   
    return;
  }

  // Step 2: If clicking same tab, do nothing
  if (this.currentTabValue === newTabValue) {
    
    return;
  }

  // Step 3: Check if user entered any data
  const hasValues = this.hasFormValues();

  // 🩵 Step 4: Allow popup in edit mode even if hasValues = false
  if (!this.isEditMode || !this.selectedId) {
    this.currentTabValue = newTabValue;
    this.applyFlagLogic(newTabValue);
  
    return;
  }

  // ✅ Step 5: When in edit mode → always confirm switch
  if (this.isEditMode && this.selectedId) {
    this.pendingTabValue = newTabValue;
    this.isTabSwitchConfirmationOpen = true;

    this.challanForm.patchValue(
      { challan_entry_flag: this.currentTabValue },
      { emitEvent: false }
    );
  }
}

//   handleTabSwitch(newTabValue: string) {
//     console.log('handleTabSwitch');
// console.log(this.currentTabValue ,'currentTabvalue');
//     // Step 1: If no current tab selected, switch directly
//     if (!this.currentTabValue) {
//       this.currentTabValue = newTabValue;
//       this.applyFlagLogic(newTabValue);
//       console.log('1');
//       return;
//     }

//     // Step 2: If clicking same tab, do nothing
//     if (this.currentTabValue === newTabValue) {
//       console.log('2');
//       return;
//     }

//     // Step 3: Check if user entered any data in current form
//     const hasValues = this.hasFormValues();

//     // Step 4: If form is empty and not in edit mode, just switch
//     if (!hasValues || !this.isEditMode || !this.selectedId) {
//       this.currentTabValue = newTabValue;
//       this.applyFlagLogic(newTabValue);
//       console.log('4');
//       return;
//     }

//     // ✅ Step 5: When in edit mode, record is selected, and form has data → show confirmation popup
//     if (this.isEditMode && this.selectedId && this.currentTabValue) {
//       this.pendingTabValue = newTabValue;
//       this.isTabSwitchConfirmationOpen = true;

//       // Keep current tab active until user confirms
//       this.challanForm.patchValue(
//         { challan_entry_flag: this.currentTabValue },
//         { emitEvent: false }
//       );
//     }
//   }

  /** Check if form has any meaningful values entered */
  hasFormValues(): boolean {
    const formValue = this.challanForm.value;

    // Fields to check for Challan Entry Flag (flag '1')
    const fieldsToCheck = [
      'bank_bsr_code',
      'challan_no',
      'challan_date',
      'tds_amt',
      'int_amt',
      'other_amt',
    ];

    // Check if any field has a non-empty value
    for (const field of fieldsToCheck) {
      const value = formValue[field];
      if (value && value.toString().trim() !== '') {
        return true;
      }
    }

    // Check if TDS Section or Minor Head has been selected (not 'Select')
    // if (
    //   formValue.tds_code &&
    //   formValue.tds_code !== 'Select' &&
    //   formValue.tds_code !== ''
    // ) {
    //   return true;
    // }

    if (
      formValue.tds_challan_minor_head &&
      formValue.tds_challan_minor_head !== 'Select' &&
      formValue.tds_challan_minor_head !== ''
    ) {
      return true;
    }

    return false;
  }

  /** Handle tab switch confirmation */
  handleTabSwitchConfirm() {
    if (this.pendingTabValue) {
      this.currentTabValue = this.pendingTabValue;
      this.applyFlagLogic(this.pendingTabValue);

      // Update the form control value
      this.challanForm.patchValue(
        { challan_entry_flag: this.pendingTabValue },
        { emitEvent: false }
      );
    }
    this.isTabSwitchConfirmationOpen = false;
    this.pendingTabValue = null;
  }

  /** Handle tab switch cancellation */
  handleTabSwitchCancel() {
    this.isTabSwitchConfirmationOpen = false;
    this.pendingTabValue = null;
    // Keep the current tab selected
    this.challanForm.patchValue(
      { challan_entry_flag: this.currentTabValue },
      { emitEvent: false }
    );
  }

  /** Handles enabling/disabling other radios based on mode */
  updateRadioState() {
    const selectedFlag = this.challanForm?.get('challan_entry_flag')?.value;
    if (this.isEditMode) {
      this.disableOtherFlagsMap = { '1': false, '2': false, '3': false };
    } else if (this.selectedId) {
      this.disableOtherFlagsMap = {
        '1': selectedFlag !== '1',
        '2': selectedFlag !== '2',
        '3': selectedFlag !== '3',
      };
    } else {
      this.disableOtherFlagsMap = { '1': false, '2': false, '3': false };
    }
  }

  /** Apply flag logic with a cleaner approach */
  applyFlagLogic(selected: string) {
    const bankCtrl = this.challanForm.get('bank_bsr_code');
    const challanNoCtrl = this.challanForm.get('challan_no');
    const tdsAmtCtrl = this.challanForm.get('tds_amt');
    const minorHeadCtrl = this.challanForm.get('tds_challan_minor_head');
    this.isTabChange = false;
    const config: any = {
      '1': {
        nil_challan_flag: 'N',
        book_entry_flag: 'N',
        bank_bsr_code: '',
        challan_no: '',
        tds_amt: '',
        minorHeadEnabled: true,
      },
      '2': {
        nil_challan_flag: 'Y',
        book_entry_flag: 'N',
        bank_bsr_code: '1111111',
        challan_no: '00001',
        tds_amt: '100.00',
        minorHeadEnabled: true,
      },
      '3': {
        nil_challan_flag: 'N',
        book_entry_flag: 'Y',
        bank_bsr_code: '',
        challan_no: '',
        tds_amt: '',
        minorHeadEnabled: false,
      },
    };

    const patch = config[selected];
    const defaultMinorHead = this.minorHeadOptions?.find(
      (option) => option.label === 'Normal Tax'
    );

    this.challanForm.reset(
      {
        ...patch,
        challan_entry_flag: selected,
        tds_challan_minor_head: defaultMinorHead
          ? defaultMinorHead.value
          : 'Normal Tax',
        tds_code: 'Select',
      },
      { emitEvent: false }
    );

    this.selectedMinorHeadLabel = defaultMinorHead
      ? defaultMinorHead.label
      : 'Normal Tax';

    // this.selectedMinorHeadLabel = 'Select';
    this.selectedTdsSectionLabel = 'Select';

    // Required fields for normal challans
    const requiredFields = [bankCtrl, challanNoCtrl, tdsAmtCtrl];
    requiredFields.forEach((ctrl) =>
      selected === '2'
        ? ctrl?.clearValidators()
        : ctrl?.setValidators([Validators.required])
    );

    // ✅ Minor Head logic
    if (patch.minorHeadEnabled) {
      minorHeadCtrl?.enable({ emitEvent: false });
      minorHeadCtrl?.setValidators([
        Validators.required,
        // custom validator to disallow "Select" value
        (control) => (control.value === 'Select' ? { required: true } : null),
      ]);
    } else {
      minorHeadCtrl?.disable({ emitEvent: false });
      this.selectedMinorHeadLabel = 'Select';
      minorHeadCtrl?.clearValidators();
    }

    [bankCtrl, challanNoCtrl, tdsAmtCtrl, minorHeadCtrl].forEach((ctrl) =>
      ctrl?.updateValueAndValidity({ emitEvent: false })
    );

    this.updateRadioState();
  }

  /** Determine initial flag */
  getInitialFlag(): string {
    if (this.nil_challan_flag === 'Y') return '2';
    if (this.book_entry_flag === 'Y') return '3';
    return '1';
  }

  // private getstatemast(): Observable<any>{
  //   // const uData = JSON.parse(this.userDataLogin);
  //   const requestBody = {
  //     sdata: JSON.stringify({
  //          a_session_seqno: "",
  //       a_iud_seqno: "",
  //       a_is_pen_flag: "",
  //       a_login_type: "login_id",
  //       a_module_type_code: this.localUserData?.default_module_type_code,
  //       a_sub_module_type_code: "R",
  //       a_entity_code: this.localUserData?.entity_code,
  //       a_client_code: this.localUserData?.client_code,
  //       a_acc_year: this.localUserData?.default_acc_year,
  //       a_quarter_no: this.localUserData?.default_quarter_no,
  //       a_tran_month: this.localUserData?.default_tran_month,
  //       a_tran_from_date: this.localUserData?.default_from_date,
  //       a_tran_to_date: this.localUserData?.default_to_date,
  //       a_tds_type_code: this.localUserData?.default_tds_type_code,
  //       a_first_level_client_code: this.localUserData?.first_level_client_code,
  //       a_validation_client_level: this.localUserData.client_code_level,
  //       a_iud_type: "",
  //       a_db_total_records: "10",
  //       a_pagination_count: "0",
  //       a_proc_type: "get_mmtx_multi_mast",
  //       a_user_code: this.localUserData.user_code,
  //       first_level_client_code: this.localUserData.first_level_client_code,
  //       a_process_seqno: '',
  //       a_proc_error: '0',
  //       a_filter_clause: [
  //         {
  //           filter_col_field: 'gd_proc_name',
  //           filter_col_depend_operator: 'wc',
  //           filter_col_value:
  //             'and gd_proc_name in(##get_mmtx_tds_mast##,##get_mmtx_minor_head_mast## )',
  //           filter_col_field_alias: 'a.',
  //         },
  //       ],
  //     }),
  //   };

  // return  this.authservice.fetchMultiMastData(requestBody).pipe({
  //     tap: (response: any) => {
  //       const multiMast = response?.body?.result?.get_mmtx_multi_mast;
  //       // console.log(multiMast)
  //       const tdsMastData = multiMast?.get_gmdt_tds_mast;
  //       this.tdsMastData = tdsMastData;

  //       const minorHeadMastData = multiMast?.get_gmdt_minor_head_mast;
  //       this.minorHeadMastData = minorHeadMastData;

  //       this.minorHeadOptions = this.minorHeadMastData?.map((item: any) => ({
  //         label: item.label, // adjust key name based on API response
  //         value: item.value, // adjust key name based on API response
  //       }));
  //       // console.log(this.minorHeadOptions);

  //       const fyStartYear = new Date().getFullYear(); // adjust if your FY doesn't align with calendar year
  //       //  console.log(fyStartYear)
  //       const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

  //       this.tdsSectionOptions = (this.tdsMastData || []).filter(
  //         (item: any) => {
  //           // condition 1: tds_type_code match
  //           const typeMatch = item.tds_type_code === this.tdsTypeCode;

  //           // condition 2: valid_to_date is null OR quarterEnd <= valid_to_date
  //           let dateValid = true;
  //           if (item.valid_to_date) {
  //             const validTo = this.parseDdMmYyyy(item.valid_to_date);
  //             dateValid = end <= validTo;
  //           }

  //           return typeMatch && dateValid;
  //         }
  //       );
  //       //  console.log(this.tdsSectionOptions)
  //       this.filteredTdsSectionOptions = this.tdsSectionOptions;
  //       this.filteredMinorHeadOptions = this.minorHeadOptions;
  //       {
  //         console.warn('TDS/Quarter/Year data not found in response.');
  //       }
  //     },
  //     error: (error: any) => {
  //       console.error(error);
  //     },
  //   });
  // }

  regexMap: { [key: string]: string } = {};
  useTdsData: any;
  regexList: any;

  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiservice
      .setRedisApi('/Comman/get_mmtx_data', requestBody)
      .subscribe({
        next: (response: any) => {
          let parsedData;
          try {
            parsedData = JSON.parse(response.data);
          } catch (e) {
            parsedData = response.data;
          }
          //console.log(parsedData);
          this.tdsMastData = parsedData.multiMast.get_gmdt_tds_mast;
     //     console.log('Parsed Redis data:', this.useTdsData);
          this.regexMap = parsedData.multiMast.get_gmdt_regex_validation;
        //  console.log(this.regexMap);
this.applyDynamicValidations();
    const minorHeadMastData = parsedData?.multiMast?.get_gmdt_minor_head_mast;
        this.minorHeadMastData = minorHeadMastData;

        this.minorHeadOptions = this.minorHeadMastData?.map((item: any) => ({
          label: item.label,
          value: item.value,
        }));
            const fyStartYear = new Date().getFullYear();
        const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

          // 5️⃣ Filter TDS data based on type and valid_to_date
          this.tdsSectionOptions = (this.tdsMastData || []).filter(
          (item: any) => {
            const typeMatch = item.tds_type_code === this.tdsTypeCode;
            let dateValid = true;

            if (item.valid_to_date) {
              const validTo = this.parseDdMmYyyy(item.valid_to_date);
              dateValid = end <= validTo;
            }

            return typeMatch && dateValid;
          }
        );

              this.filteredTdsSectionOptions = this.tdsSectionOptions;
        this.filteredMinorHeadOptions = this.minorHeadOptions;

        console.warn('TDS/Quarter/Year data not found in response.');
          // console.log(
          //   '✅ Loaded TDS Section list from localStorage:',
          //   this.branchCodeOption
          // );
        },
        error: (error: any) => {
          this.errorMessage =
            error.message || 'Failed to fetch header master data.';
          this.showError(this.errorMessage);
        },
      });
  }






  // private getstatemast(): Observable<any> {
  //   const requestBody = {
  //     sdata: JSON.stringify({
  //       a_session_seqno: '',
  //       a_iud_seqno: '',
  //       a_is_pen_flag: '',
  //       a_login_type: 'login_id',
  //       a_module_type_code: this.localUserData?.default_module_type_code,
  //       a_sub_module_type_code: 'R',
  //       a_entity_code: this.localUserData?.entity_code,
  //       a_client_code: this.localUserData?.client_code,
  //       a_acc_year: this.localUserData?.default_acc_year,
  //       a_quarter_no: this.localUserData?.default_quarter_no,
  //       a_tran_month: this.localUserData?.default_tran_month,
  //       a_tran_from_date: this.localUserData?.default_from_date,
  //       a_tran_to_date: this.localUserData?.default_to_date,
  //       a_tds_type_code: this.localUserData?.default_tds_type_code,
  //       a_first_level_client_code: this.localUserData?.first_level_client_code,
  //       a_validation_client_level: this.localUserData.client_code_level,
  //       a_iud_type: '',
  //       a_db_total_records: '10',
  //       a_pagination_count: '0',
  //       a_proc_type: 'get_mmtx_multi_mast',
  //       a_user_code: this.localUserData.user_code,
  //       first_level_client_code: this.localUserData.first_level_client_code,
  //       a_process_seqno: '',
  //       a_proc_error: '0',
  //       a_filter_clause: [
  //         {
  //           filter_col_field: 'gd_proc_name',
  //           filter_col_depend_operator: 'wc',
  //           filter_col_value:
  //             'and gd_proc_name in(##get_mmtx_tds_mast##,##get_mmtx_minor_head_mast##, ##get_mmtx_regex_validation##)',
  //           filter_col_field_alias: 'a.',
  //         },
  //       ],
  //     }),
  //   };

  //   return this.authservice.fetchMultiMastData(requestBody).pipe(
  //     tap((response: any) => {
  //       const validations =
  //         response?.body?.result?.get_mmtx_multi_mast
  //           ?.get_gmdt_regex_validation || [];
  //       this.regexMap = validations.reduce((acc: any, cur: any) => {
  //         acc[cur.label] = cur.value;
  //         return acc;
  //       }, {});

  //       // After fetching regex, re-apply validations
  //       // this.applyDynamicValidations();

  //       const multiMast = response?.body?.result?.get_mmtx_multi_mast;
  //       const tdsMastData = multiMast?.get_gmdt_tds_mast;
  //       this.tdsMastData = tdsMastData;

  //       const minorHeadMastData = multiMast?.get_gmdt_minor_head_mast;
  //       this.minorHeadMastData = minorHeadMastData;

  //       this.minorHeadOptions = this.minorHeadMastData?.map((item: any) => ({
  //         label: item.label,
  //         value: item.value,
  //       }));

  //       const fyStartYear = new Date().getFullYear();
  //       const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

  //       this.tdsSectionOptions = (this.tdsMastData || []).filter(
  //         (item: any) => {
  //           const typeMatch = item.tds_type_code === this.tdsTypeCode;
  //           let dateValid = true;

  //           if (item.valid_to_date) {
  //             const validTo = this.parseDdMmYyyy(item.valid_to_date);
  //             dateValid = end <= validTo;
  //           }

  //           return typeMatch && dateValid;
  //         }
  //       );

  //       this.filteredTdsSectionOptions = this.tdsSectionOptions;
  //       this.filteredMinorHeadOptions = this.minorHeadOptions;

  //       console.warn('TDS/Quarter/Year data not found in response.');
  //     })
  //     // Optional error handling operator
  //     // catchError((error) => {
  //     //   console.error(error);
  //     //   return throwError(() => error);
  //     // })
  //   );
  // }

  private applyDynamicValidations(): void {
    if (!this.regexMap || !this.challanForm) return;

    Object.keys(this.regexMap).forEach((key) => {
      const regexString = this.regexMap[key];
      const control = this.challanForm.get(key);

      if (control && regexString) {
        try {
          const regex = new RegExp(regexString);
          const existingValidators = control.validator
            ? [control.validator]
            : [];

          // Add dynamic regex validator
          control.setValidators([
            ...existingValidators,
            Validators.pattern(regex),
          ]);
          control.updateValueAndValidity({ emitEvent: false });
        } catch (e) {
          console.error(`Invalid regex for ${key}: ${regexString}`, e);
        }
      }
    });

    // console.log('✅ Dynamic regex validators applied:', this.regexMap);
  }

  isSubmitting: boolean = false;
  isSubmittingUpdate = false;
  errorMessage: string = '';
  //subbmit
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiservice
      .createData('/Transaction/get_tiud_tds_challan_tran_load', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.closeDrawer();
            this.refreshdata.trigerRefresh('Challans');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                  if (this.challanForm.controls[field]) {
                    this.challanForm.controls[field].setErrors({
                      serverError: error.message,
                    });
                  }
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }

  //form subbmit
  onSubmit() {
    if (this.challanForm.invalid) {
      this.challanForm.markAllAsTouched();
      this.toastService.showError('Please fill all required fields'); // your toast service
      return;
      // return;
      // console.log('onSubmit() called ✅', this.challanForm.value);
    }

    this.isSubmitting = true;
    const formData = this.challanForm.value;
    // console.log(formData);
    // console.log(this.selectedTdsSectionValue);
    // console.log(this.selectedMinorHeadValue);
    const requestBody = {
      a_is_pen_flag: '',
      a_sub_module_type_code: '',
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type:
        this.isDelete && this.selectedId ? 'd' : this.selectedId ? 'u' : 'i',
      a_proc_type: 'get_tiud_tds_challan_tran_load',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_email_id: this.dynamicUserData.email_id,
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      tds_challan_tran_load: {
        rowid_seq: this.selectedId ? this.roleData.rowid_seq : '',
        bank_bsr_code: formData.bank_bsr_code,
        challan_entry_flag: formData.challan_entry_flag,
        nil_challan_flag: formData.nil_challan_flag,
        book_entry_flag: formData.book_entry_flag,
        challan_no: formData.challan_no,
        challan_date: formData.challan_date,
        tds_challan_minor_head:
          this.selectedMinorHeadValue || formData.tds_challan_minor_head,
        tds_amt: formData.tds_amt,
        int_amt: formData.int_amt,
        other_amt: formData.other_amt,
        tds_code: this.selectedTdsSectionValue,
      },
    };

    this.submitRequest(
      requestBody,
      'Challans  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
  }

  isEditMode: boolean = false;
  toggleEditMode() {
    this.isEditMode = true;
    this.isTabChange = true;
  }
  //single details
  fetchChallanDetails(roleCode: string) {
      this.detailsLoader = true;
    const requestBody = {
      a_iud_seqno: '',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: '',
      a_session_seqno: '',
      a_proc_type: 'get_gtdt_tds_challan_tran_load',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_login_type: 'login_id',
      a_email_id: this.dynamicUserData.email_id,
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails(
        '/Transaction/get_gtdt_tds_challan_tran_load',
        requestBody
      )
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_gtdt_tds_challan_tran_load
              ?.get_gtdt_tds_challan_tran_load_detail?.[0];
          this.roleData = roleData;

          if (!roleData) {
            // this.showError('No user data found.');
             this.detailsLoader =false;
            return;
            
          }
           this.detailsLoader =false;
        
          this.book_entry_flag = roleData.book_entry_flag;
this.nil_challan_flag = roleData.nil_challan_flag;
 this.initializeForm();
          this.challanForm.patchValue({
            bank_bsr_code: roleData?.bank_bsr_code || '',
            challan_no: roleData?.challan_no || '',
            challan_date: roleData?.challan_date || '',
            tds_code: roleData?.tds_code || '',
            tds_amt: roleData?.tds_amt || '0',
            int_amt: roleData?.int_amt || '0',
            other_amt: roleData?.other_amt || '0',
            nil_challan_flag: roleData?.nil_challan_flag || '',
            book_entry_flag: roleData?.book_entry_flag,
            tds_challan_minor_head: roleData?.tds_challan_minor_head,
          });
          const selectedOption = this.minorHeadOptions?.find(
            (opt) => opt.value === roleData?.tds_challan_minor_head
          );
          this.selectedMinorHeadLabel = selectedOption
            ? selectedOption.label
            : '';

          this.selectedMinorHeadValue = roleData?.tds_challan_minor_head;
          // console.log(this.tdsSectionOptions);
          const tdsSectionOption = this.tdsSectionOptions?.find(
            (opt) => String(opt.value) === String(roleData?.tds_code)
          );
          this.selectedTdsSectionLabel = tdsSectionOption
            ? tdsSectionOption.label
            : '';
          this.selectedTdsSectionValue = roleData?.tds_code;
        },
        error: () => {
          this.showError('Failed to fetch User details.');
           this.detailsLoader =false;
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  showMinorHeadOption = false;
  selectedMinorHeadLabel = '';
  selectedMinorHeadValue: any;
  filteredMinorHeadOptions: any[] = [];
  searchMinorHead = '';

  filterMinorHeadOptions() {
    const searchValue = this.searchMinorHead.toLowerCase();
    this.filteredMinorHeadOptions = this.minorHeadOptions.filter(
      (option: any) => option.label.toLowerCase().includes(searchValue)
    );
  }
  selectMinorHead(option: any) {
    // console.log(option);
    this.challanForm.get('tds_challan_minor_head')?.setValue(option.value);
    this.selectedMinorHeadLabel = option.label;
    this.selectedMinorHeadValue = option.value;
    this.showMinorHeadOption = false;
  }
  clearTdsSelection(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedTdsSectionLabel = 'Select';
    this.selectedTdsSectionValue = null;
    this.challanForm.patchValue({
      tds_code: '',
    });
    this.challanForm.get('tds_code')?.markAsTouched();
  }

  clearMinorHead(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedMinorHeadLabel = 'Select';
    this.selectedMinorHeadValue = null;
    this.challanForm.patchValue({
      tds_challan_minor_head: '',
    });
    this.challanForm.get('tds_challan_minor_head')?.markAsTouched();
  }

  showTdsSectionOption = false;
  selectedTdsSectionLabel = '';
  selectedTdsSectionValue: any;
  filteredTdsSectionOptions: any[] = [];
  filterTdsSectionOptions() {
    const searchValue = this.searchTdsSection.toLowerCase();
    this.filteredTdsSectionOptions = this.tdsSectionOptions.filter(
      (option: any) => option.label.toLowerCase().includes(searchValue)
    );
    // console.log(this.filteredMinorHeadOptions);
  }
  // Optional: mark touched if dropdown closed without selecting
  onCloseTdsSectionDropdown() {
    this.showTdsSectionOption = false;

    this.ngZone.run(() => {
      const control = this.challanForm.get('tds_code');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }
  selectTdsSection(option: any) {
    this.selectedTdsSectionLabel = option.label;
    this.selectedTdsSectionValue = option.value;
    // console.log(this.selectedTdsSectionValue);
    this.challanForm.get('tds_code')?.setValue(option.value);
    this.showTdsSectionOption = false;
  }

  // helper to get quarter start and end date
  private getQuarterDateRange(
    quarterNo: number,
    fyStartYear: number
  ): { start: Date; end: Date } {
    switch (quarterNo) {
      case 1: // Apr–Jun
        return {
          start: new Date(fyStartYear, 3, 1), // 1 Apr
          end: new Date(fyStartYear, 5, 30), // 30 Jun
        };
      case 2: // Jul–Sep
        return {
          start: new Date(fyStartYear, 6, 1),
          end: new Date(fyStartYear, 8, 30),
        };
      case 3: // Oct–Dec
        return {
          start: new Date(fyStartYear, 9, 1),
          end: new Date(fyStartYear, 11, 31),
        };
      case 4: // Jan–Mar (next calendar year)
        return {
          start: new Date(fyStartYear + 1, 0, 1),
          end: new Date(fyStartYear + 1, 2, 31),
        };
      default:
        throw new Error('Invalid quarter number');
    }
  }
  // helper to parse dd-MMM-yyyy into Date
  private parseDdMmYyyy(dateStr: string): Date {
    const [day, mon, year] = dateStr.split('-');

    const months: { [key: string]: number } = {
      JAN: 0,
      FEB: 1,
      MAR: 2,
      APR: 3,
      MAY: 4,
      JUN: 5,
      JUL: 6,
      AUG: 7,
      SEP: 8,
      OCT: 9,
      NOV: 10,
      DEC: 11,
    };

    const monthIndex = months[mon.toUpperCase()] ?? -1; // fallback if not found
    return new Date(parseInt(year, 10), monthIndex, parseInt(day, 10));
  }

  allowNumbersOnly(event: KeyboardEvent) {
    const allowedKeys = [
      'Backspace',
      'Tab',
      'ArrowLeft',
      'ArrowRight',
      'Delete',
    ];
    if (allowedKeys.includes(event.key)) return;

    // Allow only digits and dot (for decimals)
    if (!/[\d.]/.test(event.key)) {
      event.preventDefault();
    }
  }

  onPasteNumbersOnly(event: ClipboardEvent) {
    const pastedData = event.clipboardData?.getData('text') || '';
    if (!/^\d*\.?\d*$/.test(pastedData)) {
      event.preventDefault();
    }
  }

  isDelete: boolean = false;
  isDeletePopupOpen = false;

  deleteSingleDetails() {
    this.isDeletePopupOpen = false;
    this.isDelete = true;
    this.onSubmit();
  }

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false;

    // console.log('called');
  }
  deleteSingleDetailsCancel() {
    this.isDelete = false;
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
  }

  isMapAllocation: boolean = false;
  // rowIdSeq:any;
  goToMapAllocation() {
    this.fetchTable();
  }

  fetchTable() {
    this.filterClause = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
    const values = Array.isArray(this.selectedValue)
      ? this.selectedValue
      : [this.selectedValue];

    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynamicUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynamicUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    if (this.selectedId) {
      newFilterClause.push({
        filter_col_field: 'rowid_seq',
        filter_col_depend_operator: '=',
        filter_col_value: this.selectedId,
        filter_col_field_alias: 'a.',
      });
    }
    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) {
        this.filterClause.push(nf);
      }
    });

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiservice.generateSData(
      'get_gtdb_tds_challan_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
         dashboardType: this.dashboardType,
      }
    );
    this.apiservice
      .getTableData('/Transaction/get_gtdb_tds_challan_tran_load', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_challan_tran_load;

            if (userData?.get_gtdb_tds_challan_tran_load_header) {
              this.challanHeaders =
                userData.get_gtdb_tds_challan_tran_load_header.map(
                  (header: any) => ({
                    ...header,
                    visible: header.display === 1,
                  })
                );
            }

            this.challanTableBody =
              userData?.get_gtdb_tds_challan_tran_load_detail || [];

            // ✅ now open the child component only after headers & body are ready
            this.isMapAllocation = true;
            this.allocationFlag = 'challanFlag';
          }
        },
        error: (error) => {
          console.error(error);
        },
      });
  }
  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  
}
