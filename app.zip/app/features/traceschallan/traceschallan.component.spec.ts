import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraceschallanComponent } from './traceschallan.component';

describe('TraceschallanComponent', () => {
  let component: TraceschallanComponent;
  let fixture: ComponentFixture<TraceschallanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TraceschallanComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TraceschallanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
