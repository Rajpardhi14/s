import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TracesService } from '../../services/traces.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import {
  JustificationReportPageData,
  JustificationReportSubmitRequest,
  JustificationReportSubmitResponse,
  DropdownOption
} from '../../models/traces.models';

@Component({
  selector: 'app-traces-justification-report-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './traces-justification-report-dialog.component.html',
  styleUrls: ['./traces-justification-report-dialog.component.css']
})
export class TracesJustificationReportDialogComponent implements OnInit {
  @Output() submitSuccess = new EventEmitter<JustificationReportSubmitResponse>();
  @Output() close = new EventEmitter<void>();

  justificationReportForm: FormGroup;
  isLoadingData: boolean = false;
  isSubmitting: boolean = false;

  financialYears: DropdownOption[] = [];
  quarters: DropdownOption[] = [];
  formTypes: DropdownOption[] = [];
  viewState: string = '';

  constructor(
    private fb: FormBuilder,
    private tracesService: TracesService,
    private toastService: ToastService
  ) {
    this.justificationReportForm = this.fb.group({
      finYr: ['', Validators.required],
      qrtr: ['', Validators.required],
      frmType: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadJustificationReportPageData();
  }

  /**
   * Load Justification Report page data (dropdowns and viewState)
   */
  loadJustificationReportPageData(): void {
    this.isLoadingData = true;
    this.toastService.showProcessing('Loading Justification Report form options...');

    this.tracesService.getJustificationReportPageData().subscribe({
      next: (response: JustificationReportPageData) => {
        console.log('✅ Justification Report Page Data:', response);

        this.financialYears = response.financialYears;
        this.quarters = response.quarters;
        this.formTypes = response.formTypes;
        this.viewState = response.viewState;

        this.isLoadingData = false;
        this.toastService.clearProcessing();

        if (this.financialYears.length === 0) {
          this.toastService.showError('No financial years available. Please check your TRACES session.');
        } else {
          this.toastService.showSuccess('Form options loaded successfully');
        }
      },
      error: (error: any) => {
        console.error('❌ Error loading Justification Report page:', error);
        this.isLoadingData = false;
        this.toastService.clearProcessing();
        this.toastService.showError(error.message || 'Failed to load Justification Report form options');

        // Close dialog after error
        setTimeout(() => this.onClose(), 2000);
      }
    });
  }

  /**
   * Submit Justification Report form
   */
  onSubmit(): void {
    if (this.justificationReportForm.invalid) {
      this.markFormGroupTouched(this.justificationReportForm);
      this.toastService.showError('Please select all required fields');
      return;
    }

    if (!this.viewState) {
      this.toastService.showError('ViewState missing. Please refresh and try again.');
      return;
    }

    this.isSubmitting = true;
    this.toastService.showProcessing('Submitting Justification Report request...');

    const formValues = this.justificationReportForm.value;
    const submitRequest: JustificationReportSubmitRequest = {
      finYr: formValues.finYr,
      qrtr: formValues.qrtr,
      frmType: formValues.frmType,
      viewState: this.viewState
    };

    this.tracesService.submitJustificationReportRequest(submitRequest).subscribe({
      next: (response: JustificationReportSubmitResponse) => {
        console.log('✅ Justification Report Submit Response:', response);
        this.isSubmitting = false;
        this.toastService.clearProcessing();

        if (response.status === 'SUCCESS' || response.status === 'REDIRECTED_TO_KYC') {
          this.toastService.showSuccess('Justification Report request submitted successfully!');
          this.submitSuccess.emit(response);

          // Close dialog after success
          setTimeout(() => this.onClose(), 1500);
        } else if (response.status === 'SESSION_EXPIRED') {
          this.toastService.showError('Session expired. Please reconnect to TRACES.');
          setTimeout(() => this.onClose(), 2000);
        } else {
          this.toastService.showError(response.message || 'Submission failed');
        }
      },
      error: (error: any) => {
        console.error('❌ Error submitting Justification Report request:', error);
        this.isSubmitting = false;
        this.toastService.clearProcessing();
        this.toastService.showError(error.message || 'Failed to submit Justification Report request');
      }
    });
  }

  /**
   * Close dialog
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Refresh form data
   */
  onRefresh(): void {
    this.justificationReportForm.reset();
    this.loadJustificationReportPageData();
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  /**
   * Check if a field has error
   */
  hasError(fieldName: string): boolean {
    const field = this.justificationReportForm.get(fieldName);
    return !!(field && field.invalid && (field.touched || field.dirty));
  }

  /**
   * Get field label
   */
  getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      finYr: 'Financial Year',
      qrtr: 'Quarter',
      frmType: 'Form Type'
    };
    return labels[fieldName] || fieldName;
  }

  /**
   * Check if form can be submitted
   */
  canSubmit(): boolean {
    return this.justificationReportForm.valid && !this.isSubmitting && !this.isLoadingData && !!this.viewState;
  }

  /**
   * Get summary of selected options
   */
  getSelectedSummary(): string {
    if (!this.justificationReportForm.valid) {
      return 'Please select all options';
    }

    const values = this.justificationReportForm.value;

    // Find labels from selected values
    const selectedFY = this.financialYears.find(fy => fy.value === values.finYr);
    const selectedQtr = this.quarters.find(q => q.value === values.qrtr);
    const selectedForm = this.formTypes.find(ft => ft.value === values.frmType);

    return `${selectedForm?.label || values.frmType} for ${selectedQtr?.label || this.getQuarterDisplay(values.qrtr)} of FY ${selectedFY?.label || values.finYr}`;
  }

  /**
   * Get user-friendly quarter display label (fallback for old data)
   * TRACES uses codes: Q1=3, Q2=4, Q3=5, Q4=6
   */
  getQuarterDisplay(quarterValue: string): string {
    if (!quarterValue) return '';

    // Find label from quarters array first
    const quarter = this.quarters.find(q => q.value === quarterValue);
    if (quarter) return quarter.label;

    // Fallback: TRACES quarter mapping
    const quarterMap: { [key: string]: string } = {
      '3': 'Q1 (Apr-Jun)',
      '4': 'Q2 (Jul-Sep)',
      '5': 'Q3 (Oct-Dec)',
      '6': 'Q4 (Jan-Mar)'
    };

    return quarterMap[quarterValue] || `Quarter ${quarterValue}`;
  }
}
