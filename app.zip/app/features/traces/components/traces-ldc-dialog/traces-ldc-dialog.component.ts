import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TracesService } from '../../services/traces.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { LdcCertificate, LdcPageData, LdcFetchListResponse } from '../../models/traces.models';
import * as pdfjsLib from 'pdfjs-dist';

@Component({
  selector: 'app-traces-ldc-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './traces-ldc-dialog.component.html',
  styleUrls: ['./traces-ldc-dialog.component.css']
})
export class TracesLdcDialogComponent implements OnInit {
  @Output() close = new EventEmitter<void>();

  ldcForm: FormGroup;
  isLoadingData: boolean = false;
  isFetchingList: boolean = false;
  isDownloading: { [key: string]: boolean } = {};
  isBulkProcessing: boolean = false;
  bulkProgress: { current: number; total: number; percentage: number } | null = null;

  financialYears: string[] = [];
  certificates: LdcCertificate[] = [];
  viewState: string = '';

  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;

  // Expose Math to template
  Math = Math;

  constructor(
    private fb: FormBuilder,
    private tracesService: TracesService,
    private toastService: ToastService
  ) {
    this.ldcForm = this.fb.group({
      finYr: ['', Validators.required],
      pan: ['', Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)]
    });
  }

  ngOnInit(): void {
    // Configure PDF.js worker
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.4.149/pdf.worker.min.mjs`;

    this.loadLdcPageData();
  }

  /**
   * Load LDC page data (financial years dropdown)
   */
  loadLdcPageData(): void {
    this.isLoadingData = true;
    this.toastService.showProcessing('Loading LDC form options...');

    this.tracesService.getLdcPageData().subscribe({
      next: (response: LdcPageData) => {
        console.log('✅ LDC Page Data:', response);

        this.financialYears = response.financialYears;
        this.viewState = response.viewState;

        this.isLoadingData = false;
        this.toastService.clearProcessing();

        if (this.financialYears.length === 0) {
          this.toastService.showError('No financial years available. Please check your TRACES session.');
        } else {
          this.toastService.showSuccess('LDC form loaded successfully');
        }
      },
      error: (error: any) => {
        console.error('❌ Error loading LDC page:', error);
        this.isLoadingData = false;
        this.toastService.clearProcessing();

        const errorMessage = error?.error?.error?.message || error?.error?.message || error?.message || 'Failed to load LDC form';
        this.toastService.showError(errorMessage);

        // Close dialog after error
        setTimeout(() => this.onClose(), 2000);
      }
    });
  }

  /**
   * Fetch LDC certificate list
   */
  onFetchList(): void {
    if (this.ldcForm.invalid) {
      this.markFormGroupTouched(this.ldcForm);
      this.toastService.showError('Please select a financial year');
      return;
    }

    this.isFetchingList = true;
    this.certificates = [];
    this.currentPage = 1;
    this.toastService.showProcessing('Fetching LDC certificates...');

    const formValues = this.ldcForm.value;
    const request = {
      finYr: formValues.finYr,
      pan: formValues.pan || undefined
    };

    this.tracesService.fetchLdcList(request).subscribe({
      next: (response: LdcFetchListResponse) => {
        console.log('✅ LDC Certificates:', response);
        this.certificates = response.certificates;
        this.isFetchingList = false;
        this.toastService.clearProcessing();

        if (this.certificates.length === 0) {
          this.toastService.showSuccess('No LDC certificates found for the selected criteria');
        } else {
          this.toastService.showSuccess(`Found ${this.certificates.length} certificate(s)`);
        }
      },
      error: (error: any) => {
        console.error('❌ Error fetching LDC list:', error);
        this.isFetchingList = false;
        this.toastService.clearProcessing();

        const errorMessage = error?.error?.error?.message || error?.error?.message || error?.message || 'Failed to fetch LDC certificates';
        this.toastService.showError(errorMessage);
      }
    });
  }

  /**
   * Download LDC certificate PDF
   */
  onDownloadCertificate(cert: LdcCertificate): void {
    const certKey = cert.certNum;
    this.isDownloading[certKey] = true;

    const downloadParams = {
      certNumber: cert.certNum,
      sectionCode: cert.secCode,
      reqNo: cert.reqNum,
      finYr: this.ldcForm.value.finYr,
      pan: cert.pan || ''
    };

    try {
      this.tracesService.downloadLdcPdf(downloadParams);
      this.toastService.showSuccess(`Downloading certificate ${cert.certNum}...`);

      // Reset downloading state after delay
      setTimeout(() => {
        this.isDownloading[certKey] = false;
      }, 2000);
    } catch (error) {
      console.error('❌ Error downloading LDC PDF:', error);
      this.isDownloading[certKey] = false;
      this.toastService.showError('Failed to download certificate');
    }
  }

  /**
   * Close dialog
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Refresh form data
   */
  onRefresh(): void {
    this.ldcForm.reset();
    this.certificates = [];
    this.currentPage = 1;
    this.loadLdcPageData();
  }

  /**
   * Clear search results
   */
  onClearResults(): void {
    this.certificates = [];
    this.currentPage = 1;
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  /**
   * Check if a field has error
   */
  hasError(fieldName: string): boolean {
    const field = this.ldcForm.get(fieldName);
    return !!(field && field.invalid && (field.touched || field.dirty));
  }

  /**
   * Get field label
   */
  getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      finYr: 'Financial Year',
      pan: 'PAN (Optional)'
    };
    return labels[fieldName] || fieldName;
  }

  /**
   * Check if fetch button can be clicked
   */
  canFetchList(): boolean {
    return this.ldcForm.valid && !this.isFetchingList && !this.isLoadingData;
  }

  /**
   * Get paginated certificates
   */
  getPaginatedCertificates(): LdcCertificate[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.certificates.slice(startIndex, endIndex);
  }

  /**
   * Get total pages
   */
  getTotalPages(): number {
    return Math.ceil(this.certificates.length / this.itemsPerPage);
  }

  /**
   * Navigate to page
   */
  goToPage(page: number): void {
    if (page >= 1 && page <= this.getTotalPages()) {
      this.currentPage = page;
    }
  }

  /**
   * Get page numbers for pagination
   */
  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();
    const pages: number[] = [];

    for (let i = 1; i <= totalPages; i++) {
      pages.push(i);
    }

    return pages;
  }

  /**
   * Format date for display
   */
  formatDate(dateStr: string): string {
    if (!dateStr) return '-';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch {
      return dateStr;
    }
  }

  /**
   * Check if certificate is currently downloading
   */
  isDownloadingCert(cert: LdcCertificate): boolean {
    return !!this.isDownloading[cert.certNum];
  }

  /**
   * Download all certificates and extract data to JSON
   * Processes 5 certificates at a time in parallel batches
   */
  async onDownloadAllAndExtract(): Promise<void> {
    if (this.certificates.length === 0) {
      this.toastService.showError('No certificates to process');
      return;
    }

    this.isBulkProcessing = true;
    this.bulkProgress = { current: 0, total: this.certificates.length, percentage: 0 };

    const extractedData: any[] = [];
    let successCount = 0;
    let failCount = 0;

    const batchSize = 5; // Process 5 certificates at a time
    const totalBatches = Math.ceil(this.certificates.length / batchSize);

    this.toastService.showProcessing(`Processing ${this.certificates.length} certificate(s) in batches of ${batchSize}...`);

    // Process certificates in batches
    for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
      const startIndex = batchIndex * batchSize;
      const endIndex = Math.min(startIndex + batchSize, this.certificates.length);
      const batchCerts = this.certificates.slice(startIndex, endIndex);

      console.log(`Processing batch ${batchIndex + 1}/${totalBatches} (certificates ${startIndex + 1}-${endIndex})`);

      // Process all certificates in this batch in parallel
      const batchPromises = batchCerts.map(async (cert, index) => {
        const globalIndex = startIndex + index;
        const serialNo = globalIndex + 1;

        try {
          // Download PDF
          const pdfBlob = await this.downloadCertificatePdf(cert);

          // Parse PDF and extract data
          const certData = await this.parseLdcPdf(pdfBlob, cert, serialNo);

          if (certData) {
            return { success: true, data: certData, index: globalIndex };
          } else {
            return { success: false, error: 'Failed to parse PDF', index: globalIndex };
          }
        } catch (error: any) {
          console.error(`Error processing certificate ${cert.certNum}:`, error);
          return { success: false, error: error.message || 'Unknown error', index: globalIndex };
        }
      });

      // Wait for all certificates in this batch to complete
      const batchResults = await Promise.all(batchPromises);

      // Process results
      batchResults.forEach(result => {
        if (result.success) {
          extractedData.push(result.data);
          successCount++;
        } else {
          failCount++;
        }

        // Update progress
        this.bulkProgress = {
          current: result.index + 1,
          total: this.certificates.length,
          percentage: Math.round(((result.index + 1) / this.certificates.length) * 100)
        };
      });

      // Small delay between batches to avoid overwhelming the server
      if (batchIndex < totalBatches - 1) {
        await this.delay(200);
      }
    }

    this.isBulkProcessing = false;
    this.bulkProgress = null;
    this.toastService.clearProcessing();

    // Sort extracted data by serial number to maintain order
    extractedData.sort((a, b) => a.serialno - b.serialno);

    // Generate and download JSON file
    if (extractedData.length > 0) {
      this.downloadJsonFile(extractedData);
      this.toastService.showSuccess(
        `Successfully processed ${successCount} certificate(s). ` +
        (failCount > 0 ? `${failCount} failed.` : '')
      );
    } else {
      this.toastService.showError('Failed to extract data from any certificate');
    }
  }

  /**
   * Download a single certificate PDF and return as Blob
   */
  private async downloadCertificatePdf(cert: LdcCertificate): Promise<Blob> {
    const downloadParams = {
      certNumber: cert.certNum,
      sectionCode: cert.secCode,
      reqNo: cert.reqNum,
      finYr: this.ldcForm.value.finYr,
      pan: cert.pan || ''
    };

    const queryParams = new URLSearchParams(downloadParams as any).toString();
    const downloadUrl = `/api/traces/ldc/download-pdf?${queryParams}`;

    const response = await fetch(downloadUrl, {
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error(`Failed to download certificate ${cert.certNum}`);
    }

    return await response.blob();
  }

  /**
   * Parse LDC PDF and extract certificate data
   */
  private async parseLdcPdf(pdfBlob: Blob, cert: LdcCertificate, serialNo: number): Promise<any | null> {
    try {
      const arrayBuffer = await pdfBlob.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

      let fullText = '';

      // Extract text from all pages
      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();

        const pageText = textContent.items
          .map((item: any) => item.str)
          .filter((str: string) => str.trim() !== '')
          .join(' ');

        fullText += pageText + ' ';
      }

      console.log(`Extracted text from ${cert.certNum}:`, fullText.substring(0, 200));

      // Extract data using regex patterns
      return this.extractCertificateData(fullText, cert, serialNo);
    } catch (error) {
      console.error(`Error parsing PDF for ${cert.certNum}:`, error);
      return null;
    }
  }

  /**
   * Extract certificate data from PDF text
   * Handles table-based format with numbered columns
   */
  private extractCertificateData(text: string, cert: LdcCertificate, serialNo: number): any {
    console.log('Full extracted text for', cert.certNum, ':', text);

    // Extract TAN Code
    let tanCode = '';
    const tanMatch = text.match(/([A-Z]{4}\d{5}[A-Z])/);
    if (tanMatch) {
      tanCode = tanMatch[1];
    }

    // Use certificate number from cert object
    const certNo = cert.certNum;

    // Extract Financial Year - look for patterns like 2019-20 or 2019-2020
    let finYear = '';
    // Try to find year in Valid From date (e.g., "06-Nov-2019" -> "2019-20")
    if (cert.validFrom) {
      const yearMatch = cert.validFrom.match(/(\d{4})/);
      if (yearMatch) {
        const year = parseInt(yearMatch[1]);
        const month = cert.validFrom.split('-')[1]; // Get month part
        const monthIndex = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].indexOf(month);

        // If month is Apr-Dec, FY is YYYY-(YY+1), else FY is (YYYY-1)-YY
        if (monthIndex >= 3) { // Apr onwards
          finYear = `${year}-${(year + 1).toString().slice(-2)}`;
        } else {
          finYear = `${year - 1}-${year.toString().slice(-2)}`;
        }
      }
    }

    // Use PAN from cert object
    const deducteePan = cert.pan || '';

    // Extract Deductee Name - find text between PAN and Section
    // The format is: [PAN] [Name] [Section] [Amount]...
    let dedName = '';
    if (deducteePan) {
      // Look for pattern: PAN followed by text, then "Section" or section code
      const namePattern = new RegExp(`${deducteePan}\\s+([A-Z\\s&.,'-]+?)\\s+(?:Section|\\d{3}[A-Z]?|\\(\\d+\\))`, 'i');
      const nameMatch = text.match(namePattern);
      if (nameMatch && nameMatch[1]) {
        dedName = nameMatch[1].trim();
        // Clean up if it contains column numbers like "(4)"
        dedName = dedName.replace(/\(\d+\)/g, '').trim();
      }

      // If still empty, try alternative pattern
      if (!dedName) {
        // Find PAN, then capture everything until we hit a number pattern or Section
        const altPattern = new RegExp(`${deducteePan}[\\s]+([A-Z][A-Z\\s&.,'-]{2,}?)\\s+(?:\\d{3}|Section|\\d+[,]|\\()`, 'i');
        const altMatch = text.match(altPattern);
        if (altMatch && altMatch[1]) {
          dedName = altMatch[1].trim();
        }
      }
    }

    // Use dates from cert object
    const validFrom = cert.validFrom;
    const validTo = cert.validTo;

    // Use section code from cert object
    const secCode = cert.secCode;

    // Extract Nature of Payment - look for text between Section and Amount/Rate
    let natOfPayment = '';
    // Pattern: Section code followed by nature text, then amount or rate
    const naturePattern = new RegExp(`${secCode}\\s+([A-Za-z\\s/&,-]+?)\\s+(?:[\\d,]+|\\d+\\.?\\d*\\s*%|\\(\\d+\\))`, 'i');
    const natureMatch = text.match(naturePattern);
    if (natureMatch && natureMatch[1]) {
      natOfPayment = natureMatch[1].trim();
      // Clean up column markers
      natOfPayment = natOfPayment.replace(/\(\d+\)/g, '').trim();
      // Remove "Amount", "Rate", "Rs." if present
      natOfPayment = natOfPayment.replace(/\b(Amount|Rate|Rs\.?)\b/gi, '').trim();
    }

    // Extract Certificate ID and Amount from table row
    // Table format: CertNum PAN Name Section NatureOfPayment CertID Amount Rate ValidFrom ValidTo
    // Example: 1AA0219ENY AAACB2894G BHARTI AIRTEL LIMITED 194J - 2334195 1.50 27-Feb-2019 31-Mar-2019
    let certId = 0;
    let certiLimit = 0;
    let rateOfTds = 0;

    // Look for pattern: Section code followed by optional dash/nature, then 7+ digit number (certID), then decimal number (rate)
    const tablePattern = new RegExp(
      `${secCode}\\s+[-]?\\s*(\\d{7,})\\s+(\\d+\\.\\d+)`,
      'i'
    );
    const tableMatch = text.match(tablePattern);

    if (tableMatch) {
      certId = parseInt(tableMatch[1]);
      certiLimit = certId; // The certificate ID is also the amount in the table
      rateOfTds = parseFloat(tableMatch[2]);
      console.log(`✅ Extracted from table: CertID=${certId}, Amount=${certiLimit}, Rate=${rateOfTds}`);
    } else {
      // Fallback: try older extraction methods
      console.log('⚠️ Table pattern not found, using fallback extraction');

      // Extract Rate of TDS - look for decimal number that looks like a percentage
      const ratePattern = /(\d+\.\d{2})\s+\d{2}-[A-Za-z]{3}-\d{4}/; // Rate before date pattern
      const rateMatch = text.match(ratePattern);
      if (rateMatch) {
        rateOfTds = parseFloat(rateMatch[1]);
      }

      // Extract Certificate ID - 7+ digit number
      const idMatches = text.match(/\b(\d{7,})\b/g);
      if (idMatches && idMatches.length > 0) {
        // Skip pincodes (usually 6 digits) and look for 7+ digit numbers
        for (const match of idMatches) {
          const num = parseInt(match);
          if (num >= 1000000) { // At least 7 digits
            certId = num;
            certiLimit = num;
            break;
          }
        }
      }
    }

    // Amount Consumed - usually 0 for new certificates
    const amtConsume = 0;

    // Extract Issue Date from "Date" field at top of certificate
    let issueDate = validFrom; // Default fallback
    const issueDatePattern = /Date\s+(\d{2}-[A-Za-z]{3}-\d{4})/i;
    const issueDateMatch = text.match(issueDatePattern);
    if (issueDateMatch && issueDateMatch[1]) {
      issueDate = issueDateMatch[1];
      console.log(`✅ Extracted Issue Date: ${issueDate}`);
    }

    // Cancellation status
    const cnclDate = 'Not Cancel';

    return {
      tanCode,
      serialno: serialNo,
      certino: certNo,
      finyear: finYear,
      deducteepan: deducteePan,
      dedname: dedName,
      validfrm: validFrom,
      validto: validTo,
      seccode: secCode,
      natofpayment: natOfPayment,
      rateoftds: rateOfTds,
      certilimit: certiLimit,
      amtconsume: amtConsume,
      issuedate: issueDate,
      cncldate: cnclDate,
      certid: certId
    };
  }

  /**
   * Download extracted data as JSON file
   * First saves to database, then downloads
   */
  private downloadJsonFile(data: any[]): void {
    this.toastService.showProcessing('Saving LDC certificates to database...');

    const finYr = this.ldcForm.value.finYr;
    const timestamp = new Date().toISOString().split('T')[0];
    const fileName = `LDC_Certificates_${finYr}_${timestamp}.json`;

    // Prepare data for database save
    const exportData = {
      type: 'LDC_EXPORT',
      totalRecords: data.length,
      financialYear: finYr,
      exportedAt: new Date().toISOString(),
      data: data
    };

    // Save to database first
    this.tracesService.saveLdcCertificatesToDb(exportData).subscribe({
      next: (response) => {
        console.log('✅ LDC certificates saved to database:', response);

        // Check if the response indicates success
        const result = response?.result?.[0];
        const isSuccess = result?.a_proc_error === 0 || result?.a_proc_error === '0';
        const message = result?.a_proc_error_message || 'Data saved successfully';

        this.toastService.clearProcessing();

        // Download JSON file regardless of database save result
        const jsonStr = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');

        link.href = url;
        link.download = fileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        if (isSuccess) {
          this.toastService.showSuccess(`${message} - Data exported successfully!`);
        } else {
          this.toastService.showError(`${message} - File downloaded anyway`);
        }
      },
      error: (error) => {
        console.error('❌ Error saving LDC certificates to database:', error);
        this.toastService.clearProcessing();

        // Still download JSON file even if database save fails
        const jsonStr = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');

        link.href = url;
        link.download = fileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        this.toastService.showError('Failed to save to database, but JSON file downloaded successfully');
      }
    });
  }

  /**
   * Utility: Delay function
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
