import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TracesService } from '../../services/traces.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import {
  TracesLoginRequest,
  CaptchaResponse,
  TracesError,
  TracesErrorType
} from '../../models/traces.models';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-traces-login-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './traces-login-dialog.component.html',
  styleUrls: ['./traces-login-dialog.component.css']
})
export class TracesLoginDialogComponent implements OnInit {
  @Output() loginSuccess = new EventEmitter<TracesLoginRequest>();
  @Output() close = new EventEmitter<void>();
  loginForm: FormGroup;
  captchaImageUrl: string | null = null;
  captchaBlob: Blob | null = null;
  isLoadingCaptcha: boolean = false;
  isLoggingIn: boolean = false;
  captchaText: string = '';
  showManualCaptchaInput: boolean = false;
  ocrAttempts: number = 0;
  maxOcrAttempts: number = 2;
    UserData: any;
      dynamicUserData: any;
  

  constructor(
    private fb: FormBuilder,
    private tracesService: TracesService,
    private toastService: ToastService,
        private userlocaldataService: UserdataService,
  ) {

    
    // Initialize form with default values for testing
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required]],
      tan: ['', [Validators.required, Validators.pattern(/^[A-Z]{4}[0-9]{5}[A-Z]$/)]],
      manualCaptcha: ['']
    });
  }

  ngOnInit(): void {
    // Fetch real captcha from TRACES via backend proxy
  this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    console.log(   this.dynamicUserData)
    if(this.dynamicUserData){
        this.loginForm.patchValue({
          username: this.dynamicUserData?.traces_id,
          password: this.dynamicUserData?.traces_pwd,
          tan: this.dynamicUserData?.tanno
        });
    }
    this.fetchCaptcha();
  }

  /**
   * Fetch captcha from TRACES via backend proxy
   */
  fetchCaptcha(): void {
    this.isLoadingCaptcha = true;
    this.captchaImageUrl = null;
    this.captchaText = '';
    this.showManualCaptchaInput = false;

    console.log('🔹 Fetching captcha via backend proxy...');
    this.toastService.showProcessing('Fetching captcha...');

    // Step 1: Connect to TRACES first
    this.tracesService.connectToTraces().subscribe({
      next: () => {
        console.log('✅ Connected to TRACES');

        // Step 2: Fetch captcha image
        this.tracesService.fetchCaptcha().subscribe({
          next: (response) => {
            console.log('✅ Captcha fetched successfully');
            this.captchaImageUrl = response.captchaImageUrl;
            this.isLoadingCaptcha = false;
            this.toastService.clearProcessing();

            // Show manual input for user to enter captcha
            this.showManualCaptchaInput = true;

            // Optional: Try OCR if image bytes are available
            if (response.imageBytes && response.imageBytes.length > 0) {
              this.attemptOcr(response.imageBytes);
            }
          },
          error: (error) => {
            console.error('❌ Failed to fetch captcha:', error);
            this.isLoadingCaptcha = false;
            this.toastService.clearProcessing();
            this.toastService.showError('Failed to fetch captcha. Please try again.');
            // Show manual input as fallback
            this.showManualCaptchaInput = true;
          }
        });
      },
      error: (error) => {
        console.error('❌ Failed to connect to TRACES:', error);
        this.isLoadingCaptcha = false;
        this.toastService.clearProcessing();
        this.toastService.showError('Failed to connect to TRACES. Make sure backend server is running.');
        // Show manual input as fallback
        this.showManualCaptchaInput = true;
      }
    });
  }

  /**
   * Attempt OCR on captcha image (optional)
   */
  private attemptOcr(imageBytes: number[]): void {
    console.log('🔹 Attempting OCR on captcha...');

    this.tracesService.performOcr(imageBytes).subscribe({
      next: (response) => {
        if (response.success && response.captchaText && response.captchaText.length > 0) {
          console.log('✅ OCR successful:', response.captchaText);
          this.captchaText = response.captchaText;
          this.showManualCaptchaInput = false; // Hide manual input if OCR succeeded
          this.toastService.showSuccess(`Captcha recognized: ${response.captchaText}`);
        } else {
          console.log('⚠️ OCR failed, using manual input');
          this.showManualCaptchaInput = true;
        }
      },
      error: (error) => {
        console.error('❌ OCR error:', error);
        this.showManualCaptchaInput = true; // Fallback to manual input
      }
    });
  }

  /**
   * Simulate captcha fetch (placeholder until backend is implemented)
   */
  private simulateCaptchaFetch(): void {
    // This is a placeholder. In production, this should call a backend endpoint
    // that fetches the captcha and performs OCR

    setTimeout(() => {
      // Create a placeholder captcha image (gray box with text)
      this.captchaImageUrl = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjYwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0IiBmaWxsPSIjOTk5IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+Q2FwdGNoYSBQbGFjZWhvbGRlcjwvdGV4dD48L3N2Zz4=';
      this.isLoadingCaptcha = false;

      // Show manual input since we don't have backend yet
      this.showManualCaptchaInput = true;
    }, 500);
  }

  /**
   * Retry captcha fetch
   */
  retryCaptcha(): void {
    this.ocrAttempts++;
    if (this.ocrAttempts >= this.maxOcrAttempts) {
      this.showManualCaptchaInput = true;
      this.toastService.showError('OCR failed. Please enter captcha manually.');
    } else {
      this.fetchCaptcha();
    }
  }

  /**
   * Handle login form submission
   */
  onLogin(): void {
    if (this.loginForm.invalid) {
      this.markFormGroupTouched(this.loginForm);
      this.toastService.showError('Please fill all required fields correctly');
      return;
    }

    const formValues = this.loginForm.value;

    // Get captcha text (either from OCR or manual input)
    const finalCaptchaText = this.showManualCaptchaInput
      ? formValues.manualCaptcha
      : this.captchaText;

    if (!finalCaptchaText) {
      this.toastService.showError('Please enter the captcha');
      return;
    }

    this.isLoggingIn = true;
    this.toastService.showProcessing('Logging in to TRACES...');

    const loginRequest: TracesLoginRequest = {
      username: formValues.username,
      password: formValues.password,
      tan: formValues.tan,
      captchaText: finalCaptchaText
    };

    // TODO: Call actual login method through TracesService
    // For now, simulate login
    this.simulateLogin(loginRequest);
  }

  /**
   * Simulate login (placeholder until backend is implemented)
   */
  private simulateLogin(request: TracesLoginRequest): void {
    console.log('Login Request:', request);

    setTimeout(() => {
      this.isLoggingIn = false;
      this.toastService.clearProcessing();

      // Simulate success
      // In production, this should call tracesService.login() which calls backend
      this.toastService.showSuccess('Credentials validated! Connecting to TRACES...');

      // Emit login credentials to parent component
      this.loginSuccess.emit(request);
    }, 1500);
  }

  /**
   * Cancel login and close dialog
   */
  onCancel(): void {
    console.log('Login cancelled');
    this.close.emit();
  }

  /**
   * Mark all form fields as touched to show validation errors
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  /**
   * Check if a form field has an error
   */
  hasError(fieldName: string, errorType: string): boolean {
    const field = this.loginForm.get(fieldName);
    return !!(field && field.hasError(errorType) && (field.touched || field.dirty));
  }

  /**
   * Get error message for a field
   */
  getErrorMessage(fieldName: string): string {
    const field = this.loginForm.get(fieldName);

    if (!field || !field.errors) {
      return '';
    }

    if (field.hasError('required')) {
      return `${this.getFieldLabel(fieldName)} is required`;
    }

    if (field.hasError('minlength')) {
      const minLength = field.errors['minlength'].requiredLength;
      return `${this.getFieldLabel(fieldName)} must be at least ${minLength} characters`;
    }

    if (field.hasError('pattern')) {
      return `${this.getFieldLabel(fieldName)} format is invalid`;
    }

    return 'Invalid field';
  }

  /**
   * Get user-friendly field label
   */
  private getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      username: 'Username',
      password: 'Password',
      tan: 'TAN',
      manualCaptcha: 'Captcha'
    };
    return labels[fieldName] || fieldName;
  }

  /**
   * Check if form is ready to submit
   */
  canSubmit(): boolean {
    const hasManualCaptcha = this.showManualCaptchaInput && this.loginForm.get('manualCaptcha')?.value;
    const hasOcrCaptcha = !this.showManualCaptchaInput && this.captchaText;

    return this.loginForm.valid && (hasManualCaptcha || hasOcrCaptcha) && !this.isLoggingIn;
  }
}
