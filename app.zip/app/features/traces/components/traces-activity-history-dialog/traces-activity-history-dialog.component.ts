import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivityHistoryService } from '../../services/activity-history.service';
import { DemandSummaryCacheService } from '../../services/demand-summary-cache.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { ActivityHistoryItem, ActivityType, ActivityStatus, CachedDemandSummary } from '../../models/traces.models';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-traces-activity-history-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './traces-activity-history-dialog.component.html',
  styleUrls: ['./traces-activity-history-dialog.component.css']
})
export class TracesActivityHistoryDialogComponent implements OnInit, OnDestroy {
  @Output() close = new EventEmitter<void>();
  @Output() viewDemandSummary = new EventEmitter<CachedDemandSummary>();

  activities: ActivityHistoryItem[] = [];
  filteredActivities: ActivityHistoryItem[] = [];

  // Filters
  selectedType: ActivityType | 'ALL' = 'ALL';
  selectedStatus: ActivityStatus | 'ALL' = 'ALL';
  searchQuery: string = '';

  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;

  // Statistics
  stats: {
    total: number;
    byType: { [key in ActivityType]?: number };
    byStatus: { [key in ActivityStatus]?: number };
    todayCount: number;
  } = {
    total: 0,
    byType: {},
    byStatus: {},
    todayCount: 0
  };

  // Expose enums to template
  activityTypes: (ActivityType | 'ALL')[] = [
    'ALL',
    'CONSO_FILE_REQUEST',
    'LDC_DOWNLOAD',
    'DEMAND_SUMMARY_VIEW',
    'DEMAND_DETAILS_VIEW',
    'FILE_DOWNLOAD',
    'LOGIN',
    'DISCONNECT'
  ];

  activityStatuses: (ActivityStatus | 'ALL')[] = [
    'ALL',
    'SUCCESS',
    'PENDING',
    'PROCESSING',
    'READY',
    'FAILED'
  ];

  Math = Math;

  private subscription?: Subscription;

  constructor(
    private activityHistoryService: ActivityHistoryService,
    private cacheService: DemandSummaryCacheService,
    private toastService: ToastService
  ) {}

  ngOnInit(): void {
    this.loadActivities();
    this.loadStatistics();

    // Subscribe to activity changes
    this.subscription = this.activityHistoryService.activities$.subscribe(activities => {
      this.activities = activities;
      this.applyFilters();
      this.loadStatistics();
    });
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  loadActivities(): void {
    this.activities = this.activityHistoryService.getAllActivities();
    this.applyFilters();
  }

  loadStatistics(): void {
    this.stats = this.activityHistoryService.getStatistics();
  }

  applyFilters(): void {
    let filtered = [...this.activities];

    // Filter by type
    if (this.selectedType !== 'ALL') {
      filtered = filtered.filter(a => a.activityType === this.selectedType);
    }

    // Filter by status
    if (this.selectedStatus !== 'ALL') {
      filtered = filtered.filter(a => a.status === this.selectedStatus);
    }

    // Filter by search query
    if (this.searchQuery.trim()) {
      const query = this.searchQuery.toLowerCase();
      filtered = filtered.filter(a =>
        a.description.toLowerCase().includes(query) ||
        a.requestId?.toLowerCase().includes(query) ||
        a.formType?.toLowerCase().includes(query) ||
        a.tan?.toLowerCase().includes(query)
      );
    }

    this.filteredActivities = filtered;
    this.currentPage = 1; // Reset to first page when filters change
  }

  onTypeFilterChange(): void {
    this.applyFilters();
  }

  onStatusFilterChange(): void {
    this.applyFilters();
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  clearFilters(): void {
    this.selectedType = 'ALL';
    this.selectedStatus = 'ALL';
    this.searchQuery = '';
    this.applyFilters();
  }

  get paginatedActivities(): ActivityHistoryItem[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredActivities.slice(start, end);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredActivities.length / this.itemsPerPage);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  /**
   * View cached demand summary from activity history
   */
  viewCachedDemandSummary(activity: ActivityHistoryItem): void {
    console.log('📦 View cached demand summary - Activity:', activity);
    console.log('📦 Metadata:', activity.metadata);

    const financialYear = activity.metadata?.financialYear || activity.financialYear;
    const quarter = activity.metadata?.quarter || activity.quarter;

    console.log('📦 Financial Year:', financialYear);
    console.log('📦 Quarter:', quarter);

    if (!financialYear || !quarter) {
      console.error('❌ Missing financial year or quarter:', { financialYear, quarter, metadata: activity.metadata });
      this.toastService.showError('Missing financial year or quarter information');
      return;
    }

    const cached = this.cacheService.getCachedSummary(financialYear, quarter);

    console.log('📦 Cached data:', cached);

    if (cached) {
      const cacheAge = this.cacheService.getCacheAge(cached.cachedAt);
      this.toastService.showSuccess(`Loading cached data from ${cacheAge}`);
      this.viewDemandSummary.emit(cached);
      this.onClose();
    } else {
      this.toastService.showError('Cached data no longer available. Please fetch latest from TRACES.');
    }
  }

  deleteActivity(id: string): void {
    if (confirm('Are you sure you want to delete this activity?')) {
      this.activityHistoryService.deleteActivity(id);
      this.toastService.showSuccess('Activity deleted successfully');
    }
  }

  clearAllHistory(): void {
    if (confirm('Are you sure you want to clear all activity history? This action cannot be undone.')) {
      this.activityHistoryService.clearHistory();
      this.toastService.showSuccess('Activity history cleared');
    }
  }

  onClose(): void {
    this.close.emit();
  }

  getActivityTypeLabel(type: ActivityType | 'ALL'): string {
    const labels: { [key: string]: string } = {
      'ALL': 'All Types',
      'CONSO_FILE_REQUEST': 'CONSO File Request',
      'LDC_DOWNLOAD': 'LDC Download',
      'DEMAND_SUMMARY_VIEW': 'Demand Summary',
      'DEMAND_DETAILS_VIEW': 'Demand Details',
      'FILE_DOWNLOAD': 'File Download',
      'LOGIN': 'Login',
      'DISCONNECT': 'Disconnect'
    };
    return labels[type] || type;
  }

  getActivityTypeIcon(type: ActivityType): string {
    const icons: { [key in ActivityType]: string } = {
      'CONSO_FILE_REQUEST': 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      'LDC_DOWNLOAD': 'M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      'DEMAND_SUMMARY_VIEW': 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      'DEMAND_DETAILS_VIEW': 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',
      'FILE_DOWNLOAD': 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4',
      'LOGIN': 'M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1',
      'DISCONNECT': 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1'
    };
    return icons[type];
  }

  getStatusClass(status: ActivityStatus): string {
    const classes: { [key in ActivityStatus]: string } = {
      'SUCCESS': 'bg-green-100 text-green-800',
      'PENDING': 'bg-yellow-100 text-yellow-800',
      'PROCESSING': 'bg-blue-100 text-blue-800',
      'READY': 'bg-purple-100 text-purple-800',
      'FAILED': 'bg-red-100 text-red-800'
    };
    return classes[status];
  }

  getStatusIcon(status: ActivityStatus): string {
    const icons: { [key in ActivityStatus]: string } = {
      'SUCCESS': 'M5 13l4 4L19 7',
      'PENDING': 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
      'PROCESSING': 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
      'READY': 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
      'FAILED': 'M6 18L18 6M6 6l12 12'
    };
    return icons[status];
  }

  formatTimestamp(timestamp: Date): string {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;

    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
