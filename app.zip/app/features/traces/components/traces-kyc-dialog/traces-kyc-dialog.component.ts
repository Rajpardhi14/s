import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TracesService } from '../../services/traces.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import {
  KycPageData,
  KycSubmitRequest,
  KycSubmitResponse
} from '../../models/traces.models';

@Component({
  selector: 'app-traces-kyc-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './traces-kyc-dialog.component.html',
  styleUrls: ['./traces-kyc-dialog.component.css']
})
export class TracesKycDialogComponent implements OnInit {
  @Input() kyctURL: string = '';
  @Input() finYr: string = '';
  @Input() qrtr: string = '';
  @Input() frmType: string = '';
  @Output() submitSuccess = new EventEmitter<KycSubmitResponse>();
  @Output() close = new EventEmitter<void>();

  kycForm: FormGroup;
  isLoadingData: boolean = false;
  isSubmitting: boolean = false;

  // KYC page data
  token: string = '';
  tan: string = '';

  constructor(
    private fb: FormBuilder,
    private tracesService: TracesService,
    private toastService: ToastService
  ) {
    this.kycForm = this.fb.group({
      token: ['', [Validators.required, Validators.pattern(/^\d{10,}$/)]],
      bsr: ['', [Validators.required, Validators.pattern(/^\d{7}$/)]],
      dtoftaxdep: ['', Validators.required],
      csn: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      chlnamt: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      dedCount: [''],
      pan1: ['', Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)],
      amt1: ['', Validators.pattern(/^\d+$/)],
      pan2: ['', Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)],
      amt2: ['', Validators.pattern(/^\d+$/)],
      pan3: ['', Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)],
      amt3: ['', Validators.pattern(/^\d+$/)]
    });
  }

  ngOnInit(): void {
    if (this.kyctURL) {
      // Load KYC page data to pre-fill form
      this.loadKYCPageData();
    }
  }

  /**
   * Auto-submit KYC (without manual form filling)
   * This prevents session timeout by processing all steps immediately
   */
  autoSubmitKyc(): void {
    this.isSubmitting = true;
    this.toastService.showProcessing('Processing KYC automatically (Steps 0-8)... Please wait...');

    console.log('🤖 Auto-submitting KYC for URL:', this.kyctURL);

    // Build simplified request with only kyctURL
    // Backend will extract all data automatically from the HTML
    const submitRequest: KycSubmitRequest = {
      kyctURL: this.kyctURL,
      kycData: undefined as any  // Backend will extract this automatically
    };

    this.tracesService.submitKyc(submitRequest).subscribe({
      next: (response: KycSubmitResponse) => {
        console.log('✅ Auto KYC Submit Response:', response);
        this.isSubmitting = false;
        this.toastService.clearProcessing();

        if (response.status === 'SUCCESS') {
          this.toastService.showSuccess(`Download request created successfully! Request ID: ${response.requestId}`);
          this.submitSuccess.emit(response);

          // Close dialog after success
          setTimeout(() => this.onClose(), 2000);
        } else {
          this.toastService.showError(response.message || 'KYC submission failed');
        }
      },
      error: (error: any) => {
        console.error('❌ Error auto-submitting KYC:', error);
        this.isSubmitting = false;
        this.toastService.clearProcessing();

        // Extract error message from nested response structure
        // Backend sends: { success: false, error: { message: "..." } }
        // Angular wraps it in HttpErrorResponse, so actual message is at error.error.error.message
        const errorMessage = error?.error?.error?.message || error?.error?.message || error?.message || 'Failed to submit KYC. Please try again.';
        this.toastService.showError(errorMessage);

        // Close dialog after error
        setTimeout(() => this.onClose(), 3000);
      }
    });
  }

  /**
   * OLD METHOD: Load KYC page data (token, TAN, etc.)
   * This is now unused - we auto-submit instead
   */
  loadKYCPageData(): void {
    this.isLoadingData = true;
    this.toastService.showProcessing('Loading KYC form...');

    this.tracesService.getKycPageData(this.kyctURL).subscribe({
      next: (response: KycPageData) => {
        console.log('✅ KYC Page Data:', response);

        this.token = response.token || '';
        this.tan = response.tan || '';

        this.isLoadingData = false;
        this.toastService.clearProcessing();

        if (!this.token) {
          this.toastService.showError('Failed to extract token from KYC page. Please try again.');
        } else {
          this.toastService.showSuccess('KYC form loaded successfully');
        }
      },
      error: (error: any) => {
        console.error('❌ Error loading KYC page:', error);
        this.isLoadingData = false;
        this.toastService.clearProcessing();

        // Extract error message from nested response structure
        const errorMessage = error?.error?.error?.message || error?.error?.message || error?.message || 'Failed to load KYC form';
        this.toastService.showError(errorMessage);

        // Close dialog after error
        setTimeout(() => this.onClose(), 2000);
      }
    });
  }

  /**
   * Submit KYC form
   */
  onSubmit(): void {
    if (this.kycForm.invalid) {
      this.markFormGroupTouched(this.kycForm);
      this.toastService.showError('Please fill in all required fields correctly');
      return;
    }

    if (!this.tan) {
      this.toastService.showError('Missing TAN. Please refresh and try again.');
      return;
    }

    this.isSubmitting = true;
    this.toastService.showProcessing('Submitting KYC and creating download request...');

    const formValues = this.kycForm.value;

    // Build KYC data object
    const kycData = {
      stmtSpecKyc: '1',
      frmType0: this.frmType,
      bforeLogin: '3',
      kycEntryFrm: 'NORMAL_KYC',
      finYr0: this.finYr,
      qrtr0: this.qrtr,
      tan: this.tan,
      token: formValues.token,  // Use form value instead of extracted token
      isChlnNil: 'true',
      dedCount: formValues.dedCount || '',
      cinbinValue: '',
      bkEntryValue: '',
      bkEntryFlgChk: 'false',
      bsr: formValues.bsr,
      dtoftaxdep: formValues.dtoftaxdep,
      csn: formValues.csn,
      chlnamt: formValues.chlnamt,
      panAmtValue: '',
      pan1: formValues.pan1 || '',
      amt1: formValues.amt1 || '',
      pan2: formValues.pan2 || '',
      amt2: formValues.amt2 || '',
      pan3: formValues.pan3 || '',
      amt3: formValues.amt3 || ''
    };

    const submitRequest: KycSubmitRequest = {
      kyctURL: this.kyctURL,
      kycData
    };

    this.tracesService.submitKyc(submitRequest).subscribe({
      next: (response: KycSubmitResponse) => {
        console.log('✅ KYC Submit Response:', response);
        this.isSubmitting = false;
        this.toastService.clearProcessing();

        if (response.status === 'SUCCESS') {
          this.toastService.showSuccess(`Download request created! Request ID: ${response.requestId}`);
          this.submitSuccess.emit(response);

          // Close dialog after success
          setTimeout(() => this.onClose(), 2000);
        } else {
          this.toastService.showError(response.message || 'KYC submission failed');
        }
      },
      error: (error: any) => {
        console.error('❌ Error submitting KYC form:', error);
        this.isSubmitting = false;
        this.toastService.clearProcessing();

        // Extract error message from nested response structure
        const errorMessage = error?.error?.error?.message || error?.error?.message || error?.message || 'Failed to submit KYC form';
        this.toastService.showError(errorMessage);
      }
    });
  }

  /**
   * Close dialog
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Refresh form data
   */
  onRefresh(): void {
    this.kycForm.reset();
    this.loadKYCPageData();
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  /**
   * Check if a field has error
   */
  hasError(fieldName: string): boolean {
    const field = this.kycForm.get(fieldName);
    return !!(field && field.invalid && (field.touched || field.dirty));
  }

  /**
   * Get field label
   */
  getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      token: 'Token Number',
      bsr: 'BSR Code (7 digits)',
      dtoftaxdep: 'Date of Tax Deposit',
      csn: 'Challan Serial Number',
      chlnamt: 'Challan Amount',
      dedCount: 'Deductee Count',
      pan1: 'PAN 1',
      amt1: 'Amount 1',
      pan2: 'PAN 2',
      amt2: 'Amount 2',
      pan3: 'PAN 3',
      amt3: 'Amount 3'
    };
    return labels[fieldName] || fieldName;
  }

  /**
   * Check if form can be submitted
   */
  canSubmit(): boolean {
    return this.kycForm.valid && !this.isSubmitting && !this.isLoadingData && !!this.tan;
  }
}
