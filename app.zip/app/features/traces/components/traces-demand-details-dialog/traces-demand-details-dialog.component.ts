import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DemandDetailsData } from '../../models/traces.models';

@Component({
  selector: 'app-traces-demand-details-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './traces-demand-details-dialog.component.html',
  styleUrls: ['./traces-demand-details-dialog.component.css']
})
export class TracesDemandDetailsDialogComponent {
  @Input() demandDetails!: DemandDetailsData;
  @Input() finYrLabel: string = '';
  @Input() quarterLabel: string = '';
  @Input() formType: string = '';
  @Output() close = new EventEmitter<void>();

  /**
   * Close dialog
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Stop event propagation when clicking inside dialog
   */
  onDialogClick(event: MouseEvent): void {
    event.stopPropagation();
  }
}
