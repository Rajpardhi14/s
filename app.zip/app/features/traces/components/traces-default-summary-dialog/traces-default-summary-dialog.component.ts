import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TracesService } from '../../services/traces.service';
import { DemandSummaryCacheService } from '../../services/demand-summary-cache.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { DefaultSummaryPageData } from '../../models/traces.models';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';

@Component({
  selector: 'app-traces-default-summary-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './traces-default-summary-dialog.component.html',
  styleUrls: ['./traces-default-summary-dialog.component.css']
})
export class TracesDefaultSummaryDialogComponent implements OnInit {
  @Input() pageData!: DefaultSummaryPageData;
  @Output() submitSuccess = new EventEmitter<any>();
  @Output() close = new EventEmitter<void>();

  defaultSummaryForm: FormGroup;

  financialYears: { value: string; label: string }[] = [];
  quarters: { value: string; label: string }[] = [];
  viewState: string = '';

  // Hardcoded financial years for bulk mode (2007 to 2025)
  bulkFinancialYears: { value: string; label: string }[] = [
    { value: '2025', label: '2025-26' },
    { value: '2024', label: '2024-25' },
    { value: '2023', label: '2023-24' },
    { value: '2022', label: '2022-23' },
    { value: '2021', label: '2021-22' },
    { value: '2020', label: '2020-21' },
    { value: '2019', label: '2019-20' },
    { value: '2018', label: '2018-19' },
    { value: '2017', label: '2017-18' },
    { value: '2016', label: '2016-17' },
    { value: '2015', label: '2015-16' },
    { value: '2014', label: '2014-15' },
    { value: '2013', label: '2013-14' },
    { value: '2012', label: '2012-13' },
    { value: '2011', label: '2011-12' },
    { value: '2010', label: '2010-11' },
    { value: '2009', label: '2009-10' },
    { value: '2008', label: '2008-09' },
    { value: '2007', label: '2007-08' }
  ];

  // Results display
  showResults: boolean = false;

  // Bulk fetch
  isBulkFetching: boolean = false;
  bulkResults: any[] = [];
  bulkProgress: { current: number; total: number; percentage: number } | null = null;


  constructor(
    private fb: FormBuilder,
    private tracesService: TracesService,
    private toastService: ToastService,
    private cacheService: DemandSummaryCacheService,
    private userdataService: UserdataService
  ) {
    this.defaultSummaryForm = this.fb.group({
      fromFinYr: ['', Validators.required],
      toFinYr: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    console.log('📋 Default Summary Dialog - PageData received:', this.pageData);

    if (this.pageData) {
      this.financialYears = this.pageData.financialYears;
      this.quarters = this.pageData.quarters;
      this.viewState = this.pageData.viewState;

      console.log('📋 Financial Years:', this.financialYears);
      console.log('📋 Quarters:', this.quarters);
      console.log('📋 ViewState:', this.viewState);

      if (this.financialYears.length === 0) {
        this.toastService.showError('No financial years available. Please check your TRACES session.');
      }
    } else {
      console.error('❌ No pageData provided to dialog!');
    }
  }

  /**
   * Submit Default Summary form - Fetch from TRACES
   */
  onSubmit(): void {
    if (this.defaultSummaryForm.invalid) {
      this.markFormGroupTouched(this.defaultSummaryForm);
      this.toastService.showError('Please select from and to financial year');
      return;
    }
    this.fetchBulkData();
  }


  /**
   * Fetch bulk demand data for selected year range
   */
  fetchBulkData(): void {
    const formValues = this.defaultSummaryForm.value;
    const fromYear = parseInt(formValues.fromFinYr);
    const toYear = parseInt(formValues.toFinYr);

    // Validate year range
    if (toYear < fromYear) {
      this.toastService.showError('To Financial Year must be greater than or equal to From Financial Year');
      return;
    }

    // Get selected years in the range from hardcoded bulk financial years
    const selectedYears = this.bulkFinancialYears.filter(fy => {
      const year = parseInt(fy.value);
      return year >= fromYear && year <= toYear;
    });

    if (selectedYears.length === 0) {
      this.toastService.showError('No financial years found in the selected range');
      return;
    }

    // Get selected form type from user data
    const dynamicUserData = this.userdataService.getAllDynamicUserData();
    const formType = dynamicUserData?.default_tds_type_code || '24Q';

    console.log(`📝 Using selected form type: ${formType}`);

    const totalCombinations = selectedYears.length * 4;
    this.isBulkFetching = true;
    this.bulkProgress = { current: 0, total: totalCombinations, percentage: 0 };

    const fromLabel = this.bulkFinancialYears.find(fy => fy.value === formValues.fromFinYr)?.label || formValues.fromFinYr;
    const toLabel = this.bulkFinancialYears.find(fy => fy.value === formValues.toFinYr)?.label || formValues.toFinYr;

    this.toastService.showProcessing(`Fetching demand summary from ${fromLabel} to ${toLabel} (all quarters) for form ${formType}...`);

    console.log(`📤 Starting bulk fetch from ${fromLabel} to ${toLabel}...`);
    console.log('📅 Selected years:', selectedYears.map(y => y.label).join(', '));
    console.log(`📊 Total combinations: ${totalCombinations}`);

    this.tracesService.fetchBulkDemandDataByRange(selectedYears, formType).subscribe({
      next: (response: any) => {
        if (response.status === 'PROCESSING') {
          // Update progress
          this.bulkProgress = response.progress;
          console.log(`📊 Progress: ${response.progress.percentage}%`);
        } else if (response.status === 'SUCCESS') {
          // All data fetched
          console.log('✅ Bulk fetch completed:', response);
          this.isBulkFetching = false;
          this.toastService.clearProcessing();

          this.bulkResults = response.data;
          this.showResults = true;

          this.toastService.showSuccess(
            `Bulk fetch completed! Retrieved data for ${response.successfulRequests} out of ${response.totalRequests} combinations.`
          );

          // Emit success event
          this.submitSuccess.emit({
            type: 'BULK_FETCH',
            data: response.data,
            summary: response
          });
        }
      },
      error: (error: any) => {
        console.error('❌ Error in bulk fetch:', error);
        this.isBulkFetching = false;
        this.bulkProgress = null;
        this.toastService.clearProcessing();
        this.toastService.showError(error.message || 'Failed to fetch bulk demand data');
      }
    });
  }


  /**
   * Close dialog
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Refresh form data
   */
  onRefresh(): void {
    this.defaultSummaryForm.reset();
    this.showResults = false;
    this.bulkResults = [];
  }

  /**
   * Go back to form view
   */
  onBackToForm(): void {
    this.showResults = false;
    this.bulkResults = [];
    this.bulkProgress = null;
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  /**
   * Check if a field has error
   */
  hasError(fieldName: string): boolean {
    const field = this.defaultSummaryForm.get(fieldName);
    return !!(field && field.invalid && (field.touched || field.dirty));
  }

  /**
   * Get field label
   */
  getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      finYr: 'Financial Year',
      qrtr: 'Quarter'
    };
    return labels[fieldName] || fieldName;
  }

  /**
   * Check if form can be submitted
   */
  canSubmit(): boolean {
    return this.defaultSummaryForm.valid && !this.isBulkFetching;
  }

  /**
   * Export bulk results to JSON file (matches TRACES format structure)
   */
  exportToJson(): void {
    if (this.bulkResults.length === 0) {
      this.toastService.showError('No data to export');
      return;
    }

    // Show processing notification
    this.toastService.showProcessing('Saving data to database...');

    try {
      // Transform to match exact TRACES format structure from sau_.txt
      const exportData: any[] = [];

      this.bulkResults.forEach(result => {
        if (result.demands && result.demands.length > 0) {
          result.demands.forEach((demand: any) => {
            const formattedItem: any = {
              finyear: result.finYr,
              finYr: result.finYrLabel,
              quarter: demand.Quarter || `Q${result.qrtr}`,
              formType: demand.FormType,
              amount: demand.NetPayable,
              link: `/app/ded/demsummarydm.xhtml?fy=${result.finYr}&quarterdesc=${demand.Quarter || 'Q' + result.qrtr}&qr=${result.qrtr}&ft=${demand.FormType}&finyrdesc=${result.finYrLabel}`,
              data: "",
              dataParsed: {}
            };

            // Add detailed breakdown if available
            if (demand.details && demand.detailsFetchStatus === 'SUCCESS') {
              formattedItem.dataParsed = {
                statementInfo: (demand.details.statements || []).map((stmt: any) => ({
                  statement: stmt.type || '',
                  token: stmt.tokenNumber || '',
                  orderPassedDate: stmt.orderPassedDate || ''
                })),
                countStatement: {
                  "Count of Correction Statement(s)": demand.details.correctionStatementsCount?.toString() || demand.NetPayable
                },
                summeryD: (demand.details.detailedBreakdown || []).map((item: any, index: number) => {
                  const row: any = {
                    "Sr.No.": item.srNo || (index + 1).toString(),
                    "Type of Default": item.typeOfDefault || '',
                    "Default Amount (Rs.)": item.defaultAmount || '0.00',
                    "Amount Reported As Interst /Others Clamed in the Statement/Manage Demand beyond 6 Years (Rs.)": item.amountReported || '0.00',
                    "Payable (Rs.)": item.payable || '0.00'
                  };
                  return row;
                }),
                panD: {
                  "Deductees Without PAN": demand.details.panErrors?.deducteesWithoutPAN?.toString() || '0',
                  "Deductees With Invalid PAN": demand.details.panErrors?.deducteesWithInvalidPAN?.toString() || '0'
                }
              };

              // Add total row at the end of summeryD
              if (demand.details.netPayable) {
                formattedItem.dataParsed.summeryD.push({
                  "Total Payable (Rs.)": demand.NetPayable,
                  "Net Payable (Rounded-Off) (Rs.)": demand.NetPayable
                });
              }
            } else {
              // Empty data parsed structure if details not available
              formattedItem.dataParsed = {
                statementInfo: [],
                countStatement: {
                  "Count of Correction Statement(s)": demand.NetPayable
                },
                summeryD: [],
                panD: {
                  "undefined": "\n\t\t\t\t\t\n\t\t\t\t\t "
                }
              };
            }

            exportData.push(formattedItem);
          });
        }
      });

      const exportWithFlattened = exportData;

      // First, save to database
      this.tracesService.saveDemandSummaryToDb({
        type: 'BULK_EXPORT',
        totalRecords: exportWithFlattened.length,
        data: exportWithFlattened
      }).subscribe({
        next: (response) => {
          console.log('✅ Data saved to database:', response);

          // Check if the response indicates success
          const result = response?.result?.[0];
          const isSuccess = result?.a_proc_error === 0 || result?.a_proc_error === '0';
          const message = result?.a_proc_error_message || 'Data saved successfully';

          this.toastService.clearProcessing();

          if (isSuccess) {
            // Success - proceed with download
            const jsonString = JSON.stringify(exportWithFlattened, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });

            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `TRACES_Demand_Summary_Last5Years_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);

            this.toastService.showSuccess(`${message} - Data exported successfully!`);
          } else {
            // Database save failed but still allow download
            this.toastService.showError(`${message} - Downloading anyway...`);

            const jsonString = JSON.stringify(exportWithFlattened, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });

            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `TRACES_Demand_Summary_Last5Years_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
          }
        },
        error: (error) => {
          console.error('❌ Error saving to database:', error);
          this.toastService.clearProcessing();

          // Still allow download even if save fails
          const jsonString = JSON.stringify(exportWithFlattened, null, 2);
          const blob = new Blob([jsonString], { type: 'application/json' });

          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `TRACES_Demand_Summary_Last5Years_${new Date().toISOString().split('T')[0]}.json`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);

          this.toastService.showError('Failed to save to database, but JSON downloaded successfully');
        }
      });
    } catch (error) {
      console.error('Export error:', error);
      this.toastService.clearProcessing();
      this.toastService.showError('Failed to export data to JSON');
    }
  }


  /**
   * Group bulk results by financial year for display
   */
  getBulkResultsByYear(): Array<{ year: string; quarters: any[] }> {
    const grouped = new Map<string, any[]>();

    this.bulkResults.forEach(result => {
      const year = result.finYrLabel || result.finYr;
      if (!grouped.has(year)) {
        grouped.set(year, []);
      }
      grouped.get(year)?.push(result);
    });

    // Convert map to array and sort by year (descending)
    return Array.from(grouped.entries())
      .map(([year, quarters]) => ({
        year,
        quarters: quarters.sort((a, b) => parseInt(a.qrtr) - parseInt(b.qrtr))
      }))
      .sort((a, b) => {
        // Extract start year from format "2023-24" -> 2023
        const yearA = parseInt(a.year.split('-')[0]);
        const yearB = parseInt(b.year.split('-')[0]);
        return yearB - yearA; // Descending order (latest first)
      });
  }

  /**
   * Convert TRACES quarter value (3,4,5,6) to display label (1,2,3,4)
   * TRACES uses: Q1=3, Q2=4, Q3=5, Q4=6
   * We display: Q1, Q2, Q3, Q4
   */
  getQuarterLabel(qrtr: string | number): number {
    const qtrNum = typeof qrtr === 'string' ? parseInt(qrtr) : qrtr;
    // Map TRACES quarter values to display labels
    // 3 → 1, 4 → 2, 5 → 3, 6 → 4
    return qtrNum - 2;
  }

  /**
   * Get count of successful bulk fetches
   */
  get bulkSuccessCount(): number {
    return this.bulkResults.filter(r => r.demands && r.demands.length > 0).length;
  }

  /**
   * Get count of failed/empty bulk fetches
   */
  get bulkFailureCount(): number {
    return this.bulkResults.filter(r => !r.demands || r.demands.length === 0).length;
  }

  /**
   * Get summary of selected year range for bulk fetch
   */
  getBulkYearRangeSummary(): string {
    const formValues = this.defaultSummaryForm.value;
    if (!formValues.fromFinYr || !formValues.toFinYr) {
      return 'Please select year range';
    }

    const fromLabel = this.financialYears.find(fy => fy.value === formValues.fromFinYr)?.label || formValues.fromFinYr;
    const toLabel = this.financialYears.find(fy => fy.value === formValues.toFinYr)?.label || formValues.toFinYr;

    const fromYear = parseInt(formValues.fromFinYr);
    const toYear = parseInt(formValues.toFinYr);
    const yearCount = toYear - fromYear + 1;
    const totalCombinations = yearCount * 4;

    return `Bulk fetch from ${fromLabel} to ${toLabel} (${yearCount} years, ${totalCombinations} combinations)`;
  }
}
