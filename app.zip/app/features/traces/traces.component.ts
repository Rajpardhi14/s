import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TracesService } from './services/traces.service';
import { ActivityHistoryService } from './services/activity-history.service';
import { ToastService } from '../../core/services/toaster/toast.service';
import { TracesLoginDialogComponent } from './components/traces-login-dialog/traces-login-dialog.component';
import { TracesNsdlDialogComponent } from './components/traces-nsdl-dialog/traces-nsdl-dialog.component';
import { TracesDefaultSummaryDialogComponent } from './components/traces-default-summary-dialog/traces-default-summary-dialog.component';
import { TracesKycDialogComponent } from './components/traces-kyc-dialog/traces-kyc-dialog.component';
import { TracesLdcDialogComponent } from './components/traces-ldc-dialog/traces-ldc-dialog.component';
import { TracesActivityHistoryDialogComponent } from './components/traces-activity-history-dialog/traces-activity-history-dialog.component';
import { TracesJustificationReportDialogComponent } from './components/traces-justification-report-dialog/traces-justification-report-dialog.component';
import { TracesForm16DialogComponent } from './components/traces-form16-dialog/traces-form16-dialog.component';
import {
  TracesConnectionResponse,
  SessionStatus,
  FileRequest,
  NsdlConsoPageData,
  DefaultSummaryPageData,
  TracesLoginRequest,
  NsdlConsoSubmitResponse,
  JustificationReportSubmitResponse,
  Form16SubmitResponse,
  KycSubmitResponse
} from './models/traces.models';
import { Router } from '@angular/router';
import { DefaultsummeryComponent } from './defaultsummery/defaultsummery.component';

interface TraceCard {
  title: string;
  description: string;
  showFooter?: boolean;
}

@Component({
  selector: 'app-traces',
  standalone: true,
  imports: [
    CommonModule,
    TracesLoginDialogComponent,
    TracesNsdlDialogComponent,
    TracesDefaultSummaryDialogComponent,
    TracesKycDialogComponent,
    TracesLdcDialogComponent,
    TracesActivityHistoryDialogComponent,
    TracesJustificationReportDialogComponent,
    TracesForm16DialogComponent,
    DefaultsummeryComponent
  ],
  templateUrl: './traces.component.html',
  styleUrl: './traces.component.css'
})
export class TracesComponent implements OnInit, OnDestroy {
  activeCard: string | null = 'Default Summary'; // First card is active by default
  isConnecting: boolean = false;
  isConnected: boolean = false;
  sessionStatus: SessionStatus | null = null;
  connectionMessage: string = '';
  showConnectionStatus: boolean = false;

  // Session validation
  private sessionValidationInterval: any = null;
  private readonly SESSION_CHECK_INTERVAL = 5 * 60 * 1000; // Check every 5 minutes

  // Dialog visibility flags
  showLoginDialog: boolean = false;
  showNsdlDialog: boolean = false;
  showDefaultSummaryDialog: boolean = false;
  showKycDialog: boolean = false;
  showLdcDialog: boolean = false;
  showActivityHistoryDialog: boolean = false;
  showJustificationReportDialog: boolean = false;
  showForm16Dialog: boolean = false;

  // Dialog data
  defaultSummaryPageData: DefaultSummaryPageData | null = null;
  kycData: { kyctURL: string; finYr: string; qrtr: string; frmType: string } | null = null;
  kycSource: 'NSDL_CONSO' | 'JUSTIFICATION_REPORT' | null = null; // Track which feature initiated KYC

 traceCards: TraceCard[] = [
  {
    title: 'Default Summary',
    description: 'Retrieve Default Summary from Traces as per financial year.',
    showFooter: true
  },
  {
    title: 'CONSO File Apply',
    description: 'Apply the console file to the traces and download the updated console file.'
  },
  {
    title: 'Lower Deduction Certificate',
    description: 'Retrieve the Lower Deduction Certificate from TRACES for the relevant financial year.'
  },
  {
    title: 'Form 16 Apply and Download',
    description: 'Apply Form 16 to the traces and download the updated Form 16 file.'
  },
  {
    title: 'Justification Report',
    description: 'Apply the justification reports to the traces and download the updated justification reports file.'
  },
  {
    title: 'File TDS Return',
    description: 'Clicking \'File TDS Return\' redirects to the e-filing portal.'
  },
  {
    title: 'Unconsumed Challan',
    description: 'Retrieve and verify the details of any unconsumed challans.'
  },
  {
    title: 'Form 16 Generation',
    description: 'Download text file and utility from the traces to generate and upload form 16.'
  },
  {
    title: 'Activity History',
    description: 'View and track all your TRACES activities including file requests, downloads, and more.'
  }
];

  constructor(
    private tracesService: TracesService,
    private toastService: ToastService,
    private activityHistoryService: ActivityHistoryService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Check if there's an existing session
    this.sessionStatus = this.tracesService.getSessionStatus();
    // Only show as connected if BOTH isActive AND isAuthenticated are true
    this.isConnected = this.sessionStatus.isActive && this.sessionStatus.isAuthenticated;

    if (this.isConnected) {
      console.log('✅ Existing TRACES session found');
      this.connectionMessage = 'Connected to TRACES (Session Active)';
      this.showConnectionStatus = true;

      // Start periodic session validation
      this.startSessionValidation();
    }

    // Subscribe to session expired events
    this.tracesService.sessionExpired$.subscribe(() => {
      console.warn('🔐 Session expired notification received');
      this.handleSessionExpired();
    });
  }

  ngOnDestroy(): void {
    // Clean up session validation interval
    this.stopSessionValidation();
  }

  /**
   * Handle session expiry
   */
  private handleSessionExpired(): void {
    this.isConnected = false;
    this.isConnecting = false;
    this.sessionStatus = null;
    this.showConnectionStatus = false;
    this.connectionMessage = '';

    // Stop session validation
    this.stopSessionValidation();

    // Close any open dialogs
    this.showLoginDialog = false;
    this.showNsdlDialog = false;
    this.showDefaultSummaryDialog = false;

    this.showErrorNotification('Your TRACES session has expired. Please reconnect to continue.');
  }

  /**
   * Start periodic session validation
   * Checks every 5 minutes if the session is still valid
   */
  private startSessionValidation(): void {
    console.log('🔄 Starting session validation (checking every 5 minutes)');

    // Clear any existing interval
    this.stopSessionValidation();

    // Set up periodic validation
    this.sessionValidationInterval = setInterval(() => {
      this.validateSession();
    }, this.SESSION_CHECK_INTERVAL);
  }

  /**
   * Stop session validation interval
   */
  private stopSessionValidation(): void {
    if (this.sessionValidationInterval) {
      clearInterval(this.sessionValidationInterval);
      this.sessionValidationInterval = null;
      console.log('🛑 Session validation stopped');
    }
  }

  /**
   * Validate current session by making a lightweight API call
   * We'll use the session status endpoint to check if session is still valid
   */
  private validateSession(): void {
    if (!this.isConnected) {
      return;
    }

    console.log('🔍 Validating TRACES session...');

    // Make a lightweight API call to check if session is still valid
    // We'll use the demand summary page data fetch as it's lightweight
    this.tracesService.fetchViewDefaultSummary().subscribe({
      next: (response) => {
        console.log('✅ Session validation successful');
        // Session is still valid, do nothing
      },
      error: (error) => {
        console.warn('❌ Session validation failed:', error);
        // handleError in service will detect session expiry and emit sessionExpired$ event
        // So we don't need to do anything here - the subscription will handle it
      }
    });
  }

  /**
   * Connect Now button handler - shows login dialog
   */
  onConnectNowClick(): void {
    if (this.isConnecting) {
      console.log('⏳ Connection already in progress...');
      return;
    }

    // Show login dialog for user to enter credentials
    console.log('🔹 Opening login dialog...');
    this.showLoginDialog = true;
  }

  /**
   * Handle successful login from dialog
   */
  onLoginSuccess(credentials: TracesLoginRequest): void {
    console.log('✅ Login successful, credentials received');
    this.showLoginDialog = false;

    // Now perform the actual connection with credentials
    this.performLogin(credentials);
  }

  /**
   * Handle login cancel
   */
  onLoginCancel(): void {
    console.log('❌ Login cancelled by user');
    this.showLoginDialog = false;
  }

  /**
   * Perform actual login with credentials
   */
  private performLogin(credentials: TracesLoginRequest): void {
    console.log('🔹 Initiating TRACES login with credentials...');
    this.isConnecting = true;
    this.connectionMessage = 'Logging in to TRACES...';
    this.showConnectionStatus = true;

    // Show processing notification
    this.showProcessingNotification('Logging in to TRACES...');

    // Step 1: Connect to TRACES first
    this.tracesService.connectToTraces().subscribe({
      next: (connectResponse: TracesConnectionResponse) => {
        console.log('✅ Connected to TRACES');

        // Step 2: Now login with credentials
        this.tracesService.login(credentials).subscribe({
          next: (response: TracesConnectionResponse) => {
            console.log('✅ Login Response:', response);
            this.isConnecting = false;
            this.isConnected = response.success;
            this.connectionMessage = 'Successfully logged in to TRACES';

            // Clear processing notification
            this.clearProcessingNotification();

            if (response.success) {
              this.sessionStatus = this.tracesService.getSessionStatus();

              // Start periodic session validation
              this.startSessionValidation();

              // Track login activity
              this.activityHistoryService.addActivity(
                'LOGIN',
                'SUCCESS',
                `Successfully logged in to TRACES as ${credentials.username}`,
                {
                  tan: credentials.tan
                }
              );

              // Show success notification
              this.showSuccessNotification('Successfully logged in to TRACES!');
            }
          },
          error: (error) => {
            console.error('❌ Login Error:', error);
            this.isConnecting = false;
            this.isConnected = false;
            this.connectionMessage = `Login failed: ${error.message || 'Unknown error'}`;

            // Clear processing notification
            this.clearProcessingNotification();

            this.showErrorNotification(error.message || 'Failed to login to TRACES');
          }
        });
      },
      error: (error) => {
        console.error('❌ Connection Error:', error);
        this.isConnecting = false;
        this.isConnected = false;
        this.connectionMessage = `Connection failed: ${error.message || 'Unknown error'}`;

        // Clear processing notification
        this.clearProcessingNotification();

        this.showErrorNotification(error.message || 'Failed to connect to TRACES');
      }
    });
  }

  /**
   * Disconnect from TRACES and clear session
   */
  onDisconnectClick(): void {
    const currentTan = this.sessionStatus?.tan;

    this.tracesService.clearSession();
    this.isConnected = false;
    this.sessionStatus = null;
    this.connectionMessage = '';
    this.showConnectionStatus = false;

    // Stop session validation
    this.stopSessionValidation();

    // Track disconnect activity
    this.activityHistoryService.addActivity(
      'DISCONNECT',
      'SUCCESS',
      'Disconnected from TRACES',
      {
        tan: currentTan || undefined
      }
    );

    this.showSuccessNotification('Disconnected from TRACES');
  }

  onCardHover(cardTitle: string): void {
    this.activeCard = cardTitle;
  }

  onCardLeave(): void {
    // Keep Default Summary active when not hovering
    this.activeCard = 'Default Summary';
  }

  onConnectClick(card: TraceCard): void {
    if (!this.isConnected) {
      this.showErrorNotification('Please connect to TRACES first using the "Connect Now" button above');
      return;
    }

    console.log(`Connecting to: ${card.title}`);

    // Handle specific card actions
    switch(card.title) {
      case 'File TDS Return':
        // Redirect to e-filing portal
        window.open('https://www.incometax.gov.in/iec/foportal/', '_blank');
        break;
      case 'Default Summary':
        // Handle Default Summary connection
        this.handleDefaultSummary();
        break;
      case 'CONSO File Apply':
        // Handle CONSO File Apply
        this.handleConsoFileApply();
        break;
      case 'Lower Deduction Certificate':
        // Handle Lower Deduction Certificate
        this.handleLowerDeductionCertificate();
        break;
      case 'Activity History':
        // Handle Activity History
        this.handleActivityHistory();
        break;
      case 'Form 16 Apply and Download':
        // Handle Form 16 Apply and Download
        this.handleForm16Apply();
        break;
      case 'Justification Report':
        // Handle Justification Report
        this.handleJustificationReport();
        break;
      case 'Unconsumed Challan':
        // Handle Unconsumed Challan
        this.handleUnconsumedChallan();
        break;
      case 'Form 16 Generation':
        // Handle Form 16 Generation
        this.handleForm16Generation();
        break;
      default:
        console.log('Action not implemented for:', card.title);
    }
  }

  private handleDefaultSummary(): void {
    console.log('Fetching Default Summary page data from TRACES...');

    if (!this.isConnected) {
      this.showErrorNotification('Please connect to TRACES first');
      return;
    }

    this.showProcessingNotification('Loading default summary options...');

    this.tracesService.fetchViewDefaultSummary().subscribe({
      next: (response: DefaultSummaryPageData) => {
        console.log('✅ Default Summary Page Data:', response);
        this.clearProcessingNotification();

        if (response.status === 'SUCCESS') {
          // Store page data and show dialog
          this.defaultSummaryPageData = response;
          this.showDefaultSummaryDialog = true;
        } else {
          this.showErrorNotification(response.message || 'Failed to fetch default summary options');
        }
      },
      error: (error) => {
        console.error('❌ Error fetching default summary page data:', error);
        this.clearProcessingNotification();
        this.showErrorNotification(error.message || 'Failed to fetch default summary options');
      }
    });
  }

  private handleConsoFileApply(): void {
    console.log('Applying CONSO file to TRACES...');

    if (!this.isConnected) {
      this.showErrorNotification('Please connect to TRACES first');
      return;
    }

    // Show NSDL dialog for user to select options
    console.log('🔹 Opening NSDL dialog...');
    this.showNsdlDialog = true;
  }

  /**
   * Handle NSDL form submission success
   */
  onNsdlSubmitSuccess(response: NsdlConsoSubmitResponse): void {
    console.log('✅ NSDL form submitted successfully:', response);
    this.showNsdlDialog = false;

    if (response.redirectURL) {
      console.log('🔗 Redirect URL received:', response.redirectURL);

      // Show success message
      this.showSuccessNotification('NSDL form submitted successfully! Opening KYC verification...');

      // Store KYC data and show KYC dialog
      this.kycData = {
        kyctURL: response.redirectURL,
        finYr: response.finYr || '',
        qrtr: response.qrtr || '',
        frmType: response.frmType || ''
      };
      this.kycSource = 'NSDL_CONSO'; // Set source as NSDL CONSO

      // Open KYC dialog
      setTimeout(() => {
        this.showKycDialog = true;
      }, 500);
    }
  }

  /**
   * Handle NSDL dialog close
   */
  onNsdlDialogClose(): void {
    console.log('❌ NSDL dialog closed');
    this.showNsdlDialog = false;
  }

  /**
   * Handle Default Summary dialog close
   */
  onDefaultSummaryDialogClose(): void {
    console.log('❌ Default Summary dialog closed');
    this.showDefaultSummaryDialog = false;
  }

  /**
   * Handle Default Summary submit success
   */
  onDefaultSummarySubmitSuccess(response: any): void {
    console.log('✅ Default Summary submitted successfully:', response);

    // Track demand summary view activity
    this.activityHistoryService.addActivity(
      'DEMAND_SUMMARY_VIEW',
      'SUCCESS',
      `Viewed demand summary for FY ${response.finYrLabel || response.finYr || 'N/A'} Q${response.qrtr || 'N/A'}`,
      {
        financialYear: response.finYr,
        quarter: response.qrtr,
        tan: this.sessionStatus?.tan || undefined
      }
    );

    // TODO: Handle the response data (maybe show in a table or download)
    this.showSuccessNotification('Default Summary fetched successfully!');
  }

  /**
   * Handle KYC dialog close
   */
  onKycDialogClose(): void {
    console.log('❌ KYC dialog closed');
    this.showKycDialog = false;
    this.kycData = null;
    this.kycSource = null; // Clear source
  }

  /**
   * Handle KYC submit success
   */
  onKycSubmitSuccess(response: KycSubmitResponse): void {
    console.log('✅ KYC submitted successfully:', response);
    this.showKycDialog = false;
    const previousKycData = this.kycData;
    const source = this.kycSource; // Store source before clearing
    this.kycData = null;
    this.kycSource = null; // Clear source

    if (response.status === 'SUCCESS' && response.requestId) {
      // Track activity based on source
      if (source === 'JUSTIFICATION_REPORT') {
        this.activityHistoryService.addActivity(
          'CONSO_FILE_REQUEST',
          'SUCCESS',
          `Justification Report request created successfully - Request ID: ${response.requestId}`,
          {
            requestId: response.requestId,
            financialYear: previousKycData?.finYr,
            quarter: previousKycData?.qrtr,
            formType: previousKycData?.frmType,
            tan: this.sessionStatus?.tan || undefined
          }
        );
      } else {
        // Default to NSDL CONSO
        this.activityHistoryService.addActivity(
          'CONSO_FILE_REQUEST',
          'SUCCESS',
          `CONSO file request created successfully - Request ID: ${response.requestId}`,
          {
            requestId: response.requestId,
            financialYear: previousKycData?.finYr,
            quarter: previousKycData?.qrtr,
            formType: previousKycData?.frmType,
            tan: this.sessionStatus?.tan || undefined
          }
        );
      }

      this.showSuccessNotification(
        `Download request created successfully! Request ID: ${response.requestId}. ` +
        `Please check the "File Download" section to download your file.`
      );
    }
  }

  private handleLowerDeductionCertificate(): void {
    console.log('Opening Lower Deduction Certificate dialog...');
    this.showLdcDialog = true;
  }

  closeLdcDialog(): void {
    this.showLdcDialog = false;
  }

  /**
   * Handle Justification Report dialog close
   */
  onJustificationReportDialogClose(): void {
    console.log('❌ Justification Report dialog closed');
    this.showJustificationReportDialog = false;
  }

  /**
   * Handle Justification Report submit success
   */
  onJustificationReportSubmitSuccess(response: JustificationReportSubmitResponse): void {
    console.log('✅ Justification Report submitted successfully:', response);
    this.showJustificationReportDialog = false;

    if (response.status === 'SUCCESS') {
      // Track Justification Report request activity
      this.activityHistoryService.addActivity(
        'CONSO_FILE_REQUEST',
        'SUCCESS',
        `Justification Report request created successfully`,
        {
          financialYear: response.finYr,
          quarter: response.qrtr,
          formType: response.frmType,
          tan: this.sessionStatus?.tan || undefined
        }
      );

      this.showSuccessNotification(
        'Justification Report request created successfully! Please check the "File Download" section to download your file.'
      );
    } else if (response.status === 'REDIRECTED_TO_KYC' && response.redirectURL) {
      console.log('🔗 Redirect URL received:', response.redirectURL);

      // Show success message
      this.showSuccessNotification('Justification Report submitted! Opening KYC verification...');

      // Store KYC data and show KYC dialog
      this.kycData = {
        kyctURL: response.redirectURL,
        finYr: response.finYr || '',
        qrtr: response.qrtr || '',
        frmType: response.frmType || ''
      };
      this.kycSource = 'JUSTIFICATION_REPORT'; // Set source as Justification Report
      this.showKycDialog = true;
    } else if (response.status === 'SESSION_EXPIRED') {
      this.showErrorNotification('Session expired. Please reconnect to TRACES.');
    } else {
      this.showErrorNotification(response.message || 'Justification Report request failed');
    }
  }

  private handleActivityHistory(): void {
    console.log('Opening Activity History dialog...');
    this.showActivityHistoryDialog = true;
  }

  closeActivityHistoryDialog(): void {
    this.showActivityHistoryDialog = false;
  }

  /**
   * View cached demand summary from activity history
   */
  onViewCachedDemandSummary(cached: any): void {
    console.log('📦 Viewing cached demand summary:', cached);
    // TODO: Open Default Summary dialog and display the cached data
    // For now, just show a notification
    this.showSuccessNotification(`Viewing cached demand summary for FY ${cached.finYrLabel || cached.finYr} Q${cached.qrtr}`);
  }

  private handleForm16Apply(): void {
    console.log('Applying Form 16 to TRACES...');

    if (!this.isConnected) {
      this.showErrorNotification('Please connect to TRACES first');
      return;
    }

    // Show Form 16 dialog for user to select options
    console.log('🔹 Opening Form 16 dialog...');
    this.showForm16Dialog = true;
  }

  /**
   * Handle Form 16 dialog close
   */
  onForm16DialogClose(): void {
    console.log('❌ Form 16 dialog closed');
    this.showForm16Dialog = false;
  }

  /**
   * Handle Form 16 submit success
   */
  onForm16SubmitSuccess(response: Form16SubmitResponse): void {
    console.log('✅ Form 16 submitted successfully:', response);
    this.showForm16Dialog = false;

    if (response.status === 'SUCCESS') {
      // Track Form 16 request activity
      this.activityHistoryService.addActivity(
        'CONSO_FILE_REQUEST',
        'SUCCESS',
        `Form 16 request created successfully`,
        {
          financialYear: response.finYr,
          quarter: response.qrtr,
          formType: response.frmType,
          tan: this.sessionStatus?.tan || undefined
        }
      );

      this.showSuccessNotification(
        'Form 16 request created successfully! Please check the "File Download" section to download your file.'
      );
    } else if (response.status === 'REDIRECTED_TO_KYC' && response.redirectURL) {
      console.log('🔗 Redirect URL received:', response.redirectURL);

      // Show success message
      this.showSuccessNotification('Form 16 submitted! Opening KYC verification...');

      // Store KYC data and show KYC dialog
      this.kycData = {
        kyctURL: response.redirectURL,
        finYr: response.finYr || '',
        qrtr: response.qrtr || '',
        frmType: response.frmType || ''
      };
      this.kycSource = 'NSDL_CONSO'; // Form 16 uses same KYC flow as NSDL
      this.showKycDialog = true;
    } else if (response.status === 'SESSION_EXPIRED') {
      this.showErrorNotification('Session expired. Please reconnect to TRACES.');
    } else {
      this.showErrorNotification(response.message || 'Form 16 request failed');
    }
  }

  private handleJustificationReport(): void {
    console.log('Applying Justification Report...');

    if (!this.isConnected) {
      this.showErrorNotification('Please connect to TRACES first');
      return;
    }

    // Show Justification Report dialog for user to select options
    console.log('🔹 Opening Justification Report dialog...');
    this.showJustificationReportDialog = true;
  }

  private handleUnconsumedChallan(): void {
    console.log('Retrieving Unconsumed Challan details...');
    this.showInfoNotification('Unconsumed Challan feature coming soon!');
    // TODO: Implement unconsumed challan logic
  }

  private handleForm16Generation(): void {
    console.log('Generating Form 16...');
    this.showInfoNotification('Form 16 Generation feature coming soon!');
    // TODO: Implement Form 16 generation logic
  }

  /**
   * Show success notification using ToastService
   */
  private showSuccessNotification(message: string): void {
    console.log('✅ SUCCESS:', message);
    this.toastService.showSuccess(message);
  }

  /**
   * Show error notification using ToastService
   */
  private showErrorNotification(message: string): void {
    console.error('❌ ERROR:', message);
    this.toastService.showError(message);
  }

  /**
   * Show info notification using ToastService
   */
  private showInfoNotification(message: string): void {
    console.log('ℹ️ INFO:', message);
    this.toastService.showSuccess(message); // Using success for info messages
  }

  /**
   * Show processing notification
   */
  private showProcessingNotification(message: string): void {
    console.log('⏳ PROCESSING:', message);
    this.toastService.showProcessing(message);
  }

  /**
   * Clear processing notification
   */
  private clearProcessingNotification(): void {
    this.toastService.clearProcessing();
  }



  isConnectActive(card: TraceCard): boolean {
  return this.activeCard === card.title;
}

onCardClick(card: TraceCard): void {
  // Make clicked card active
  this.activeCard = card.title;

  // Call your existing logic
  this.onConnectClick(card);
}

/**
 * Get dynamic button text based on card and connection status
 */
getButtonText(card: TraceCard): string {
  if (!this.isConnected) {
    return 'Not Connected';
  }

  // Return action-specific text when connected
  switch(card.title) {
    case 'Default Summary':
      return 'View Summary';
    case 'CONSO File Apply':
      return 'Apply File';
    case 'Lower Deduction Certificate':
      return 'Get Certificate';
    case 'Activity History':
      return 'View History';
    case 'Form 16 Apply and Download':
      return 'Apply & Download';
    case 'Justification Report':
      return 'Get Report';
    case 'File TDS Return':
      return 'Go to Portal';
    case 'Unconsumed Challan':
      return 'View Challan';
    case 'Form 16 Generation':
      return 'Generate Form 16';
    default:
      return 'Connect Now';
  }
}

viewDefaultSummery(): void {
  this.router.navigate(['defaultsummery']);
}

}