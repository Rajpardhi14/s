/**
 * TRACES API Models and Interfaces
 * TypeScript implementation for TRACES (TDS CPC) Government Portal Integration
 */

// ==================== LOGIN & CONNECTION ====================

export interface TracesLoginRequest {
  username: string;
  password: string;
  tan: string;
  captchaText: string;
}

export interface TracesConnectionResponse {
  success: boolean;
  message: string;
  cookies?: string[];
}

// ==================== CAPTCHA ====================

export interface CaptchaResponse {
  success: boolean;
  message: string;
  captchaImageUrl: string;
  imageBytes: number[];
  cookiesCount?: number;
  timestamp?: string;
}

export interface OcrApiResponse {
  output?: {
    captcha: string;
  };
  error?: string;
}

export interface CaptchaExtractionResult {
  captchaText: string;
  success: boolean;
  error?: string;
}

// ==================== FILE DOWNLOAD ====================

export interface FileRequest {
  reqNo: string;
  reqDate: string;
  finYr: string;
  qrtr: string;
  status: string;
}

export interface FileRequestListResponse {
  success: boolean;
  message: string;
  fileRequests: FileRequest[];
  count: number;
  timestamp?: string;
}

export interface FileDownloadRequest {
  reqNo: string;
}

export interface FileDownloadResponse {
  success: string; // Download URL
}

export interface DownloadResult {
  success: boolean;
  fileName?: string;
  filePath?: string;
  message?: string;
  error?: string;
}

// ==================== NSDL CONSOLIDATED FILE ====================

export interface DropdownOption {
  value: string;
  label: string;
}

export interface NsdlConsoPageData {
  financialYears: DropdownOption[];
  quarters: DropdownOption[];
  formTypes: DropdownOption[];
  viewState: string;
}

export interface NsdlConsoSubmitRequest {
  finYr: string;
  qrtr: string;
  frmType: string;
  viewState: string;
}

export interface NsdlConsoSubmitResponse {
  status: 'SUCCESS' | 'SESSION_EXPIRED' | 'FAILED';
  redirectURL?: string;
  message?: string;
  finYr?: string;
  qrtr?: string;
  frmType?: string;
  cookies?: any[];
}

export interface NsdlDownloadPageResponse {
  status: 'SUCCESS' | 'REDIRECTED_TO_KYC' | 'SESSION_EXPIRED' | 'FAILED';
  nextURL?: string;
  pageTitle?: string;
  htmlSnippet?: string;
  message?: string;
}

// ==================== KYC & DSC ====================

export interface KycFormData {
  stmtSpecKyc: string;
  frmType0: string;
  bforeLogin: string;
  kycEntryFrm: string;
  finYr0: string;
  qrtr0: string;
  tan: string;
  token: string;
  isChlnNil: string;
  dedCount: string;
  cinbinValue: string;
  bkEntryValue: string;
  bkEntryFlgChk: string;
  bsr: string;
  dtoftaxdep: string;
  csn: string;
  chlnamt: string;
  panAmtValue: string;
  pan1?: string;
  amt1?: string;
  pan2?: string;
  amt2?: string;
  pan3?: string;
  amt3?: string;
}

export interface KycSubmitRequest {
  kyctURL: string;
  kycData?: KycFormData;
}

export interface KycSubmitResponse {
  status: 'SUCCESS' | 'SESSION_EXPIRED_STEP0' | 'SUBMISSION_FAILED';
  requestId?: string;
  confirmationUrl?: string;
  error?: string;
  message?: string;
}

export interface KycPageData {
  success: boolean;
  status: 'SUCCESS' | 'FAILED';
  message?: string;
  token: string;
  tan: string;
  timestamp?: string;
}

// ==================== DEMAND SUMMARY ====================

export interface DemandSummaryOption {
  value: string;
  label: string;
}

export interface DefaultSummaryPageData {
  status: 'SUCCESS' | 'FAILED';
  viewState: string;
  financialYears: DemandSummaryOption[];
  quarters: DemandSummaryOption[];
  htmlSnippet?: string;
  message?: string;
}

export interface DemandSummaryRequest {
  finYr: string;
  qrtr: string;
  finYrLabel?: string; // Optional - will be derived if not provided (e.g., "2023-24")
}

export interface DemandSummaryItem {
  Quarter: string;
  FormType: string;
  NetPayable: string;
}

export interface DemandSummaryResponse {
  status: 'SUCCESS' | 'FAILED';
  demands: DemandSummaryItem[];
  htmlSnippet?: string;
  message?: string;
}

// ==================== DEMAND DETAILS ====================

export interface DemandDetailsRequest {
  finYr: string;
  qrtr: string;
  formType: string;
  finYrLabel?: string;
  quarterLabel?: string;
}

export interface StatementDetail {
  type: string;
  tokenNumber: string;
  orderPassedDate: string;
}

export interface DefaultBreakdownItem {
  srNo: string;
  typeOfDefault: string;
  defaultAmount: string;
  amountReported: string;
  payable: string;
}

export interface PANErrors {
  deducteesWithoutPAN: number;
  deducteesWithInvalidPAN: number;
}

export interface DemandDetailsData {
  statements: StatementDetail[];
  correctionStatementsCount: number;
  netPayable: string;
  detailedBreakdown: DefaultBreakdownItem[];
  panErrors: PANErrors;
}

export interface DemandDetailsResponse {
  success: boolean;
  status: 'SUCCESS' | 'FAILED';
  message: string;
  data: DemandDetailsData;
  timestamp?: string;
}

// ==================== COMMON RESPONSES ====================

export interface ApiErrorResponse {
  error: string;
  message: string;
  statusCode?: number;
}

export interface SessionStatus {
  isActive: boolean;
  isAuthenticated: boolean;
  username: string | null;
  tan: string | null;
  expiresAt?: Date;
  cookies?: any[];
}

// ==================== TRACES SERVICE CONFIG ====================

export interface TracesConfig {
  baseUrl: string;
  loginUrl: string;
  captchaUrl: string;
  ocrApiUrl: string;
  ocrApiToken: string;
  ocrCsrfToken: string;
  timeout: number;
  retryAttempts: number;
}

export const DEFAULT_TRACES_CONFIG: TracesConfig = {
  baseUrl: 'https://www.tdscpc.gov.in',
  loginUrl: 'https://www.tdscpc.gov.in/app/login.xhtml?usr=Ded',
  captchaUrl: 'https://www.tdscpc.gov.in/app/srv/GetCaptchaImg',
  ocrApiUrl: 'https://api.azapi.ai/t0001c',
  ocrApiToken: 'prod-d15ef2be286e0dbb92efc0d62776af25a25aa5a733b74d14ba9ff5e2879a2a72',
  ocrCsrfToken: 'b7l7cMvzt7l9IdPkW1OVsINEWeOk60IV',
  timeout: 30000,
  retryAttempts: 3
};

// ==================== HTTP REQUEST OPTIONS ====================

export interface TracesHttpOptions {
  headers?: { [key: string]: string };
  responseType?: 'json' | 'blob' | 'text' | 'arraybuffer';
  withCredentials?: boolean;
  observe?: 'body' | 'response';
}

// ==================== UTILITY TYPES ====================

export type TracesFormType = '26Q' | '27Q' | '26QB' | '27EQ';
export type TracesQuarter = '1' | '2' | '3' | '4';

export interface TracesRequestParams {
  finYr: string;
  qrtr: TracesQuarter;
  formType: TracesFormType;
  dt?: string;
  unmFlg?: string;
}

// ==================== MULTI-FILE DOWNLOAD ====================

export interface MultiFileDownloadRequest {
  reqNos: string[];
}

export interface MultiFileDownloadResponse {
  results: DownloadResult[];
  successCount: number;
  failureCount: number;
}

// ==================== EXCEL GENERATION ====================

export interface ExcelGenerationRequest {
  startYear?: number;
  endYear?: number;
  includeDetails?: boolean;
}

export interface ExcelGenerationResponse {
  success: boolean;
  fileData?: Blob;
  fileName?: string;
  error?: string;
}

// ==================== TRACES ENDPOINTS ====================

export const TRACES_ENDPOINTS = {
  // Connection & Auth
  LOGIN_PAGE: '/app/login.xhtml?usr=Ded',
  SECURITY_CHECK: '/app/j_security_check',
  GET_CAPTCHA: '/app/srv/GetCaptchaImg',

  // File Download
  FILE_DOWNLOAD_PAGE: '/app/ded/filedownload.xhtml',
  GET_REQUEST_LIST: '/app/srv/GetReqListServlet',
  DOWNLOAD_SERVLET: '/app/srv/DownloadServlet',
  CREATE_DOWNLOAD_REQUEST: '/app/srv/CreateDwnldReqServlet',

  // NSDL Consolidated
  NSDL_CONSO_PAGE: '/app/ded/nsdlconsofile.xhtml',
  DOWNLOAD_REQ_SPEC: '/app/ded/downloadreqspec.xhtml',
  KYC_3_FORM_DSC: '/app/ded/kyc3formdsc.xhtml',
  KYC_3_FORM: '/app/ded/kyc3form.xhtml',
  KYC_3_CONFIRM: '/app/ded/kyc3confirm.xhtml',

  // Demand Summary
  VIEW_DEMAND_SUMMARY: '/app/ded/viewdemandsum.xhtml',
  DEMAND_SUMMARY: '/app/ded/demandsum.xhtml',
  DEM_SUMMARY_DETAIL: '/app/ded/demsummary.xhtml',

  // Justification Report
  JUSTI_REPORT_DOWNLOAD: '/app/ded/justrepdwnld.xhtml'
} as const;

// ==================== CONSTANTS ====================

export const TRACES_CONSTANTS = {
  USER_AGENT: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
  ACCEPT_HTML: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
  ACCEPT_JSON: 'application/json, text/javascript, */*; q=0.01',
  CONTENT_TYPE_FORM: 'application/x-www-form-urlencoded',
  CONTENT_TYPE_JSON: 'application/json',
  ACCEPT_LANGUAGE: 'en-US,en;q=0.9',
  CONNECTION: 'keep-alive',

  // Login Form Fields
  LOGIN_FIELDS: {
    SEARCH1: 'on',
    SELRADIO: 'D',
    TICKER: ''
  },

  // Session Keys
  STORAGE_KEYS: {
    TRACES_COOKIES: 'traces_cookies',
    TRACES_SESSION: 'traces_session',
    TRACES_USER: 'traces_user_data'
  }
} as const;

// ==================== ERROR TYPES ====================

export enum TracesErrorType {
  CONNECTION_ERROR = 'CONNECTION_ERROR',
  CAPTCHA_ERROR = 'CAPTCHA_ERROR',
  AUTHENTICATION_ERROR = 'AUTHENTICATION_ERROR',
  SESSION_EXPIRED = 'SESSION_EXPIRED',
  DOWNLOAD_ERROR = 'DOWNLOAD_ERROR',
  DATA_FETCH_ERROR = 'DATA_FETCH_ERROR',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  NETWORK_ERROR = 'NETWORK_ERROR',
  UNKNOWN_ERROR = 'UNKNOWN_ERROR'
}

export class TracesError extends Error {
  constructor(
    public type: TracesErrorType,
    message: string,
    public originalError?: any
  ) {
    super(message);
    this.name = 'TracesError';
  }
}

// ==================== LOWER DEDUCTION CERTIFICATE (LDC) ====================

export interface LdcPageData {
  success: boolean;
  status: string;
  message: string;
  viewState: string;
  financialYears: string[];
  timestamp: string;
}

export interface LdcCertificate {
  reqNum: string;
  secCode: string;
  validFrom: string;
  validTo: string;
  certNum: string;
  pan: string;
  remarks: string;
}

export interface LdcFetchListRequest {
  finYr: string;
  pan?: string;
}

export interface LdcFetchListResponse {
  success: boolean;
  status: string;
  message: string;
  financialYear: string;
  count: number;
  certificates: LdcCertificate[];
  timestamp: string;
}

export interface LdcDownloadParams {
  certNumber: string;
  sectionCode: string;
  reqNo: string;
  finYr: string;
  pan?: string;
}

// ==================== ACTIVITY HISTORY ====================

export type ActivityType =
  | 'CONSO_FILE_REQUEST'
  | 'LDC_DOWNLOAD'
  | 'DEMAND_SUMMARY_VIEW'
  | 'DEMAND_DETAILS_VIEW'
  | 'FILE_DOWNLOAD'
  | 'LOGIN'
  | 'DISCONNECT';

export type ActivityStatus =
  | 'SUCCESS'
  | 'PENDING'
  | 'PROCESSING'
  | 'READY'
  | 'FAILED';

export interface ActivityHistoryItem {
  id: string;                    // Unique identifier
  timestamp: Date;               // When activity occurred
  activityType: ActivityType;    // Type of activity
  status: ActivityStatus;        // Current status
  requestId?: string;            // TRACES request ID (if applicable)
  financialYear?: string;        // FY for the activity
  quarter?: string;              // Quarter for the activity
  formType?: string;             // Form type (26Q, 27Q, etc.)
  tan?: string;                  // TAN number
  description: string;           // Human-readable description
  metadata?: any;                // Additional activity-specific data
}

export interface ActivityHistoryStorage {
  activities: ActivityHistoryItem[];
  lastUpdated: Date;
}

// ==================== DEMAND SUMMARY CACHE ====================

export interface CachedDemandSummary {
  finYr: string;
  qrtr: string;
  finYrLabel?: string;
  data: DemandSummaryResponse;
  cachedAt: Date;
}

export interface DemandSummaryCacheStorage {
  summaries: CachedDemandSummary[];
  lastUpdated: Date;
}

// ==================== JUSTIFICATION REPORT ====================

export interface JustificationReportPageData {
  status: 'SUCCESS' | 'FAILED';
  financialYears: DropdownOption[];
  quarters: DropdownOption[];
  formTypes: DropdownOption[];
  viewState: string;
  message?: string;
}

export interface JustificationReportSubmitRequest {
  finYr: string;
  qrtr: string;
  frmType: string;
  viewState: string;
}

export interface JustificationReportSubmitResponse {
  status: 'SUCCESS' | 'REDIRECTED_TO_KYC' | 'SESSION_EXPIRED' | 'FAILED';
  redirectURL?: string;
  nextURL?: string;
  message?: string;
  finYr?: string;
  qrtr?: string;
  frmType?: string;
}

// ==================== FORM 16 ====================

export interface Form16PageData {
  status: 'SUCCESS' | 'FAILED';
  financialYears: DropdownOption[];
  quarters: DropdownOption[];
  formTypes: DropdownOption[];
  viewState: string;
  message?: string;
}

export interface Form16SubmitRequest {
  finYr: string;
  qrtr: string;
  frmType: string;
  viewState: string;
  dwnldFormBulkType?: string; // Default: '14'
}

export interface Form16SubmitResponse {
  status: 'SUCCESS' | 'REDIRECTED_TO_KYC' | 'SESSION_EXPIRED' | 'FAILED';
  redirectURL?: string;
  nextURL?: string;
  message?: string;
  finYr?: string;
  qrtr?: string;
  frmType?: string;
}
