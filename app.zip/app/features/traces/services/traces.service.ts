/**
 * TRACES Service
 * Handles all HTTP communication with TRACES backend proxy
 * Simplified version - backend handles all cookie management and session handling
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, Subject, forkJoin, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import {
  TracesConnectionResponse,
  TracesLoginRequest,
  CaptchaResponse,
  FileRequestListResponse,
  FileDownloadRequest,
  NsdlConsoPageData,
  NsdlConsoSubmitRequest,
  NsdlConsoSubmitResponse,
  KycPageData,
  KycSubmitRequest,
  KycSubmitResponse,
  DefaultSummaryPageData,
  DemandSummaryRequest,
  DemandSummaryResponse,
  DemandDetailsRequest,
  DemandDetailsResponse,
  JustificationReportPageData,
  JustificationReportSubmitRequest,
  JustificationReportSubmitResponse,
  Form16PageData,
  Form16SubmitRequest,
  Form16SubmitResponse,
  SessionStatus,
  TracesError,
  TracesErrorType
} from '../models/traces.models';

import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';

@Injectable({
  providedIn: 'root'
})
export class TracesService {
    private readonly API_BASE_URL = 'http://localhost:4200/api/traces';
  // private readonly API_BASE_URL = 'https://tdscpc.gstcpc.com/api/traces';
  private sessionStatus: SessionStatus = {
    isActive: false,
    isAuthenticated: false,
    username: null,
    tan: null
  };

  // Subject to notify components about session expiry
  private sessionExpiredSubject = new Subject<void>();
  public sessionExpired$ = this.sessionExpiredSubject.asObservable();

  // Subject to notify components about session status changes (connected/updated)
  private sessionStatusChangedSubject = new Subject<SessionStatus>();
  public sessionStatusChanged$ = this.sessionStatusChangedSubject.asObservable();

  constructor(
    private http: HttpClient,
    private apiservice: ApiserviceService,
    private userdataService: UserdataService
  ) {
    this.loadStoredSession();
  }

  // ==================== CONNECTION & AUTHENTICATION ====================

  /**
   * Connect to TRACES - Establish initial session
   * Calls backend: POST /api/traces/connect
   * NOTE: This just fetches the homepage to get cookies, it doesn't mean logged in
   */
  connectToTraces(): Observable<TracesConnectionResponse> {
    console.log('🔹 Connecting to TRACES via backend proxy...');

    return this.http.post<TracesConnectionResponse>(`${this.API_BASE_URL}/connect`, {}, {
      withCredentials: true // Important: Send cookies with request
    }).pipe(
      tap(response => {
        console.log('✅ Connected to TRACES (cookies established):', response);
        // Don't set isActive here - only after successful login
      }),
      catchError(error => this.handleError(error, 'Connection'))
    );
  }

  /**
   * Fetch captcha image from TRACES
   * Calls backend: POST /api/traces/captcha
   */
  fetchCaptcha(): Observable<CaptchaResponse> {
    console.log('🔹 Fetching captcha via backend proxy...');

    return this.http.post<CaptchaResponse>(`${this.API_BASE_URL}/captcha`, {}, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Captcha fetched:', response.message);
      }),
      catchError(error => this.handleError(error, 'Captcha fetch'))
    );
  }

  /**
   * Perform OCR on captcha image
   * Calls backend: POST /api/traces/ocr
   */
  performOcr(imageBytes: number[]): Observable<{ success: boolean; captchaText: string; message: string }> {
    console.log('🔹 Performing OCR via backend proxy...');

    return this.http.post<{ success: boolean; captchaText: string; message: string }>(
      `${this.API_BASE_URL}/ocr`,
      { imageBytes },
      { withCredentials: true }
    ).pipe(
      tap(response => {
        console.log('✅ OCR completed:', response.captchaText);
      }),
      catchError(error => this.handleError(error, 'OCR'))
    );
  }

  /**
   * Login to TRACES with credentials
   * Calls backend: POST /api/traces/login
   */
  login(credentials: TracesLoginRequest): Observable<TracesConnectionResponse> {
    console.log('🔹 Logging in to TRACES via backend proxy...');

    return this.http.post<TracesConnectionResponse>(`${this.API_BASE_URL}/login`, credentials, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Login successful:', response);
        if (response.success) {
          this.sessionStatus = {
            isActive: true,
            isAuthenticated: true,
            username: credentials.username,
            tan: credentials.tan
          };
          this.saveSessionToStorage();
          // Notify all subscribers about session status change
          this.sessionStatusChangedSubject.next(this.sessionStatus);
        }
      }),
      catchError(error => this.handleError(error, 'Login'))
    );
  }

  /**
   * Get current session status
   * Calls backend: GET /api/traces/session-status
   */
  getSessionStatus(): SessionStatus {
    // Return cached status, or fetch from backend if needed
    return this.sessionStatus;
  }

  /**
   * Fetch session status from backend
   */
  refreshSessionStatus(): Observable<SessionStatus> {
    return this.http.get<SessionStatus>(`${this.API_BASE_URL}/session-status`, {
      withCredentials: true
    }).pipe(
      tap(status => {
        this.sessionStatus = status;
        this.saveSessionToStorage();
      }),
      catchError(error => {
        console.error('Failed to fetch session status:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Clear session and disconnect
   * Calls backend: POST /api/traces/disconnect
   */
  clearSession(): void {
    this.http.post(`${this.API_BASE_URL}/disconnect`, {}, {
      withCredentials: true
    }).subscribe({
      next: () => {
        console.log('✅ Disconnected from TRACES');
        this.sessionStatus = {
          isActive: false,
          isAuthenticated: false,
          username: null,
          tan: null
        };
        this.clearStoredSession();
        // Notify all subscribers about session status change
        this.sessionStatusChangedSubject.next(this.sessionStatus);
      },
      error: (error) => {
        console.error('Error disconnecting:', error);
        // Clear local session anyway
        this.sessionStatus = {
          isActive: false,
          isAuthenticated: false,
          username: null,
          tan: null
        };
        this.clearStoredSession();
        // Notify all subscribers about session status change
        this.sessionStatusChangedSubject.next(this.sessionStatus);
      }
    });
  }

  // ==================== FILE DOWNLOAD OPERATIONS ====================

  /**
   * Get all file requests from TRACES
   * Calls backend: GET /api/traces/file-requests
   */
  getFileRequests(): Observable<FileRequestListResponse> {
    console.log('🔹 Fetching file requests via backend proxy...');

    return this.http.get<FileRequestListResponse>(`${this.API_BASE_URL}/file-requests`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log(`✅ File requests fetched: ${response.count} files`);
      }),
      catchError(error => this.handleError(error, 'File requests fetch'))
    );
  }

  /**
   * Download single file by request number
   * Calls backend: POST /api/traces/download-file
   */
  downloadFile(request: FileDownloadRequest): Observable<Blob> {
    console.log(`🔹 Downloading file ${request.reqNo} via backend proxy...`);

    return this.http.post(`${this.API_BASE_URL}/download-file`, request, {
      withCredentials: true,
      responseType: 'blob'
    }).pipe(
      tap((blob: Blob) => {
        console.log(`✅ File downloaded: ${blob.size} bytes`);
        // Auto-download the file
        this.saveFile(blob, `TRACES_${request.reqNo}.zip`);
      }),
      catchError(error => this.handleError(error, 'File download'))
    );
  }

  /**
   * Download multiple files
   * Calls backend: POST /api/traces/download-multiple
   */
  downloadMultipleFiles(reqNos: string[]): Observable<any> {
    console.log(`🔹 Downloading ${reqNos.length} files via backend proxy...`);

    return this.http.post(`${this.API_BASE_URL}/download-multiple`, { reqNos }, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Multiple files download initiated');
      }),
      catchError(error => this.handleError(error, 'Multiple files download'))
    );
  }

  // ==================== NSDL CONSOLIDATED FILE ====================

  /**
   * Get NSDL page data (dropdowns and viewState)
   * Calls backend: GET /api/traces/nsdl/page-data
   */
  getNsdlPageData(): Observable<NsdlConsoPageData> {
    console.log('🔹 Fetching NSDL page data via backend proxy...');

    return this.http.get<NsdlConsoPageData>(`${this.API_BASE_URL}/nsdl/page-data`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ NSDL page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'NSDL page data fetch'))
    );
  }

  /**
   * Submit NSDL form selection
   * Calls backend: POST /api/traces/nsdl/submit
   */
  submitNsdlForm(request: NsdlConsoSubmitRequest): Observable<NsdlConsoSubmitResponse> {
    console.log('🔹 Submitting NSDL form via backend proxy...');

    return this.http.post<NsdlConsoSubmitResponse>(`${this.API_BASE_URL}/nsdl/submit`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ NSDL form submitted:', response);
      }),
      catchError(error => this.handleError(error, 'NSDL form submit'))
    );
  }

  /**
   * Get KYC page data (token, TAN)
   * Calls backend: GET /api/traces/kyc/page-data
   */
  getKycPageData(kyctURL: string): Observable<KycPageData> {
    console.log('🔹 Fetching KYC page data...');

    const params = new URLSearchParams({ kyctURL });

    return this.http.get<KycPageData>(`${this.API_BASE_URL}/kyc/page-data?${params.toString()}`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ KYC page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'KYC page data fetch'))
    );
  }

  /**
   * Submit KYC and generate download request
   * Calls backend: POST /api/nsdl/submit-kyc
   */
  submitKyc(request: KycSubmitRequest): Observable<KycSubmitResponse> {
    console.log('🔹 Submitting KYC form and generating download request...');

    return this.http.post<KycSubmitResponse>('/api/nsdl/submit-kyc', request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ KYC submitted and download request created:', response);
      }),
      catchError(error => this.handleError(error, 'KYC submit'))
    );
  }

  // ==================== DEMAND SUMMARY ====================

  /**
   * Get demand summary page data
   * Calls backend: GET /api/traces/demand-summary
   */
  fetchViewDefaultSummary(): Observable<DefaultSummaryPageData> {
    console.log('🔹 Fetching demand summary page data via backend proxy...');

    return this.http.get<DefaultSummaryPageData>(`${this.API_BASE_URL}/demand-summary`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Demand summary page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'Demand summary fetch'))
    );
  }

  /**
   * Fetch demand data for specific FY and Quarter
   * Calls backend: POST /api/traces/fetch-demand
   */
  fetchDemandData(request: DemandSummaryRequest): Observable<DemandSummaryResponse> {
    console.log('🔹 Fetching demand data via backend proxy...');

    return this.http.post<DemandSummaryResponse>(`${this.API_BASE_URL}/fetch-demand`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Demand data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'Demand data fetch'))
    );
  }

  /**
   * Fetch detailed demand breakdown for specific demand
   * Calls backend: POST /api/traces/fetch-demand-details
   */
  fetchDemandDetails(request: DemandDetailsRequest): Observable<DemandDetailsResponse> {
    console.log('🔹 Fetching demand details via backend proxy...');

    return this.http.post<DemandDetailsResponse>(`${this.API_BASE_URL}/fetch-demand-details`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Demand details fetched:', response);
      }),
      catchError(error => this.handleError(error, 'Demand details fetch'))
    );
  }

  /**
   * Fetch bulk demand data for a specific range of years
   * @param selectedYears - Array of years to fetch
   * @param formType - Form type (24Q, 26Q, etc.) selected by user
   */
  fetchBulkDemandDataByRange(selectedYears: { value: string; label: string }[], formType: string): Observable<any> {
    console.log(`🔹 Fetching bulk demand data for ${selectedYears.length} selected years...`);
    console.log(`📅 Years:`, selectedYears.map(y => y.label).join(', '));
    console.log(`📝 Form Type:`, formType);

    return this.fetchSequentially(this.buildYearQuarterRequests(selectedYears, formType));
  }

  /**
   * Build array of all FY-Quarter combinations for given years
   */
  private buildYearQuarterRequests(years: { value: string; label: string }[], formType: string): Array<{ finYr: string; qrtr: string; finYrLabel: string; formType: string }> {
    // TRACES uses quarter values 3, 4, 5, 6 (not 1, 2, 3, 4)
    // Q1 (Apr-Jun) = 3, Q2 (Jul-Sep) = 4, Q3 (Oct-Dec) = 5, Q4 (Jan-Mar) = 6
    const quarters = ['3', '4', '5', '6'];
    const requests: Array<{ finYr: string; qrtr: string; finYrLabel: string; formType: string }> = [];

    years.forEach(year => {
      quarters.forEach(qtr => {
        requests.push({
          finYr: year.value,
          qrtr: qtr,
          finYrLabel: year.label,
          formType: formType
        });
      });
    });

    console.log(`📋 Total combinations to fetch: ${requests.length} (Form Type: ${formType})`);
    return requests;
  }

  /**
   * Fetch demand data for last N years, all quarters in bulk (DEPRECATED - use fetchBulkDemandDataByRange)
   * Returns aggregated data for all FY-Quarter combinations
   * Fetches from current FY backwards (e.g., 2024-25, 2023-24, 2022-23, 2021-22, 2020-21)
   */
  fetchBulkDemandData(financialYears: { value: string; label: string }[], yearsCount: number = 5): Observable<any> {
    console.log(`🔹 Fetching bulk demand data for current FY + last ${yearsCount - 1} years...`);

    // HARDCODED: Calculate current FY and work backwards
    // Financial year starts in April, so if current month is Jan-Mar, we're still in previous FY
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1; // 1-12

    // If we're between Jan-Mar, current FY started last year
    // If we're between Apr-Dec, current FY started this year
    let currentFYStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;

    console.log(`📅 Current Date: ${today.toISOString().split('T')[0]}`);
    console.log(`📅 Calculated Current FY Start Year: ${currentFYStartYear}`);

    // Build last N years starting from current FY
    const targetYears: { value: string; label: string }[] = [];
    for (let i = 0; i < yearsCount; i++) {
      const fyStartYear = currentFYStartYear - i;
      const fyEndYear = fyStartYear + 1;

      // Match the year with available years in financialYears array
      const matchedYear = financialYears.find(fy => parseInt(fy.value) === fyStartYear);

      if (matchedYear) {
        targetYears.push(matchedYear);
      } else {
        // If not found in array, create it manually
        targetYears.push({
          value: fyStartYear.toString(),
          label: `${fyStartYear}-${fyEndYear.toString().slice(-2)}`
        });
      }
    }

    console.log(`✅ HARDCODED Selected target years (${targetYears.length}):`, targetYears.map(y => `${y.value}:${y.label}`).join(', '));

    const quarters = ['1', '2', '3', '4'];

    // Create array of all FY-Quarter combinations
    const requests: Array<{ finYr: string; qrtr: string; finYrLabel: string }> = [];
    targetYears.forEach(year => {
      quarters.forEach(qtr => {
        requests.push({
          finYr: year.value,
          qrtr: qtr,
          finYrLabel: year.label
        });
      });
    });

    console.log(`📋 Total combinations to fetch: ${requests.length}`);

    // Use forkJoin to make all requests in parallel (or sequentially with delayWhen)
    // For now, let's make them sequentially to avoid overwhelming the server
    return this.fetchSequentially(requests);
  }

  /**
   * Fetch demand data sequentially with delay to avoid server overload
   */
  private fetchSequentially(requests: Array<{ finYr: string; qrtr: string; finYrLabel: string; formType?: string }>): Observable<any> {
    const results: any[] = [];
    let completed = 0;

    return new Observable(observer => {
      const fetchNext = (index: number) => {
        if (index >= requests.length) {
          // All requests completed
          observer.next({
            status: 'SUCCESS',
            message: `Successfully fetched ${completed} out of ${requests.length} combinations`,
            totalRequests: requests.length,
            successfulRequests: completed,
            failedRequests: requests.length - completed,
            data: results
          });
          observer.complete();
          return;
        }

        const request = requests[index];
        console.log(`📤 Fetching [${index + 1}/${requests.length}] FY: ${request.finYrLabel}, Q${request.qrtr}${request.formType ? `, Form: ${request.formType}` : ''}`);

        // Emit progress update
        observer.next({
          status: 'PROCESSING',
          progress: {
            current: index + 1,
            total: requests.length,
            percentage: Math.round(((index + 1) / requests.length) * 100)
          },
          currentRequest: request
        });

        // If formType is present, call fetchDemandDetails directly (new approach)
        // Otherwise use the old two-step process
        if (request.formType) {
          // NEW APPROACH: Direct call to fetchDemandDetails with form type
          const quarterLabel = request.qrtr === '3' ? 'Q1' : request.qrtr === '4' ? 'Q2' : request.qrtr === '5' ? 'Q3' : 'Q4';

          this.fetchDemandDetails({
            finYr: request.finYr,
            qrtr: request.qrtr,
            formType: request.formType,
            finYrLabel: request.finYrLabel,
            quarterLabel: quarterLabel
          }).subscribe({
            next: (detailResponse) => {
              if (detailResponse.status === 'SUCCESS' && detailResponse.data) {
                console.log(`✅ [${index + 1}/${requests.length}] Details fetched successfully`);

                // Format the response to match expected structure
                const enrichedDemand = {
                  Quarter: quarterLabel,
                  FormType: request.formType,
                  NetPayable: detailResponse.data.netPayable || '0.00',
                  financialYear: request.finYr,
                  financialYearLabel: request.finYrLabel,
                  quarter: request.qrtr,
                  details: detailResponse.data,
                  detailsFetchStatus: 'SUCCESS'
                };

                results.push({
                  finYr: request.finYr,
                  finYrLabel: request.finYrLabel,
                  qrtr: request.qrtr,
                  demands: [enrichedDemand],
                  fetchedAt: new Date().toISOString()
                });
                completed++;

                // Add small delay before next request
                setTimeout(() => fetchNext(index + 1), 500);
              } else {
                console.warn(`⚠️ [${index + 1}/${requests.length}] No data or failed`);
                results.push({
                  finYr: request.finYr,
                  finYrLabel: request.finYrLabel,
                  qrtr: request.qrtr,
                  demands: [],
                  error: detailResponse.message || 'No data available',
                  fetchedAt: new Date().toISOString()
                });

                setTimeout(() => fetchNext(index + 1), 500);
              }
            },
            error: (error) => {
              console.error(`❌ [${index + 1}/${requests.length}] Error:`, error.message);
              results.push({
                finYr: request.finYr,
                finYrLabel: request.finYrLabel,
                qrtr: request.qrtr,
                demands: [],
                error: error.message || 'Failed to fetch',
                fetchedAt: new Date().toISOString()
              });

              setTimeout(() => fetchNext(index + 1), 500);
            }
          });
        } else {
          // OLD APPROACH: Two-step process (for backward compatibility)
          this.fetchDemandData(request).subscribe({
          next: (response: DemandSummaryResponse) => {
            if (response.status === 'SUCCESS' && response.demands && response.demands.length > 0) {
              console.log(`✅ [${index + 1}/${requests.length}] Summary fetched: ${response.demands.length} demands found. Fetching details...`);

              // Fetch details for each demand
              const detailRequests = response.demands.map(demand =>
                this.fetchDemandDetails({
                  finYr: request.finYr,
                  qrtr: request.qrtr,
                  formType: demand.FormType,
                  finYrLabel: request.finYrLabel,
                  quarterLabel: `Q${request.qrtr}`
                }).pipe(
                  catchError(err => {
                    console.warn(`⚠️ Failed to fetch details for ${demand.FormType}:`, err.message);
                    return of({ status: 'ERROR', data: null, message: err.message });
                  })
                )
              );

              // Fetch all details in parallel for this FY-Quarter
              forkJoin(detailRequests).subscribe({
                next: (detailResponses) => {
                  // Merge details with demands
                  const enrichedDemands = response.demands.map((demand, idx) => ({
                    ...demand,
                    financialYear: request.finYr,
                    financialYearLabel: request.finYrLabel,
                    quarter: request.qrtr,
                    details: detailResponses[idx]?.status === 'SUCCESS' ? detailResponses[idx].data : null,
                    detailsFetchStatus: detailResponses[idx]?.status || 'ERROR'
                  }));

                  results.push({
                    finYr: request.finYr,
                    finYrLabel: request.finYrLabel,
                    qrtr: request.qrtr,
                    demands: enrichedDemands,
                    fetchedAt: new Date().toISOString()
                  });
                  completed++;
                  console.log(`✅ [${index + 1}/${requests.length}] Complete with details: ${enrichedDemands.length} demands`);

                  // Add small delay before next request to avoid server overload
                  setTimeout(() => fetchNext(index + 1), 500);
                },
                error: (error) => {
                  console.error(`❌ [${index + 1}/${requests.length}] Error fetching details:`, error.message);

                  // Still save the summary data even if details failed
                  const enrichedDemands = response.demands.map(demand => ({
                    ...demand,
                    financialYear: request.finYr,
                    financialYearLabel: request.finYrLabel,
                    quarter: request.qrtr,
                    details: null,
                    detailsFetchStatus: 'ERROR'
                  }));

                  results.push({
                    finYr: request.finYr,
                    finYrLabel: request.finYrLabel,
                    qrtr: request.qrtr,
                    demands: enrichedDemands,
                    fetchedAt: new Date().toISOString()
                  });
                  completed++;

                  // Continue with next request
                  setTimeout(() => fetchNext(index + 1), 500);
                }
              });
            } else {
              console.warn(`⚠️ [${index + 1}/${requests.length}] No data or failed`);
              results.push({
                finYr: request.finYr,
                finYrLabel: request.finYrLabel,
                qrtr: request.qrtr,
                demands: [],
                error: response.message || 'No data available',
                fetchedAt: new Date().toISOString()
              });

              // Add small delay before next request
              setTimeout(() => fetchNext(index + 1), 500);
            }
          },
          error: (error) => {
            console.error(`❌ [${index + 1}/${requests.length}] Error:`, error.message);
            results.push({
              finYr: request.finYr,
              finYrLabel: request.finYrLabel,
              qrtr: request.qrtr,
              demands: [],
              error: error.message || 'Failed to fetch',
              fetchedAt: new Date().toISOString()
            });

            // Continue with next request even if this one fails
            setTimeout(() => fetchNext(index + 1), 500);
          }
        });
        } // End of else block (old two-step approach)
      };

      // Start fetching
      fetchNext(0);
    });
  }

  // ==================== JUSTIFICATION REPORT ====================

  /**
   * Get Justification Report page data (dropdowns and viewState)
   * Calls backend: GET /api/traces/justification-report/page-data
   */
  getJustificationReportPageData(): Observable<JustificationReportPageData> {
    console.log('🔹 Fetching Justification Report page data via backend proxy...');

    return this.http.get<JustificationReportPageData>(`${this.API_BASE_URL}/justification-report/page-data`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Justification Report page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'Justification Report page data fetch'))
    );
  }

  /**
   * Submit Justification Report request
   * Calls backend: POST /api/traces/justification-report/submit
   */
  submitJustificationReportRequest(request: JustificationReportSubmitRequest): Observable<JustificationReportSubmitResponse> {
    console.log('🔹 Submitting Justification Report request via backend proxy...');

    return this.http.post<JustificationReportSubmitResponse>(`${this.API_BASE_URL}/justification-report/submit`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Justification Report request submitted:', response);
      }),
      catchError(error => this.handleError(error, 'Justification Report submit'))
    );
  }

  // ==================== FORM 16 ====================

  /**
   * Get Form 16 page data (dropdowns and viewState)
   * Calls backend: GET /api/traces/form16/page-data
   */
  getForm16PageData(): Observable<Form16PageData> {
    console.log('🔹 Fetching Form 16 page data via backend proxy...');

    return this.http.get<Form16PageData>(`${this.API_BASE_URL}/form16/page-data`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Form 16 page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'Form 16 page data fetch'))
    );
  }

  /**
   * Submit Form 16 request
   * Calls backend: POST /api/traces/form16/submit
   */
  submitForm16Request(request: Form16SubmitRequest): Observable<Form16SubmitResponse> {
    console.log('🔹 Submitting Form 16 request via backend proxy...');

    return this.http.post<Form16SubmitResponse>(`${this.API_BASE_URL}/form16/submit`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ Form 16 request submitted:', response);
      }),
      catchError(error => this.handleError(error, 'Form 16 submit'))
    );
  }

  // ==================== LOWER DEDUCTION CERTIFICATE (LDC) ====================

  /**
   * Get LDC page data (financial years dropdown)
   * Calls backend: GET /api/traces/ldc/page-data
   */
  getLdcPageData(): Observable<any> {
    console.log('🔹 Fetching LDC page data...');

    return this.http.get<any>(`${this.API_BASE_URL}/ldc/page-data`, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ LDC page data fetched:', response);
      }),
      catchError(error => this.handleError(error, 'LDC page data fetch'))
    );
  }

  /**
   * Fetch list of LDC certificates for given financial year
   * Calls backend: POST /api/traces/ldc/fetch-list
   */
  fetchLdcList(request: any): Observable<any> {
    console.log('🔹 Fetching LDC certificate list...');

    return this.http.post<any>(`${this.API_BASE_URL}/ldc/fetch-list`, request, {
      withCredentials: true
    }).pipe(
      tap(response => {
        console.log('✅ LDC certificate list fetched:', response);
      }),
      catchError(error => this.handleError(error, 'LDC certificate list fetch'))
    );
  }

  /**
   * Download LDC certificate as PDF
   * Calls backend: GET /api/traces/ldc/download-pdf
   */
  downloadLdcPdf(params: any): void {
    console.log('🔹 Downloading LDC certificate PDF...');

    const queryParams = new URLSearchParams(params).toString();
    const downloadUrl = `${this.API_BASE_URL}/ldc/download-pdf?${queryParams}`;

    // Create temporary link and trigger download
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `LDC_${params.certNumber}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    console.log('✅ LDC PDF download initiated');
  }

  // ==================== DATA PERSISTENCE ====================

  /**
   * Save demand summary data to database
   * Following the database operation pattern from file import (line 682)
   */
  saveDemandSummaryToDb(demandData: any): Observable<any> {
    console.log('🔹 Saving demand summary to database...');

    // Get user data using UserdataService
    const localUserData = this.userdataService.getLocalUserData();
    const dynaUserData = this.userdataService.getAllDynamicUserData();

    if (!localUserData || !dynaUserData) {
      return throwError(() => new Error('User data not found. Please login first.'));
    }

    // Use generateSData like templateInsertApi does (line 682)
    const baseSdata = this.apiservice.generateSData(
      'get_tiud_tds_justification_tran',
      dynaUserData,
      [],  // filterClause
      1000,  // limit
      0,  // offset
      1,  // currentPage
      {
        FYYear: 'Yes',
        iudtype: 'i'
      }
    );

    // Add TRACES-specific fields to the generated sdata
    const sdata = {
      ...baseSdata,
      a_tanno: this.sessionStatus?.tan || '',
      traces_username: this.sessionStatus?.username || '',
      a_app_json_data_test_rowid_seq: "",
      data: demandData.data || demandData,  // Extract data array
      fetch_timestamp: new Date().toISOString()
    };

    // Use apiservice.createData for consistent API calls
    const endpoint = '/Traces/get_tiud_tds_justification_tran';

    console.log('📤 Sending demand summary with sdata:', sdata);

    return this.apiservice.createData(endpoint, sdata).pipe(
      tap(response => {
        console.log('✅ Demand summary saved to database:', response);

        // Check if the response indicates success
        if (response?.result?.[0]?.a_proc_error === 0) {
          console.log('✅ Success:', response.result[0].a_proc_error_message);
        } else if (response?.result?.[0]?.a_proc_error) {
          console.warn('⚠️ Warning:', response.result[0].a_proc_error_message);
        }
      }),
      catchError(error => {
        console.error('❌ Error saving demand summary:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Save LDC certificates data to database
   * Similar to saveDemandSummaryToDb but uses get_miud_tds_spl_rate_mast_json proc type
   */
  saveLdcCertificatesToDb(ldcData: any): Observable<any> {
    console.log('🔹 Saving LDC certificates to database...');

    // Get user data using UserdataService
    const localUserData = this.userdataService.getLocalUserData();
    const dynaUserData = this.userdataService.getAllDynamicUserData();

    if (!localUserData || !dynaUserData) {
      return throwError(() => new Error('User data not found. Please login first.'));
    }

    // Use generateSData with the LDC-specific proc type
    const baseSdata = this.apiservice.generateSData(
      'get_miud_tds_spl_rate_mast_json',
      dynaUserData,
      [],  // filterClause
      1000,  // limit
      0,  // offset
      1,  // currentPage
      {
        FYYear: 'Yes',
        iudtype: 'i'
      }
    );

    // Add TRACES-specific fields to the generated sdata
    const sdata = {
      ...baseSdata,
      a_tanno: this.sessionStatus?.tan || '',
      traces_username: this.sessionStatus?.username || '',
      a_app_json_data_test_rowid_seq: "",
      data: ldcData.data || ldcData,  // Extract data array
      fetch_timestamp: new Date().toISOString()
    };

    // Use apiservice.createData for consistent API calls
    const endpoint = '/Traces/get_miud_tds_spl_rate_mast_json';

    console.log('📤 Sending LDC certificates with sdata:', sdata);

    return this.apiservice.createData(endpoint, sdata).pipe(
      tap(response => {
        console.log('✅ LDC certificates saved to database:', response);

        // Check if the response indicates success
        if (response?.result?.[0]?.a_proc_error === 0) {
          console.log('✅ Success:', response.result[0].a_proc_error_message);
        } else if (response?.result?.[0]?.a_proc_error) {
          console.warn('⚠️ Warning:', response.result[0].a_proc_error_message);
        }
      }),
      catchError(error => {
        console.error('❌ Error saving LDC certificates:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get local user data from session storage
   */
  private getLocalUserData(): any {
    try {
      const storedData = sessionStorage.getItem('localUserData');
      return storedData ? JSON.parse(storedData) : null;
    } catch (error) {
      console.error('Error reading local user data:', error);
      return null;
    }
  }

  /**
   * Get cookie value by name
   */
  private getCookie(name: string): string | null {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : null;
  }

  // ==================== UTILITY METHODS ====================

  /**
   * Save session to localStorage
   */
  private saveSessionToStorage(): void {
    try {
      localStorage.setItem('traces_session', JSON.stringify({
        isActive: this.sessionStatus.isActive,
        isAuthenticated: this.sessionStatus.isAuthenticated,
        username: this.sessionStatus.username,
        tan: this.sessionStatus.tan,
        timestamp: new Date().toISOString()
      }));
      console.log('💾 Session saved to localStorage');
    } catch (error) {
      console.error('Failed to save session:', error);
    }
  }

  /**
   * Load session from localStorage
   */
  private loadStoredSession(): void {
    try {
      const stored = localStorage.getItem('traces_session');
      if (stored) {
        const session = JSON.parse(stored);
        // Check if session is not too old (e.g., max 30 minutes)
        const timestamp = new Date(session.timestamp).getTime();
        const now = new Date().getTime();
        const ageMinutes = (now - timestamp) / 1000 / 60;

        if (ageMinutes < 30) {
          // Validate session: must be both active AND authenticated
          const isValid = session.isActive && session.isAuthenticated && session.username && session.tan;

          if (isValid) {
            this.sessionStatus = {
              isActive: session.isActive,
              isAuthenticated: session.isAuthenticated,
              username: session.username,
              tan: session.tan
            };
            console.log('✅ Loaded valid session from localStorage');
          } else {
            console.log('❌ Invalid session data in localStorage - clearing');
            this.clearStoredSession();
          }
        } else {
          console.log('⏰ Stored session expired');
          this.clearStoredSession();
        }
      }
    } catch (error) {
      console.error('Failed to load session:', error);
    }
  }

  /**
   * Clear stored session
   */
  private clearStoredSession(): void {
    try {
      localStorage.removeItem('traces_session');
      console.log('🗑️ Cleared session from localStorage');
    } catch (error) {
      console.error('Failed to clear session:', error);
    }
  }

  /**
   * Save file to disk (trigger download)
   */
  private saveFile(blob: Blob, fileName: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    window.URL.revokeObjectURL(url);
    console.log(`📥 File saved: ${fileName}`);
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: any, context: string): Observable<never> {
    console.error(`❌ ${context} error:`, error);

    let errorMessage = 'An unexpected error occurred';
    let errorType: TracesErrorType = TracesErrorType.UNKNOWN_ERROR;

    if (error.error) {
      // Backend returned an error response
      if (typeof error.error === 'string') {
        errorMessage = error.error;
      } else if (error.error.message) {
        errorMessage = error.error.message;
      }

      // Check for error type in response
      if (error.error.error && error.error.error.type === 'SESSION_EXPIRED') {
        errorType = TracesErrorType.SESSION_EXPIRED;
      }

      // Determine error type based on error code or message
      if (error.status === 440 || error.status === 401 || errorMessage.includes('auth') || errorMessage.includes('login')) {
        if (error.status === 440 || errorMessage.includes('session') || errorMessage.includes('expired')) {
          errorType = TracesErrorType.SESSION_EXPIRED;
        } else {
          errorType = TracesErrorType.AUTHENTICATION_ERROR;
        }
      } else if (error.status === 0 || errorMessage.includes('connection') || errorMessage.includes('network')) {
        errorType = TracesErrorType.CONNECTION_ERROR;
      } else if (errorMessage.includes('captcha')) {
        errorType = TracesErrorType.CAPTCHA_ERROR;
      } else if (errorMessage.includes('session') || errorMessage.includes('expired')) {
        errorType = TracesErrorType.SESSION_EXPIRED;
      } else if (errorMessage.includes('download')) {
        errorType = TracesErrorType.DOWNLOAD_ERROR;
      } else if (errorMessage.includes('fetch') || errorMessage.includes('data')) {
        errorType = TracesErrorType.DATA_FETCH_ERROR;
      }
    } else if (error.status === 0) {
      errorMessage = 'Unable to reach backend server. Make sure the backend is running on port 3000.';
      errorType = TracesErrorType.CONNECTION_ERROR;
    } else if (error.status === 440) {
      errorMessage = 'Session expired. Please reconnect to TRACES.';
      errorType = TracesErrorType.SESSION_EXPIRED;
    } else {
      errorMessage = error.message || error.statusText || errorMessage;
    }

    // If session expired, clear local session and notify components
    if (errorType === TracesErrorType.SESSION_EXPIRED) {
      console.warn('🔐 Session expired - clearing local session');
      this.clearSession();
      this.sessionExpiredSubject.next();
    }

    const tracesError = new TracesError(errorType, errorMessage, error);
    return throwError(() => tracesError);
  }
}
