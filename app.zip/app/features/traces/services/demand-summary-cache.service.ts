import { Injectable } from '@angular/core';
import {
  CachedDemandSummary,
  DemandSummaryCacheStorage,
  DemandSummaryResponse
} from '../models/traces.models';

@Injectable({
  providedIn: 'root'
})
export class DemandSummaryCacheService {
  private readonly STORAGE_KEY = 'traces_demand_summary_cache';
  private readonly MAX_CACHE_ENTRIES = 50; // Limit cache size
  private readonly CACHE_EXPIRY_DAYS = 7; // Cache expires after 7 days

  constructor() {}

  /**
   * Get cached demand summary for specific FY and Quarter
   */
  getCachedSummary(finYr: string, qrtr: string): CachedDemandSummary | null {
    try {
      const cached = this.getAllCachedSummaries();
      const found = cached.find(c => c.finYr === finYr && c.qrtr === qrtr);

      if (found) {
        // Check if cache is expired
        const cachedDate = new Date(found.cachedAt);
        const daysDiff = Math.floor((new Date().getTime() - cachedDate.getTime()) / (1000 * 60 * 60 * 24));

        if (daysDiff <= this.CACHE_EXPIRY_DAYS) {
          return {
            ...found,
            cachedAt: new Date(found.cachedAt)
          };
        } else {
          // Cache expired, remove it
          this.removeCachedSummary(finYr, qrtr);
          return null;
        }
      }

      return null;
    } catch (error) {
      console.error('Error getting cached demand summary:', error);
      return null;
    }
  }

  /**
   * Save demand summary to cache
   */
  saveSummary(finYr: string, qrtr: string, data: DemandSummaryResponse, finYrLabel?: string): void {
    try {
      const cached = this.getAllCachedSummaries();

      // Remove existing entry for same FY and Quarter
      const filtered = cached.filter(c => !(c.finYr === finYr && c.qrtr === qrtr));

      // Add new entry
      const newEntry: CachedDemandSummary = {
        finYr,
        qrtr,
        finYrLabel,
        data,
        cachedAt: new Date()
      };

      filtered.unshift(newEntry);

      // Limit cache size
      if (filtered.length > this.MAX_CACHE_ENTRIES) {
        filtered.splice(this.MAX_CACHE_ENTRIES);
      }

      this.saveToStorage(filtered);
      console.log(`✅ Demand summary cached: FY ${finYr}, Q${qrtr}`);
    } catch (error) {
      console.error('Error saving demand summary to cache:', error);
    }
  }

  /**
   * Remove specific cached summary
   */
  removeCachedSummary(finYr: string, qrtr: string): void {
    try {
      const cached = this.getAllCachedSummaries();
      const filtered = cached.filter(c => !(c.finYr === finYr && c.qrtr === qrtr));
      this.saveToStorage(filtered);
    } catch (error) {
      console.error('Error removing cached demand summary:', error);
    }
  }

  /**
   * Get all cached summaries
   */
  getAllCachedSummaries(): CachedDemandSummary[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const data: DemandSummaryCacheStorage = JSON.parse(stored);
        return data.summaries || [];
      }
      return [];
    } catch (error) {
      console.error('Error loading cached demand summaries:', error);
      return [];
    }
  }

  /**
   * Clear all cached summaries
   */
  clearAllCache(): void {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
      console.log('🗑️ All demand summary cache cleared');
    } catch (error) {
      console.error('Error clearing demand summary cache:', error);
    }
  }

  /**
   * Get cache statistics
   */
  getCacheStats(): {
    totalEntries: number;
    oldestEntry: Date | null;
    newestEntry: Date | null;
  } {
    const cached = this.getAllCachedSummaries();

    if (cached.length === 0) {
      return {
        totalEntries: 0,
        oldestEntry: null,
        newestEntry: null
      };
    }

    const dates = cached.map(c => new Date(c.cachedAt));
    const oldest = new Date(Math.min(...dates.map(d => d.getTime())));
    const newest = new Date(Math.max(...dates.map(d => d.getTime())));

    return {
      totalEntries: cached.length,
      oldestEntry: oldest,
      newestEntry: newest
    };
  }

  /**
   * Save to localStorage
   */
  private saveToStorage(summaries: CachedDemandSummary[]): void {
    try {
      const data: DemandSummaryCacheStorage = {
        summaries,
        lastUpdated: new Date()
      };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving to demand summary cache storage:', error);
    }
  }

  /**
   * Format cache age for display
   */
  getCacheAge(cachedAt: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - cachedAt.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  }
}
