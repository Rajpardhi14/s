import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  ActivityHistoryItem,
  ActivityHistoryStorage,
  ActivityType,
  ActivityStatus
} from '../models/traces.models';

@Injectable({
  providedIn: 'root'
})
export class ActivityHistoryService {
  private readonly STORAGE_KEY = 'traces_activity_history';
  private readonly MAX_ACTIVITIES = 100; // Limit to prevent localStorage overflow

  private activitiesSubject = new BehaviorSubject<ActivityHistoryItem[]>([]);
  public activities$ = this.activitiesSubject.asObservable();

  constructor() {
    this.loadActivitiesFromStorage();
  }

  /**
   * Load activities from localStorage
   */
  private loadActivitiesFromStorage(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const data: ActivityHistoryStorage = JSON.parse(stored);
        // Convert timestamp strings back to Date objects
        const activities = data.activities.map(activity => ({
          ...activity,
          timestamp: new Date(activity.timestamp)
        }));
        this.activitiesSubject.next(activities);
      }
    } catch (error) {
      console.error('Error loading activity history from localStorage:', error);
      this.activitiesSubject.next([]);
    }
  }

  /**
   * Save activities to localStorage
   */
  private saveActivitiesToStorage(activities: ActivityHistoryItem[]): void {
    try {
      const data: ActivityHistoryStorage = {
        activities,
        lastUpdated: new Date()
      };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving activity history to localStorage:', error);
    }
  }

  /**
   * Add a new activity to history
   */
  addActivity(
    activityType: ActivityType,
    status: ActivityStatus,
    description: string,
    metadata?: {
      requestId?: string;
      financialYear?: string;
      quarter?: string;
      formType?: string;
      tan?: string;
      [key: string]: any;
    }
  ): void {
    const newActivity: ActivityHistoryItem = {
      id: this.generateId(),
      timestamp: new Date(),
      activityType,
      status,
      description,
      ...metadata
    };

    const currentActivities = this.activitiesSubject.value;
    const updatedActivities = [newActivity, ...currentActivities];

    // Limit the number of activities stored
    if (updatedActivities.length > this.MAX_ACTIVITIES) {
      updatedActivities.splice(this.MAX_ACTIVITIES);
    }

    this.activitiesSubject.next(updatedActivities);
    this.saveActivitiesToStorage(updatedActivities);

    console.log('✅ Activity added:', newActivity);
  }

  /**
   * Update an existing activity (e.g., status change from PENDING to SUCCESS)
   */
  updateActivity(id: string, updates: Partial<ActivityHistoryItem>): void {
    const currentActivities = this.activitiesSubject.value;
    const activityIndex = currentActivities.findIndex(a => a.id === id);

    if (activityIndex !== -1) {
      const updatedActivities = [...currentActivities];
      updatedActivities[activityIndex] = {
        ...updatedActivities[activityIndex],
        ...updates
      };

      this.activitiesSubject.next(updatedActivities);
      this.saveActivitiesToStorage(updatedActivities);

      console.log('✅ Activity updated:', updatedActivities[activityIndex]);
    }
  }

  /**
   * Get all activities
   */
  getAllActivities(): ActivityHistoryItem[] {
    return this.activitiesSubject.value;
  }

  /**
   * Get activities by type
   */
  getActivitiesByType(type: ActivityType): ActivityHistoryItem[] {
    return this.activitiesSubject.value.filter(a => a.activityType === type);
  }

  /**
   * Get activities by status
   */
  getActivitiesByStatus(status: ActivityStatus): ActivityHistoryItem[] {
    return this.activitiesSubject.value.filter(a => a.status === status);
  }

  /**
   * Get recent activities (default: last 10)
   */
  getRecentActivities(count: number = 10): ActivityHistoryItem[] {
    return this.activitiesSubject.value.slice(0, count);
  }

  /**
   * Clear all activity history
   */
  clearHistory(): void {
    this.activitiesSubject.next([]);
    localStorage.removeItem(this.STORAGE_KEY);
    console.log('🗑️ Activity history cleared');
  }

  /**
   * Delete a specific activity
   */
  deleteActivity(id: string): void {
    const currentActivities = this.activitiesSubject.value;
    const updatedActivities = currentActivities.filter(a => a.id !== id);

    this.activitiesSubject.next(updatedActivities);
    this.saveActivitiesToStorage(updatedActivities);

    console.log('🗑️ Activity deleted:', id);
  }

  /**
   * Get activity count
   */
  getActivityCount(): number {
    return this.activitiesSubject.value.length;
  }

  /**
   * Generate a unique ID for activities
   */
  private generateId(): string {
    return `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get activity statistics
   */
  getStatistics(): {
    total: number;
    byType: { [key in ActivityType]?: number };
    byStatus: { [key in ActivityStatus]?: number };
    todayCount: number;
  } {
    const activities = this.activitiesSubject.value;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = {
      total: activities.length,
      byType: {} as { [key in ActivityType]?: number },
      byStatus: {} as { [key in ActivityStatus]?: number },
      todayCount: 0
    };

    activities.forEach(activity => {
      // Count by type
      stats.byType[activity.activityType] = (stats.byType[activity.activityType] || 0) + 1;

      // Count by status
      stats.byStatus[activity.status] = (stats.byStatus[activity.status] || 0) + 1;

      // Count today's activities
      const activityDate = new Date(activity.timestamp);
      activityDate.setHours(0, 0, 0, 0);
      if (activityDate.getTime() === today.getTime()) {
        stats.todayCount++;
      }
    });

    return stats;
  }
}
