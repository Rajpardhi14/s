import { Component } from '@angular/core';

@Component({
  selector: 'app-defaultsummery',
  standalone: true,
  imports: [],
  templateUrl: './defaultsummery.component.html',
  styleUrl: './defaultsummery.component.css'
})
export class DefaultsummeryComponent {

}
