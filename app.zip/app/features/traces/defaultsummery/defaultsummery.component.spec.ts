import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultsummeryComponent } from './defaultsummery.component';

describe('DefaultsummeryComponent', () => {
  let component: DefaultsummeryComponent;
  let fixture: ComponentFixture<DefaultsummeryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DefaultsummeryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DefaultsummeryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
