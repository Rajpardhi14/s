import { CommonModule } from '@angular/common';
import { Component, DestroyRef, Inject, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { capitalizeEachWord, formatDatesend } from '../../shared/utils/passmatch';
import { interval, skip, Subject, Subscription, switchMap } from 'rxjs';
import { RefreshdataService } from '../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../core/services/screensize/screensize.service';
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { ToastService } from '../../core/services/toaster/toast.service';
import { XldownloadService } from '../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { TableskeletonComponent } from '../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../shared/components/nodata/nodata.component';
import { BasicFilterComponent } from '../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../shared/components/advance-filter/advance-filter.component';
import { GearboxComponent } from "../../shared/components/gearbox/gearbox.component";
import { OutSideClickDirective } from '../../core/services/outclick/outside-click.directive';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-deductee',
  standalone: true,
  imports: [BasicFilterComponent, AdvanceFilterComponent, GearboxComponent, TableskeletonComponent, NodataComponent, CommonModule, FormsModule, ReactiveFormsModule, OutSideClickDirective],
  templateUrl: './deductee.component.html',
  styleUrl: './deductee.component.css'
})
export class DeducteeComponent {

  capatilizeEachword = capitalizeEachWord
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];

  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field?: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;

  // selectedMaster: string = 'USER_MASTER';
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = "Yes";
  iudtype: string = 'ALL';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  circumference = 2 * Math.PI * 16;

  capitalizeEachWord = capitalizeEachWord;

  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private router: Router,
  ) {

  }


  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

    this.dynamicUserData$
      .pipe(
        skip(1),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(dynamicData => {

        this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
        this.offset = 0;
        this.fetchTable();
        this.fetchFilter();
        this.fetchGrandTotal();
      });

    // this.fetchTable();
    this.fetchFilter();
    //  this.startPolling();

    // this.fetchGrandTotal();

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    this.refreshSubscription = this.refreshdata.onRefresh('Deductee').subscribe(() => {
      this.fetchTable();
      this.fetchGrandTotal();

    });

  }

  // Check if all rows are selected
  isAllSelected(): boolean {
    return this.paginatedList?.every((row: any) => row.selected);
  }

  // Toggle all rows
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }

  // Get selected rows (optional helper)
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }


  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  buildMergeGroups() {
    this.headers?.forEach(header => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }


  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );

  }

  isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
    return dateFields.includes(field);
  }

  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }


  fetchTable(isClearAction = false) {

    // Ensure filterClause is always an array
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
    console.log('userFilters', userFilters);
    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
      // {
      //   filter_col_field: "deductee_panno_verified",
      //   filter_col_depend_operator: "wc",
      //   filter_col_value: this.defaultTabFilter,
      //   filter_col_field_alias: "a.",

      // }
    ];
    console.log('newFilterClause', newFilterClause);

    // Always rebuild final filterClause fresh:
    //     const finalFilterClause = [
    //       ...newFilterClause,
    //       ...userFilters.filter(
    //         (uf: any) =>
    //           !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
    //       ),
    //     ];
    // console.log(finalFilterClause);

    // ✅ Logic for which filters to use
    let finalFilterClause: any;

    if (isClearAction) {

      finalFilterClause = {

        filter_col_field: "deductee_panno_verified",
        filter_col_depend_operator: "wc",
        filter_col_value: this.defaultTabFilter ? this.defaultTabFilter : this.defaultCondition[0],
        filter_col_field_alias: "a.",

      };

    } else if (userFilters.length > 0) {
      // If user has applied filters → use user filters
      // finalFilterClause = userFilters;
      console.log(this.removedFilter);
      console.log(this.defaultTabFilter);
      if (this.defaultTabFilter) {
        newFilterClause.push({
          filter_col_field: "deductee_panno_verified",
          filter_col_depend_operator: "wc",
          filter_col_value: this.defaultTabFilter,
          filter_col_field_alias: "a.",

        })
        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...userFilters,
            ...newFilterClause.filter(
              (uf: any) =>
                !userFilters.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }
      else if (this.activeFilterTab) {
        newFilterClause.push({

          filter_col_field: this.externalColField,
          filter_col_depend_operator: "wc",
          filter_col_value: this.defaultCondition[0],
          filter_col_field_alias: "a.",
        })

        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...userFilters,
            ...newFilterClause.filter(
              (uf: any) =>
                !userFilters.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }
      else {
        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...newFilterClause,
            ...userFilters.filter(
              (uf: any) =>
                !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }

    }
    else if (this.removedFilter) {
      // If user has applied filters → use user filters
      // finalFilterClause = userFilters;
      console.log(this.removedFilter);
      finalFilterClause = userFilters;
    }
    else {
      // Initial load → use default filters
      finalFilterClause = newFilterClause;
    }

    console.log('Final Filter Clause:', finalFilterClause);

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtdb_deductee_details',
      this.localUserData,
      finalFilterClause, // always pass fresh filters
      // this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype
      },

    );

    this.apiService.getTableData('/Deductee/get_gtdb_deductee_details', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.get_gtdb_deductee_details;
          if (userData?.get_gtdb_deductee_details_header) {
            this.headers = userData?.get_gtdb_deductee_details_header?.map(
              (header: any) => ({
                ...header,
                  visible:
        this.gearboxState.hasOwnProperty(header.field)
          ? this.gearboxState[header.field] // restore previous state
          : header.display === 1,   // default if no previous state

              })
            );

          }
          // this.allUsersData = userData || {};
          this.mergeGroups = {};
          this.fieldToMergeGroup = {};
          this.tableBody = userData?.get_gtdb_deductee_details_detail || [];
          this.buildMergeGroups()
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
          this.loading = false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.toastService.showError(this.errorMessage);
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.toastService.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
      },
    });


  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }



  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  externalField: any;
  default: any;
  externalColField: any;
  defaultCondition: any;

  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_deductee_details',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );



    this.apiService.getFilterData('/Deductee/get_gtfb_deductee_details', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.get_gtfb_deductee_details?.[0]?.basic_filter;

          this.advance_filter =
            response?.result?.get_gtfb_deductee_details?.[1]?.advance_filter;
          setTimeout(() => {
            this.setDefaultFilters();
          }, 0);


          this.selectedValue = this.advance_filter
            .filter((filter: any) => filter.filter_col_external === 1)
            .map((filter: any) => filter.filter_col_external_default_value);

          console.log(this.selectedValue);

          this.externalField = this.advance_filter
            .filter((filter: any) => filter.filter_col_external === 1)
            .map((filter: any) => filter.filter_col_field);
          console.log(this.externalField);

          this.externalColField = this.externalField[0];
          console.log(this.externalColField);

          this.default = this.selectedValue[0];
          console.log(this.default);
          this.activeFilterTab = this.default;


          this.defaultCondition = this.advance_filter.filter((filter: any) => filter.filter_col_external === 1).map((filter: any) => {
            const match = filter.filter_col_depend_value?.find(
              (item: any) => item.value === filter.filter_col_external_default_value);
            return match ? match.condition : null;
          })
            .filter((condition: any) => condition !== null);

          if (this.default) {

            this.filterClause = [
              {
                filter_col_field: this.externalColField,
                filter_col_depend_operator: "wc",
                filter_col_value: this.defaultCondition[0],
                filter_col_field_alias: "a.",
              },
            ];
            console.log(this.filterClause);
          }

          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];

          this.fetchTable();
          this.fetchGrandTotal();
        } else {
          // this.errorMessage = response.result?.a_proc_error_message || "Please Check Endpoint";
          this.toastService.showError(response.result?.a_proc_error_message || "Please Check Endpoint");
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion

  selectedTabFilter(filterField: string, condition: any, value: any, label: any): void {
    this.paginatedList = [];
    this.currentPage = 1;
    this.offset = 0;
    this.defaultTabFilter = condition;
    this.selectedValue = value;
    this.selectedLabel = label;
    this.activeFilterTab = value;

    //Always run logic even if the tab value is the same as previous
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    this.filterClause = this.buildFilterClause();
    console.log('filterClause', this.filterClause);
    this.fetchTable();
    this.fetchGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 0) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
        else if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }
  gearboxState: { [key: string]: boolean } = {};

  saveGearboxState() {
  this.headers.forEach(h => {
    this.gearboxState[h.field] = h.visible;
  });
}
  onSubmit() {
          // 1️⃣ Save the gearbox state before table refresh
  this.saveGearboxState(); // save current visibility
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          controlValue = controlValue.trim().toUpperCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
      this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchTable(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }

  private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim().toUpperCase(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value?.toUpperCase() !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value.toUpperCase() !== basicValue) {
      this.searchTerm = control.value.toUpperCase();
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }


  // private buildFilterClause(): any[] {
  //   const filterClause: any[] = [];
  //   Object.keys(this.filterForm.controls).forEach((key) => {
  //     const controlValue = this.filterForm.get(key)?.value;
  //     const filterConfig = this.advance_filter?.find(
  //       (filter: any) => filter.filter_col_field === key
  //     );

  //     if (controlValue && controlValue !== 'ALL' && filterConfig) {

  //       let filterValue: string;
  //       const operator = filterConfig.filter_col_depend_operator;
  //       filterValue = controlValue.toString().trim();

  //       if (filterValue && filterValue !== '') {
  //         filterClause.push({
  //           filter_col_field: filterConfig.filter_col_field,
  //           filter_col_depend_operator: operator,
  //           filter_col_value: filterValue.toUpperCase(),
  //           filter_col_field_alias: filterConfig.filter_col_field_alias,
  //         });
  //       }
  //     }
  //   });
  //   if (
  //     this.searchTerm &&
  //     this.searchTerm.trim() !== '' &&
  //     this.selectedOption
  //   ) {
  //     filterClause.push({
  //       filter_col_field: this.selectedOption.field,
  //       filter_col_depend_operator: this.selectedOption.operator,
  //       filter_col_value: this.searchTerm.toUpperCase(),
  //       filter_col_field_alias: this.selectedOption.alias,
  //     });
  //   }
  //   return filterClause;
  // }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {

          // For "wc", find the condition based on selected value

          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue
            // (opt: any) => opt.value === controlValue.toUpperCase()
          );

          filterValue = selectedOption ? selectedOption.condition : '';

        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: operator === 'wc' ? filterValue : filterValue.toUpperCase(),
            // filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    // Include search term if present
    if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }

    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;
  }





  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    const selectedFilters: { label: string; field?: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {

        // ✅ Skip fields where filter_col_external === 1
        if (field.filter_col_external === 1) {
          return;
        }

        const control = this.filterForm.get(field.filter_col_field);

        if (control && control.value != null && control.value.toString().trim() !== '') {
          let label: string;

          // If current value is the default, use prompt as label
          if (field._isDefaultValue !== undefined && control.value === field._isDefaultValue) {
            label = field.filter_col_prompt;
          }
          // Otherwise, use depend_value label if available
          else {
            const dependValue = field.filter_col_depend_value?.find(
              (dv: any) => dv.value == control.value
            );
            label = dependValue?.label || field.filter_col_prompt;
          }

          selectedFilters.push({
            label,
            field: field.filter_col_field,
            value: control.value.toString().trim(),
          });
        }
      });

    }

    return selectedFilters;
  }


  getExternalFilter() {
    const selectedFilters: { label: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          const control = this.filterForm.get(field.filter_col_field);
          if (control && field.filter_col_depend_value) {
            const matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) =>
                dependValue.value === field.filter_col_external_default_value
            );
            const label = matchingDependValue ? matchingDependValue.label : "";

            selectedFilters.push({
              label: this.selectedLabel || label,
              value: control.value ? control.value.toString().trim() : "",
            });
          }
        }
      });
    }
    return selectedFilters;
  }



  removedFilter: any;

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );
    console.log(filterToRemove);

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );

    console.log(filterRemove);
    if (filterToRemove) {
      this.removedFilter = filterToRemove.filter_col_field;
      console.log(this.removedFilter);
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      this.removedFilter = filterRemove.filter_col_field;
      console.log(this.removedFilter);
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    console.log(this.filterClause);
    // ✅ If no filters left → pass empty array (not defaultFilters)
    const isLastFilterCleared = !this.filterClause || this.filterClause.length === 0;

    if (isLastFilterCleared) {
      this.fetchTable(true); // 'true' means clear action, same as clearAllFilters
    } else {
      this.fetchTable(); // normal behavior
    }

    this.fetchGrandTotal();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  // user grand total


  private fetchGrandTotal(isClearAction = false): void {
    // Ensure filterClause is always an array
    // Ensure filterClause is always an array
    const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];
    console.log('userFilters', userFilters);
    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
      // {
      //   filter_col_field: "deductee_panno_verified",
      //   filter_col_depend_operator: "wc",
      //   filter_col_value: this.defaultTabFilter,
      //   filter_col_field_alias: "a.",

      // }
    ];
    console.log('newFilterClause', newFilterClause);

    // Always rebuild final filterClause fresh:
    //     const finalFilterClause = [
    //       ...newFilterClause,
    //       ...userFilters.filter(
    //         (uf: any) =>
    //           !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
    //       ),
    //     ];
    // console.log(finalFilterClause);

    // ✅ Logic for which filters to use
    let finalFilterClause: any;

    if (isClearAction) {

      finalFilterClause = {

        filter_col_field: "deductee_panno_verified",
        filter_col_depend_operator: "wc",
        filter_col_value: this.defaultTabFilter ? this.defaultTabFilter : this.defaultCondition[0],
        filter_col_field_alias: "a.",

      };

    } else if (userFilters.length > 0) {
      // If user has applied filters → use user filters
      // finalFilterClause = userFilters;
      console.log(this.removedFilter);
      console.log(this.defaultTabFilter);
      if (this.defaultTabFilter) {
        newFilterClause.push({
          filter_col_field: "deductee_panno_verified",
          filter_col_depend_operator: "wc",
          filter_col_value: this.defaultTabFilter,
          filter_col_field_alias: "a.",

        })
        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...userFilters,
            ...newFilterClause.filter(
              (uf: any) =>
                !userFilters.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }
      else if (this.activeFilterTab) {
        newFilterClause.push({

          filter_col_field: this.externalColField,
          filter_col_depend_operator: "wc",
          filter_col_value: this.defaultCondition[0],
          filter_col_field_alias: "a.",
        })

        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...userFilters,
            ...newFilterClause.filter(
              (uf: any) =>
                !userFilters.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }
      else {
        finalFilterClause = this.removedFilter ? userFilters :
          [
            ...newFilterClause,
            ...userFilters.filter(
              (uf: any) =>
                !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
            ),
          ];

        console.log(finalFilterClause);
      }

    }
    else if (this.removedFilter) {
      // If user has applied filters → use user filters
      // finalFilterClause = userFilters;
      console.log(this.removedFilter);
      finalFilterClause = userFilters;
    }
    else {
      // Initial load → use default filters
      finalFilterClause = newFilterClause;
    }

    console.log('Final Filter Clause:', finalFilterClause);

    const sdata = this.apiService.generateSData(
      'get_gtdg_deductee_details',
      this.localUserData,
      finalFilterClause,
      // this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype
      },

    );

    this.apiService.getGrandTotal('/Deductee/get_gtdg_deductee_details', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          // Success case
          this.usergrandtotal =
            response?.result?.get_gtdg_deductee_details?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.toastService.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        // console.error('Error fetching vendor data:', error);
        this.toastService.showError('Something Went Wrong');
      },
    });
  }

  // Remove all filter label values
  // clearAllFilters() {
  //   this.searchTerm = '';
  //   this.offset = 0;
  //   this.currentPage = 1;
  //   this.selectedFilters = [];
  //   this.filterClause = [];
  //   if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //     this.advance_filter.forEach((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);
  //       if (control) {
  //         control.setValue('');
  //       }
  //     });
  //   }
  //   this.filtercount = this.getSelectedFilterCount();
  //   // this.filterClause = this.buildFilterClause();
  //   this.fetchTable(true);
  //   this.fetchGrandTotal(true);

  // }

  // clearAllFilters() {
  //     this.searchTerm = '';
  //     this.offset = 0;
  //     this.currentPage = 1;

  //     // 🔹 True if user applied any filters different from defaults
  //     const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
  //       const control = this.filterForm.get(field.filter_col_field);
  //       const value = control?.value;
  //       const defaultVal = field._isDefaultValue ?? '';

  //       // Compare deeply in case of object-type defaults
  //       return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
  //     });

  //     if (this.advance_filter && Array.isArray(this.advance_filter)) {
  //       this.advance_filter.forEach((field: any) => {
  //         const control = this.filterForm.get(field.filter_col_field);
  //         if (!control) return;

  //         if (hasUserAppliedFilters) {
  //           // ✅ Keep default filters if user applied something
  //           if (field._isDefaultValue !== undefined && field._isDefaultValue !== null) {
  //             control.setValue(field._isDefaultValue);
  //           } else {
  //             control.setValue('');
  //           }
  //         } else {
  //           // ✅ If user hasn’t applied anything → clear defaults also
  //           control.setValue('');
  //           field._isDefaultValue = null; // clear stored defaults
  //         }
  //       });
  //     }

  //     this.selectedFilters = this.getSelectedFilters();
  //     this.filterClause = this.buildFilterClause();
  //     this.filtercount = this.getSelectedFilterCount();

  //     this.fetchTable(true);
  //     this.fetchGrandTotal();
  //   }


  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;

    // Check if user applied any filters different from defaults
    const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      const value = control?.value;
      const defaultVal = field._isDefaultValue ?? '';
      return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
    });

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (!control) return;

        const defaultVal = field._isDefaultValue ?? null;

        if (hasUserAppliedFilters) {
          // ✅ Keep default filters intact
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue(''); // clear user-only filters
          }
        } else {
          // ✅ If no user filters were applied — reset to defaults, not empty
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue('');
          }
        }
      });
    }

    // ✅ Rebuild filterClause including defaults
    this.selectedFilters = this.getSelectedFilters();
    this.filterClause = this.buildFilterClause();
    this.filtercount = this.getSelectedFilterCount();

    // 🚫 Don’t treat this as a full clear for fetchTable()
    this.fetchTable(false);
    this.fetchGrandTotal();
  }


  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'transaction_data'
    );
  }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }

  isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  selectedRowDetails: any;


  openDrawer(idTofetch?: string, details?: any) {
    this.selectedId = idTofetch ?? null;
    this.selectedRowDetails = details;  // store row if needed
    this.isDrawerOpen = true;
  }



  closeDrawer() {
    this.selectedId = null;
    this.isDrawerOpen = false;
  }


  handleClosePopup() {
    this.isDrawerOpen = false; // or any logic to close popup
  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  selectedIdsForDeletion: number = 0;
  // Count selected rows
  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }

  getSelectedRowIds(): number[] {
    return this.paginatedList
      ?.filter((row: any) => row.selected)
      ?.map((row: any) => row.rowid_seq);
  }

  isDeletePopupOpen = false;

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.DeleteRecord();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
    // this.isDrawerOpen=true;
  }


  onClear() {
    // Uncheck all rows 
    this.paginatedList?.forEach((r: any) =>
      r.selected = false);
  }


  DeleteRecord() {
    const selectedIds = this.getSelectedRowIds();
    if (selectedIds.length === 0) {
      this.toastService.showError('Please select at least one row to delete.');
      return;
    }

    const isAll = this.isAllSelected();

    let iudType: 'sd' | 'md';
    if (this.paginatedList.length === 1 && selectedIds.length === 1) {
      iudType = 'sd'; // single record → SD always
    } else {
      iudType = isAll ? 'md' : 'sd';
    }


    // Base request body
    const requestBody: any = {
      a_iud_seqno: '',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: '',
      a_session_seqno: '',
      a_proc_type: 'get_gtmd_tds_tran_load',
      a_user_code: this.dynaUserData.user_code,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_seqno: '',
      a_iud_type: iudType,
    };

    if (iudType === 'md') {
      // Build dynamic filter clause
      this.filterClause = Array.isArray(this.filterClause)
        ? this.filterClause
        : [];

      const newFilterClause = [
        {
          filter_col_field: 'quarter_no',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_quarter_no,
          filter_col_field_alias: 'a.',
        },
        {
          filter_col_field: 'tds_type_code',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_tds_type_code,
          filter_col_field_alias: 'a.',
        },
      ];

      newFilterClause.forEach((nf) => {
        const exists = this.filterClause.some(
          (f: any) => f.filter_col_field === nf.filter_col_field
        );
        if (!exists) {
          this.filterClause.push(nf);
        }
      });

      requestBody.a_filter_clause = this.filterClause;
    } else {
      // Single delete → map selected IDs
      requestBody.tds_tran_load = selectedIds.map((id: number) => ({
        rowid_seq: id,
      }));
    }

    this.apiService
      .createData('/LDC/get_gtmd_tds_tran_load', requestBody)
      .subscribe({
        next: (response) => {
          const result = response?.result?.[0];
          if (!result) {
            this.toastService.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message);
            this.refreshdata.trigerRefresh('Transaction');
          } else {
            this.toastService.showError(
              result.a_proc_error_message || 'Error while deleting rows.'
            );
          }
        },
        error: () => {
          this.toastService.showError('Something went wrong! Please try again later.');
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }
  private showProcessing(message: string) {
    this.toastService.showProcessing(message);
  }



  // setDefaultFilters() {
  //   if (!this.advance_filter || !this.filterForm) return;

  //   this.advance_filter.forEach((field: any) => {
  //     // Set default for quarter_no
  //     if (field.filter_col_field === 'quarter_no') {
  //       const defaultQuarter = this.dynaUserData?.default_quarter_no || 'Q1';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultQuarter);
  //     }

  //     // Set default for tds_type_code
  //     if (field.filter_col_field === 'tds_type_code') {
  //       const defaultTdsType = this.dynaUserData?.default_tds_type_code || '26Q';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
  //     }

  //     if (field.filter_col_field === "shord_deduction_remark_status") {
  //       const dvs = field.filter_col_external_default_value
  //       this.filterForm.get(field.filter_col_field)?.setValue(dvs);
  //     }


  //     // if (field.filter_col_field === 'shord_deduction_remark_status') {
  //     //   const defaultTdsType = this.dynaUserData?.default_tds_type_code || '26Q';
  //     //   this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
  //     // }
  //     // if (field.filter_col_external === 0 ) {
  //     //   const dvs=field.filter_col_external_default_value
  //     //  this.filterForm.get(field.filter_col_field)?.setValue(dvs);
  //     // }

  //     // if (
  //     //   field.filter_col_external === 0 &&
  //     //   field.filter_col_external_default_value &&
  //     //   field.filter_col_external_default_value !== ''
  //     // ) {
  //     //   this.filterForm
  //     //     .get(field.filter_col_field)
  //     //     ?.setValue(field.filter_col_external_default_value);
  //     // }
  //   });


  //   this.selectedFilters = this.getSelectedFilters();
  // }

  setDefaultFilters() {
    if (!this.advance_filter || !this.filterForm) return;

    this.advance_filter.forEach((field: any) => {
      let defaultValue: any;

      switch (field.filter_col_field) {
        case 'quarter_no':
          defaultValue = this.dynaUserData?.default_quarter_no || 'Q1';
          break;
        case 'tds_type_code':
          defaultValue = this.dynaUserData?.default_tds_type_code || '26Q';
          break;
        case 'shord_deduction_remark_status':
          defaultValue = field.filter_col_external_default_value;
          break;
        default:
          if (field.filter_col_external_default_value) {
            defaultValue = field.filter_col_external_default_value;
          }
      }

      if (defaultValue !== undefined) {
        this.filterForm.get(field.filter_col_field)?.setValue(defaultValue);

        // Store the default value itself to detect in getSelectedFilters
        field._isDefaultValue = defaultValue;
      }
    });

    this.selectedFilters = this.getSelectedFilters();
    console.log(this.selectedFilter)
  }



  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }

  drawerOpen = false;
  isOpen = false;

  openMoreDrawer() {

    this.isOpen = true;
  }

  selectedMenu: string = 'Pan_veri'; // default selection

  setSelected(option: string) {
    this.selectedMenu = option;

    if (option == 'Pan_veri') {
      // this.addSingleClient();
    } else if (option === 'rebuild') {
      // this.bulkImport();
    }
  }

  deducteeHeader: any;
  deducteeDetails: any;

  pollingSub: Subscription | undefined;
  processingStatus: any;
  totalPan: any;
  panProcessed: any;
  panStatus: any;

  startPolling() {
    this.toastService.clearMessages();
    this.pollingSub = interval(2000) // every 2 seconds
      .pipe(switchMap(() => this.apiService.getMiudProcessingStatus()))
      .subscribe({
        next: (response) => {
          const statusCode = response.status;
          const data = response.body;

          if (statusCode === 200 && data?.status == 'completed') {
            this.toastService.showSuccess(data.message || 'Processing completed successfully!');
            this.stopPolling();
            this.refreshdata.trigerRefresh('Deductee');
          } else if (statusCode === 200 && data?.status === 'processing') {
            this.panStatus = data?.status;
            this.panProcessed = data.processed;
            this.totalPan = data.total;
            this.toastService.showProcessing(data.message || 'Still processing...');
          } else {
            console.warn('Unexpected response during polling:', data);
          }
        },
        error: (err) => {
          console.error('Polling error:', err);
          this.toastService.showError('Error fetching processing status.');
          this.stopPolling();
        }
      });
  }

  stopPolling() {
    if (this.pollingSub) {
      this.progressbarPan = false
      this.pollingSub.unsubscribe();
      this.pollingSub = undefined;
      // 🧹 Clear any active "Processing..." toast
      this.toastService.clearProcessing();
      this.progressbarPan = false;
    }
  }


  onPanVeriClick() {
    if (this.paginatedList?.length > 0) {
      this.openPanVeriDrawer();
    }
    else {
      this.toastService.showError("Pan Not Available for Verification");
    }
  }

  progressbarPan: boolean = false;
  openPanVeriDrawer() {

    const prinRight = this.dynaUserData.print_right;

    //const prinRight = 20;
    if (prinRight > 0) {
      this.toastService.showSuccess('Processing Start...');
    }
    this.progressbarPan = true;

    if (this.activeFilterTab === 'N') {
      const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];

      const newFilterClause = [
        {
          filter_col_field: 'quarter_no',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_quarter_no,
          filter_col_field_alias: 'a.',
        },
        {
          filter_col_field: 'tds_type_code',
          filter_col_depend_operator: '=',
          filter_col_value: this.dynaUserData.default_tds_type_code,
          filter_col_field_alias: 'a.',
        },
        {
          filter_col_field: 'deductee_panno_verified',
          filter_col_depend_operator: 'wc',
          filter_col_value: this.defaultTabFilter,
          filter_col_field_alias: 'a.',
        },
      ];

      const finalFilterClause = [
        ...newFilterClause,
        ...userFilters.filter(
          (uf: any) => !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
        ),
      ];

      const sdata = this.apiService.generateSData(
        'get_gtdb_deductee_details',
        this.localUserData,
        finalFilterClause,
        prinRight,
        this.offset,
        this.currentPage,
        {
          FYYear: this.FYYear,
          iudtype: this.iudtype,
        }
      );

      this.apiService.getTableData('/Deductee/get_gtdb_deductee_details', sdata).subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_deductee_details;

            if (userData?.get_gtdb_deductee_details_header) {
              this.deducteeHeader = userData.get_gtdb_deductee_details_header.map((header: any) => ({
                ...header,
                visible: header.display === 1,
              }));
            }

            this.deducteeDetails = userData?.get_gtdb_deductee_details_detail || [];

            const panList = this.deducteeDetails
              .filter((item: any) => !!item.deductee_panno)
              .map((item: any) => ({ pan_no: item.deductee_panno }));

            const requestBody = {
              a_session_seqno: '',
              a_iud_seqno: '',
              a_is_pen_flag: '',
              a_login_type: 'login_id',
              a_module_type_code: this.dynaUserData?.default_module_type_code,
              a_sub_module_type_code: 'R',
              a_user_code: this.localUserData.user_code,
              a_entity_code: this.dynaUserData.entity_code,
              a_client_code: this.dynaUserData.client_code,
              a_acc_year: this.dynaUserData.default_acc_year,
              a_quarter_no: this.dynaUserData.default_quarter_no,
              a_tran_month: this.dynaUserData.default_tran_month,
              a_validation_client_level: this.dynaUserData.client_code_level,
              a_tran_from_date: this.dynaUserData.default_from_date,
              a_tran_to_date: this.dynaUserData.default_to_date,
              a_tds_type_code: this.dynaUserData.default_tds_type_code,
              a_first_level_client_code: this.dynaUserData.first_level_client_code,
              a_client_code_level: this.dynaUserData.client_code_level,
              a_user_level: this.dynaUserData.user_level,
              a_proc_error: '0',
              a_db_total_records: '1000',
              a_pagination_count: '0',
              a_proc_type: 'get_miud_pan_mast',
              a_process_seqno: '',
              a_iud_type: 'i',
              a_process_status_code: 'ZA',
              pan_list: panList,
            };

            this.apiService.deducteemiudApi('/Comman/get_miud_pan_mast_from_list', requestBody).subscribe({
              next: (response) => {
                const statusCode = response.status;
                const data = response.body;

                if (statusCode === 200 || statusCode === 202) {
                  if (data?.result?.[0]?.a_proc_error === 0) {
                    this.toastService.showSuccess(data.result[0].a_proc_error_message);
                  } else {
                    this.toastService.showSuccess(data.message);

                  }

                  // ✅ Start polling after successful PAN verification

                  // this.toastService.clearMessages();
                  this.startPolling();
                } else {
                  this.progressbarPan = false;
                  this.toastService.showError(`Unexpected status code: ${statusCode}`);
                }
              },
              error: (error) => {
                console.error('API Error:', error);

                const errorMessages: Record<number, string> = {
                  0: 'Network Error — check your internet connection.',
                  400: 'Bad Request — invalid data sent.',
                  401: 'Unauthorized — please log in again.',
                  403: 'Forbidden — you do not have access.',
                  404: 'Not Found — resource missing.',
                  500: 'Internal Server Error — please try again later.',
                };

                const errMsg =
                  error.error?.message ||
                  errorMessages[error.status as number] ||
                  'Unexpected error occurred.';

                this.toastService.showError(errMsg);
              }

            });
          }
        },
      });
    }
  }

  navigateToReturns() {
    const code = 'PANVERIFY03'
    this.router.navigate(['/home/returns'], {
      queryParams: { code: code },
    });
  }

   sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";


   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }

}
