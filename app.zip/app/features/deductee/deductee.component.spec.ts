import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeducteeComponent } from './deductee.component';

describe('DeducteeComponent', () => {
  let component: DeducteeComponent;
  let fixture: ComponentFixture<DeducteeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeducteeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeducteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
