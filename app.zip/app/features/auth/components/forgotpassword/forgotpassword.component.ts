import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { AuthbannerComponent } from "../authbanner/authbanner.component";

// change
@Component({
  selector: 'app-forgotpassword',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ReactiveFormsModule, AuthbannerComponent],
  templateUrl: './forgotpassword.component.html',
  styleUrl: './forgotpassword.component.css'
})
export class ForgotpasswordComponent {
  forgetPasswordForm!: FormGroup;
  isSubmitted = false;
  responseMessage: string = '';
  isLoading: boolean = false; // Added loading state


constructor(
    private fb: FormBuilder,
    private toastService: ToastService,
    private router: Router,
    private authservice: AuthService) {
    this.forgetPasswordForm = this.fb.group({
      loginId: ['', [Validators.required,
         Validators.email,
         Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
    });
  }

//capital text input
capitalizeText(controlName: string) {
    let control = this.forgetPasswordForm.controls[controlName];
    if (control && control.value) {
      control.setValue(control.value.toUpperCase(), { emitEvent: false });
    }
  }


  // Getter for loginId form control
  get loginIdControl() {
    return this.forgetPasswordForm.controls['loginId'];
  }

// Form Submit Function
  forgetpassformsubbmit() {
    this.isSubmitted = true;
    if (this.forgetPasswordForm.invalid) {
      this.forgetPasswordForm.markAllAsTouched();
      return;
    }
    this.isLoading = true; // Start loading
    const email = this.forgetPasswordForm.value.loginId;
    console.log(email)
   this.authservice.forgetPassword(email).subscribe(
  (response: any) => {
    if (response.status === 1) {
      this.responseMessage = response.msg || 'Password reset link sent successfully!';
      this.toastService.showSuccess(this.responseMessage);
      this.router.navigate(['/emailsendsuccessful']);
    } else {
      this.responseMessage = response.msg || 'Login id not found!';
      this.toastService.showError(this.responseMessage);
      this.isLoading = false;
    }
  },
  (error) => {
    this.responseMessage = 'Error sending password reset link.';
    this.toastService.showError(this.responseMessage);
    this.isLoading = false;
  }
);

  }

}