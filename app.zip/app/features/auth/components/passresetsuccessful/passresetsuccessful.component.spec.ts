import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PassresetsuccessfulComponent } from './passresetsuccessful.component';

describe('PassresetsuccessfulComponent', () => {
  let component: PassresetsuccessfulComponent;
  let fixture: ComponentFixture<PassresetsuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PassresetsuccessfulComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PassresetsuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
