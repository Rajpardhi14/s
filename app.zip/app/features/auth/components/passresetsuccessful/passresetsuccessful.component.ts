import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthbannerComponent } from "../authbanner/authbanner.component";



@Component({
  selector: 'app-passresetsuccessful',
  standalone: true,
  imports: [ CommonModule, RouterLink, AuthbannerComponent],
  templateUrl: './passresetsuccessful.component.html',
  styleUrl: './passresetsuccessful.component.css'
})
export class PassresetsuccessfulComponent {
 
}
