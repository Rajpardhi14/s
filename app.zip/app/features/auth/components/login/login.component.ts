import { Component, inject, NgZone, PLATFORM_ID } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth/auth.service';

import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { IpService } from '../../../../core/services/ipaddress/ip.service';
import { CommonModule, isPlatformBrowser } from '@angular/common';

import { Router, RouterLink } from '@angular/router';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { AuthbannerComponent } from "../authbanner/authbanner.component";
import * as CryptoJS from 'crypto-js';
import * as bcrypt from 'bcryptjs';
import { OauthService } from '../../../../core/services/oauth/oauth.service';


import { SessionService } from '../../../../core/services/session/session/session.service';
import { GeolocationService } from '../../../../core/services/geolocation/geolocation.service';
import { runInThisContext } from 'vm';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, AuthbannerComponent, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  localUserData: any
  loginErrorMessage: string = '';
  passwordErrorMessage: string = '';
  ipAddress: string | null = null;
  isLoading: boolean = false;
  isPasswordVisible: boolean = false;
  loginForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';
  userData: any = null;
  userDataLogin: any;
  permissionData: any;
  passwordCriteria = {
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    specialChar: false,
  };
  opendrawer: boolean = false;
  signUpGoogle: any;

  // Temporary auth data for 2FA
  tempAuthData: any = null;

  togglePasswordVisibility(): void {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  private platformId = inject(PLATFORM_ID);

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private toastService: ToastService,
    private router: Router,
    private userlocaldataService: UserdataService,
    private ipService: IpService,
    private ngZone: NgZone,
    private oauthService: OauthService,
    private sessionService: SessionService,
    private geolocationService: GeolocationService,
    private apiService: ApiserviceService,
    // private permissionService: PermissionService,
  ) {
    this.loginForm = this.fb.group({
      loginId: [
        '',
        [
          Validators.required,
          Validators.pattern(
            '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'
          ),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(
            '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
          ),
        ],
      ],
    });
  }


  ngOnInit(): void {


  }

  private encryptPassword(secretKey: string, plainText: string): string {
    // Generate 256-bit key from secretKey
    const key = CryptoJS.SHA256(CryptoJS.enc.Utf8.parse(secretKey));

    // Generate random IV (16 bytes)
    const iv = CryptoJS.lib.WordArray.random(16);

    // Encrypt with AES-CBC + PKCS7
    const encrypted = CryptoJS.AES.encrypt(plainText, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    // Combine IV + CipherText (like in C#)
    const ivCipher = CryptoJS.lib.WordArray.create(
      iv.words.concat(encrypted.ciphertext.words),
      iv.sigBytes + encrypted.ciphertext.sigBytes
    );



    // Return Base64
    return CryptoJS.enc.Base64.stringify(ivCipher);
  }

  onLogin() {
    this.ipService.ipAddress$.subscribe((ip) => {
      this.ipAddress = ip;
    });

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    const loginId = this.loginForm.value.loginId.trim();
    const Login = '';
    const enteredPassword = this.loginForm.value.password.trim();
    const hashedPassword = this.encryptPassword(loginId, enteredPassword);

    this.authService.validateLogin(loginId, this.ipAddress, Login, hashedPassword).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.body?.status === 0) {
          const msg =
            response.body?.msg ||
            response.body?.message ||
            'Login failed';

          this.toastService.showError(msg);
          return;
        }
        const token = response.headers?.get('Authtoken');
        console.log(token)
        if (response?.body?.result?.get_gmdt_login_id?.length) {
          this.userData = response.body.result.get_gmdt_login_id[0];

          // Check if user has 2FA enabled using tfa_flag
          const has2FAEnabled = this.userData.tfa_flag === 'Y' ||
            this.userData.tfa_flag === 'y' ||
            this.userData.is_mfa === 'Y' ||
            this.userData.is_mfa === 'y';

          // console.log('Login - User data:', this.userData); // Debug log
          // console.log('Login - 2FA enabled check:', {
          //   tfa_flag: this.userData.tfa_flag,
          //   is_mfa: this.userData.is_mfa,
          //   has2FAEnabled: has2FAEnabled
          // }); 

          if (has2FAEnabled) {
            console.log('Login - 2FA is enabled, navigating to OTP screen'); // Debug log
            // Store temporary auth data for 2FA verification
            this.tempAuthData = {
              userData: this.userData,
              token: token,
              loginId: loginId,
              password: hashedPassword
            };

            // Navigate to OTP verification screen for 2FA
            this.isLoading = false;
            this.router.navigate(['/otpverify'], {  // Fixed route path
              state: {
                mode: '2fa',
                authData: this.tempAuthData
              }
            }).then(success => {
              console.log('Navigation to OTP screen:', success ? 'Success' : 'Failed');
            });
            return;
          }


          if (token) {
            document.cookie = `Authtoken=${encodeURIComponent(token)}; path=/; secure; samesite=strict`;
            sessionStorage.setItem('Usercode', this.userData.user_code);
            sessionStorage.setItem('token', token);
            sessionStorage.setItem('Clientcode', this.userData.client_code);

          }

          // this.permissionData =
          //   this.userData?.user_role_str ?? this.userData?.client_role_str;

          this.userlocaldataService.setLocalUserData(this.userData);
          this.userlocaldataService.setDynamic(this.userData)
          this.localUserData = this.userlocaldataService.getLocalUserData();
          sessionStorage.setItem('loginSuccess', 'true');
          this.getstatemast();
          this.createUserSession(this.userData);
          this.getLocalStorageUserData();;
          this.apiService.refreshSession();
          if (this.userData.first_time_login == 0) {
            this.router.navigate(['clientslist']);
          } else {
            this.router.navigate(['clients']);
          }
          this.loginErrorMessage = '';
          this.passwordErrorMessage = '';
          this.opendrawer = false;
        } else if (response.body.statusCode === 0) {
          this.opendrawer = true;
        } else {
          this.loginErrorMessage =
            response.body.result?.[0]?.a_proc_error_message || 'Something went wrong';
          this.passwordErrorMessage = '';
          this.toastService.showError(this.loginErrorMessage)
          this.opendrawer = false;
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error(err);
        this.toastService.showError('Something went wrong. Please try again later.');
        this.loginErrorMessage = '';
        this.passwordErrorMessage = '';
      },
    });
  }

  private getLocalStorageUserData(): void {
    this.userDataLogin = sessionStorage.getItem('localUserData');
  }

  private createUserSession(userData: any): void {
    // Get browser and device information
    const userAgent = navigator.userAgent;
    const platform = navigator.platform;

    // First get location data from IP, then create session
    this.geolocationService.getLocationFromIP(this.ipAddress || undefined).subscribe({
      next: (locationData) => {
        // Create session data with location
        const sessionData = {
          userId: userData.user_code || userData.entity_code,
          email: userData.email_id || userData.login_id || '',
          userAgent: userAgent,
          ipAddress: this.ipAddress || '',
          loginTime: new Date().toISOString(),
          lastActivity: new Date().toISOString(),
          deviceInfo: {
            platform: platform,
            browser: this.getBrowserInfo(),
            os: this.getOSInfo(),
            machineName: this.getMachineInfo()
          },
          location: {
            city: locationData.city || 'Unknown',
            country: locationData.country || 'Unknown',
            region: locationData.region || ''
          }
        };

        // Call session creation API
        this.sessionService.createSession(sessionData).subscribe({
          next: (response) => {
            if (response && response.sessionId) {
              // Store session ID
              sessionStorage.setItem('sessionId', response.sessionId);

              // Store auth token if provided
              if (response.authToken) {
                sessionStorage.setItem('sessionAuthToken', response.authToken);
              }


              const updatedUserData = { ...userData, sessionId: response.sessionId };
              this.userlocaldataService.setLocalUserData(updatedUserData);

              console.log('Session created successfully:', response.sessionId, 'Location:', locationData);
            }
          },
          error: (error) => {
            console.error('Failed to create session:', error);
            // Continue with login even if session creation fails
          }
        });
      },
      error: (error) => {
        console.error('Failed to get location:', error);
        // Create session without location data
        const sessionData = {
          userId: userData.user_code || userData.entity_code,
          email: userData.email_id || userData.login_id || '',
          userAgent: userAgent,
          ipAddress: this.ipAddress || '',
          loginTime: new Date().toISOString(),
          lastActivity: new Date().toISOString(),
          deviceInfo: {
            platform: platform,
            browser: this.getBrowserInfo(),
            os: this.getOSInfo(),
            machineName: this.getMachineInfo()
          },
          location: {
            city: 'Unknown',
            country: 'Unknown',
            region: ''
          }
        };

        // Still create session even if location fetch fails
        this.sessionService.createSession(sessionData).subscribe({
          next: (response) => {
            if (response && response.sessionId) {
              sessionStorage.setItem('sessionId', response.sessionId);
              if (response.authToken) {
                sessionStorage.setItem('sessionAuthToken', response.authToken);
              }
              const updatedUserData = { ...userData, sessionId: response.sessionId };
              this.userlocaldataService.setLocalUserData(updatedUserData);
              console.log('Session created successfully (without location):', response.sessionId);
            }
          },
          error: (err) => {
            console.error('Failed to create session:', err);
          }
        });
      }
    });
  }

  private getBrowserInfo(): string {
    const userAgent = navigator.userAgent;
    if (userAgent.indexOf('Chrome') > -1) return 'Chrome';
    if (userAgent.indexOf('Safari') > -1) return 'Safari';
    if (userAgent.indexOf('Firefox') > -1) return 'Firefox';
    if (userAgent.indexOf('Edge') > -1) return 'Edge';
    return 'Unknown';
  }

  private getOSInfo(): string {
    const platform = navigator.platform;
    const userAgent = navigator.userAgent;
    if (platform.indexOf('Win') > -1) return 'Windows';
    if (platform.indexOf('Mac') > -1) return 'macOS';
    if (platform.indexOf('Linux') > -1) return 'Linux';
    if (/Android/.test(userAgent)) return 'Android';
    if (/iPhone|iPad|iPod/.test(userAgent)) return 'iOS';
    return 'Unknown';
  }

  private getMachineInfo(): string {
    // Create a persistent device identifier
    let deviceId = sessionStorage.getItem('deviceId');

    if (!deviceId) {
      // Generate a unique device ID if not exists
      deviceId = this.generateDeviceId();
      sessionStorage.setItem('deviceId', deviceId);
    }

    // Gather all available device information
    const osInfo = this.getDetailedOSInfo();
    const browserInfo = this.getDetailedBrowserInfo();
    const screenInfo = `${screen.width}x${screen.height}`;
    const colorDepth = screen.colorDepth;
    const platform = navigator.platform;
    const cores = navigator.hardwareConcurrency || 'Unknown';
    const memory = (navigator as any).deviceMemory || 'Unknown'; // Chrome only
    const language = navigator.language;

    // Create a more descriptive device identifier
    const deviceDetails = {
      os: osInfo,
      browser: browserInfo,
      screen: screenInfo,
      cores: cores !== 'Unknown' ? `${cores}Cores` : '',
      memory: memory !== 'Unknown' ? `${memory}GB` : '',
      id: deviceId.substring(0, 8)
    };

    // Build device name based on available info
    let deviceName = `${osInfo}-${browserInfo}`;

    if (cores !== 'Unknown') {
      deviceName += `-${cores}Core`;
    }

    if (memory !== 'Unknown') {
      deviceName += `-${memory}GB`;
    }

    // Add screen resolution for uniqueness
    deviceName += `-${screenInfo}`;

    // Add short unique ID
    deviceName += `-${deviceId.substring(0, 6).toUpperCase()}`;

    return deviceName;
  }

  private getDetailedOSInfo(): string {
    const userAgent = navigator.userAgent;
    const platform = navigator.platform;

    // More detailed OS detection
    if (/Windows NT 10/.test(userAgent)) {
      if (/Windows NT 10.0; Win64; x64/.test(userAgent)) {
        return 'Win10-64bit';
      }
      return 'Win10';
    } else if (/Windows NT 6.3/.test(userAgent)) {
      return 'Win8.1';
    } else if (/Windows NT 6.2/.test(userAgent)) {
      return 'Win8';
    } else if (/Windows NT 6.1/.test(userAgent)) {
      return 'Win7';
    } else if (/Mac OS X 10_(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Mac OS X 10_(\d+)/)?.[1];
      return `macOS-10.${version}`;
    } else if (/Mac OS X 11/.test(userAgent)) {
      return 'macOS-11';
    } else if (/Mac OS X 12/.test(userAgent)) {
      return 'macOS-12';
    } else if (/Mac OS X 13/.test(userAgent)) {
      return 'macOS-13';
    } else if (/Mac OS X 14/.test(userAgent)) {
      return 'macOS-14';
    } else if (/Android (\d+)/.test(userAgent)) {
      const version = userAgent.match(/Android (\d+)/)?.[1];
      return `Android-${version}`;
    } else if (/iPhone OS (\d+)/.test(userAgent)) {
      const version = userAgent.match(/iPhone OS (\d+)/)?.[1];
      return `iOS-${version}`;
    } else if (/Linux/.test(platform)) {
      if (/Ubuntu/.test(userAgent)) return 'Ubuntu';
      if (/Debian/.test(userAgent)) return 'Debian';
      if (/Fedora/.test(userAgent)) return 'Fedora';
      if (/CentOS/.test(userAgent)) return 'CentOS';
      return 'Linux';
    }

    return 'Unknown-OS';
  }

  private getDetailedBrowserInfo(): string {
    const userAgent = navigator.userAgent;

    // Get browser with version
    if (/Chrome\/(\d+)/.test(userAgent) && !/Edg/.test(userAgent)) {
      const version = userAgent.match(/Chrome\/(\d+)/)?.[1];
      return `Chrome${version}`;
    } else if (/Firefox\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Firefox\/(\d+)/)?.[1];
      return `Firefox${version}`;
    } else if (/Version\/(\d+).*Safari/.test(userAgent) && !/Chrome/.test(userAgent)) {
      const version = userAgent.match(/Version\/(\d+)/)?.[1];
      return `Safari${version}`;
    } else if (/Edg\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Edg\/(\d+)/)?.[1];
      return `Edge${version}`;
    } else if (/Opera|OPR\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/(?:Opera|OPR)\/(\d+)/)?.[1];
      return `Opera${version || ''}`;
    }

    return 'Browser';
  }

  private generateDeviceId(): string {
    // Generate a unique device identifier
    const timestamp = Date.now().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 15);
    const userAgent = navigator.userAgent.replace(/[^a-zA-Z0-9]/g, '');
    const screenRes = `${screen.width}x${screen.height}`;

    // Create a somewhat stable device fingerprint
    const fingerprint = `${userAgent}-${screenRes}-${timestamp}-${randomStr}`;

    // Simple hash function to create a shorter ID
    let hash = 0;
    for (let i = 0; i < fingerprint.length; i++) {
      const char = fingerprint.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }

    return Math.abs(hash).toString(36).toUpperCase();
  }


  closeContinue() {
    this.isLoading = false;

    this.opendrawer = false;
    this.router.navigateByUrl('/');
  }

  //  save mmtx for state
  private getstatemast(): void {
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_is_pen_flag: "",
        a_login_type: "login_id",
        a_module_type_code: this.localUserData?.default_module_type_code,
        a_sub_module_type_code: "R",
        a_entity_code: this.localUserData?.entity_code,
        a_client_code: this.localUserData?.client_code,
        a_acc_year: this.localUserData?.default_acc_year,
        a_quarter_no: this.localUserData?.default_quarter_no,
        a_tran_month: this.localUserData?.default_tran_month,
        a_tran_from_date: this.localUserData?.default_from_date,
        a_tran_to_date: this.localUserData?.default_to_date,
        a_tds_type_code: this.localUserData?.default_tds_type_code,
        a_first_level_client_code: this.localUserData?.first_level_client_code,
        a_validation_client_level: this.localUserData.client_code_level,
        a_iud_type: "",
        a_db_total_records: "10",
        a_pagination_count: "0",
        a_proc_type: "get_mmtx_multi_mast",
        a_filter_clause: [
          {
            filter_col_field: "gd_proc_name",
            filter_col_depend_operator: "wc",
            filter_col_value:
              "and gd_proc_name in (##get_mmtx_acc_year_mast##, ##get_mmtx_client_level_mast##,##get_mmtx_quarter_mast##, ##get_mmtx_regex_validation##,##get_mmtx_app_parameters##, ##get_mmtx_module_type_mast##,##get_mmtx_sub_module_type_mast##,##get_mmtx_tds_type_mast##,##get_mmtx_stream_mast##)",

            // filter_col_value:
            //   "and gd_proc_name in (##get_mmtx_acc_year_mast##, ##get_mmtx_client_level_mast##,##get_mmtx_quarter_mast##, ##get_mmtx_regex_validation##,##get_mmtx_tds_type_mast##,##get_mmtx_app_parameters##)",
            filter_col_field_alias: "a.",
          },
        ],
      }),
    };

    // this.isloading = true;

    this.authService.fetchMultiMastData(requestBody).subscribe({
      next: (response: any) => {
        const result = response?.body?.result;
        if (result?.a_proc_error == 0) {
          const multiMast = result?.get_mmtx_multi_mast;
          if (multiMast) {
            sessionStorage.setItem('headermaster', JSON.stringify(multiMast));
            // localStorage.setItem('headermaster', JSON.stringify(multiMast));
            console.log('📦 Header master data stored successfully');
          } else {
            console.warn('⚠️ No multiMast data found in API response');
          }
        } else {
          this.errorMessage = result?.a_proc_error_message || 'Unknown process error';
          this.showError(this.errorMessage);
        }

        // this.isloading = false;
      },
      error: (error: any) => {
        console.error('❌ API Error:', error);
        // this.isloading = false;
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }


  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }
  validatePassword() {
    const password = this.loginForm.controls['password'].value;
    this.passwordCriteria.length = password.length >= 8;
    this.passwordCriteria.uppercase = /[A-Z]/.test(password);
    this.passwordCriteria.lowercase = /[a-z]/.test(password);
    this.passwordCriteria.number = /[0-9]/.test(password);
    this.passwordCriteria.specialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  }


  handleError(error: any) {
    console.error('Login Failed:', error);
  }

  // ngOnDestroy(): void {
  //   this.subscription.unsubscribe();
  // }





  // Google Sign In
  signInWithGoogle(): void {
    this.isLoading = true;
    this.oauthService.signInWithGoogle().subscribe({
      next: (user) => {
        if (user) {
          console.log('Google user data:', user);
          // Extract user details
          const firstName = user.firstName || '';
          const lastName = user.lastName || '';
          const email = user.email;
          const photoUrl = user.photoUrl;
          const provider = user.provider;

          // Create registration request for social login
          this.registerSocialUser({
            client_name: firstName,
            deductor_name: lastName,
            email: email,
            provider: provider,
            social_id: user.id,
            photo_url: photoUrl
          });
        } else {
          this.isLoading = false;
          this.toastService.showError('Google sign-in was cancelled');
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Google sign-in error:', error);
        this.toastService.showError('Failed to sign in with Google');
      }
    });
  }

  // Microsoft Sign In
  signInWithMicrosoft(): void {
    this.isLoading = true;
    this.oauthService.signInWithMicrosoft().subscribe({
      next: (user) => {
        if (user) {
          console.log('Microsoft user data:', user);
          // Extract user details
          const firstName = user.firstName || '';
          const lastName = user.lastName || '';
          const email = user.email;
          const provider = user.provider;

          // Create registration request for social login
          this.registerSocialUser({
            client_name: firstName,
            deductor_name: lastName,
            email: email,
            provider: provider,
            social_id: user.id,
            photo_url: user.photoUrl || ''
          });
        } else {
          this.isLoading = false;
          this.toastService.showError('Microsoft sign-in was cancelled');
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Microsoft sign-in error:', error);
        this.toastService.showError('Failed to sign in with Microsoft');
      }
    });
  }

  // Register user from social login
  private registerSocialUser(userData: any): void {
    const randomPassword = this.generateRandomPassword();
    const salt = bcrypt.genSaltSync(10);
    const saltRounds = 10;
    const hashedPassword = bcrypt.hashSync(randomPassword, saltRounds);
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_process_seqno: "",
        a_iud_type: "i",
        a_proc_type: "get_miud_client_mast_proposal",
        a_user_code: "12345678",
        a_entity_code: "B0",
        a_client_code: "",
        a_acc_year: "",
        a_quarter_no: "",
        a_tran_month: "",
        a_tran_from_date: "",
        a_tran_to_date: "",
        a_tds_type_code: "",
        a_module_type_code: "TAXCPC",
        a_sub_module_type_code: "R",
        a_first_level_client_code: "",
        client_mast_proposal: {
          entity_code: 'B0',
          client_name: userData.client_name,
          deductor_name: userData.deductor_name,
          email_id: userData.email,
          phoneno: userData.phoneno || '',
          organisation_type: userData.provider === 'GOOGLE' ? 'Google Account' : 'Microsoft Account',
          login_pwd: hashedPassword,
          social_provider: userData.provider,
          social_id: userData.social_id,
          signup_type: userData.provider === "GOOGLE" ? "G" : "M",
          signup_key_value: userData,
        },
      }),
    };
    this.authService.signup(requestBody).subscribe({
      next: (response) => {
        this.isLoading = false;

        const result = response?.result?.[0];
        if (!result) {
          this.toastService.showError('Unexpected server response.');
          return;
        }

        if (result.a_proc_error == -1) {
          let errorMessage = '';

          if (result.a_proc_error_message) {
            // Use direct error message if available
            errorMessage = result.a_proc_error_message;
          } else if (result.a_errors && result.a_errors.length > 0) {
            // Combine all field errors into one string
            errorMessage = result.a_errors
              .map((err: any) => `${err.field}: ${err.message}`)
              .join(', ');
          } else {
            errorMessage = 'An unknown error occurred.';
          }

          if (errorMessage.toLowerCase().includes('already exist')) {
            this.getLocalStorageUserData();
            this.getstatemast();
            sessionStorage.setItem('loginSuccess', 'true');
            this.router.navigate(['/home/dashboard']);
          } else {
            this.toastService.showError(errorMessage);
          }
        } else if (result.a_proc_error == 0) {
          // ✅ Registration successful
          const successMessage =
            result.a_proc_error_message || 'Registration successful!';
          this.toastService.showSuccess(successMessage);

          setTimeout(() => {
            this.router.navigate(['/home/dashboard']);
          }, 200);
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Signup error:', err);
        this.toastService.showError('Registration failed. Please try again');
      }
    });

  }

  // Generate random password for social users
  private generateRandomPassword(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 16; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

}
