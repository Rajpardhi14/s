import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-terms-services',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './terms-services.component.html',
  styleUrl: './terms-services.component.css'
})
export class TermsServicesComponent {

}
