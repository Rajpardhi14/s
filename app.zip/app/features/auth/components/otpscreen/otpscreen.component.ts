import { Component } from '@angular/core';

@Component({
  selector: 'app-otpscreen',
  standalone: true,
  imports: [],
  templateUrl: './otpscreen.component.html',
  styleUrl: './otpscreen.component.css'
})
export class OtpscreenComponent {

}
