import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SuccesstoastComponent } from "../../../../shared/components/toaster/successtoast/successtoast.component";
import { ErrortoastComponent } from "../../../../shared/components/toaster/errortoast/errortoast.component";
import { AuthbannerComponent } from "../authbanner/authbanner.component";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { Router, RouterLink } from '@angular/router';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { OauthService } from '../../../../core/services/oauth/oauth.service';
import { CommonModule } from '@angular/common';
import * as CryptoJS from 'crypto-js';
import { IpService } from '../../../../core/services/ipaddress/ip.service';
import * as bcrypt from 'bcryptjs';
import { noWhitespaceValidator } from '../../../../shared/utils/passmatch';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [SuccesstoastComponent, ErrortoastComponent, AuthbannerComponent, CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent {
  signupForm!: FormGroup;
  isSubmitting = false;
  isPasswordVisible = false;
  errorMessage = '';
  localUserData: any;
  isLoading: boolean = false;
  ipAddress: string | null = null;
  emailerr: string = '';
  passworderr: string = '';
  passwordCriteria = {
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    specialChar: false,
  };
  constructor(
    private fb: FormBuilder,
    private toastService: ToastService,
    private router: Router,
    private userlocaldataService: UserdataService,
    private authservice: AuthService,
    private ipService: IpService,
    private oauthService: OauthService,

    @Inject(PLATFORM_ID) private platformId: Object
  ) { }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.ipService.ipAddress$.subscribe((ip) => {
      this.ipAddress = ip;
    });
    this.initializeForm();
    this.checkOtpVerification();

    window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
      const reason: any = event.reason;

      // Detect Google popup cancel
      if (reason?.name === 'AbortError' || reason?.message?.includes('aborted')) {
        this.toastService.showError('Google sign-in was cancelled');
        this.isLoading = false;
      }
    });

    //  const saltRounds = 10;
    //     const hashedPassword = bcrypt.hashSync("Pass@2025", saltRounds);
    //   console.log(hashedPassword)
  }

  // private initializeForm(): void {
  //   this.signupForm = this.fb.group({
  //     client_name: ['', [Validators.required, Validators.minLength(3), noWhitespaceValidator()]],
  //     deductorlastname: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z\s]+$/), noWhitespaceValidator()]],
  //     deductor_name: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z\s]+$/), noWhitespaceValidator()]],
  //     contactNumber: [
  //       '',
  //       [Validators.required, Validators.pattern(/^\d{10}$/)],
  //     ],
  //     email: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.pattern(
  //           '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'
  //         ),
  //       ],
  //     ],
  //     password: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.minLength(8),
  //         Validators.pattern(
  //           '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d@#$!%*?&]{8,}$'
  //         ),
  //       ],
  //     ],

  //     confirmPassword: ['', Validators.required],

  //     // company_name: ['', [Validators.required, Validators.minLength(4)]],
  //     company_type: ['', Validators.required, noWhitespaceValidator()],
  //     terms: [false, Validators.requiredTrue],
  //   }, {
  //     validators: this.passwordMatchValidator
  //   }
  //   );
  // }

  //sendotp
  // sendOtp(): void {
  //   if (this.signupForm.invalid) {
  //     this.signupForm.markAllAsTouched();
  //     return;
  //   }

  //   this.isLoading = true;
  //   this.isSubmitting = true;
  //   const formData = this.signupForm.value;


  //     const email = this.signupForm.get('email')?.value;
  // if (!email) return;






  //   const requestBody = {
  //     email_id: formData.email,
  //     username: `${formData.deductor_name} ${formData.deductorlastname}`.trim(),
  //     ip_address: this.ipAddress || ''
  //   };

  //   this.authservice.signotp(requestBody).subscribe({
  //     next: (response) => {
  //       this.isSubmitting = false;
  //       this.isLoading = false;
  //       if (response?.status === 1 || response?.success === 1) {
  //         if (isPlatformBrowser(this.platformId)) {
  //           localStorage.setItem('signupFormData', JSON.stringify(formData));
  //           localStorage.setItem('userEmail', formData.email);
  //         }
  //         this.router.navigate(['/otpverify']);
  //         this.toastService.showSuccess(response.msg || response.message || 'OTP sent successfully!');
  //       } else {
  //         this.toastService.showError(
  //           response?.msg || response?.message || 'Failed to send OTP'
  //         );
  //         this.emailerr = response?.msg || response?.message;
  //       }
  //     },
  //     error: (err) => {
  //       this.isLoading = false;
  //       this.isSubmitting = false;
  //       this.toastService.showError('Failed to send OTP. Please try again');
  //     },
  //   });
  // }


  private initializeForm(): void {
    this.signupForm = this.fb.group({
      client_name: ['', [Validators.required, Validators.minLength(3), noWhitespaceValidator()]],
      deductorlastname: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z\s]+$/), noWhitespaceValidator()]],
      deductor_name: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z\s]+$/), noWhitespaceValidator()]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.pattern('^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d@#$!%*?&]{8,}$')]],
      confirmPassword: ['', Validators.required],
      company_type: ['', [Validators.required, noWhitespaceValidator()]], // ✅ Fixed
      terms: [false, Validators.requiredTrue],
    }, {
      validators: this.passwordMatchValidator
    });
  }
  sendOtp(): void {
    if (this.signupForm.invalid) {
    
      this.signupForm.markAllAsTouched();
      return;
    }

  console.log(this.signupForm)
    const email = this.signupForm.get('email')?.value;
    if (!email) return;


    this.isLoading = true;
    this.isSubmitting = true;

    // ✅ First, check if email already exists
    this.checkEmailExists(email, (emailExists: boolean) => {
      if (emailExists) {
        this.isLoading = false;
        this.isSubmitting = false;
        this.toastService.showError(this.emailerr || 'This email is already registered');
        return;
      }

      // ✅ Proceed to send OTP if email is valid and not taken
      const formData = this.signupForm.value;

      const requestBody = {
        email_id: formData.email,
        username: `${formData.deductor_name} ${formData.deductorlastname}`.trim(),
        ip_address: this.ipAddress || '',
      };

      this.authservice.signotp(requestBody).subscribe({
        next: (response) => {
          this.isSubmitting = false;
          this.isLoading = false;

          if (response?.status === 1 || response?.success === 1) {
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('signupFormData', JSON.stringify(formData));
              localStorage.setItem('userEmail', formData.email);
            }
            this.router.navigate(['/otpverify']);
            this.toastService.showSuccess(response.msg || response.message || 'OTP sent successfully!');
          } else {
            this.toastService.showError(response?.msg || response?.message || 'Failed to send OTP');
            this.router.navigate(['/registration']);
          }
        },
        error: () => {
          this.isLoading = false;
          this.isSubmitting = false;
          this.toastService.showError('Failed to send OTP. Please try again');
        },
      });
    });
  }
  sanitizeNumberInput(event: Event) {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/[^0-9]/g, '').slice(0, 10);
    this.signupForm.controls['contactNumber'].setValue(input.value, {
      emitEvent: false,
    });
  }


  haspassed: any

  //signupSubmit
  signupSubmit(): void {
    if (this.signupForm.invalid) {
      this.signupForm.markAllAsTouched();
      console.log(this.signupForm.value)
      console.warn('Form invalid, stopping submit');
      return;
    }
    // console.log('Form is valid, proceeding with signup');
    this.isSubmitting = true;
    const formData = this.signupForm.value;
    const saltRounds = 10;

    // const hashedPassword = bcrypt.hashSync(formData.password, saltRounds);


    // this.haspassed=hashedPassword
    // console.log(hashedPassword)
    console.log(this.haspassed)

    // const companyFullName =
    //   formData.company_type && formData.company_name
    //     ? `${formData.company_type} - ${formData.company_name}`
    //     : formData.company_name || formData.company_type;


    const deductorFullName =
      formData.deduc && formData.deduc
        ? `${formData.deductor_name} ~ ${formData.deductorlastname}`
        : formData.deductor_name || formData.deductorlastname;


    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_process_seqno: "",
        a_iud_type: "i",
        a_proc_type: "get_miud_client_mast_proposal",
        a_user_code: "",
        a_entity_code: "B0",
        a_client_code: "",
        a_acc_year: "",
        a_quarter_no: "",
        a_tran_month: "",
        a_tran_from_date: "",
        a_tran_to_date: "",
        a_tds_type_code: "",
        a_module_type_code: "TAXCPC",
        a_sub_module_type_code: "R",
        a_first_level_client_code: "",
        client_mast_proposal: {
          entity_code: 'B0',

          client_name: formData.client_name?.toUpperCase(),
          deductor_name: deductorFullName?.toUpperCase(),
          email_id: formData.email,
          phoneno: formData.contactNumber,
          organisation_type: formData.company_type?.toUpperCase(),
          login_pwd: formData.password,
          // signup_key_value: '',
          // signup_type: 'N',
        },
      }),
    };
    this.authservice.signup(requestBody).subscribe({
      next: (response) => {
        this.isSubmitting = false;
        console.log('Registration API response:', response);


        if (response?.result?.[0]?.a_proc_error == -1) {

          const errorMessage = response.result[0].a_proc_error_message || 'Registration failed';
          this.toastService.showError(errorMessage);

          // If it's a duplicate email error, show it below the email field
          if (errorMessage.toLowerCase().includes('already exist')) {
            this.emailerr = 'This email is already registered';
          }
        } else if (response?.result?.[0]?.a_proc_error == 0) {
          // Registration successful
          const successMessage = response.result[0].a_proc_error_message || 'Registration successful!';
          this.toastService.showSuccess(successMessage);


          if (isPlatformBrowser(this.platformId)) {
            localStorage.removeItem('signupFormData');
            localStorage.removeItem('otpVerified');
          }

          // Navigate to login after 2 seconds
          setTimeout(() => {
            this.router.navigate(['/']);
          }, 2000);
        } else {
          // Unexpected response format
          this.toastService.showError('Unexpected response. Please try again');
        }
      },
      error: (err) => {
        this.isSubmitting = false;
        console.error('Registration error:', err);
        this.toastService.showError('Registration failed. Please try again');
      },
    });
  }


  checkEmailExists(email: string, callback: (emailExists: boolean) => void): void {
    if (!email) {
      callback(false);
      return;
    }

    const sdata = {
      a_process_seqno: "",
      a_proc_type: "get_gmdt_user_mast_email_id",
      a_proc_error: "0",
      a_db_total_records: "0",
      a_pagination_count: "0",
      a_page_from: "1",
      a_page_to: "1",
      a_process_status_code: "",
      a_in_parameter_json: [{ a_rowid_seq: email }],
    };

    const requestBody = { sdata: JSON.stringify(sdata) };

    this.authservice.checkEmail(requestBody).subscribe({
      next: (response) => {
        if (response?.status == 1) {
          this.emailerr = response?.msg || 'This email is already registered';
          this.signupForm.get('email')?.setErrors({ emailTaken: true });
          callback(true); // Email exists
        } else {
          this.emailerr = '';
          this.signupForm.get('email')?.setErrors(null);
          callback(false); // Email not found
        }
      },
      error: () => {
        this.emailerr = 'Unable to verify email at the moment';
        callback(true); // Treat as exists to block submission safely
      },
    });
  }



  // checkEmailExists(email: string): void {
  //   if (!email) return;

  //   const sdata = {
  //     a_process_seqno: "",
  //     a_proc_type: "get_gmdt_user_mast_email_id",
  //     a_proc_error: "0",
  //     a_db_total_records: "0",
  //     a_pagination_count: "0",
  //     a_page_from: "1",
  //     a_page_to: "1",
  //     a_process_status_code: "",
  //     a_in_parameter_json: [{ a_rowid_seq: email }],
  //   };

  //   const requestBody = {
  //     sdata: JSON.stringify(sdata)
  //   };

  //   this.authservice.checkEmail(requestBody).subscribe({
  //     next: (response) => {
  //       if (response?.status == 1) {
  //         // Email already exists
  //         this.emailerr = response?.msg || 'This email is already registered';
  //         this.signupForm.get('email')?.setErrors({ emailTaken: true });
  //       } else if (response?.status == 0) {
  //         // Email not present
  //         this.emailerr = '';
  //         this.signupForm.get('email')?.setErrors(null);
  //       }
  //     },
  //     error: () => {
  //       this.emailerr = 'Unable to verify email at the moment';
  //     },
  //   });
  // }








  //checkOtpVerification
  checkOtpVerification(): void {
    if (isPlatformBrowser(this.platformId)) {
      const otpVerified = localStorage.getItem('otpVerified');
      const storedFormData = localStorage.getItem('signupFormData');
      if (otpVerified === 'true' && storedFormData) {
        this.signupForm.patchValue(JSON.parse(storedFormData));
        this.signupSubmit();
        localStorage.removeItem('otpVerified');
      }
    }
  }

  //password show hide
  togglePasswordVisibility(): void {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  validatePassword() {
    const password = this.signupForm.controls['password'].value;
    this.passwordCriteria.length = password.length >= 8;
    this.passwordCriteria.uppercase = /[A-Z]/.test(password);
    this.passwordCriteria.lowercase = /[a-z]/.test(password);
    this.passwordCriteria.number = /[0-9]/.test(password);
    this.passwordCriteria.specialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  }



  // State
  showCompanyTypeOptions = false;
  selectedCompanyTypeValue: string | null = null;
  selectedCompanyTypeLabel: string | null = null;

  // Options
  companyTypeOptions = [
    { label: 'CA', value: 'CA' },
    { label: 'Corporate', value: 'CO' },
    { label: 'Other', value: 'OT' }
  ];

  // Toggle dropdown
  toggleDropdownCompanyType() {
    this.showCompanyTypeOptions = !this.showCompanyTypeOptions;
  }

  // Select option
  selectCompanyType(option: { label: string; value: string }) {
    this.selectedCompanyTypeValue = option.value;
    this.selectedCompanyTypeLabel = option.label;
    this.showCompanyTypeOptions = false;
    this.signupForm.patchValue({
      company_type: option.value,
    });

    // company_type: ['', Validators.required],
  }



  confirmPasswordVisible: boolean = false;
  // password visibility
  toggleConfirmPasswordVisibility(): void {
    this.confirmPasswordVisible = !this.confirmPasswordVisible;
  }

  // Google Sign In
  signInWithGoogle(): void {
    this.isLoading = true;
    this.oauthService.signInWithGoogle().subscribe({
      next: (user) => {
        if (user) {
          console.log('Google user data:', user);
          // Extract user details
          const firstName = user.firstName || '';
          const lastName = user.lastName || '';
          const email = user.email;
          const photoUrl = user.photoUrl;
          const provider = user.provider;

          // Create registration request for social login
          this.registerSocialUser({
            client_name: firstName,
            deductor_name: lastName,
            email: email,
            provider: provider,
            social_id: user.id,
            photo_url: photoUrl
          });
        } else {
          this.isLoading = false;
          this.toastService.showError('Google sign-in was cancelled');
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Google sign-in error:', error);
        this.toastService.showError('Failed to sign in with Google');
      }
    });
  }

  // Microsoft Sign In
  signInWithMicrosoft(): void {
    this.isLoading = true;
    this.oauthService.signInWithMicrosoft().subscribe({
      next: (user) => {
        if (user) {
          console.log('Microsoft user data:', user);
          // Extract user details
          const firstName = user.firstName || '';
          const lastName = user.lastName || '';
          const email = user.email;
          const provider = user.provider;

          // Create registration request for social login
          this.registerSocialUser({
            client_name: firstName,
            deductor_name: lastName,
            email: email,
            provider: provider,
            social_id: user.id,
            photo_url: user.photoUrl || ''
          });
        } else {
          this.isLoading = false;
          this.toastService.showError('Microsoft sign-in was cancelled');
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Microsoft sign-in error:', error);
        this.toastService.showError('Failed to sign in with Microsoft');
      }
    });
  }

  // Register user from social login
  private registerSocialUser(userData: any): void {
    // Generate a random password for social users (they won't use it)
    const randomPassword = this.generateRandomPassword();
    const saltRounds = 10;
    const hashedPassword = bcrypt.hashSync(randomPassword, saltRounds);

    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_process_seqno: "",
        a_iud_type: "i",
        a_proc_type: "get_miud_client_mast_proposal",
        a_user_code: "12345678",
        a_entity_code: "B0",
        a_client_code: "",
        a_acc_year: "",
        a_quarter_no: "",
        a_tran_month: "",
        a_tran_from_date: "",
        a_tran_to_date: "",
        a_tds_type_code: "",
        a_module_type_code: "TAXCPC",
        a_sub_module_type_code: "R",
        a_first_level_client_code: "",
        client_mast_proposal: {
          entity_code: 'B0',
          client_name: userData.client_name,
          deductor_name: userData.deductor_name,
          email_id: userData.email,
          phoneno: userData.phoneno || '',
          organisation_type: userData.provider === 'GOOGLE' ? 'Google Account' : 'Microsoft Account',
          login_pwd: hashedPassword,
          social_provider: userData.provider,
          social_id: userData.social_id,
          signup_type: userData.provider === "GOOGLE" ? "G" : "M",
          signup_key_value: userData,
        },
      }),
    };

    this.authservice.signup(requestBody).subscribe({
      next: (response) => {
        this.isLoading = false;
        const result = response?.result?.[0];
        if (result.a_proc_error == -1) {
          // User might already exist, try to log them in
          const errorMessage = result.a_proc_error_message || '';

          if (errorMessage.toLowerCase().includes('already exist')) {
            // Redirect to login with social auth token
            this.toastService.showSuccess('Account exists. Redirecting to dashboard...');
            setTimeout(() => {
              this.router.navigate(['/home/dashboard']);
            }, 1000);
          } else {
            this.toastService.showError(errorMessage);
          }
        } else if (result.a_proc_error == -1) {

          const successMessage = result.a_proc_error_message || 'Registration successful!';
          this.toastService.showSuccess(successMessage);

          // Auto-login user
          setTimeout(() => {
            this.router.navigate(['/home/dashboard']);
          }, 1000);
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Social registration error:', err);
        this.toastService.showError('Registration failed. Please try again');
      }
    });
  }

  // Generate random password for social users
  private generateRandomPassword(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 16; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }







}
