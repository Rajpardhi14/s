import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

import { AuthService } from '../../../../core/services/auth/auth.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { AuthbannerComponent } from "../authbanner/authbanner.component";
import * as bcrypt from 'bcryptjs';
@Component({
  selector: 'app-changepassword',
  standalone: true,
  imports: [CommonModule,
    RouterLink, FormsModule, ReactiveFormsModule, AuthbannerComponent],
  templateUrl: './changepassword.component.html',
  styleUrl: './changepassword.component.css'
})
export class ChangepasswordComponent implements OnInit {
  isLoading: boolean = false; // Added loading state
  isPasswordVisible: boolean = false;
  confirmPasswordVisible: boolean = false;
  changePasswordForm!: FormGroup;
  passKey: string = '';
  isSubmitting: boolean = false;
  passwordCriteria = {
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    specialChar: false,
  };

  constructor(private router: Router,
    private authService: AuthService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private toastService: ToastService,
  ) { }
  userCode: any


  // ngOnInit(): void {
  //   this.route.queryParams.subscribe((params) => {
  //     if (params['token']) {
  //       try {
  //         // decode base64 JSON
  //         const decoded = JSON.parse(atob(params['token'].split('.')[0] || params['token']));
  //         console.log('Decoded token:', decoded);

        
  //         this.userCode = decoded.user_code || '';
         
  //         this.passKey = decoded.pass_key || '';
  //       } catch (err) {
  //         console.error('Invalid token format', err);
  //       }
  //     }
  //   });
  //   this.changePasswordForm = this.fb.group({
  //     newPassword: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.minLength(8),
  //         Validators.pattern(
  //           '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
  //         ),
  //       ],
  //     ],
  //     confirmPassword: ['', [Validators.required]],
  //   });
  //   // Add match validator
  //   this.changePasswordForm
  //     .get('confirmPassword')
  //     ?.setValidators([Validators.required, this.matchPassword.bind(this)]);

  //   // Update validation when password changes
  //   this.changePasswordForm.get('newPassword')?.valueChanges.subscribe(() => {
  //     this.changePasswordForm.get('confirmPassword')?.updateValueAndValidity();
  //   });
  // }

  

  ngOnInit(): void {
  this.route.queryParams.subscribe((params) => {
    if (params['token']) {
      try {
        // decode base64 JSON (support normal Base64 & JWT-like token)
        const decoded = JSON.parse(atob(params['token'].split('.')[0] || params['token']));
        console.log('Decoded token:', decoded);

        this.userCode = decoded.user_code || '';
        this.passKey = decoded.pass_key || '';

        // 🕐 Check expiry (assuming 10-minute validity)
        if (decoded.request_at) {
          const requestTime = new Date(decoded.request_at).getTime();
          const now = Date.now();
          const diffMinutes = (now - requestTime) / (1000 * 60);

          // If more than 10 minutes old → token expired
          if (diffMinutes > 10) {
            this.toastService.showError('Your password reset link has expired. Please request a new one.');
            this.router.navigate(['/resetpasslinkexpired']);
            return;
          }
        }

      } catch (err) {
        console.error('Invalid token format', err);
        this.toastService.showError('Invalid or corrupted token.');
        this.router.navigate(['/resetpasslinkexpired']);
      }
    } else {
      this.toastService.showError('Missing token parameter.');
      this.router.navigate(['/resetpasslinkexpired']);
    }
  });

  this.changePasswordForm = this.fb.group({
    newPassword: [
      '',
      [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(
          '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$!%*?&])[A-Za-z\\d#@$!%*?&]{8,}$'
        ),
      ],
    ],
    confirmPassword: ['', [Validators.required]],
  });

  // confirm password validator
  this.changePasswordForm
    .get('confirmPassword')
    ?.setValidators([Validators.required, this.matchPassword.bind(this)]);

  this.changePasswordForm.get('newPassword')?.valueChanges.subscribe(() => {
    this.changePasswordForm.get('confirmPassword')?.updateValueAndValidity();
  });
}



  // Custom Validator
  matchPassword(control: any) {
    if (!this.changePasswordForm) return null;
    return control.value === this.changePasswordForm.get('newPassword')?.value
      ? null
      : { mismatch: true };
  }




  // Submit Form
  submitForm() {
    if (this.changePasswordForm.invalid) {
      this.changePasswordForm.markAllAsTouched();
      return;
    }
    this.isLoading = true; 
    this.isSubmitting = true;

    const saltRounds = 10;

    

    const newPassword = this.changePasswordForm.value.newPassword;
    const hashedPassword = bcrypt.hashSync(newPassword, saltRounds);
    const requestBody = {
      sdata: JSON.stringify({

        a_session_seqno: '',
        a_iud_seqno: '',
        a_process_seqno: '',
        a_login_type: 'login_id',
        a_iud_type: 'rp',
        a_proc_type: 'get_miud_user_mast',
        a_user_code: '',
        a_entity_code: 'T1',
        a_client_code: '1686992',
        a_acc_year: '23-24',
        a_quarter_no: '4',
        a_tran_month: 'JAN',
        a_tran_from_date: '01-JAN-2024',
        a_tran_to_date: '31-MAR-2024',
        a_tds_type_code: '24Q',
        a_module_type_code: 'TAXCPC',
        a_first_level_client_code: '',
        a_process_status_code: 'ZA',
        a_db_total_records: '1000',
        a_pagination_count: '0',

        user_mast: {
          user_code: this.userCode,
          login_pwd: hashedPassword
        }
        // a_login_pwd: newPassword,
        // pass_key: this.passKey,
      }),
    };
    // this.authService.changepassword(requestBody).subscribe(
    //   (response: any) => {
    //     if (response.result && response.result.length > 0) {
    //       const result = response.result[0];
    //       if (result.a_proc_error === 0) {
    //         this.toastService.showSuccess(result.a_proc_error_message || 'Password reset successfully!');
    //         this.router.navigate(['/passresetsuccessful']);
    //       } else if (result.a_proc_error === -1) {
    //         this.toastService.showError(result.a_proc_error_message || 'Password reset failed!');
    //       } else {
    //         this.toastService.showError('Unexpected response. Please try again.');
    //       }
    //     } else {
    //       this.toastService.showError(response.message || 'Unexpected response. Please try again.');
    //     }
    //     this.isSubmitting = false;
    //     this.isLoading = false;
    //   },
    //   (error) => {
    //     this.toastService.showError('An error occurred. Please try again.');
    //     this.isSubmitting = false;
    //     this.isLoading = false;
    //   }
    // );


    this.authService.changepassword(requestBody).subscribe(
      (response: any) => {
        this.isLoading = false;
        this.isSubmitting = false;

        if (response.status === 0) {
          // Failure
          const message = response.msg || 'Password reset failed!';
          this.toastService.showError(message);
          // Success

        } else {
          const message = response.msg || 'Password reset successfully!';
          this.toastService.showSuccess(message);
          this.router.navigate(['/passresetsuccessful']);

        }
      },
      (error) => {
        this.isLoading = false;
        this.isSubmitting = false;
        this.toastService.showError('An error occurred. Please try again.');
      }
    );

  }

  // password visibility
  togglePasswordVisibility(): void {
    this.isPasswordVisible = !this.isPasswordVisible;
  }


  // password visibility
  toggleConfirmPasswordVisibility(): void {
    this.confirmPasswordVisible = !this.confirmPasswordVisible;
  }

  //validatePassword tooltip
  validatePassword() {
    const password = this.changePasswordForm.controls['newPassword'].value;
    this.passwordCriteria.length = password.length >= 8;
    this.passwordCriteria.uppercase = /[A-Z]/.test(password);
    this.passwordCriteria.lowercase = /[a-z]/.test(password);
    this.passwordCriteria.number = /[0-9]/.test(password);
    this.passwordCriteria.specialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  }
}

