import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthbannerComponent } from '../authbanner/authbanner.component';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { AuthService } from '../../../../core/services/auth/auth.service';
import * as CryptoJS from 'crypto-js';
import { IpService } from '../../../../core/services/ipaddress/ip.service';
import * as bcrypt from 'bcryptjs';
@Component({
  selector: 'app-otpverification',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AuthbannerComponent,
    RouterLink
    ,
  ],
  templateUrl: './otpverification.component.html',
  styleUrls: ['./otpverification.component.css'],
})
export class OtpverificationComponent implements OnInit {
  @ViewChildren('otpInputs') otpInputs!: QueryList<ElementRef>;
  otpArray: string[] = ['', '', '', '', '', '']; // 6 digits for both OTP and 2FA
  inputsDisabled: boolean = false;
  ipAddress: string | null = null;
  email!: string;
  isLoading: boolean = false; // Loading state
  countdown: number = 120; // Initial countdown value
  isResendDisabled: boolean = true; 
  private countdownInterval: any; 

  // 2FA specific properties
  is2FAMode: boolean = false;
  tempAuthData: any = null;
  verificationType: 'otp' | '2fa' = 'otp';

  constructor(
    private router: Router,
    private toastService: ToastService,
    private authservice: AuthService,
    private ipService: IpService
  ) { }

  ngOnInit(): void {
    // Check if we're in 2FA mode - check both navigation state and history state
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state || history.state;

    console.log('OTP Component - Navigation state:', state); // Debug log

    if (state?.['mode'] === '2fa') {
      // 2FA mode from login
      console.log('2FA mode detected, authData:', state['authData']); // Debug log
      this.is2FAMode = true;
      this.verificationType = '2fa';
      this.tempAuthData = state['authData'];
      this.email = this.tempAuthData?.userData?.email_id || this.tempAuthData?.userData?.login_id || '';
      // Don't start countdown for 2FA
    } else {
      // Regular OTP mode for signup
      console.log('Regular OTP mode'); // Debug log
      this.email = localStorage.getItem('userEmail') || '';
      if (!this.email) this.router.navigate(['/signup']);
      this.startCountdown();
    }

    this.ipService.ipAddress$.subscribe((ip) => {
      this.ipAddress = ip;
    });
  }


  ngAfterViewInit() {
    this.otpInputs.changes.subscribe(() => {
      this.otpInputs.forEach((input) => {
        input.nativeElement.setAttribute('autocomplete', 'one-time-code');
      });
    });
  }

  //countdown
  startCountdown(): void {
    this.isResendDisabled = true; // Disable resend button
    this.countdown = 120; // Reset countdown
    clearInterval(this.countdownInterval); // Clear any existing interval
    this.countdownInterval = setInterval(() => {
      if (this.countdown > 0) {
        this.countdown--;
      } else {
        this.isResendDisabled = false; // Enable resend button when timer ends
        clearInterval(this.countdownInterval); // Stop countdown
      }
    }, 1000);
  }

  onInput(event: any, nextInput: any) {
    const input = event.target;
    const value = input.value;
    if (value.length === 1 && nextInput) {
      nextInput.focus();
    }
  }

  onKeyDown(event: KeyboardEvent, prevInput: any) {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Backspace' && input.value === '' && prevInput) {
      prevInput.focus();
    }
  }

  // verifyOtp - handles both OTP and 2FA verification
  verifyOtp(): void {
    if (!this.isOtpComplete()) {
      const message = this.is2FAMode ? 'Please enter a valid 6-digit code from Google Authenticator' : 'Please enter a valid 6-digit OTP';
      this.toastService.showError(message);
      return;
    }

    this.isLoading = true; // Start loading

    if (this.is2FAMode) {
      // 2FA verification
      this.verify2FA();
    } else {
      // Regular OTP verification for signup
      const requestBody = {
        email_id: this.email,
        otp: this.otpArray.join(''),
      };
      this.authservice.verifyotp(requestBody).subscribe({
        next: (response) => {
          this.isLoading = false; // Stop loading

          if (response?.status === 1) {
            localStorage.setItem('otpVerified', 'true');
            this.toastService.showSuccess('OTP verified successfully');

            setTimeout(() => {
              const storedFormData = localStorage.getItem('signupFormData');
              if (storedFormData) {
                this.completeSignup(JSON.parse(storedFormData));
              }
            }, 1000);
          } else if (response?.status === 0) {
            const errorMessage = response?.message || 'Invalid OTP. Please try again';
            this.otpArray = ['', '', '', '', '', ''];
            this.toastService.showError(errorMessage);
          } else {
            this.toastService.showError('Verification failed. Please try again');
          }
        },
        error: () => {
          this.isLoading = false; // Stop loading on error
          this.toastService.showError('Verification failed. Please try again');
        },
      });
    }
  }

  // New method for 2FA verification
  private verify2FA(): void {
    const verifyRequest = {
      user_code: this.tempAuthData.userData.user_code,
      verification_code: this.otpArray.join(''),
      temp_token: this.tempAuthData.token,
      login_id: this.tempAuthData.loginId
    };

    this.authservice.verify2FA(verifyRequest).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          // 2FA verified successfully, complete login
          this.complete2FALogin();
        } else {
          this.toastService.showError('Invalid 2FA code. Please try again.');
          this.otpArray = ['', '', '', '', '', ''];
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('2FA verification error:', error);
        this.toastService.showError('Failed to verify 2FA code. Please try again.');
      }
    });
  }

  // Complete login after 2FA verification
  private complete2FALogin(): void {
    const userData = this.tempAuthData.userData;
    const token = this.tempAuthData.token;

    if (token) {
      document.cookie = `Authtoken=${encodeURIComponent(token)}; path=/; secure; samesite=strict`;
      localStorage.setItem('Usercode', userData.user_code);
    }

    // Store user data
    localStorage.setItem('localUserData', JSON.stringify(userData));
    sessionStorage.setItem('loginSuccess', 'true');

    this.toastService.showSuccess('Login successful!');

    // Navigate to home/dashboard
    this.router.navigate(['home/dashboard']);
  }

  //Resend OTP with Proper Loading Handling
  resendOtp(): void {
    if (this.isResendDisabled) return;
    this.isLoading = true;
    const storedFormData = localStorage.getItem('signupFormData');
    let username = '';
    if (storedFormData) {
      const formData = JSON.parse(storedFormData);
      username = `${formData.client_name || ''} ${formData.deductor_name || ''}`.trim();
    }

    const requestBody = {
      email_id: this.email,
      username: username || "",
      ip_address: this.ipAddress || ''
    };
    this.authservice
      .signotp(requestBody).subscribe({
        next: (response) => {
          this.isLoading = false; // Stop loading
          if (response?.status === 1) {
            this.otpArray = ['', '', '', '']; // Clear OTP inputs
            this.toastService.showSuccess('New OTP sent to your email');
            this.startCountdown(); // Restart countdown
          } else {
            this.toastService.showError('Failed to resend OTP');
          }
        },
        error: () => {
          this.isLoading = false; // Stop loading on error
          this.toastService.showError('Failed to resend OTP');
        },
      });
  }

  //Check if OTP is Complete
  isOtpComplete(): boolean {
    return this.otpArray.every((digit) => digit !== '');
  }

  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.key.charCodeAt(0);
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }

  completeSignup(formData: any) {

    const saltRounds = 10;
    const hashedPassword = bcrypt.hashSync(formData.password, saltRounds);
    console.log(hashedPassword)
    const fullname = formData.deductor_name && formData.deductorlastname
      ? `${formData.deductor_name} ~ ${formData.deductorlastname}`
      : formData.deductorlastname || formData.deductorlastname;


    // const companyFullName =
    //   formData.company_type && formData.company_name
    //     ? `${formData.company_type} - ${formData.company_name}`
    //     : formData.company_name || formData.company_type;
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_process_seqno: "",

        a_iud_type: "i",
        a_proc_type: "get_miud_client_mast_proposal",
        a_user_code: "12345678",
        a_entity_code: "B0",
        a_client_code: "",
        a_acc_year: "",
        a_quarter_no: "",
        a_tran_month: "",
        a_tran_from_date: "",
        a_tran_to_date: "",
        a_tds_type_code: "",
        a_module_type_code: "TAXCPC",
        a_sub_module_type_code: "R",
        a_first_level_client_code: "",
        client_mast_proposal: {
          entity_code: 'B0',
          client_name: formData.client_name.toUpperCase(),
          deductor_name: fullname.toUpperCase(),
          email_id: formData.email,
          phoneno: formData.contactNumber,
          organisation_type: formData.company_type.toUpperCase(),
          login_pwd: hashedPassword,
          // signup_key_value: '',
          // signup_type: 'N',
        },
      }),
    };

    this.authservice.signup(requestBody).subscribe({
      next: (response) => {
        this.isLoading = false;
        const firstResult = response?.result?.[0];
        if (firstResult == -1) {

          if (firstResult.a_errors?.length > 0) {
            this.toastService.showError(firstResult.a_errors[0].message);
          } else {
            // Fallback if no a_errors array or empty
            this.toastService.showError(firstResult.a_proc_error_message || 'Registration failed');
          }
        } else {
          localStorage.removeItem('signupFormData');
          localStorage.removeItem('userEmail');
          this.router.navigate(['/']);
          this.toastService.showSuccess('Registration successful!');
        }
      },
      error: () => {
        this.toastService.showError('Registration failed');
      },
    });
  }
}
