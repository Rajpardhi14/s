import { Component } from '@angular/core';

import { AuthbannerComponent } from "../authbanner/authbanner.component";

@Component({
  selector: 'app-resetpasslinkexpired',
  standalone: true,
  imports: [ AuthbannerComponent],
  templateUrl: './resetpasslinkexpired.component.html',
  styleUrl: './resetpasslinkexpired.component.css'
})
export class ResetpasslinkexpiredComponent {

}
