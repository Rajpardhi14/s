import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetpasslinkexpiredComponent } from './resetpasslinkexpired.component';

describe('ResetpasslinkexpiredComponent', () => {
  let component: ResetpasslinkexpiredComponent;
  let fixture: ComponentFixture<ResetpasslinkexpiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResetpasslinkexpiredComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ResetpasslinkexpiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
