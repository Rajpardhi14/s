import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthbannerComponent } from './authbanner.component';

describe('AuthbannerComponent', () => {
  let component: AuthbannerComponent;
  let fixture: ComponentFixture<AuthbannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AuthbannerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AuthbannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
