import { CommonModule } from '@angular/common';
import { Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-authbanner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './authbanner.component.html',
  styleUrl: './authbanner.component.css'
})
export class AuthbannerComponent {
  slides = [
    { image: '../../../assets/loginbanner1.svg', data: "Achieve vendor delight with effortless<br>  onboarding" },
    { image: '../../../assets/slidetwo.svg', data: "Track, control, and optimize vendor expenses <br> with real-time insights." },
    { image: '../../../assets/slidethree.svg', data: "Automate payments and monitor utility  <br> expenses  effortlessly." },
  ];
  activeSlide = 0;
  interval: any;

  constructor(private ngZone: NgZone) { }

  ngOnInit() {
    this.startAutoSlide();
  }

  ngOnDestroy() {
    clearInterval(this.interval);
  }

  startAutoSlide() {
    this.ngZone.runOutsideAngular(() => {
      this.interval = setInterval(() => {
        this.ngZone.run(() => {

          if (this.activeSlide === this.slides.length - 1) {
            setTimeout(() => {
              this.activeSlide = 0;
            }, 500);
          } else {
            this.activeSlide = (this.activeSlide + 1) % this.slides.length;
          }
        });
      }, 4000);
    });
  }


  goToSlide(index: number) {
    this.activeSlide = index;
    clearInterval(this.interval);
    this.startAutoSlide();
  }

}
