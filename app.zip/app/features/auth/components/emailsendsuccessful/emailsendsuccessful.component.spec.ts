import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailsendsuccessfulComponent } from './emailsendsuccessful.component';

describe('EmailsendsuccessfulComponent', () => {
  let component: EmailsendsuccessfulComponent;
  let fixture: ComponentFixture<EmailsendsuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmailsendsuccessfulComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmailsendsuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
