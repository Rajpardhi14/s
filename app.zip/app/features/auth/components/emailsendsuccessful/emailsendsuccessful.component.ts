import { Component } from '@angular/core';

import { RouterLink } from '@angular/router';
import { AuthbannerComponent } from "../authbanner/authbanner.component";

@Component({
  selector: 'app-emailsendsuccessful',
  standalone: true,
  imports: [ RouterLink, AuthbannerComponent],
  templateUrl: './emailsendsuccessful.component.html',
  styleUrl: './emailsendsuccessful.component.css'
})
export class EmailsendsuccessfulComponent {

}
