import { CommonModule } from '@angular/common';
import { Component, DestroyRef, inject } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import {
  capitalizeEachWord,
  formatDatesend, formatValue
} from '../../shared/utils/passmatch';
import { Observable, skip, Subject, Subscription } from 'rxjs';
import { RefreshdataService } from '../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../core/services/screensize/screensize.service';
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { ToastService } from '../../core/services/toaster/toast.service';
import { XldownloadService } from '../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { TableskeletonComponent } from '../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../shared/components/nodata/nodata.component';
import { BasicFilterComponent } from '../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../shared/components/advance-filter/advance-filter.component';
import { GearboxComponent } from '../../shared/components/gearbox/gearbox.component';
import { AlertpoupComponent } from '../../shared/components/alertpoup/alertpoup.component';
import { AddldcComponent } from './addldc/addldc.component';
import { DisplayValueUtilService } from '../../shared/utils/displayValue';
import { AuthService } from '../../core/services/auth/auth.service';
import { Router } from '@angular/router';
import { OutSideClickDirective } from '../../core/services/outclick/outside-click.directive';
import { TooltipComponent } from '../../shared/components/tooltip/tooltip.component';
import { ButtoneventlisnerDirective } from '../../core/services/session/timer-session/buttoneventlisner.directive';
@Component({
  selector: 'app-ldc',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TableskeletonComponent,
    NodataComponent,
    BasicFilterComponent,
    AdvanceFilterComponent,
    FormsModule,
    GearboxComponent,
    AlertpoupComponent,
    AddldcComponent,
    OutSideClickDirective,
    TooltipComponent,
    ButtoneventlisnerDirective
  ],
  templateUrl: './ldc.component.html',
  styleUrl: './ldc.component.css',
})
export class LdcComponent {
  capatilizeEachword = capitalizeEachWord;
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  // Table data variable
  formatValue = formatValue;
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field?: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  isDeletePopupOpen = false;
  selectedIdsForDeletion: number = 0;
  isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  selectedRowDetails: any;
  capitalizeEachWord = capitalizeEachWord;
  dynamicUserData: any;
  multiMast: any;
  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private displayValueUtil: DisplayValueUtilService,
    private authservice: AuthService,
    private router: Router,

  ) { }

  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {

    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    const headerMastString = sessionStorage.getItem('headermastertwo');
    if (headerMastString) {
      const headerMast = JSON.parse(headerMastString);
      this.multiMast = headerMast;
    } else {
      console.error('No header master found in localStorage');
    }

    // this.dynamicUserData$
    //   .pipe(skip(1), takeUntilDestroyed(this.destroyRef))
    //   .subscribe((dynamicData) => {
    //     // console.log("Dynamic user data changed:", dynamicData);
    //     this.dynaUserData =
    //       this.userlocaldataService.getAllDynamicUserData() || {};
    //     this.offset = 0;
    //     this.fetchData();
    //     this.fetchFilter();
    //     this.fetchGrandTotal();
    //   });

    this.fetchData();
    this.fetchFilter();
    this.fetchGrandTotal();

    // this.refreshSubscription = this.refreshdata
    //   .onRefresh('LDC')
    //   .subscribe(() => {
    //     this.fetchData();
    //     this.fetchGrandTotal();
    //   });

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    this.refreshSubscription = this.refreshdata
      .onRefresh('LDC')
      .subscribe(() => {
        this.fetchData();
        this.fetchGrandTotal();
      });
    // console.log(this.dynaUserData);
  }

  buildMergeGroups() {
    this.headers?.forEach((header) => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }

  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );
  }
  values: any;
  selectedTab: any;
  fetchData() {
    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmdb_tds_spl_rate_mast_alloc',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService

      .getTableData('/LDC/get_gmdb_tds_spl_rate_mast_alloc', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gmdb_tds_spl_rate_mast_alloc;
            if (userData?.get_gmdb_tds_spl_rate_mast_alloc_header) {
              this.headers =
                userData?.get_gmdb_tds_spl_rate_mast_alloc_header?.map(
                  (header: any) => ({
                    ...header,
                   visible:
        this.gearboxState.hasOwnProperty(header.field)
          ? this.gearboxState[header.field] // restore previous state
          : header.display === 1,   // default if no previous state
                  })
                );
            }
            // this.allUsersData = userData || {};
            this.mergeGroups = {};
            this.fieldToMergeGroup = {};
            this.tableBody =
              userData?.get_gmdb_tds_spl_rate_mast_alloc_detail || [];
            this.buildMergeGroups();
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }
  myfilterfileds: any;

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchData();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmfb_tds_spl_rate_mast_alloc',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage
    );

    this.apiService
      .getFilterData('/LDC/get_gmfb_tds_spl_rate_mast_alloc', sdata)
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error === '0') {
            this.basic_filter =
              response?.result?.get_gmfb_tds_spl_rate_mast_alloc?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gmfb_tds_spl_rate_mast_alloc?.[1]?.advance_filter;

            this.initializeForm();
            this.advance_filter?.forEach((field: any) => {
              if (
                field.filter_col_external === 1 &&
                field.filter_col_type === 'filter-select'
              ) {
                const allOption = { value: 'ALL', label: 'All' };
                const exists = field.filter_col_depend_value?.some(
                  (opt: any) => opt.value === 'ALL'
                );
                if (!exists) {
                  field.filter_col_depend_value?.unshift(allOption);
                }
              }
            });

            const defaultField = this.advance_filter?.find(
              (field: any) =>
                field.filter_col_external === 1 &&
                (field.filter_col_type === 'filter-select' ||
                  field.filter_col_type === 'select')
            );

            const defaultOption = defaultField?.filter_col_depend_value?.find(
              (opt: any) => opt.value === 'ALL'
            );

            // Set default active tab
            this.defaultTabFilter = defaultOption;
            this.activeFilterTab = defaultOption?.value;

            if (defaultField && defaultOption) {
              const control = this.filterForm.get(
                defaultField.filter_col_field
              );
              if (control) {
                control.setValue(defaultOption.value, { emitEvent: false });
              }
            }

            this.menuOptions = this.basic_filter?.map((filter: any) => ({
              label: filter.filter_col_prompt,
              field: filter.filter_col_field,
              operator: filter.filter_col_depend_operator,
              alias: filter.filter_col_field_alias,
              placeholder: filter.filter_col_placeholder,
            }));
            this.selectedOption = this.menuOptions?.[0];
          } else {
            // this.errorMessage =response.result?.[0].a_proc_error_message || 'Please Check Endpoint';
            this.showError(this.errorMessage);
          }

          if (this.isFirstLoad) {
            this.isSkeletonshow = false;
            this.isFirstLoad = false;
          }
        },
        error: (error) => {
          console.error('Error user filter:', error);
          this.isSkeletonshow = false;
        },
      });
  }
  //#endregion

  // newFilterclase(filterField: string, value: any) {
  //   const control = this.filterForm.get(filterField);
  //   if (control) {
  //     control.setValue(null, { emitEvent: false });
  //     control.setValue(value, { emitEvent: true });
  //   }
  //   Object.keys(this.filterForm.controls).forEach((key) => {
  //     const ctrl = this.filterForm.get(key);
  //     if (ctrl && typeof ctrl.value === 'string') {
  //       ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
  //     }
  //   });
  //   // this.filterClause = this.buildFilterClause();

  //    const selectedFilter = this.values.find(
  //   (v: any) => v.value === value
  // );
  //   const condition = selectedFilter ? selectedFilter.condition : 'and 1=1';

  //   const newFilterClause = [
  //     {
  //       filter_col_field: 'tds_limit_amt_bal',
  //       filter_col_depend_operator: 'wc',
  //       filter_col_value: condition,
  //       filter_col_field_alias: 'a.',
  //     },
  //   ];
  //   this.filterClause = newFilterClause;
  // }



  selectedTabFilter(filterField: string, value: any, label: any): void {
    // console.log(value)
    this.selectedValue = value;
    this.myfilterfileds = filterField;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }


    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }
  gearboxState: { [key: string]: boolean } = {};

  saveGearboxState() {
  this.headers.forEach(h => {
    this.gearboxState[h.field] = h.visible;
  });
}
  onSubmit() {
    // 1️⃣ Save the gearbox state before table refresh
  this.saveGearboxState(); // save current visibility
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });
      this.syncBasicAndAdvanceFilters();
      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchData(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
  private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }




  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();

    // Check if user applied any filters different from defaults
    const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      const value = control?.value;
      const defaultVal = field._isDefaultValue ?? '';
      return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
    });

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (!control) return;

        const defaultVal = field._isDefaultValue ?? null;

        if (hasUserAppliedFilters) {
          // ✅ Keep default filters intact
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue(''); // clear user-only filters
          }
        } else {
          // ✅ If no user filters were applied — reset to defaults, not empty
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue('');
          }
        }
      });
    }

    // ✅ Rebuild filterClause including defaults
    this.selectedFilters = this.getSelectedFilters();
    this.filterClause = this.buildFilterClause();
    this.filtercount = this.getSelectedFilterCount();

    // 🚫 Don’t treat this as a full clear for fetchTable()
    this.fetchData;
    this.fetchGrandTotal();
  }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {
        const operator = filterConfig.filter_col_depend_operator || 'like';
        let filterValue: string | null = null;

        if (operator === 'wc') {
          const matchedCondition = filterConfig.filter_col_depend_value?.find(
            (item: any) =>
              item.value?.toLowerCase() === controlValue?.toLowerCase()
          );
          if (matchedCondition) {
            filterValue = matchedCondition.condition;
          }
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    if (this.searchTerm?.trim() && this.selectedOption) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.trim().toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }

    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;

    // console.log('Generated Filter Clause:', filterClause);
    // return filterClause;
  }


  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    const selectedFilters: { label: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
         if (
    this.searchTerm &&
    (this.searchTerm === selectedFilter.label ||
      this.searchTerm === selectedFilter.value ||
      this.searchTerm.toLowerCase().includes(selectedFilter.label?.toLowerCase()))
  ) {
    this.searchTerm = '';
  }
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
    this.clearAllFilters();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
 // user grand total
gtdgData:any;
showFooter: boolean = false; 

toggleFooter() {
  this.showFooter = !this.showFooter;
}
getVisibleHeaders() {
  return this.headers?.filter(h => h.visible) || [];
}

  private fetchGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gmdg_tds_spl_rate_mast_alloc',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { FYYear: this.FYYear ,
        iudtype: this.iudtype,
      }
    );

    this.apiService
      .getGrandTotal('/LDC/get_gmdg_tds_spl_rate_mast_alloc', sdata)
      .subscribe({
        next: (response) => {
          // this.loading = false;
          this.isLoadingMore = false;
          if (response?.result?.a_proc_error == 0) {
           this.gtdgData =
    response?.result?.get_gmdg_tds_spl_rate_mast_alloc?.[0] || null;

  this.usergrandtotal = this.gtdgData?.rec || null;
  this.totalcount = this.usergrandtotal;
          } else {
            this.showError(this.errorMessage);
          }
        },
        error: (error) => {
          // this.loading = false;
          this.isLoadingMore = false;
          this.showError('Something Went Wrong');
        },
      });
  }



  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(this.headers, this.tableBody, 'LDC Data');
  }

  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }

  statuskey: any;
selectedAlocValue: any;
  openDrawer(idTofetch?: string,AlocVal?:string) {
    this.selectedId = idTofetch ?? null;
    this.selectedAlocValue = AlocVal ?? null;
    this.isDrawerOpen = true;
    console.log(this.selectedAlocValue);
  }

  closeDrawer() {
    this.selectedId = null;
    this.isDrawerOpen = false;
  }
  handleClosePopup() {
    this.isDrawerOpen = false;
  }
  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  // Count selected rows
  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }

  // getSelectedRows(): any[] {
  //   return this.paginatedList?.filter((row: any) => row.selected) || [];
  // }

  // openDeletePopup(key: string) {
  //   this.statuskey = key;
  //   if (this.statuskey === 'a') {
  //     this.DeleteRecord();
  //   } else {
  //     this.isDeletePopupOpen = true;
  //     this.isDrawerOpen = false;
  //   }
  // }
    openDeletePopup() {
    this.isDeletePopupOpen = true;
    // console.log('called');
    this.isDrawerOpen = false;
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.DeleteRecord();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = false;
  }
  getSelectedRowIds(): number[] {
    return this.paginatedList
      ?.filter((row: any) => row.selected)
      ?.map((row: any) => row.rowid_seq);
  }





  DeleteRecord() {
    const selectedIds = this.getSelectedRowIds();
    if (selectedIds.length === 0) {
      this.showError('Please select at least one row to delete.');
      return;
    }
    const isAll = this.isAllSelected();

    let iudType: 'sd' | 'md';
    if (this.paginatedList.length === 1 && selectedIds.length === 1) {
      iudType = 'sd'; // single record → SD always
    } else {
      iudType = isAll ? 'md' : 'sd';
    }
    // const iudType = isAll ? 'md' : 'sd';

    // Base request body
    const requestBody: any = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type: iudType,
      a_user_code: this.localUserData?.user_code,
      a_entity_code: this.dynaUserData?.entity_code,
      a_client_code: this.dynaUserData?.client_code,
      a_acc_year: this.dynaUserData?.default_acc_year,
      a_quarter_no: this.dynaUserData?.default_quarter_no,
      a_tran_month: this.dynaUserData?.default_tran_month,
      a_validation_client_level: this.dynaUserData?.client_code_level,
      a_tran_from_date: this.dynaUserData?.default_from_date,
      a_tran_to_date: this.dynaUserData?.default_to_date,
      a_tds_type_code: this.dynaUserData?.default_tds_type_code,
      a_module_type_code: this.dynaUserData?.default_module_type_code,
      a_first_level_client_code: this.dynaUserData?.first_level_client_code,
      a_client_code_level: this.dynaUserData?.client_code_level,
      a_user_level: this.dynaUserData.user_level,
      // a_email_id: this.dynaUserData.email_id,
      a_proc_type: 'get_gtmd_tds_spl_rate_mast',
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      // tds_spl_rate_mast: selectedIds.map((id: any) => ({
      //   rowid_seq: id,
      // })),
    };

    // if (selectedRows.length === this.paginatedList.length) {
    //   requestBody.get_miud_tds_spl_rate_mast_alloc = {
    //     a_filter_clause: this.filterClause
    //   };
    // } else {
    //   // Otherwise, send selected row IDs
    //   requestBody.get_miud_tds_spl_rate_mast_alloc = {
    //     rowid_seq: selectedIds
    //   };
    // }
    // console.log(iudType);
    if (iudType == 'md') {

      // Build dynamic filter clause
      this.filterClause = Array.isArray(this.filterClause)
        ? this.filterClause
        : [];

      // const newFilterClause = [
      //   {
      //     filter_col_field: 'tds_type_code',
      //     filter_col_depend_operator: '=',
      //     filter_col_value: this.dynaUserData.default_tds_type_code,
      //     filter_col_field_alias: 'a.',
      //   },
      // ];

      // newFilterClause.forEach((nf) => {
      //   const exists = this.filterClause.some(
      //     (f: any) => f.filter_col_field === nf.filter_col_field
      //   );
      //   if (!exists) {
      //     this.filterClause.push(nf);
      //   }
      // });

      requestBody.a_filter_clause = this.filterClause;
    } else {
      // Single delete → map selected IDs
      requestBody.tds_spl_rate_mast = selectedIds.map(
        (id: number) => ({
          rowid_seq: id,
        })
      );
    }
    this.apiService
      .miudApi('/LDC/get_gtmd_tds_spl_rate_mast', requestBody)
      .subscribe({
        next: (response) => {
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message);
            // this.
            this.refreshdata.trigerRefresh('LDC');
          } else {
            this.showError(
              result.a_proc_error_message || 'Error while creating User.'
            );
          }
        },
        error: () => {
          this.showError('Something went wrong! Please try again later.');
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  // Check if all rows are selected
  isAllSelected(): boolean {

    return this.paginatedList?.every((row: any) => row.selected);

  }

  // Toggle all rows
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }

  // Get selected rows (optional helper)
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }

  onClear() {
    this.paginatedList?.forEach((r: any) => (r.selected = false));
  }

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }

  isDateField(field: string): boolean {
    const dateFields = [
      'challan_date',
      'certificate_valid_upto',
      'certificate_valid_from',
    ];
    return dateFields.includes(field);
  }
  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }


  iudType: any;
  filterValue: any;
  tiudfilterClause: any;
  isSubmitting: boolean = false;
  isSubmittingUpdate = false;





  // onsubmit() {
  //   const selectedIds = this.getSelectedRowIds();
  //   console.log(selectedIds)
  //   if (selectedIds.length === 0) {
  //     this.showError('Please select at least one row.');
  //     return;
  //   }
  //   const isAll = this.isAllSelected();

  //   // 👇 Determine iudType based on your logic
  //   let iudType: 'UN-ALLOC' | 'SELECTED-UN-ALLOC' | 'ALLOC' | 'SELECTED-ALLOC';

  //   if (this.selectedTab == 'ALLOC' && this.paginatedList.length === 1 && selectedIds.length === 1) {
  //     // Allocation cases
  //     iudType = 'SELECTED-ALLOC';
  //   } else if (this.selectedTab == 'ALLOC' && isAll) {
  //     // Un-allocation cases
  //     iudType = 'ALLOC';
  //   }
  //   else if (this.selectedTab == 'UN-ALLOC' && isAll) {
  //     iudType = 'UN-ALLOC';
  //   }
  //   else {
  //     iudType = 'SELECTED-UN-ALLOC';
  //   }
  //   const requestBody = {
  //     a_session_seqno: '',
  //     a_iud_seqno: '',
  //     a_is_pen_flag: '',
  //     a_login_type: 'login_id',
  //     a_module_type_code: this.dynaUserData?.default_module_type_code,
  //     a_sub_module_type_code: 'R',
  //     a_user_code: this.localUserData.user_code,
  //     a_entity_code: this.dynaUserData.entity_code,
  //     a_client_code: this.dynaUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_client_code_level: this.dynaUserData.client_code_level,
  //     a_user_level: this.dynaUserData.user_level,
  //     a_proc_error: '0',
  //     a_process_seqno: '',
  //     a_alloc_group_str: '',
  //     a_iud_type: iudType,
  //     a_proc_type: 'get_miud_tds_spl_rate_mast_alloc',
  //     a_process_status_code: '',
  //     // a_db_total_records: '1000',
  //     // a_pagination_count: '0',
  //     tds_spl_rate_mast: selectedIds.map(id => ({ rowid_seq: id }))


  //   };
  //   console.log(selectedIds);
  //   this.submitRequest(
  //     requestBody,
  //     'Challans  Record Created Successfully!',
  //     (value) => (this.isSubmittingUpdate = value)
  //   );

  // }
  //subbmit

  allocUnallocBtn(action: 'ALLOCATE' | 'UNALLOCATE'){
    if(action=='ALLOCATE'){
      this.onsubmit('ALLOCATE')
      this.isLoader1=true;
    }else if(action=='UNALLOCATE'){
       this.onsubmit('UNALLOCATE')
       this.isLoader2=true;
    }else{
this.isLoader3=true;
    }
  }
isLoader1:boolean=false;
isLoader2:boolean=false;
isLoader3:boolean=false;

  onsubmit(action:any) {
 
    const selectedIds = this.getSelectedRowIds();
    // console.log(selectedIds);

    if (selectedIds.length === 0) {
      this.showError('Please select at least one row.');
      return;
    }

    const isAll = this.isAllSelected();

    let iudType: 'UN-ALLOC' | 'SELECTED-UN-ALLOC' | 'ALLOC' | 'SELECTED-ALLOC';

    if (action === 'ALLOCATE') {
      // When Allocate button is clicked
      if (isAll) {
        iudType = 'ALLOC';
      } else {
        iudType = 'SELECTED-ALLOC';
      }
    } else {
      // When UnAllocate button is clicked
      if (isAll) {
        iudType = 'UN-ALLOC';
      } else {
        iudType = 'SELECTED-UN-ALLOC';
      }
    }

    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_is_pen_flag: '',
      a_login_type: 'login_id',
      a_module_type_code: this.dynaUserData?.default_module_type_code,
      a_sub_module_type_code: 'R',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_client_code_level: this.dynaUserData.client_code_level,
      a_user_level: this.dynaUserData.user_level,
      a_proc_error: '0',
      a_process_seqno: '',
      a_alloc_group_str: '',
      a_iud_type: iudType,
      a_proc_type: 'get_miud_tds_spl_rate_mast_alloc',
      a_process_status_code: '',
      tds_spl_rate_mast: selectedIds.map(id => ({ rowid_seq: id })),
    };
    // this.isLoader1 = true;
    //  this.isLoader2 = true;
    //   this.isLoader3 = true;
    // console.log('Final iudType:', iudType);

    this.submitRequest(
      
      requestBody,
      
      'LDC Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
      
    );
       
  }






  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiService
      .createData('/LDC/get_miud_tds_spl_rate_mast_alloc', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
         this.isLoader1 = false;
            this.isLoader2 = false;
      this.isLoader3 = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            // this.close();
            this.refreshdata.trigerRefresh('LDC');


          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while Unalocate/Allocate the data.'
              );
              this.isSubmitting = false;
               this.isLoader1 = false;
                  this.isLoader2 = false;
               this.isLoader3 = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }





  // handleMultiMast(multiMastData: any) {
  //   console.log('Received multiMast data:', multiMastData);
  // this.multiMast = multiMastData;

  // }


  //Get label from master list dynamically based on col_field_select

  getLabelFromMaster(colFieldSelect: string, value: any): string {
    if (!colFieldSelect || value === null || value === undefined) return value;

    const masterList = this.multiMast?.[colFieldSelect];
    if (!masterList || !Array.isArray(masterList)) return value;

    // Assuming your master data structure looks like [{ code: '1', name: 'Section 194C' }]
    const found = masterList.find(
      (item: any) => item.code == value || item.value == value
    );
    return found ? (found.name || found.label || value) : value;
  }


  // getDisplayValue(header: any, row: any) {
  //   return this.displayValueUtil.getDisplayValue(header, row, this.multiMast);
  // }

isDropdownOpen = false;

// ✅ Button label
mainButtonLabel = 'More';

// ✅ Dropdown options array
dropdownOptions = [
  { label: 'Fetch from Traces', action: 'fetchTraces' },
  { label: 'Bulk Import', action: 'BulkImport' },
  // You can add more dynamically here
];

toggleDropdown() {
  this.isDropdownOpen = !this.isDropdownOpen;
}
// ✅ Handle option click dynamically
handleOptionClick(option: any) {
  this.isDropdownOpen = false;

  switch (option.action) {
    case 'fetchTraces':
      this.onFetchTraces();
      break;
    case 'BulkImport':
      this.navigateToReturns();
      break;
    default:
      console.warn('No action found for:', option);
  }
}

  navigateToReturns() {
    const code = 'ZZTMPETDM00LD02'
    this.router.navigate(['/home/returns'], {
      queryParams: { code: code },
    });
  }

// ✅ Example methods
onFetchTraces() {
//  routes(/home/traces)
this.router.navigate(['/home/traces']);
}


   sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";

   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }
}
