import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddldcComponent } from './addldc.component';

describe('AddldcComponent', () => {
  let component: AddldcComponent;
  let fixture: ComponentFixture<AddldcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddldcComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddldcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
