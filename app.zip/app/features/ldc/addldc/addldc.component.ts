import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { DatepickerComponent } from '../../../shared/components/datepicker/datepicker.component';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
import { formatDatesend } from '../../../shared/utils/passmatch';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';
@Component({
  selector: 'app-addldc',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OutSideClickDirective,
    DatepickerComponent,
    AlertpoupComponent,
    ButtoneventlisnerDirective
  ],
  templateUrl: './addldc.component.html',
  styleUrl: './addldc.component.css',
})
// export class AddldcComponent {

// }
export class AddldcComponent {
  @Input() selectedId: string | null = null;
   @Input() selectedAlocValue: string | null = null;
  @Input() isDrawerOpen: boolean = false;
  @Output() closeDrawer = new EventEmitter<void>();

  roleData: any;
  isSubmittingUpdate = false;
  originalPassword: string = '';
  userForm!: FormGroup;
  dynamicUserData: any;
  isSubmitting = false;
  showBankBranchCodeOption: boolean = false;
  selectedBranchCodeLabel: string = 'Select';
  selectedBranchCodeValue: string | null = null;
  originalBranchCodeOption: any[] = [];
  branchCodeOption: any[] = [];
  //  this.selectedBranchCodeLabel = 'Select';
  searchText: string = '';
  localUserData: any;
  errorMessage: string = '';
  quarterNo: any;
  tdsTypeCode: any;
  FYear: any;
  selectedFYRange: { yrbegdate: string; yrenddate: string } | null = null;
  // financialYears = [
  //   { acc_year: '22-23', yrbegdate: '01-APR-2022', yrenddate: '31-MAR-2023' },
  //   { acc_year: '23-24', yrbegdate: '01-APR-2023', yrenddate: '31-MAR-2024' },
  //   { acc_year: '24-25', yrbegdate: '01-APR-2024', yrenddate: '31-MAR-2025' },
  //   { acc_year: '25-26', yrbegdate: '01-APR-2025', yrenddate: '31-MAR-2026' },
  // ];
  isLoadingPanData: boolean = false;
  detailsLoader: boolean = false;
  pannoVerified: string | null = null;
    isSubmittingUpdateLoader: boolean = false;
  constructor(
    private fb: FormBuilder,
    private refreshdata: RefreshdataService,
    private apiservice: ApiserviceService,
    private userlocaldata: UserdataService,
    private toastService: ToastService,
    private authservice: AuthService
  ) {}

  // ngOnChanges(changes: SimpleChanges): void {
  //       this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
  //      this.localUserData = this.userlocaldata.getLocalUserData();
  //   this.FYear=this.dynamicUserData.default_acc_year;

  //  console.log('Current FY:', this.FYear);

  // // find current year details
  // this.selectedFYRange = this.financialYears.find(
  //   (fy) => fy.acc_year === this.FYear
  // ) || null;

  // console.log('FY Range:', this.selectedFYRange);
  //   // this.isLoading = true;
  //   if (changes['selectedId'] && this.selectedId) {
  //     console.log(this.selectedId);
  //     this.fetchUserDetails(this.selectedId);
  //     this.isEditMode = false;
  //     this.isDrawerOpen = true;
  //   } else {
  //     // this.isLoading = false;
  //     this.isEditMode = true;
  //     this.initializeForm();
  //   }
  // }
  fyRange: any = {};
  regexList: any;
  ngOnChanges(changes: SimpleChanges): void {
    this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.FYear = this.dynamicUserData.default_acc_year;

    if (this.FYear) {
      this.fyRange = this.getFyDateRange(this.FYear);
      // console.log('Dynamic FY Range:', this.fyRange);
    }

    if (changes['selectedId'] && this.selectedId) {
      this.fetchUserDetails(this.selectedId);
      this.isEditMode = false;
      this.isDrawerOpen = true;
    } else {
      this.isEditMode = true;
      this.initializeForm();
    }
  }
  ngOnInit(): void {
    this.dynamicUserData = this.userlocaldata.getAllDynamicUserData();
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.quarterNo = this.dynamicUserData.default_quarter_no;
    this.tdsTypeCode = this.dynamicUserData.default_tds_type_code;
    this.FYear = this.dynamicUserData.default_acc_year;

    // 🟩 Load regex list from localStorage before initializing the form
    // const regexData = localStorage.getItem('regexList');
    // this.regexList = regexData ? JSON.parse(regexData) : [];

    this.initializeForm();
    // this.gettdsSec();
    this.selectedBranchCodeLabel = 'Select';
    this.getsData();
  }

  // initializeForm() {
  //    const getRegex = (label: string): string | null => {
  //   const found = this.regexList.find((r: any) => r.label === label);
  //   return found ? found.value : null;
  // };
  //   this.userForm = this.fb.group({
  //     deductee_panno: [
  //       '',
  //       [Validators.required, Validators.pattern(getRegex('deductee_panno') || /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)],
  //     ],

  //     tds_code: ['', Validators.required,],

  //     certificate_no: [
  //       '',
  //       [
  //         Validators.minLength(10),
  //         Validators.maxLength(10),
  //         Validators.required,
  //       ],
  //     ],
  //     cust_id: ['', [Validators.minLength(7), Validators.maxLength(10)]],
  //     // tds_type_code: ['', Validators.required],

  //     tds_limit_amt:  ['',[Validators.required,Validators.max(1000000000),Validators.pattern(/^\d+(\.\d{1,2})?$/)]],
  //     tds_rate: [
  //       '',
  //       [
  //         Validators.required,
  //         Validators.min(0),
  //         Validators.max(100),
  //         Validators.pattern(/^\d+(\.\d{1,2})?$/), // allows numbers with up to 2 decimals
  //       ],
  //     ],

  //     amount_consumed: ['',[Validators.max(1000000000),Validators.pattern(/^\d+(\.\d{1,2})?$/)]], //ldc amount consume
  //     certificate_valid_from: ['', [Validators.required,]],
  //     certificate_valid_upto: ['', Validators.required],
  //   });
  // }

  initializeForm() {
    const regexList = this.regexList || [];

    // ✅ Helper: get regex dynamically if it exists
    const getRegex = (label: string): RegExp | undefined => {
      const found = regexList.find((r: any) => r.label === label);
      if (found?.value) {
        try {
          // convert string value to RegExp
          return new RegExp(found.value);
        } catch (err) {
          console.error(`❌ Invalid regex for ${label}:`, found.value);
          return undefined;
        }
      }
      return undefined;
    };

    // ✅ Define base form controls
    const formConfig: any = {
      deductee_panno: [
        '',
        [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)],
      ],

      tds_code: ['', [Validators.required]],
      deductee_name: [''],

      certificate_no: [
        '',
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],

      cust_id: ['', [Validators.minLength(1), Validators.maxLength(10)]],

      tds_limit_amt: [
        '',
        [
          Validators.required,
          Validators.max(1000000000000),
          Validators.pattern(/^\d+(\.\d{1,2})?$/),
        ],
      ],

      tds_rate: [
        '',
        [
          Validators.required,
          Validators.min(0),
          Validators.max(100),
          Validators.pattern(/^\d+(\.\d{1,2})?$/),
        ],
      ],

      amount_consumed: [
        '',
        [Validators.max(1000000000000), Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ],

      certificate_valid_from: ['', [Validators.required]],
      certificate_valid_upto: ['', [Validators.required]],
    };

    // ✅ Apply regex dynamically if available in `get_gmdt_regex_validation`
    Object.keys(formConfig).forEach((key) => {
      const regex = getRegex(key);
      if (regex) {
        let [initialValue, validators] = formConfig[key];

        // 🛡️ Ensure validators array exists
        if (!Array.isArray(validators)) {
          validators = [];
        }

        validators.push(Validators.pattern(regex));
        formConfig[key] = [initialValue, validators];

        // console.log(`✅ Applied dynamic regex for: ${key} (${regex})`);
      } else {
        // console.warn(`⚠️ No regex found for: ${key}`);
      }
    });

    // ✅ Build form
    this.userForm = this.fb.group(formConfig, {
      validators: [this.amountLessThanTdsLimitValidator],
    });
  }

  //condition to check amount consume less than tds limit amt
  amountLessThanTdsLimitValidator(formGroup: FormGroup) {
    const tdsLimit = Number(formGroup.get('tds_limit_amt')?.value || 0);
    const consumed = Number(formGroup.get('amount_consumed')?.value || 0);

    if (consumed > tdsLimit) {
      formGroup.get('amount_consumed')?.setErrors({ exceedLimit: true });
    } else {
      const errors = formGroup.get('amount_consumed')?.errors;
      if (errors) {
        delete errors['exceedLimit'];
        if (Object.keys(errors).length === 0) {
          formGroup.get('amount_consumed')?.setErrors(null);
        } else {
          formGroup.get('amount_consumed')?.setErrors(errors);
        }
      }
    }
    return null;
  }

  panValidationStatus: {
    isValid: boolean | null;
    message: string;
  } = {
    isValid: null,
    message: '',
  };

  isPanValid = false;
  panMessage = '';
  panDataDetails: any;
  panNo: any;
  panErrorMessage: string = '';
  // checkPan(panNumber: string) {
  //   const control = this.userForm.get('deductee_panno');

  //   if (!control || control.invalid) return;

  //   this.authservice.getPanMasterData(panNumber).subscribe({
  //     next: (response: any) => {
  //       const panData = response?.body?.result;

  //       if (panData) {
  //         // ✅ Condition: valid if Y (even if not verified)
  //         const isValid = panData.deductee_panno_valid === 'Y';

  //         this.isPanValid = isValid;
  //         this.panMessage = isValid ? 'Valid PAN' : '';
  //         control.setErrors(
  //           isValid
  //             ? null
  //             : { serverError: 'PAN does not exist or is invalid!' }
  //         );

  //         // Optionally populate deductee_name if available
  //         // if (isValid && panData.deductee_name) {
  //         //   this.userForm.patchValue({ cust_id: panData.deductee_name });
  //         // }
  //       } else {
  //         this.isPanValid = false;
  //         control.setErrors({ serverError: 'Invalid PAN response!' });
  //       }
  //     },
  //     error: () => {
  //       this.isPanValid = false;
  //       control?.setErrors({ serverError: 'Server error validating PAN.' });
  //     },
  //   });
  // }
  checkPan(panNumber: string) {
  const control = this.userForm.get('deductee_panno');
  if (!control || control.invalid || !panNumber) return;

  this.isLoadingPanData = true;
  this.panNo = panNumber.toUpperCase();

  this.authservice.getPanMasterData(this.panNo).subscribe({
    next: (response: any) => {
      const panData = response?.body?.result;

      if (panData) {
        const isValid = panData.deductee_panno_valid === 'Y';
        this.isPanValid = isValid;
        this.panValidationStatus = {
          isValid,
          message: isValid ? 'Valid PAN' : 'Invalid PAN',
        };

        if (isValid) {
          // ✅ Extract and clean name properly
          const { name, verifiedStatus } = this.cleanDeducteeName(
            panData.deductee_name
          );

          this.userForm.patchValue({
            deductee_name: name || '',
          });

          this.pannoVerified = verifiedStatus; // Y/N/I/X flag
          // this.toastService.showSuccess('Valid PAN - Details fetched successfully');
        } else {
          // control.setErrors({ serverError: 'PAN does not exist or is invalid!' });
          // this.toastService.showError('Invalid PAN number.');
        }
      } else {
        this.isPanValid = false;
        control.setErrors({ serverError: 'Invalid PAN response!' });
      }

      this.isLoadingPanData = false;
    },
    error: () => {
      this.isLoadingPanData = false;
      this.isPanValid = false;
      control?.setErrors({ serverError: 'Server error validating PAN.' });
    },
  });
}

  deductee_panno_status: any;

  // Fetch PAN master data from API
  private fetchPanMasterData(panNumber: string) {
    // console.log('called');
    if (!panNumber || panNumber.length !== 10) return;

    // Clear previously filled dependent fields before fetching new PAN data
    // this.clearPanDependentFields();

    this.isLoadingPanData = true;
    this.panNo = panNumber;

    this.authservice.getPanMasterData(panNumber).subscribe({
      next: (response) => {
        if (response?.body?.status === 1 && response?.body?.result) {
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          // console.log(this.deductee_panno_status);

          // Handle validation status
          const isValid = panData.deductee_panno_valid === 'Y';
          this.panValidationStatus = {
            isValid: isValid,
            message: isValid ? 'Valid PAN' : 'Invalid PAN',
          };

          if (panData.deductee_name) {
            // console.log('PAN API deductee_name raw:', panData.deductee_name);
            const { name, verifiedStatus } = this.cleanDeducteeName(
              panData.deductee_name
            );
            this.userForm.patchValue({ deductee_name: name });
            this.pannoVerified = verifiedStatus; // ✅ update flag for UI
            // console.log(
            //   'Cleaned Deductee Name:',
            //   name,
            //   ' | Status:',
            //   verifiedStatus
            // );
          } else {
            console.warn('No deductee_name found in PAN data.');
            this.pannoVerified = '';
          }

          this.isLoadingPanData = false;

          if (isValid && this.isEditMode && !this.selectedId) {
            // this.toastService.showSuccess(
            //   'Valid PAN - Details fetched successfully'
            // );
          } else if (!isValid) {
            // this.toastService.showError('PAN found but marked as invalid');
          }
          // Auto-populate deductee name if available
          if (panData.deductee_name) {
            // console.log(panData.deductee_name);
            // Clean up the deductee name using the dedicated cleaning function
            const cleanedName = this.cleanDeducteeName(panData.deductee_name);
            // console.log('Cleaned Deductee Name:', cleanedName);
            this.userForm.patchValue({
              deductee_name: cleanedName,
            });
            this.isLoadingPanData = false;
          } else {
            this.isLoadingPanData = false;
            console.error(
              'No deductee_name found in PAN data. Available fields:',
              Object.keys(panData)
            );
          }

          if (isValid) {
            if (this.isEditMode && !this.selectedId) {
              // this.toastService.showSuccess(
              //   'Valid PAN - Details fetched successfully'
              // );
            }
          } else {
            // this.toastService.showError('PAN found but marked as invalid');
          }
        } else if (response?.body?.status === 0) {
          this.isLoadingPanData = true;
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          // console.log(this.deductee_panno_status);
          this.pannoVerified = 'N';

          this.authservice.getPanValidationData(panNumber).subscribe({
            next: (validationResponse) => {
              const result = validationResponse?.body;
              this.isLoadingPanData = true;
              if (result?.code == 0) {
                const panData = result.data;
                const parsePanData = JSON.parse(panData);
                this.panDataDetails = parsePanData.data[0];

                if (panData) {
                  const requestBody = {
                    a_session_seqno: '',
                    a_iud_seqno: '',
                    a_is_pen_flag: '',
                    a_login_type: 'login_id',
                    a_module_type_code:
                      this.dynamicUserData?.default_module_type_code,
                    a_sub_module_type_code: 'R',
                    a_user_code: this.localUserData.user_code,
                    a_entity_code: this.dynamicUserData.entity_code,
                    a_client_code: this.dynamicUserData.client_code,
                    a_acc_year: this.dynamicUserData.default_acc_year,
                    a_quarter_no: this.dynamicUserData.default_quarter_no,
                    a_tran_month: this.dynamicUserData.default_tran_month,
                    a_validation_client_level:
                      this.dynamicUserData.client_code_level,
                    a_tran_from_date: this.dynamicUserData.default_from_date,
                    a_tran_to_date: this.dynamicUserData.default_to_date,
                    a_tds_type_code: this.dynamicUserData.default_tds_type_code,
                    a_first_level_client_code:
                      this.dynamicUserData.first_level_client_code,
                    a_client_code_level: this.dynamicUserData.client_code_level,
                    a_user_level: this.dynamicUserData.user_level,
                    a_proc_error: '0',
                    a_db_total_records: '1000',
                    a_pagination_count: '0',
                    a_proc_type: 'get_miud_pan_mast',
                    a_process_seqno: '',
                    a_iud_type: 'i',
                    a_process_status_code: 'ZA',
                    pan_mast: {
                      panno: this.panDataDetails?.pan,
                      first_name: this.panDataDetails?.panName,
                      pan_allot_date: this.formatDate(
                        this.panDataDetails?.panAlotmentDate
                      ),
                      pan_aadhar_status:
                        this.panDataDetails?.panAadhaarLinkStatus,
                      ab206_status: '',
                      n194_status: '',
                      verifiedby_flag: '',
                    },
                  };
                  this.apiservice
                    .miudApi('/Dashboard/get_miud_pan_mast', requestBody)
                    .subscribe({
                      next: (response) => {
                        if (response.result[0].a_proc_error == 0) {
                          // this.toastService.showSuccess(
                          //   response.result[0].a_proc_error_message
                          // );
                          const upperVal = this.panNo.toUpperCase();
                          this.fetchPanMasterData(upperVal);
                        } else {
                          this.toastService.showError(
                            response.result[0].a_proc_error_message
                          );
                          this.isLoadingPanData = true;
                        }
                      },
                    });
                }
              } else {
                const panerrorData = JSON.parse(result.data)?.errdata;
                this.isLoadingPanData = false;
                // this.panErrorMessage = panerrorData?.errorMessage;

                this.toastService.showError('PAN not found in validation data');
              }
            },
            error: (error) => {
              console.error('Error fetching PAN validation data:', error);

              // Extract meaningful message safely
              const errorMessage =
                error?.error?.message ||
                error?.message ||
                'Something went wrong. Please try again.';

              // Show toast with extracted message
              this.showError(errorMessage);
            },
          });
        } else {
          // Set status as unknown when no data found
          this.panValidationStatus = {
            isValid: null,
            message: 'PAN not found in master data',
          };
        }
        this.isLoadingPanData = false;
      },
      error: (error) => {
        this.isLoadingPanData = false;
        console.error('Error fetching PAN master data:', error);

        // Don't show error message as PAN API failure shouldn't block the form
      },
    });
  }
  private cleanDeducteeName(rawName: any): {
    name: string;
    verifiedStatus: string;
  } {
    let cleanedName = '';
    let verifiedStatus = '';

    if (!rawName) {
      return { name: '', verifiedStatus: '' };
    }

    // Normalize input type
    if (typeof rawName === 'string') {
      cleanedName = rawName;
    } else if (Array.isArray(rawName)) {
      cleanedName = rawName.join(', ');
    } else if (typeof rawName === 'object') {
      cleanedName = rawName.label ?? JSON.stringify(rawName);
    } else {
      cleanedName = String(rawName);
    }

    cleanedName = cleanedName.trim();

    // Extract value if JSON-like structure with "label"
    const matchLabel = /"label"\s*:\s*"([^"]+)"/.exec(cleanedName);
    if (matchLabel) {
      cleanedName = matchLabel[1];
    }

    // ✅ Extract trailing ,Y or ,N or ,I or ,X (verification flag)
    const match = cleanedName.match(/,\s*([YyNnIiXx])$/);
    if (match) {
      verifiedStatus = match[1].toUpperCase(); // Store Y/N/I/X
      cleanedName = cleanedName.slice(0, match.index).trim(); // Remove suffix
    }

    // Remove unwanted brackets or quotes
    cleanedName = cleanedName.replace(/[\[\]{}"]/g, '').trim();

    return { name: cleanedName || '', verifiedStatus };
  }

  close() {
    this.userForm.reset();
    this.selectedBranchCodeLabel = 'Select';
    this.selectedBranchCodeValue = null;
    this.closeDrawer.emit();
  }

  allowNumbersOnly(event: KeyboardEvent): boolean {
    const charCode = event.charCode;
    const input = (event.target as HTMLInputElement).value;

    // Allow digits (0–9)
    if (charCode >= 48 && charCode <= 57) {
      return true;
    }

    // Allow one dot (.)
    if (charCode === 46 && !input.includes('.')) {
      return true;
    }

    // Block everything else
    event.preventDefault();
    return false;
  }

  onPasteNumbersOnly(event: ClipboardEvent) {
    const pastedData = event.clipboardData?.getData('text') || '';
    if (!/^\d*\.?\d*$/.test(pastedData)) {
      event.preventDefault();
    }
  }

  toUppercase(event: any) {
    const input = event.target as HTMLInputElement;
    input.value = input.value.toUpperCase();
    this.userForm
      .get('deductee_panno')
      ?.setValue(input.value, { emitEvent: false });
  }

  isEditMode: boolean = false;
  toggleEditMode() {
    this.isEditMode = true;
  }

  //subbmit
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    this.isSubmitting = true;
    this.apiservice
      .createData('/LDC/get_miud_tds_spl_rate_mast', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.close();
            this.refreshdata.trigerRefresh('LDC');
          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                  if (this.userForm.controls[field]) {
                    this.userForm.controls[field].setErrors({
                      serverError: error.message,
                    });
                  }
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          this.isSubmitting = false;
        },
      });
  }

  // private gettdsSec(): void {
  //   const requestBody = {
  //     sdata: JSON.stringify({
  //       a_login_type: 'login_id',
  //       a_module_type_code: 'TAXCPC',
  //       a_sub_module_type_code: 'R',
  //       a_user_code: this.localUserData.user_code,
  //       a_entity_code: this.dynamicUserData.entity_code,
  //       a_client_code: this.dynamicUserData.client_code,
  //       a_acc_year: this.dynamicUserData.default_acc_year,
  //       a_quarter_no: this.dynamicUserData.default_quarter_no,
  //       a_tran_month: this.dynamicUserData.default_tran_month,
  //       a_validation_client_level: this.dynamicUserData.client_code_level,
  //       a_tran_from_date: this.dynamicUserData.default_from_date,
  //       a_tran_to_date: this.dynamicUserData.default_to_date,
  //       a_tds_type_code: this.dynamicUserData.default_tds_type_code,
  //       a_first_level_client_code: this.dynamicUserData.first_level_client_code,
  //       a_client_code_level: this.dynamicUserData.client_code_level,
  //       a_user_level: this.dynamicUserData.user_level,
  //       a_email_id: this.dynamicUserData.email_id,
  //       a_proc_type: 'get_mmtx_multi_mast',
  //       a_filter_clause: [
  //         {
  //           filter_col_field: 'gd_proc_name',
  //           filter_col_depend_operator: 'wc',
  //           filter_col_value: 'and gd_proc_name in (##get_mmtx_tds_mast##)',
  //           filter_col_field_alias: 'a.',
  //         },
  //       ],
  //     }),
  //   };

  //   this.authservice.fetchMultiMastData(requestBody).subscribe({
  //     next: (response: any) => {
  //       const multiMast = response?.body?.result?.get_mmtx_multi_mast;
  //       const tdsMastData = multiMast?.get_gmdt_tds_mast || [];

  //       const fyStartYear = new Date().getFullYear();
  //       const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

  //       this.originalBranchCodeOption = tdsMastData
  //         .filter((item: any) => {
  //           const typeMatch = item.tds_type_code === this.tdsTypeCode;
  //           let dateValid = true;
  //           if (item.valid_to_date) {
  //             const validTo = this.parseDdMmYyyy(item.valid_to_date);
  //             dateValid = end <= validTo;
  //           }
  //           return typeMatch && dateValid;
  //         })
  //         .map((item: any) => ({
  //           value: item.tds_code,
  //           label: item.tds_code_details,
  //         }));

  //       this.branchCodeOption = [...this.originalBranchCodeOption];
  //       console.warn('TDS/Quarter/Year data not found in response.');
  //     },
  //     error: (error: any) => {
  //       console.error(error);
  //     },
  //   });
  // }

  useTdsData: any;
  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }
  // helper to get quarter start and end date

  //   private gettdsSec(): void {
  //   // 1️⃣ Read TDS master data from localStorage
  //   const storedData = localStorage.getItem('headermastertwo');
  //   if (!storedData) {
  //     console.warn('⚠️ No data found in localStorage for headermastertwo.');
  //     return;
  //   }

  //   // 2️⃣ Parse stored JSON
  //   let parsedData: any;
  //   try {
  //     parsedData = JSON.parse(storedData);
  //   } catch (e) {
  //     console.error('❌ Error parsing headermastertwo JSON:', e);
  //     return;
  //   }

  //   // 3️⃣ Extract TDS master data
  //   const tdsMastData =
  //     parsedData?.get_mmtx_multi_mast?.get_gmdt_tds_mast ||
  //     parsedData?.get_gmdt_tds_mast ||
  //     [];

  //   if (!tdsMastData.length) {
  //     console.warn('⚠️ No TDS data found inside headermastertwo.');
  //     return;
  //   }

  //   // 4️⃣ Calculate financial year end date
  //   const fyStartYear = new Date().getFullYear();
  //   const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

  //   // 5️⃣ Filter TDS data based on type and valid_to_date
  //   this.originalBranchCodeOption = tdsMastData
  //     .filter((item: any) => {
  //       const typeMatch = item.tds_type_code === this.tdsTypeCode;
  //       let dateValid = true;

  //       if (item.valid_to_date) {
  //         const validTo = this.parseDdMmYyyy(item.valid_to_date);
  //         dateValid = end <= validTo;
  //       }

  //       return typeMatch && dateValid;
  //     })
  //     .map((item: any) => ({
  //       value: item.tds_code,
  //       label: item.tds_code_details,
  //     }));

  //   // 6️⃣ Assign filtered list to dropdown
  //   this.branchCodeOption = [...this.originalBranchCodeOption];

  //   console.log('✅ Loaded TDS Section list from localStorage:', this.branchCodeOption);
  // }

  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiservice
      .setRedisApi('/Comman/get_mmtx_data', requestBody)
      .subscribe({
        next: (response: any) => {
          let parsedData;
          try {
            parsedData = JSON.parse(response.data);
          } catch (e) {
            parsedData = response.data;
          }
          // console.log(parsedData);
          this.useTdsData = parsedData.multiMast.get_gmdt_tds_mast;
          // console.log('Parsed Redis data:', this.useTdsData);
          this.regexList = parsedData.multiMast.get_gmdt_regex_validation;
          // console.log(this.regexList);
          const fyStartYear = new Date().getFullYear();
          const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

          // 5️⃣ Filter TDS data based on type and valid_to_date
          this.originalBranchCodeOption = this.useTdsData
            .filter((item: any) => {
              const typeMatch = item.tds_type_code === this.tdsTypeCode;
              let dateValid = true;

              if (item.valid_to_date) {
                const validTo = this.parseDdMmYyyy(item.valid_to_date);
                dateValid = end <= validTo;
              }

              return typeMatch && dateValid;
            })
            .map((item: any) => ({
              value: item.tds_code,
              label: item.tds_code_details,
            }));

          // 6️⃣ Assign filtered list to dropdown
          this.branchCodeOption = [...this.originalBranchCodeOption];

          // console.log(
          //   '✅ Loaded TDS Section list from localStorage:',
          //   this.branchCodeOption
          // );
        },
        error: (error: any) => {
          this.errorMessage =
            error.message || 'Failed to fetch header master data.';
          this.showError(this.errorMessage);
        },
      });
  }

  private getQuarterDateRange(
    quarterNo: number,
    fyStartYear: number
  ): { start: Date; end: Date } {
    switch (quarterNo) {
      case 1: // Apr–Jun
        return {
          start: new Date(fyStartYear, 3, 1), // 1 Apr
          end: new Date(fyStartYear, 5, 30), // 30 Jun
        };
      case 2: // Jul–Sep
        return {
          start: new Date(fyStartYear, 6, 1),
          end: new Date(fyStartYear, 8, 30),
        };
      case 3: // Oct–Dec
        return {
          start: new Date(fyStartYear, 9, 1),
          end: new Date(fyStartYear, 11, 31),
        };
      case 4: // Jan–Mar (next calendar year)
        return {
          start: new Date(fyStartYear + 1, 0, 1),
          end: new Date(fyStartYear + 1, 2, 31),
        };
      default:
        throw new Error('Invalid quarter number');
    }
  }

  // helper to parse dd-MMM-yyyy into Date
  private parseDdMmYyyy(dateStr: string): Date {
    const [day, mon, year] = dateStr.split('-');

    const months: { [key: string]: number } = {
      JAN: 0,
      FEB: 1,
      MAR: 2,
      APR: 3,
      MAY: 4,
      JUN: 5,
      JUL: 6,
      AUG: 7,
      SEP: 8,
      OCT: 9,
      NOV: 10,
      DEC: 11,
    };

    const monthIndex = months[mon.toUpperCase()] ?? -1; // fallback if not found
    return new Date(parseInt(year, 10), monthIndex, parseInt(day, 10));
  }
getFyDateRange(accYear: string) {
  const [start, end] = accYear.split('-').map((y) => parseInt('20' + y));

  const startDate = new Date(start, 3, 1); // 1 Apr
  const endDate = new Date(end, 2, 31);   // 31 Mar

  // 👇 Add one extra month before fyRange.yrbegdate (March)
  const minDisplayDate = new Date(startDate);
  minDisplayDate.setMonth(startDate.getMonth() - 1);

  return {
    yrbegdate: startDate,
    yrenddate: endDate,
    displayFrom: minDisplayDate, // 👈 add this
  };
}

  //form subbmit
  onSubmit() {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      return;
    }
    this.isSubmitting = true;
     this.isSubmittingUpdateLoader = true;
    const formData = this.userForm.value;
// Convert all string fields to uppercase
Object.keys(formData).forEach(key => {
  if (typeof formData[key] === 'string') {
    formData[key] = formData[key].toUpperCase();
  }
});
    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type:
        this.isDelete && this.selectedId ? 'd' : this.selectedId ? 'u' : 'i',
      a_proc_type: 'get_miud_tds_spl_rate_mast',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_email_id: this.dynamicUserData.email_id,
      a_process_status_code: 'ZA',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      tds_spl_rate_mast: {
        rowid_seq: this.selectedId ? this.selectedId : '',
        deductee_panno: formData.deductee_panno,
        tds_code: this.selectedBranchCodeValue,
        certificate_no: formData.certificate_no,
        certificate_date: formData.certificate_valid_from,
        cust_id: formData.cust_id,
        tds_type_code: this.dynamicUserData.tds_type_code,
        tds_limit_amt: formData.tds_limit_amt,
        tds_rate: formData.tds_rate,
        amount_consumed: formData.amount_consumed,
        certificate_valid_from: formData.certificate_valid_from,
        certificate_valid_upto: formData.certificate_valid_upto,
      },
    };

    this.submitRequest(
      requestBody,
      'User Mast  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
  }

  fetchUserDetails(roleCode: string) {
    this.detailsLoader = true;
    const requestBody = {
      a_proc_type: 'get_gmdt_tds_spl_rate_mast',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_module_type_code: this.dynamicUserData.default_module_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_login_type: 'login_id',
      a_email_id: this.dynamicUserData.email_id,
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/LDC/get_gmdt_tds_spl_rate_mast', requestBody)
      .subscribe({
        next: (response) => {
          // console.log(response);
          const roleData =
            response?.result?.get_gmdt_tds_spl_rate_mast
              ?.get_gmdt_tds_spl_rate_mast_detail?.[0];
          this.roleData = roleData;

          if (!roleData) {
            this.showError('No ldc data found.');
            this.detailsLoader = false;
            return;
          }
          this.detailsLoader = false;
          this.userForm.patchValue({
            deductee_panno: roleData.deductee_panno || '',
            certificate_no: roleData.certificate_no || '',
            tds_limit_amt: roleData.tds_limit_amt || '',
            amount_consumed: roleData.amount_consumed || '',
            tds_rate: roleData.tds_rate || '',
            cust_id: roleData.cust_id || '',
            certificate_valid_from: roleData.certificate_valid_from || '',
            certificate_valid_upto: roleData.certificate_valid_upto || '',
            tds_code: roleData.tds_code || '',
          });

          if (roleData.tds_code) {
            const selectedOption = this.originalBranchCodeOption.find(
              (opt) => opt.value === roleData.tds_code
            );
            this.selectedBranchCodeLabel = selectedOption
              ? selectedOption.label
              : '';
            this.selectedBranchCodeValue = roleData.tds_code;
          }
        },
        error: () => {
          this.showError('Failed to fetch LDC details.');
          this.detailsLoader = false;
        },
      });
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  toggleDropDownBranchCode() {
    // Open
    if (!this.showBankBranchCodeOption) {
      this.showBankBranchCodeOption = true;
      this.searchText = '';
      this.branchCodeOption = [...this.originalBranchCodeOption];
    } else {
      // Close
      this.showBankBranchCodeOption = false;
    }
  }

  closebranchSelector() {
    this.showBankBranchCodeOption = true;
  }

  selectBranchCodeOption(option: any) {
    this.selectedBranchCodeLabel = option.label;
    this.selectedBranchCodeValue = option.value;

    this.showBankBranchCodeOption = false;

    this.userForm.patchValue({
      tds_code: this.selectedBranchCodeValue,
    });
  }

  clearBranchCodeSelection(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedBranchCodeLabel = 'Select';
    this.selectedBranchCodeValue = null;
    this.userForm.patchValue({
      tds_code: '',
    });
    this.userForm.get('tds_code')?.markAsTouched();
  }

  searchBranch() {
    if (!this.searchText.trim()) {
      this.branchCodeOption = [...this.originalBranchCodeOption];
    } else {
      this.branchCodeOption = this.originalBranchCodeOption.filter((option) =>
        option.label.toLowerCase().includes(this.searchText.toLowerCase())
      );
    }
  }

  isDelete: boolean = false;
  isDeletePopupOpen = false;

  deleteSingleDetails() {
    this.isDeletePopupOpen = false;
    this.isDelete = true;
    this.onSubmit();
  }

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false;

    // console.log('called');
  }
  deleteSingleDetailsCancel() {
    this.isDelete = false;
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
  }
  // getFyDateRange(accYear: string) {
  //   const [start, end] = accYear.split('-').map((y) => parseInt('20' + y));
  //   const startDate = `01-APR-${start}`;
  //   const endDate = `31-MAR-${end}`;
  //   return {
  //     yrbegdate: startDate,
  //     yrenddate: endDate,
  //   };
  // }


}
