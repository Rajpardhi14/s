import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-certificate',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule , FormsModule],
  templateUrl: './certificate.component.html',
  styleUrl: './certificate.component.css'
})
export class CertificateComponent {
@Input() certificateDetails:any;
@Input() certificateHeader:any;
@Input() showCertificatePopup:any;
  @Output() closeDrawer = new EventEmitter<void>();

  @Output() certificateApplied = new EventEmitter<any>();
  remainingHeight: number = 0;

    // Close certificate popup
  closeCertificatePopup() {
    this.closeDrawer.emit();
  }

   // Apply selected certificate rate
  // applyCertificateRate(certificate: any): void {
  //   // Update TDS rates with the selected certificate's rate
  //   this.tdsRates.tdsRate = parseFloat(certificate.tds_rate) || 0;

  //   // Recalculate amounts based on new rates
  //   this.calculateTdsAmounts();

  //   // Close popup
  //   this.closeCertificatePopup();

  //   // Show success message
  //   this.toastService.showSuccess(`Special TDS rate ${certificate.tds_rate}% applied from certificate ${certificate.certificate_no}`);
  // }

   applyCertificateRate(certificate: any) {
    this.certificateApplied.emit(certificate);
  }
  

}
