import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnDestroy, NgZone, SimpleChanges, ChangeDetectorRef, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { formatDatesend } from '../../../shared/utils/passmatch';
import { catchError, debounceTime, distinctUntilChanged, filter, map, merge, Observable, Subject, takeUntil, tap, throwError } from 'rxjs';
import { DatepickerComponent } from '../../../shared/components/datepicker/datepicker.component';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
import { CertificateComponent } from './certificate/certificate.component';
import { MapAllocationComponent } from '../../map-allocation/map-allocation.component';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';

@Component({
  selector: 'app-addtransaction',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, OutSideClickDirective, DatepickerComponent, AlertpoupComponent, CertificateComponent, MapAllocationComponent,
    ButtoneventlisnerDirective
  ],
  templateUrl: './addtransaction.component.html',
  styleUrl: './addtransaction.component.css'
})
export class AddtransactionComponent implements OnDestroy {
   @ViewChild('datePicker') datePicker!: DatepickerComponent; 
  @Input() removedFilter:any;
  detailsLoader: boolean = false;
  isCertificateEnabled = false;
  @Input() selectedRowDetails: any;
  @Input() selectedRowId: any;
  @Output() close = new EventEmitter<void>();
  @Input() isDrawerOpen: any;
  transactionForm!: FormGroup;
  UserData: any;
  roleData: any;
  dynamicUserData: any;
  private destroy$ = new Subject<void>();
  tdsTypeCode: any;
  tdsRateTypeMastData: any;
  countryMastData: any;
  tdsReasonMastData: any;
  showRemittanceOptions = false;
  searchRemittance = '';
  selectedRemittanceLabel: string | null = null;
  selectedRemittanceValue: any
  tdsMastData: any;
  tdsSectionOptions: any[] = [];

  // original data from API
  tdsRemittanceData: any[] = [];
  quarterNo: any;
  show194NInputs: boolean = false;
  isLoadingRates: boolean = false;
  isLoadingSpecialRates: boolean = false;
  // Certificate popup variables
  showCertificatePopup: boolean = false;
  certificateDetails: any[] = [];
  // Date restrictions for quarter
  quarterStartDate: string = '';
  quarterEndDate: string = '';
  maxDate: string = '';
  isLoadingPanData: boolean = false;
  panValidationStatus: {
    isValid: boolean | null;
    message: string;
  } = {
      isValid: null,
      message: ''
    };
  tdsRates = {
    tdsRate: 0,
    surchargeRate: 0,
    cessRate: 0
  };
  isEditMode: boolean = true;
  // filtered options
  filteredRemittanceOptions: any[] = [];
  activeSection: string = 'deductee'; // start with Deductee Details
  completedSections: string[] = [];
  deductee_panno_status: any;
  fyStartDate!: string;
  serverErrors: { [key: string]: string } = {}; // Store server errors separately
  private fieldMap: { [key: string]: string } = {
    deductee_panno_valid: 'deductee_panno',
    deductee_panno_verified: 'deductee_panno',
    tds_deduct_date: 'tds_deduct_date',
    tds_code: 'tds_code',
    deductee_panno: 'deductee_panno',
    deductee_name: 'deductee_name',
    tran_ref_date: 'tran_ref_date',
    tran_amt: 'tran_amt',
    cust_id: 'cust_id'
    // Add more mappings as needed for other fields
  };
 multiMast: any;
 firsttimetdsget:boolean = false;

  constructor(private userlocaldataService: UserdataService,
    private toastService: ToastService,
    private apiservice: ApiserviceService,
    private authservice: AuthService,
    private refreshdata: RefreshdataService,
    private fb: FormBuilder,
    private ngZone: NgZone,
    private userlocaldata: UserdataService,
    private cdr: ChangeDetectorRef,
      private apiService: ApiserviceService,
  ) {
    // this.createTransactionForm();
  }

 
  ngOnChanges(changes: SimpleChanges): void {
    this.localUserData = this.userlocaldata.getLocalUserData();
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};
      this.getsData();
    const challanRowId = this.selectedRowDetails?.tds_challan_rowid_seq;
    // this.isLoading = true;
    if (changes['selectedRowId'] && this.selectedRowId) {
      this.fetchUserDetails(this.selectedRowId);
      this.fetchChallanDetails(challanRowId);
      this.isEditMode = false;
      this.isDrawerOpen = true;
         this.createTransactionForm();

    } else {
      // this.isLoading = false;
      this.isEditMode = true;
      this.createTransactionForm();
    }
  }


  ngOnInit(): void {
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    
    this.createTransactionForm();

    // Set date restrictions based on quarter
    this.setQuarterDateRestrictions();

    // Flag to prevent infinite loops between forward and reverse calculations
    let isCalculating = false;

    // Listen to transaction amount changes to recalculate TDS amounts (Forward calculation)
      if(!this.selectedRowId){
    this.transactionForm.get('tran_amt')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((value: number) => {
        if (!isCalculating && value && this.selectedTdsSectionValue) {
          isCalculating = true;
          if (!this.selectedRowId && !this.firsttimetdsget) {
            // console.log('noSelectedRowId');
            this.calculateTdsAmounts();
            setTimeout(() => isCalculating = false, 100);
          }

        }
      });
    }

    if(this.selectedRowId){
       this.transactionForm.get('tran_amt')?.valueChanges
    .pipe(
      debounceTime(300),
      distinctUntilChanged(),
      takeUntil(this.destroy$)
    )
    .subscribe((tranAmount: number) => {
      if (isCalculating) return;
      isCalculating = true;

      if (tranAmount && tranAmount > 0) {
    
        const tdsAmount = this.transactionForm.get('tds_base_amt')?.value;
    
        if (tdsAmount != null && tdsAmount >= 0) {
          // 🔹 Recalculate TDS rate when tran_amt changes
          this.reverseCalculateFromTdsAmount(tdsAmount);
          
       setTimeout(() => (isCalculating = false), 100);
        } else {
          console.error('TDS amount not available to reverse-calculate.');
        }
      }

      // Reset flag after a short delay
      setTimeout(() => (isCalculating = false), 100);
    });
    }

    

    // Listen to TDS amount changes for reverse calculation
    this.transactionForm.get('tds_base_amt')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((value: number) => {
        if (!isCalculating && value && this.tdsRates.tdsRate >= 0) {
             if (this.isCertificateRateActive) {
      this.isCertificateRateActive = false; // ✅ disable certificate rate when user changes base amount
    }

    this.firsttimetdsget = true;
          // console.log('tds amt change');
          isCalculating = true;
          // console.log(value);
          this.reverseCalculateFromTdsAmount(value);
          setTimeout(() => isCalculating = false, 100);
        }
      });

    // Listen to Surcharge amount changes for reverse calculation
    this.transactionForm.get('surcharge_amt')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((value: number) => {
        if (!isCalculating && value && this.tdsRates.surchargeRate >= 0) {
          isCalculating = true;
          this.reverseCalculateFromSurchargeAmount(value);
          setTimeout(() => isCalculating = false, 100);
        }
      });

    // Listen to Cess amount changes for reverse calculation
    this.transactionForm.get('cess_amt')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((value: number) => {
        if (!isCalculating && value && this.tdsRates.cessRate >= 0) {
          isCalculating = true;
          this.reverseCalculateFromCessAmount(value);
          setTimeout(() => isCalculating = false, 100);
        }
      });
  }

  private getsData(): void {
    const requestBody = {
      usercode: this.localUserData?.user_code,
      clientcode: this.localUserData?.client_code,
    };
    this.apiService.setRedisApi('/Comman/get_mmtx_data', requestBody).subscribe({
      next: (response: any) => {
        let parsedData;
        try {
          parsedData = JSON.parse(response.data);
          this.multiMast = parsedData.multiMast;
             this.getHreaderData();
        } catch (e) {
          parsedData = response.data;
        }
        
      },
      error: (error: any) => {
        this.errorMessage = error.message || 'Failed to fetch header master data.';
        this.showError(this.errorMessage);
      },
    });
  }


  private createTransactionForm() {
    // console.log(this.tdsTypeCode );
    const is26Q = this.tdsTypeCode == '26Q';
    this.transactionForm = this.fb.group({
      deductee_name: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(75)]],
      deductee_panno: ['', [Validators.required]],
      cust_id: ['', [Validators.maxLength(10)]],
      account_no: ['', [Validators.maxLength(25)]],
      tin_uin_no: [''],
      deductee_email_id: ['', [Validators.email]],
      deductee_phoneno: [''],
      deductee_address: [''],
      tran_ref_date: [''],
      tds_deduct_date: [''],
      tran_ref_no: ['', [Validators.maxLength(50)]],
      tds_code: ['', Validators.required], // TDS Section
      tds_deduct_reason: [''],
      // certificate_no: [{ value: '', disabled: true }], 
      certificate_no: [
        { value: '', disabled: true },
        [
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern(/^[A-Z0-9]+$/) // only letters & numbers
        ]
      ],
      rate_type: ['', Validators.required],
      country_code: ['', Validators.required],
      nature_of_remittance: ['', Validators.required],
      tran_amt: [0.00, [Validators.required,Validators.max(1000000000000), this.amountGreaterThanZeroValidator()]],

      // tran_amt: [0, [Validators.required, Validators.pattern(/^\d+$/), this.amountGreaterThanZeroValidator()]], // decimals allowed
      tds_base_amt: [0.00 , [Validators.max(1000000000000)]],
      surcharge_amt: [0.00 , [Validators.max(1000000000000)]],
      cess_amt:[0.00 , [Validators.max(1000000000000)]],
      grossup_Indicator_flag: ['N'],
      new_regime_flag: ['N'],
      ca15_ackno: [''],
      // n94_cash_20l_amt: [0, [Validators.pattern(/^\d+$/)]],   // integers only
      // n94_cash_1cr_amt: [0, [Validators.pattern(/^\d+$/)]],
      // n94_cash_3cr_amt: [0, [Validators.pattern(/^\d+$/)]],
      n94_cash_20l_amt: [0, [Validators.pattern(/^\d*\.?\d*$/), Validators.max(1000000000000)]],  // integers or decimals
      n94_cash_1cr_amt: [0, [Validators.pattern(/^\d*\.?\d*$/), Validators.max(1000000000000)]],
      n94_cash_3cr_amt: [0, [Validators.pattern(/^\d*\.?\d*$/), Validators.max(1000000000000)]],

    });
this.subscribeToPanValueChanges();

    const custIdControl = this.transactionForm.get('cust_id');
    this.tdsTypeCode = this.dynamicUserData?.default_tds_type_code;
    this.quarterNo = this.dynamicUserData?.default_quarter_no;
this.updateDisableState();
    if (this.tdsTypeCode == '24Q') {
      custIdControl?.setValidators([
        Validators.minLength(0),
        Validators.maxLength(9)
      ]);
    } else {
      custIdControl?.setValidators([
        Validators.minLength(0),
        Validators.maxLength(10)
      ]);
    }

    custIdControl?.updateValueAndValidity();

    if (this.tdsTypeCode == '27Q') {

      this.transactionForm.addControl('tin_uin_no', this.fb.control(''));
      this.transactionForm.addControl('deductee_email_id', this.fb.control('', [Validators.email]));
      this.transactionForm.addControl('deductee_phoneno', this.fb.control(''));
      this.transactionForm.addControl('deductee_address', this.fb.control(''));
      this.transactionForm.addControl('grossup_Indicator_flag', this.fb.control('N'));
      this.transactionForm.addControl('new_regime_flag', this.fb.control('N'));
      this.transactionForm.addControl('ca15_ackno', this.fb.control(''));
      this.transactionForm.addControl('rate_type', this.fb.control('', Validators.required));
      this.transactionForm.addControl('country_code', this.fb.control('', Validators.required));
      this.transactionForm.addControl('nature_of_remittance', this.fb.control('', Validators.required));
    }

    if (this.tdsTypeCode == '26Q' || this.tdsTypeCode == '24Q' || this.tdsTypeCode == '27EQ') {

      this.transactionForm.removeControl('tin_uin_no');
      this.transactionForm.removeControl('deductee_email_id');
      this.transactionForm.removeControl('deductee_phoneno');
      this.transactionForm.removeControl('deductee_address');
      this.transactionForm.removeControl('grossup_Indicator_flag');
      this.transactionForm.removeControl('new_regime_flag');
      this.transactionForm.removeControl('ca15_ackno');
      this.transactionForm.removeControl('rate_type');
      this.transactionForm.removeControl('country_code');
      this.transactionForm.removeControl('nature_of_remittance');
    }
  }

  updateDisableState() {
  const code = this.tdsTypeCode?.trim().toUpperCase();

  if (code === '26Q' || code === '27EQ') {
    this.transactionForm.get('surcharge_amt')?.disable({ emitEvent: false });
    this.transactionForm.get('cess_amt')?.disable({ emitEvent: false });
  } else {
    this.transactionForm.get('surcharge_amt')?.enable({ emitEvent: false });
    this.transactionForm.get('cess_amt')?.enable({ emitEvent: false });
  }
}



  private resetFormOnPanEdit() {
  // Clear name and other dependent fields
  // this.transactionForm.patchValue({
  //   deductee_name: '',
  // });

  // Reset validation status
  this.panValidationStatus = {
    isValid: null,
    message: ''
  };

  // If you want to reset all form fields:
  // this.transactionForm.reset();

  // Also reset PAN verification flags
  this.pannoVerified = null;

  if(this.roleData){
      this.roleData.deductee_panno_verified = null;
  }

  this.isLoadingPanData = false;
}


  goToNextSection(nextSection: string, currentSection: string) {
    if (this.isSectionValid(currentSection)) {
      if (!this.completedSections.includes(currentSection)) {
        this.completedSections.push(currentSection);
      }
      this.activeSection = nextSection;
    } else {
      this.transactionForm.markAllAsTouched();
    }
  }

onKeyDown(event: KeyboardEvent, section: string, current: string) {
  if (event.key === 'Enter' || event.key === 'Tab') {
    event.preventDefault();

    let isSectionComplete = false;

    // Check completion based on the current section
    if (current === 'deductee') {
      isSectionComplete = this.isdeducteeDetailsComplete;
    } else if (current === 'transaction') {
      isSectionComplete = this.istransactionDetailsComplete;
    }

    // Proceed only if the current section is complete
    if (isSectionComplete) {
      this.goToNextSection(section, current);
      this.onSaveAndNext();

      // Add the current section to completedSections
      if (!this.completedSections.includes(current)) {
        this.completedSections.push(current);
      }

      // Move to next section
      this.activeSection = section;
    } else {
      // Optionally, mark all fields as touched to show validation errors
      if (current === 'deductee') {
        this.markSectionFieldsAsTouched(['deductee_name', 'deductee_panno']);
      } else if (current === 'transaction') {
        this.markSectionFieldsAsTouched(['tds_code', 'tran_ref_date', 'tran_amt']);
      }
    }
  }
}

// Optional helper to mark fields as touched
private markSectionFieldsAsTouched(fields: string[]) {
  fields.forEach(field => {
    const control = this.transactionForm.get(field);
    if (control) {
      control.markAsTouched();
      control.updateValueAndValidity();
    }
  });
}


  onButtonNext(nextSection: string, currentSection: string) {
    // console.log('Transaction Form Value:', this.transactionForm.value);

    this.goToNextSection(nextSection, currentSection);

    // Mark sections completed correctly
    if (currentSection && !this.completedSections.includes(currentSection)) {
      this.completedSections.push(currentSection);
    }
    if (nextSection && !this.completedSections.includes(nextSection)) {
      this.completedSections.push(nextSection);
    }
    this.onSaveAndNext();

    // Mark section completed
    if (!this.completedSections.includes('transaction')) {
      this.completedSections.push('transaction');
    }

    // Move to next section
    this.activeSection = nextSection;
  }

  // Helper: check validity for each section
  isSectionValid(section: string): boolean {
    switch (section) {
      case 'deductee':
        // Deductee section must have valid PAN and name
        return !!(
          this.transactionForm.get('deductee_panno')?.valid &&
          this.transactionForm.get('deductee_name')?.valid
        );

      case 'transaction':
        // Transaction section must have valid TDS code and base amount
        return !!(
          this.transactionForm.get('tds_code')?.valid &&
          this.transactionForm.get('tds_base_amt')?.valid &&
          this.transactionForm.get('tran_ref_date')?.valid &&
          this.transactionForm.get('tds_deduct_date')?.valid
        );

      case 'other':
        // Other section: mark as valid if any of the important fields are valid
        return !!(
          this.transactionForm.get('tran_amt')?.valid ||
          this.transactionForm.get('ca15_ackno')?.valid ||
          (this.show194NInputs && (
            this.transactionForm.get('n94_cash_20l_amt')?.valid ||
            this.transactionForm.get('n94_cash_1cr_amt')?.valid ||
            this.transactionForm.get('n94_cash_3cr_amt')?.valid
          ))
        );

      default:
        return true;
    }
  }


  tdsReasonOptions: any[] = [];
  showTdsReasonOption = false;
  selectedTdsReasonLabel = '';
  selectedTdsReasonValue: any;
  filteredTdsReasonOptions: any[] = [];
  searchTdsReason = '';


  selectTdsReason(option: any) {
    this.selectedTdsReasonLabel = option.label;
    this.selectedTdsReasonValue = option.value;
    this.transactionForm.get('tds_deduct_reason')?.setValue(option.value);
    this.showTdsReasonOption = false;
      this.searchTdsReason = '';
  this.filteredTdsReasonOptions = [...(this.tdsReasonOptions || [])];

  }

  filterTdsReasonOptions() {
    const searchValue = this.searchTdsReason.toLowerCase();
    this.filteredTdsReasonOptions = this.tdsReasonOptions.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }


  showtdsRegimeOption = false;
  selectedtdsRegimeLabel = 'No';

  tdsRegimeOptions = [
    { value: 'N', label: 'No' },
    { value: 'Y', label: 'Yes' }
  ];

  // Grossing Up Indicator variables
  showGrossingUpOption = false;
  selectedGrossingUpLabel = 'No';
  grossingUpOptions = [
    { value: 'N', label: 'No' },
    { value: 'Y', label: 'Yes' }
  ];

  selecttdsRegime(option: any) {
    this.selectedtdsRegimeLabel = option.label;
    this.transactionForm.get('new_regime_flag')?.setValue(option.value);
    this.showtdsRegimeOption = false;
  }

  selectGrossingUp(option: any) {
    this.selectedGrossingUpLabel = option.label;
    this.transactionForm.get('grossup_Indicator_flag')?.setValue(option.value);
    this.showGrossingUpOption = false;
  }


  closePopup() {
    this.close.emit(); // Emit event to parent
  }

  sanitizeValue(value: any, toUpper: boolean = false): string {
    if (!value) return '';
    let transformed = value.toString().trim();
    return toUpper ? transformed.toUpperCase() : transformed;
  }


  regexMap: { [key: string]: string } = {};

  private applyDynamicValidations(): void {
    if (!this.transactionForm || !this.regexMap) return;

    Object.entries(this.regexMap).forEach(([label, pattern]) => {
      const control = this.transactionForm.get(label);
      if (control) {
        const regexValidator = Validators.pattern(new RegExp(pattern));

        // ✅ Get all existing validators
        const existingValidators = control.validator ? [control.validator] : [];

        // ✅ Remove any existing pattern validators (optional)
        const cleanedValidators = existingValidators.filter(
          (fn) => fn.name !== 'patternValidator'
        );

        // ✅ Conditional validator (apply only if value exists)
        const conditionalValidator = (ctrl: AbstractControl) =>
          !ctrl.value ? null : regexValidator(ctrl);

        // ✅ Preserve "required" and merge with regex
        const isRequired = control.hasValidator(Validators.required);
        const validators = [
          conditionalValidator,
          ...(isRequired ? [Validators.required] : []),
        ];

        control.setValidators(validators);
        control.updateValueAndValidity({ emitEvent: false });
      }
    });
  }


  getHreaderData(){
           const validations = this.multiMast?.get_gmdt_regex_validation || [];
        this.regexMap = validations.reduce((acc: any, cur: any) => {
          acc[cur.label] = cur.value;
          return acc;
        }, {});

        // After fetching regex, re-apply validations
        this.applyDynamicValidations();

        const tdsRateTypeMastData = this.multiMast?.get_gmdt_tds_rate_type_mast;
        this.tdsRateTypeMastData = tdsRateTypeMastData;
  

        const countryMastData = this.multiMast?.get_gmdt_country_mast;
        this.countryMastData = countryMastData;


        const tdsRemittanceData = this.multiMast?.get_gmdt_remittance_nature_mast;
        this.tdsRemittanceData = tdsRemittanceData;

        const tdsMastData = this.multiMast?.get_gmdt_tds_mast;
        this.tdsMastData = tdsMastData;


        const fyStartYear = new Date().getFullYear(); // adjust if your FY doesn't align with calendar year
        const { end } = this.getQuarterDateRange(this.quarterNo, fyStartYear);

        this.tdsSectionOptions = (this.tdsMastData || []).filter((item: any) => {
          // condition 1: tds_type_code match
          const typeMatch = item.tds_type_code === this.tdsTypeCode;

          // condition 2: valid_to_date is null OR quarterEnd <= valid_to_date
          let dateValid = true;
          if (item.valid_to_date) {
            const validTo = this.parseDdMmYyyy(item.valid_to_date);
            dateValid = end <= validTo;
          }

          return typeMatch && dateValid;
        });

        this.filteredTdsSectionOptions = this.tdsSectionOptions;


        // Map to {label, value}
        this.filteredRemittanceOptions = this.tdsRemittanceData.map(item => ({
          label: item.nature_of_remittance_name,
          value: item.nature_of_remittance_code
        }));

        this.filteredRateTypeOptions = this.tdsRateTypeMastData || [];
        this.filteredCountryOptions = this.countryMastData || [];
        this.filteredRemittanceOptions = this.tdsRemittanceData || [];

        const tdsReasonMastData = this.multiMast?.get_gmdt_tds_deduct_reason_mast;
        this.tdsReasonMastData = tdsReasonMastData;

                const tdsDeductReasonControl = this.transactionForm.get('tds_deduct_reason');
        const certificateControl = this.transactionForm.get('certificate_no');

        const toggleCertificate = (val: string | string[]) => {
          const reasons = Array.isArray(val) ? val : [val];
          if (reasons.includes('A')) {
            certificateControl?.enable();
            this.isCertificateEnabled = true;
          } else {
            certificateControl?.disable();
            certificateControl?.reset();
            this.isCertificateEnabled = false;
          }
        };

        // Initial check after patch
        toggleCertificate(tdsDeductReasonControl?.value);

        // Subscribe for changes
        tdsDeductReasonControl?.valueChanges
          .pipe(takeUntil(this.destroy$))
          .subscribe(toggleCertificate);

        if (tdsRateTypeMastData && Array.isArray(tdsRateTypeMastData)) {
          localStorage.setItem('tdsRateTypeMastData', JSON.stringify(tdsRateTypeMastData));
        }



        else {
          console.warn('TDS/Quarter/Year data not found in response.');
        }
  }

  showTdsSectionOption = false;
  selectedTdsSectionLabel = '';
  selectedTdsSectionValue: any;
  searchTdsSection = '';
  filteredTdsSectionOptions: any[] = [];

  filterTdsSectionOptions() {
    const searchValue = this.searchTdsSection.toLowerCase();
    this.filteredTdsSectionOptions = this.tdsSectionOptions.filter((option: any) =>
      option.label.toLowerCase().includes(searchValue)
    );
  }

  clearSelectionInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedTdsSectionLabel = 'Select';
    this.selectedTdsSectionValue = null;
    this.transactionForm.patchValue({
      tds_code: '',
    });
    this.transactionForm.get('tds_code')?.markAsTouched();
  }

  clearTdsReasonInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedTdsReasonLabel = 'Select';
    this.selectedTdsReasonValue = null;
    this.transactionForm.patchValue({
      tds_deduct_reason: '',
    });
    this.transactionForm.get('tds_deduct_reason')?.markAsTouched();
  }

  clearRateTypeInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedRateTypeLabel = 'Select';
    this.selectedRateTypeValue = null;
    this.transactionForm.patchValue({
      rate_type: '',
    });
    this.transactionForm.get('rate_type')?.markAsTouched();
  }

  clearCountryInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedCountryLabel = 'Select';
    this.selectedCountryValue = null;
    this.transactionForm.patchValue({
      country_code: '',
    });
    this.transactionForm.get('country_code')?.markAsTouched();
  }

  clearRemittanceInput(event: Event) {
    event.stopPropagation(); // Prevent dropdown toggle
    this.selectedRemittanceLabel = 'Select';
    this.selectedRemittanceValue = null;
    this.transactionForm.patchValue({
      nature_of_remittance: '',
    });
    this.transactionForm.get('nature_of_remittance')?.markAsTouched();
  }

  selectTdsSection(option: any) {
    this.selectedTdsSectionLabel = option.label;
    this.selectedTdsSectionValue = option.value;

    this.transactionForm.get('tds_code')?.setValue(option.value);

    const control = this.transactionForm.get('tds_code');
    control?.setValue(option.value);
    control?.markAsTouched();
    control?.updateValueAndValidity();

    this.showTdsSectionOption = false;

      this.searchTdsSection = '';
  this.filteredTdsSectionOptions = [...(this.tdsSectionOptions || [])];


    // Dynamically filter reasons
    const mastRecord = option;
    if (mastRecord) {
      const flagStr = mastRecord.tds_deduct_reason_flag_str || "";

      this.tdsReasonOptions = (this.tdsReasonMastData || [])
        .filter((item: any) => flagStr.includes(`#${item.tds_deduct_reason}#`))
        .map((item: any) => ({
          value: item.tds_deduct_reason,
          label: item.tds_deduct_reason_name,
        }));

      this.filteredTdsReasonOptions = this.tdsReasonOptions;
    }

    // 🔽 Add this logic after setting TDS Section
    const tdsMastRecord = this.tdsMastData?.find(
      (item: any) =>
      (item.tds_type_code === option.tds_type_code &&
        String(item.tds_code) === String(option.value))
    );

    // console.log(tdsMastRecord.tds_code);
    if (tdsMastRecord) {
      if (
        (tdsMastRecord.tds_type_code === '26Q' &&
          ['53', '56', '74', '79'].includes(String(tdsMastRecord.tds_code))) ||
        (tdsMastRecord.tds_type_code === '27Q' &&
          ['87', '88', '94', '95'].includes(String(tdsMastRecord.tds_code)))
      ) {
        this.show194NInputs = true;
      } else {
        this.show194NInputs = false;
      }
    } else {
      this.show194NInputs = false;
    }

    // ✅ Fetch TDS rates when section changes (only in ADD mode and if PAN entered)
  // if (!this.selectedRowId || this.isEditMode) {
  if (!this.selectedRowId) {
    const panNumber = this.transactionForm.get('deductee_panno')?.value;
    if (panNumber && panNumber.length === 10 && this.tdsTypeCode != '24Q' && !this.firsttimetdsget) {
    
      this.fetchTdsRates(option.value);
    } else {
      console.warn(
        'PAN not entered yet — will fetch TDS rates once PAN is provided.'
      );
    }
  }
  }


  // Optional: mark touched if dropdown closed without selecting
  onCloseTdsSectionDropdown() {
    this.showTdsSectionOption = false;

     // Reset search and show all options
  this.searchTdsSection = '';
  this.filteredTdsSectionOptions = [...(this.tdsSectionOptions || [])];


    this.ngZone.run(() => {
      const control = this.transactionForm.get('tds_code');
      if (!control?.value) {
        control?.markAsTouched();
        control?.updateValueAndValidity();
      }
    });
  }


  // helper to get quarter start and end date
  private getQuarterDateRange(quarterNo: number, fyStartYear: number) {
    
    let start: Date, end: Date;
    switch (quarterNo) {
      case 1:
        start = new Date(fyStartYear, 3, 1); // Apr 1
        end = new Date(fyStartYear, 5, 30); // Jun 30
        break;
      case 2:
        start = new Date(fyStartYear, 6, 1); // Jul 1
        end = new Date(fyStartYear, 8, 30); // Sep 30
        break;
      case 3:
        start = new Date(fyStartYear, 9, 1); // Oct 1
        end = new Date(fyStartYear + 1, 11, 31); // Dec 31
        break;
      case 4:
        start = new Date(fyStartYear + 1, 0, 1); // Jan 1
        end = new Date(fyStartYear + 1, 2, 31); // Mar 31
        break;
      default:
        start = new Date(fyStartYear, 3, 1);
        end = new Date(fyStartYear, 5, 30);
    }
    return { start, end };
  }


  private setQuarterDateRestrictions(): void {
    // Get current quarter
    const currentQuarter = this.dynamicUserData?.default_quarter_no || 1;

    // Parse fiscal year
    const fyString = this.dynamicUserData?.default_acc_year || '24-25';
    // console.log(fyString);
    const fyStartYear = 2000 + parseInt(fyString.split('-')[0], 10);
    const fyEndYear = 2000 + parseInt(fyString.split('-')[1], 10);

    // Financial Year Start: 1-Apr-FYStart
    const fyStart = new Date(fyStartYear, 3, 1); // Apr 1
    this.fyStartDate = this.formatDateForInput(fyStart);


    // Get quarter start/end
    const { start, end } = this.getQuarterDateRange(currentQuarter, fyStartYear);
    this.quarterStartDate = this.formatDateForInput(start);
    this.quarterEndDate = this.formatDateForInput(end);

    // Max Date is today or quarter end (whichever is earlier)
    const today = new Date();
    const maxDateObj = today < end ? today : end;
    this.maxDate = this.formatDateForInput(maxDateObj);

    // Set validators
    this.setDateValidators();
  }

  // Get current quarter based on today's date
  private getCurrentQuarter(): number {
    const today = new Date();
    const month = today.getMonth();

    if (month >= 3 && month <= 5) return 1;  // Apr-Jun
    if (month >= 6 && month <= 8) return 2;  // Jul-Sep
    if (month >= 9 && month <= 11) return 3; // Oct-Dec
    return 4; // Jan-Mar
  }

  private formatDateForInput(date: Date): string {
    const yyyy = date.getFullYear();
    const mm = ('0' + (date.getMonth() + 1)).slice(-2);
    const dd = ('0' + date.getDate()).slice(-2);
    return `${yyyy}-${mm}-${dd}`;
  }

  // Set date validators for transaction and TDS deduction dates
  private setDateValidators(): void {
    const tranRefDateControl = this.transactionForm.get('tran_ref_date');
    const tdsDeductDateControl = this.transactionForm.get('tds_deduct_date');

    const tranRefDateValidator = (control: any) => {
      if (!control.value) return null;

      // Normalize both to local midnight (ignore time zone differences)
      const normalizeDate = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

      const selectedDate = normalizeDate(new Date(control.value));
      const fyStartDate = normalizeDate(new Date(this.fyStartDate));
      const maxDate = normalizeDate(new Date(this.maxDate));

      if (selectedDate < fyStartDate) return { beforeFYStart: true };
      if (selectedDate > maxDate) return { afterMaxDate: true };
      return null;
    };

    const tdsQuarterValidator = (control: any) => {
      if (!control.value) return null;

      const normalizeDate = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

      const selectedDate = normalizeDate(new Date(control.value));
      const quarterStart = normalizeDate(new Date(this.quarterStartDate));
      const maxDate = normalizeDate(new Date(this.maxDate));

      if (selectedDate < quarterStart) return { beforeQuarterStart: true };
      if (selectedDate > maxDate) return { afterMaxDate: true };
      return null;
    };


    tranRefDateControl?.setValidators([Validators.required, tranRefDateValidator]);
    tdsDeductDateControl?.setValidators([tdsQuarterValidator]);

    tranRefDateControl?.updateValueAndValidity();
    tdsDeductDateControl?.updateValueAndValidity();
  }


  // helper to parse dd-MMM-yyyy into Date
  private parseDdMmYyyy(dateStr: string): Date {
    const [day, mon, year] = dateStr.split('-');

    const months: { [key: string]: number } = {
      JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
      JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11
    };

    const monthIndex = months[mon.toUpperCase()] ?? -1; // fallback if not found
    return new Date(parseInt(year, 10), monthIndex, parseInt(day, 10));
  }


  showRateTypeOptions = false;
  showCountryOptions = false;

  // Selected labels
  selectedRateTypeLabel: string = '';
  selectedRateTypeValue: any;
  selectedCountryLabel: string = '';
  selectedCountryValue: any;

  // Search inputs
  searchRateType: string = '';
  searchCountry: string = '';

  // Filtered lists
  filteredRateTypeOptions: any[] = [];
  filteredCountryOptions: any[] = [];

  // Search filtering
  filterRateTypeOptions() {
    const search = this.searchRateType.toLowerCase();
    this.filteredRateTypeOptions = this.tdsRateTypeMastData.filter((opt: any) =>
      opt.label.toLowerCase().includes(search)
    );
  }

  filterCountryOptions() {
    const search = this.searchCountry.toLowerCase();
    this.filteredCountryOptions = this.countryMastData.filter((opt: any) =>
      opt.label.toLowerCase().includes(search)
    );
  }

  // Select option
  selectRateTypeOption(option: any) {
    this.selectedRateTypeValue = option.value;
    this.transactionForm.get('rate_type')?.setValue(option.value);
    this.selectedRateTypeLabel = option.label;
    this.showRateTypeOptions = false;

        this.searchRateType = '';
  this.filteredRateTypeOptions = [...(this.tdsRateTypeMastData || [])];

    // Trigger TDS rate fetch when rate type changes (if PAN and TDS section are already selected)
    if (this.canFetchRates() && this.tdsTypeCode != '24Q' && !this.selectedRowId && !this.firsttimetdsget ) {
      this.fetchTdsRates(this.selectedTdsSectionValue);
    }
  }

  selectCountryOption(option: any) {
    this.transactionForm.get('country_code')?.setValue(option.value);
    this.selectedCountryLabel = option.label;
    this.selectedCountryValue = option.value;
    this.showCountryOptions = false;

        this.searchCountry = '';
  this.filteredCountryOptions = [...(this.countryMastData || [])];

    // Trigger TDS rate fetch when country changes (if all required fields are selected)
    if (this.canFetchRates() && this.tdsTypeCode != '24Q'  && !this.selectedRowId && !this.firsttimetdsget) {
      this.fetchTdsRates(this.selectedTdsSectionValue);
    }
  }


  filterRemittanceOptions() {
    const search = this.searchRemittance.toLowerCase();
    this.filteredRemittanceOptions = this.tdsRemittanceData.filter(opt =>
      opt.label.toLowerCase().includes(search)
    );
  }

  selectRemittanceOption(option: any) {
    this.selectedRemittanceLabel = option.label;
    this.selectedRemittanceValue = option.value;
    this.transactionForm.get('nature_of_remittance')?.setValue(option.value); // bind form
    this.showRemittanceOptions = false;

        this.searchRemittance = '';
  this.filteredRemittanceOptions = [...(this.tdsRemittanceData || [])];

    // Trigger TDS rate fetch when remittance type changes (if all required fields are selected)
    if (this.canFetchRates() && this.tdsTypeCode != '24Q' && !this.selectedRowId  && !this.firsttimetdsget) {
      this.fetchTdsRates(this.selectedTdsSectionValue);
    }
  }

  // Helper method to check if all required fields are populated for TDS rate fetching
  private canFetchRates(): boolean {
    const panNo = this.transactionForm.get('deductee_panno')?.value;
    const tdsSection = this.selectedTdsSectionValue;

    return !!(panNo && tdsSection && panNo.trim().length > 0 && tdsSection.trim().length > 0);
  }


  // Helper method to get all form validation errors
  getFormValidationErrors() {
    const errors: any = {};
    const invalidFieldsDetails: any[] = [];

    Object.keys(this.transactionForm.controls).forEach(key => {
      const control = this.transactionForm.get(key);
      if (control && control.errors) {
        errors[key] = control.errors;
        invalidFieldsDetails.push({
          field: key,
          value: control.value,
          errors: control.errors
        });
      }
    });

    return { errors, invalidFieldsDetails };
  }


private cleanDeducteeName(rawName: any): { name: string; verifiedStatus: string } {
  let cleanedName = '';
  let verifiedStatus = '';

  if (!rawName) {
    return { name: '', verifiedStatus: '' };
  }

  // Normalize input type
  if (typeof rawName === 'string') {
    cleanedName = rawName;
  } else if (Array.isArray(rawName)) {
    cleanedName = rawName.join(', ');
  } else if (typeof rawName === 'object') {
    cleanedName = rawName.label ?? JSON.stringify(rawName);
  } else {
    cleanedName = String(rawName);
  }

  cleanedName = cleanedName.trim();

  // Extract value if JSON-like structure with "label"
  const matchLabel = /"label"\s*:\s*"([^"]+)"/.exec(cleanedName);
  if (matchLabel) {
    cleanedName = matchLabel[1];
  }

  // ✅ Extract trailing ,Y or ,N or ,I or ,X (verification flag)
  const match = cleanedName.match(/,\s*([YyNnIiXx])$/);
  if (match) {
    verifiedStatus = match[1].toUpperCase(); // Store Y/N/I/X
    cleanedName = cleanedName.slice(0, match.index).trim(); // Remove suffix
  }

  // Remove unwanted brackets or quotes
  cleanedName = cleanedName.replace(/[\[\]{}"]/g, '').trim();

  return { name: cleanedName || '', verifiedStatus };
}



  panDataDetails: any;
  panNo: any;
  panErrorMessage: string = '';
 pannoVerified: string | null = null;

  private clearPanDependentFields() {
    // this.transactionForm.patchValue({
    //   deductee_name: '',
    // });
    this.panValidationStatus = {
      isValid: null,
      message: ''
    };
  }

deducteeName:any;
  // Fetch PAN master data from API
  private fetchPanMasterData(panNumber: string) {
    if (!panNumber || panNumber.length !== 10) return;

    // Clear previously filled dependent fields before fetching new PAN data
    this.clearPanDependentFields();

    this.isLoadingPanData = true;
    this.panNo = panNumber;

    this.authservice.getPanMasterData(panNumber).subscribe({
      next: (response) => {

        if (response?.body?.status === 1 && response?.body?.result) {
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          // console.log(this.deductee_panno_status);

          // Handle validation status
          const isValid = panData.deductee_panno_valid === 'Y';
          this.panValidationStatus = {
            isValid: isValid,
            message: isValid ? 'Valid PAN' : 'Invalid PAN'
          };

  if (panData.deductee_name) {
          // console.log('PAN API deductee_name raw:', panData.deductee_name);
          const { name, verifiedStatus } = this.cleanDeducteeName(panData.deductee_name);
          this.deducteeName = this.cleanDeducteeName(panData.deductee_name).name; 

         // this.transactionForm.patchValue({ deductee_name: name });
          this.pannoVerified = verifiedStatus; // ✅ update flag for UI
          // console.log('Cleaned Deductee Name:', name, ' | Status:', verifiedStatus);
        } else {
          console.warn('No deductee_name found in PAN data.');
          this.pannoVerified = '';
        }

        this.isLoadingPanData = false;

        if (isValid && this.isEditMode && !this.selectedRowId && this.deducteeName != '') {
          this.toastService.showSuccess('Valid PAN - Details fetched successfully');
        } else if (!isValid) {
          this.toastService.showError('PAN found but marked as invalid');
        }
        
        }
        else if (response?.body?.status === 0) {
          this.isLoadingPanData = true;
          const panData = response.body.result;

          this.deductee_panno_status = panData.deductee_panno_valid;
          // console.log(this.deductee_panno_status);
          this.pannoVerified = 'N'

          this.authservice.getPanValidationData(panNumber).subscribe({
            next: (validationResponse) => {
              const result = validationResponse?.body;
              this.isLoadingPanData = true;
            
              if (result?.code == 0) {

                const panData = result.data;
                const parsePanData = JSON.parse(panData);
                this.panDataDetails = parsePanData.data[0];

                if (panData) {

                  const requestBody = {

                    a_session_seqno: "",
                    a_iud_seqno: "",
                    a_is_pen_flag: "",
                    a_login_type: "login_id",
                    a_module_type_code: this.dynamicUserData?.default_module_type_code,
                    a_sub_module_type_code: "R",
                    a_user_code: this.UserData.user_code,
                    a_entity_code: this.dynamicUserData.entity_code,
                    a_client_code: this.dynamicUserData.client_code,
                    a_acc_year: this.dynamicUserData.default_acc_year,
                    a_quarter_no: this.dynamicUserData.default_quarter_no,
                    a_tran_month: this.dynamicUserData.default_tran_month,
                    a_validation_client_level: this.dynamicUserData.client_code_level,
                    a_tran_from_date: this.dynamicUserData.default_from_date,
                    a_tran_to_date: this.dynamicUserData.default_to_date,
                    a_tds_type_code: this.dynamicUserData.default_tds_type_code,
                    a_first_level_client_code: this.dynamicUserData.first_level_client_code,
                    a_client_code_level: this.dynamicUserData.client_code_level,
                    a_user_level: this.dynamicUserData.user_level,
                    a_proc_error: "0",
                    a_db_total_records: '1000',
                    a_pagination_count: '0',
                    a_proc_type: 'get_miud_pan_mast',
                    a_process_seqno: "",
                    a_iud_type: "i",
                    a_process_status_code: "ZA",
                    pan_mast: {
                      panno: this.panDataDetails?.pan,
                      first_name: this.panDataDetails?.panName,
                      pan_allot_date: this.formatDate(this.panDataDetails?.panAlotmentDate),
                      pan_aadhar_status: this.panDataDetails?.panAadhaarLinkStatus,
                      ab206_status: "",
                      n194_status: "",
                      verifiedby_flag: ""
                    }

                  };
                  this.apiservice
                    .miudApi('/Dashboard/get_miud_pan_mast', requestBody)
                    .subscribe({
                      next: (response) => {
                  
                        if (response.result[0].a_proc_error == 0) {

                          this.toastService.showSuccess(response.result[0].a_proc_error_message);
                          const upperVal = this.panNo.toUpperCase();
                          this.fetchPanMasterData(upperVal);
                        }
                        else {
                          this.toastService.showError(response.result[0].a_proc_error_message);
                          this.isLoadingPanData = true;
                        }
                      }
                    });

                }

              } else {
                const panerrorData = JSON.parse(result.data)?.errdata;
                this.isLoadingPanData = false;
                this.panErrorMessage = panerrorData?.errorMessage;
    
                this.toastService.showError('PAN not found in validation data');
              }
            },
            error: (error) => {
              console.error('Error fetching PAN validation data:', error);
             
              // Extract meaningful message safely
              const errorMessage =
                error?.error?.message ||
                error?.message ||
                'Something went wrong. Please try again.';

              // Show toast with extracted message
              // this.showError(errorMessage);
            }
          });
        }

        else {

          // Set status as unknown when no data found
          this.panValidationStatus = {
            isValid: null,
            message: 'PAN not found in master data'
          };
        }
        this.isLoadingPanData = false;
      },
      error: (error) => {
        this.isLoadingPanData = false;
        console.error('Error fetching PAN master data:', error);

        // Don't show error message as PAN API failure shouldn't block the form
      }
    });
  }


  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }


  // Fetch TDS rates from API using the correct parameter structure
  private fetchTdsRates(tdsCode: string) {
    if (!tdsCode) return;

    this.isLoadingRates = true;

    // Get the PAN number from the form (deductee's PAN)
    const panNumber = this.transactionForm.get('deductee_panno')?.value || "";

    // If PAN is not yet entered, we can't fetch rates
    if (!panNumber || panNumber.length !== 10) {

      this.isLoadingRates = false;
      this.toastService.showError('Please enter a valid PAN number first');
      return;
    }


    // Format date properly (DD-Mon-YYYY with proper case)
    const formatDateForAPI = (dateStr: string): string => {
      if (!dateStr) return "30-Jun-2024";
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const day = parts[0];
        const month = parts[1].charAt(0).toUpperCase() + parts[1].slice(1).toLowerCase();
        const year = parts[2];
        return `${day}-${month}-${year}`;
      }
      return dateStr;
    };

    const toDate = formatDateForAPI(this.dynamicUserData.default_to_date || "30-Jun-2024");

    // Get values from form fields
    const rateType = this.transactionForm.get('rate_type')?.value || "I";
    const natureOfRemittance = this.transactionForm.get('nature_of_remittance')?.value || "";
    const countryCode = this.transactionForm.get('country_code')?.value || "";
    const certificateNo = this.transactionForm.get('certificate_no')?.value || "";
    const tranAmt = this.transactionForm.get('tran_amt')?.value || "0.00";

    // Prepare parameters matching the API structure exactly
    const baseSdata = [
      this.dynamicUserData.entity_code || this.UserData?.entity_code || "GKK",          // a_entity_code
      this.dynamicUserData.client_code || this.UserData?.client_code || "GKKHO",        // a_client_code
      this.dynamicUserData.default_acc_year || this.UserData?.default_acc_year || "24-25", // a_acc_year
      this.dynamicUserData.default_tds_type_code || this.UserData?.default_tds_type_code || "26Q", // a_tds_type_code
      panNumber,                                                                        // a_deductee_panno
      "Y",                                                                             // a_deductee_panno_valid
      "Y",                                                                             // a_deductee_panno_verified
      certificateNo,                                                                   // a_certificate_no
      rateType,                                                                        // a_rate_type (from dropdown)
      natureOfRemittance,                                                              // a_nature_of_remittance (from dropdown)
      countryCode,                                                                     // a_country_code (from dropdown)
      tdsCode,                                                                         // a_tds_code
      toDate,                                                                          // a_tds_deduct_date
      tranAmt.toString()                                                              // a_tran_amt
    ];



    // Create three API calls for TDS, Surcharge, and Cess rates
    const tdsRateCall = this.fetchSingleRate([...baseSdata, "TDS_RATE"]);
    const surchargeRateCall = this.fetchSingleRate([...baseSdata, "surcharge_Rate"]);
    const cessRateCall = this.fetchSingleRate([...baseSdata, "cess_Rate"]);

    // Execute all three calls in parallel
    Promise.all([tdsRateCall, surchargeRateCall, cessRateCall])
      .then(([tdsResponse, surchargeResponse, cessResponse]) => {
        this.isLoadingRates = false;

        // Update rates
        this.tdsRates.tdsRate = this.parseRateResponse(tdsResponse, 'TDS_RATE');
        this.tdsRates.surchargeRate = this.parseRateResponse(surchargeResponse, 'surcharge_Rate');
        this.tdsRates.cessRate = this.parseRateResponse(cessResponse, 'cess_Rate');

        // Calculate amounts based on transaction amount
         if (!this.selectedRowId && !this.firsttimetdsget) {
        this.calculateTdsAmounts();
         }
      })
      .catch(error => {
        this.isLoadingRates = false;
        console.error('Error fetching TDS rates:', error);
        this.toastService.showError('Failed to fetch TDS rates');
      });
  }

  // Helper to make single rate API call
  private fetchSingleRate(sdata: any[]): Promise<any> {
    return new Promise((resolve, reject) => {
      this.authservice.getTdsRate(sdata).subscribe({
        next: (response) => {
          resolve(response);
        },
        error: (error) => {
          console.error('Rate API error:', error);
          resolve(null);
        }
      });
    });
  }

  // Parse rate response
  private parseRateResponse(response: any, rateType: string): number {
    if (!response) return 0;

    // Handle direct response body
    if (response.body) {
      // Format 1: {"type":"TDS_RATE","value":"1"} or {"type":"TDS_RATE","value":""}
      if (response.body.type === rateType && response.body.value !== undefined) {
        const value = response.body.value;
        return value === "" ? 0 : (parseFloat(value) || 0);
      }

      // Format 2: {"value":"1"} or {"value":""}
      if (response.body.value !== undefined) {
        const value = response.body.value;
        return value === "" ? 0 : (parseFloat(value) || 0);
      }

      // Format 3: Nested result
      if (response.body.result) {
        if (response.body.result.value !== undefined) {
          return parseFloat(response.body.result.value) || 0;
        }
        if (response.body.result.type === rateType && response.body.result.value !== undefined) {
          return parseFloat(response.body.result.value) || 0;
        }
      }
    }

    // Direct response format
    if (response.type === rateType && response.value !== undefined) {
      const value = response.value;
      return value === "" ? 0 : (parseFloat(value) || 0);
    }

    if (response.value !== undefined) {
      const value = response.value;
      return value === "" ? 0 : (parseFloat(value) || 0);
    }

    return 0;
  }

  private getEffectiveTdsRate(): number {
  if (!this.selectedRowId && this.certificate_tds_rate && this.isCertificateRateActive) {
    return this.certificate_tds_rate;
  }
  return this.tdsRates?.tdsRate || 0;
}


  // Calculate TDS amounts based on transaction amount and rates
  private calculateTdsAmounts() {
    const tranAmount = parseFloat(this.transactionForm.get('tran_amt')?.value) || 0;

    if (tranAmount > 0) {
      // Calculate TDS amount = transaction amount * TDS rate / 100
      // const tdsAmount = (tranAmount * this.tdsRates.tdsRate) / 100;
      const effectiveTdsRate = this.getEffectiveTdsRate();
const tdsAmount = (tranAmount * effectiveTdsRate) / 100;
// console.log('Effective Rate:', effectiveTdsRate, 'TDS Amount:', tdsAmount);

      // Calculate surcharge amount = transaction amount * Surcharge rate / 100
      const surchargeAmount = (tranAmount * this.tdsRates.surchargeRate) / 100;

      // Calculate cess amount = transaction amount * Cess rate / 100
      const cessAmount = (tranAmount * this.tdsRates.cessRate) / 100;

      // Update form with calculated amounts (rounded to 2 decimal places)
      this.transactionForm.patchValue({
        tds_base_amt: parseFloat(tdsAmount.toFixed(2)),
        surcharge_amt: parseFloat(surchargeAmount.toFixed(2)),
        cess_amt: parseFloat(cessAmount.toFixed(2)),
        // tds_base_amt: tranAmount // Also set TDS base amount to transaction amount
      }, { emitEvent: false }); // Don't emit events to prevent loops
// console.log( 'if' ,this.transactionForm)

    } else {
      // Clear amounts if transaction amount is 0 or empty
      this.transactionForm.patchValue({
        tds_base_amt: 0,
        surcharge_amt: 0,
        cess_amt: 0,
        // tds_base_amt: 0
      }, { emitEvent: false });
   
    }
  }

  // Reverse calculation of rate from TDS Amount
  private reverseCalculateFromTdsAmount(tdsAmount: number) {
    const tranAmount = this.transactionForm.get('tran_amt')?.value;
    if (tranAmount > 0 && tdsAmount >= 0) {
      const tdsRate = (tdsAmount * 100) / tranAmount;
      const surchargeRate = (this.transactionForm.get('surcharge_amt')?.value * 100) / tranAmount || 0;
      const cessRate = (this.transactionForm.get('cess_amt')?.value * 100) / tranAmount || 0;

      this.tdsRates = {
        ...this.tdsRates,
        tdsRate: parseFloat(tdsRate.toFixed(2)),
        surchargeRate: parseFloat(surchargeRate.toFixed(2)),
        cessRate: parseFloat(cessRate.toFixed(2))
      };
      // console.log( this.tdsRates )
    }
  }

  // Reverse calculation from Surcharge Amount
  private reverseCalculateFromSurchargeAmount(surchargeAmount: number) {
    const tranAmount = this.transactionForm.get('tran_amt')?.value;
    if (tranAmount > 0 && surchargeAmount >= 0) {
      const surchargeRate = (surchargeAmount * 100) / tranAmount;
      const tdsRate = (this.transactionForm.get('tds_base_amt')?.value * 100) / tranAmount || 0;
      const cessRate = (this.transactionForm.get('cess_amt')?.value * 100) / tranAmount || 0;

      this.tdsRates = {
        ...this.tdsRates,
        tdsRate: parseFloat(tdsRate.toFixed(2)),
        surchargeRate: parseFloat(surchargeRate.toFixed(2)),
        cessRate: parseFloat(cessRate.toFixed(2))
      };
    }
  }

  // Reverse calculation from Cess Amount
  private reverseCalculateFromCessAmount(cessAmount: number) {
    const tranAmount = this.transactionForm.get('tran_amt')?.value;
    if (tranAmount > 0 && cessAmount >= 0) {
      const cessRate = (cessAmount * 100) / tranAmount;
      const tdsRate = (this.transactionForm.get('tds_base_amt')?.value * 100) / tranAmount || 0;
      const surchargeRate = (this.transactionForm.get('surcharge_amt')?.value * 100) / tranAmount || 0;

      this.tdsRates = {
        ...this.tdsRates,
        tdsRate: parseFloat(tdsRate.toFixed(2)),
        surchargeRate: parseFloat(surchargeRate.toFixed(2)),
        cessRate: parseFloat(cessRate.toFixed(2))
      };
    }
  }



  openCertificateDrawer() {
    this.fetchSpecialRates();
  }
  certificateHeader: any;
  // Fetch special TDS rates based on certificate number
  fetchSpecialRates() {

    const certificateNo = this.transactionForm.get('certificate_no')?.value;
    const deducteePanNo = this.transactionForm.get('deductee_panno')?.value;
    const tdsCode = this.selectedTdsSectionValue;


    // For now, let's show the popup even if some fields are missing for testing
    if (!deducteePanNo || !tdsCode) {
      // Show a test popup with sample data to verify it's working
      this.certificateDetails = [{
        certificate_no: certificateNo || 'TEST123',
        deductee_panno: deducteePanNo || 'AFRPM1762R',
        tds_section: '26',
        tds_rate: 3.5,
        certificate_valid_from: '28-MAY-2025',
        certificate_valid_upto: '31-MAR-2026',
        tds_limit_amt: 2500000,
        amount_consumed: 0
      }];
      //  this.showCertificatePopup = true;

      return;
    }

    this.isLoadingSpecialRates = true;


    // Prepare the request data following the same pattern as other API calls
    const requestData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_process_seqno: "",
      a_proc_type: "get_gmdb_tds_spl_rate_mast",
      a_process_status_code: "ZA",
      a_db_total_records: "100",
      a_pagination_count: "0",
      a_page_from: "1",
      a_page_to: "1",
      a_dashboard_type: "DB",
      a_filter_clause: [
        {
          filter_col_field: "deductee_panno",
          filter_col_depend_operator: "=",
          filter_col_value: deducteePanNo,
          filter_col_field_alias: "a."
        },
        {
          filter_col_field: "tds_code",
          filter_col_depend_operator: "=",
          filter_col_value: tdsCode,
          filter_col_field_alias: "a."
        }
      ]
    };

    // Call the API using apiservice
    this.apiservice.miudApi('/Transaction/get_gmdb_tds_spl_rate_mast', requestData).subscribe({
      next: (response: any) => {
        this.isLoadingSpecialRates = false;

        if (response?.result?.get_gmdb_tds_spl_rate_mast?.get_gmdb_tds_spl_rate_mast_detail) {
          const certificateData = response.result.get_gmdb_tds_spl_rate_mast.get_gmdb_tds_spl_rate_mast_detail;
          this.certificateHeader = response.result.get_gmdb_tds_spl_rate_mast.get_gmdb_tds_spl_rate_mast_header;

          if (certificateData && certificateData.length > 0) {
            this.certificateDetails = certificateData;
            this.showCertificatePopup = true;

          }
          else {
            this.certificateDetails = [];
            this.toastService.showSuccess('No special rate certificates found for this PAN and TDS section combination');
          }
        } else {

          this.certificateDetails = [];
          this.toastService.showSuccess('No special rate certificates found for this PAN and TDS section combination');
        }
      },
      error: (error: any) => {
        this.isLoadingSpecialRates = false;
        console.error('Error fetching special rates:', error);
        this.toastService.showError('Failed to fetch special TDS rates');
      }
    });
  }


  onCloseDrawer() {
    this.showCertificatePopup = false;
  }
  certificate_Number: any;
  certificate_tds_rate:any;
  isCertificateRateActive = false;


  onCertificateApplied(certificate: any) {

    this.certificate_Number = certificate.certificate_no;
    if(!this.selectedRowId && certificate){
      this.certificate_tds_rate = certificate.tds_rate;
        this.isCertificateRateActive = true; 
    }


    this.showCertificatePopup = false; // optional auto-close
    this.transactionForm.patchValue(
      {
        certificate_no: this.certificate_Number || '',
      });

  }

  get displayedTdsRate(): number {
  //  If in Add mode and certificate rate exists, show certificate rate
 if (!this.selectedRowId && this.certificate_tds_rate && this.isCertificateRateActive) {
    return this.certificate_tds_rate;
  }

  // Otherwise, show the default fetched rate
  return this.tdsRates?.tdsRate || 0;
}

  errorMessage: string = '';

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  toggleEditMode() {
    this.isEditMode = !this.isEditMode;
  }
  roleChallanData: any;
  private tdsCodeManuallyChanged = false;


  fetchChallanDetails(roleCode: string) {

    const requestBody = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_db_total_records: '1000',
      a_pagination_count: '0',
      a_proc_type: 'get_gtdt_tds_challan_tran_load',
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails(
        '/Transaction/get_gtdt_tds_challan_tran_load',
        requestBody
      )
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error == 0) {

            const roleChallanData =
              response?.result?.get_gtdt_tds_challan_tran_load
                ?.get_gtdt_tds_challan_tran_load_detail?.[0];
            this.roleChallanData = roleChallanData;
          }

        },
        error: () => {
          this.showError('Failed to fetch User details.');
        },
      });
  }
  private panManuallyChanged = false;
  fetchUserDetails(roleCode: string) {
    this.detailsLoader = true;
    const requestBody = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: 'get_gtdt_tds_tran_load',
      a_in_parameter_json: [{ a_rowid_seq: roleCode }],
    };

    this.apiservice
      .getsingleDetails('/Dashboard/get_gtdt_tds_tran_load', requestBody)
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_gtdt_tds_tran_load
              ?.get_gtdt_tds_tran_load_detail?.[0];
          this.roleData = roleData


          if (!roleData) {
            this.showError('No user data found.');
            return;
          }

          this.detailsLoader = false;
          this.tdsCodeManuallyChanged = false;

          this.tdsRates = {
            tdsRate: roleData.tds_rate || 0,
            surchargeRate: roleData.surcharge_rate || 0,
            cessRate: roleData.cess_rate || 0
          };


    
          this.transactionForm.patchValue(
            {
              // Deductee Details
              deductee_name: roleData.deductee_name || '',
              deductee_panno: roleData.deductee_panno || '',
              cust_id: roleData.cust_id || '',
              account_no: roleData.account_no || '',
              tin_uin_no: roleData.tin_uin_no || '',
              deductee_email_id: roleData.deductee_email_id || '',
              deductee_phoneno: roleData.deductee_phoneno || '',
              deductee_address: roleData.deductee_address || '',

              // Transaction Dates
              tran_ref_date: roleData.tran_ref_date || '',
              tds_deduct_date: roleData.tds_deduct_date || '',

              // Reference & Codes
              tran_ref_no: roleData.tran_ref_no || '',
              tds_code: roleData.tds_code || '',
              tds_deduct_reason: roleData.tds_deduct_reason || '',
              certificate_no: roleData.certificate_no || '',

              // Rates & Country
              rate_type: roleData.rate_type || '',
              country_code: roleData.country_code || '',
              nature_of_remittance: roleData.nature_of_remittance || '',

              // Amounts
              tran_amt: roleData.tran_amt || 0,
              tds_base_amt: roleData.tds_base_amt || 0,
              surcharge_amt: roleData.surcharge_amt || 0,
              cess_amt: roleData.cess_amt || 0,
              tds_rate: roleData.tds_rate || 0,
              surcharge_rate: roleData.surcharge_rate || 0,
              cess_rate: roleData.cess_rate || 0,
              // Flags
              grossup_Indicator_flag: roleData.grossup_Indicator_flag || 'N',
              new_regime_flag: roleData.new_regime_flag || 'N',

              // Other Details
              ca15_ackno: roleData.ca15_ackno || '',
              n94_cash_20l_amt: roleData.n94_cash_20l_amt || 0,
              n94_cash_1cr_amt: roleData.n94_cash_1cr_amt || 0,
              n94_cash_3cr_amt: roleData.n94_cash_3cr_amt || 0,
            },
            { emitEvent: true } // ensures valueChanges is triggered
          );
          // After patch, allow future manual changes to trigger API
          setTimeout(() => (this.tdsCodeManuallyChanged = true), 0);
          // After patch, allow future manual edits to trigger API
          setTimeout(() => (this.panManuallyChanged = true), 0);

          // Dynamically filter reasons
          // ✅ Dynamically load TDS deduct reasons based on tds_code
          const currentselectedTdsCode = this.transactionForm.get('tds_code')?.value || roleData?.tds_code;

          if (currentselectedTdsCode && this.tdsMastData?.length && this.tdsReasonMastData?.length) {
            const tdsMastRecord = this.tdsMastData.find(
              (item: any) => String(item.tds_code) === String(currentselectedTdsCode)
            );

            if (tdsMastRecord) {
              const flagStr = tdsMastRecord.tds_deduct_reason_flag_str || "";


              // ✅ Always show full list
              this.tdsReasonOptions = this.tdsReasonMastData.map((item: any) => ({
                value: item.tds_deduct_reason,
                label: item.tds_deduct_reason_name,
              }));

              // ✅ Preselect valid ones based on flagStr
              const preselectedReasons = (this.tdsReasonMastData || [])
                .filter((item: any) => flagStr.includes(`#${item.tds_deduct_reason}#`))
                .map((item: any) => item.tds_deduct_reason);


              // Assuming both are arrays of objects and you compare by 'code' or 'id'
              this.filteredTdsReasonOptions = this.tdsReasonOptions.filter(
                (option: any) => preselectedReasons.includes(option.value)
              );

              // Patch both (preselected + saved reasons)
              const savedReasons = roleData.tds_deduct_reason
                ? roleData.tds_deduct_reason.split(',').map((r: string) => r.trim())
                : [];

              const finalReasons = savedReasons.length
                ? savedReasons
                : preselectedReasons;

              this.transactionForm.patchValue({
                tds_deduct_reason: finalReasons,
              });
            }
          }

          // Patch tds_deduct_reason with proper array handling
          const reasons = roleData.tds_deduct_reason
            ? roleData.tds_deduct_reason.split(',').map((r: string) => r.trim())
            : [];
          this.transactionForm.patchValue({ tds_deduct_reason: reasons });

          // Patch certificate_no enabling based on tds_deduct_reason
          const certificateControl = this.transactionForm.get('certificate_no');
          const toggleCertificate = (val: string | string[]) => {
            const vals = Array.isArray(val) ? val : [val];
            if (vals.includes('A')) {
              certificateControl?.enable();
              this.isCertificateEnabled = true;
            } else {
              certificateControl?.disable();
              certificateControl?.reset();
              this.isCertificateEnabled = false;
            }
          };
          toggleCertificate(reasons);

          const currentTdsCode = this.transactionForm.get('tds_code')?.value || roleData?.tds_code;

          const tdsMastRecord = this.tdsMastData?.find(
            (item: any) =>
              item.tds_code == currentTdsCode &&
              (
                (item.tds_type_code === '26Q' && ['53', '56', '74', '79'].includes(String(item.tds_code))) ||
                (item.tds_type_code === '27Q' && ['87', '88', '94', '95'].includes(String(item.tds_code)))
              )
          );

          this.show194NInputs = !!tdsMastRecord;

          // Update labels
          this.updateDisplayLabels(roleData);

          // if (this.canFetchRatesFromForm() && !this.selectedRowId && this.isEditMode && this.tdsTypeCode != '24Q') {
          if (this.canFetchRatesFromForm() && !this.selectedRowId && this.tdsTypeCode != '24Q') {

            const tdsCode = this.transactionForm.get('tds_code')?.value;
             
            this.fetchTdsRates(tdsCode);
          }


        },
        error: () => {
          this.showError('Failed to fetch User details.');
          this.detailsLoader = false;
        },
      });


  }

  private subscribeToPanValueChanges() {
  const panControl = this.transactionForm.get('deductee_panno');
  if (!panControl) return;

  panControl.valueChanges
    .pipe(
      debounceTime(500),
      distinctUntilChanged(),
      takeUntil(this.destroy$)
    )
    .subscribe((val: string) => {
      if (!val) {
        this.panValidationStatus = { isValid: null, message: '' };
        return;
      }
   if (val) {
      const upperVal = val.toUpperCase();
      if (upperVal !== val) {
        panControl.setValue(upperVal, { emitEvent: false });
      }

      const isValid = this.roleData?.deductee_panno_valid === 'Y';
      this.panValidationStatus = {
        isValid,
        message: isValid ? 'Valid PAN' : 'Invalid PAN',
      };

      if (upperVal.length < 10) {
          this.panValidationStatus = {
    isValid: null,
    message: ''
  };

          this.resetFormOnPanEdit();
        return;
      }

      if (upperVal.length === 10 && (this.panManuallyChanged || !this.selectedRowId) && this.isEditMode && !this.transactionForm.get('deductee_panno')?.hasError('pattern')) {
        // console.log('onpan');
        this.fetchPanMasterData(upperVal);

          // if (this.selectedTdsSectionValue && !this.isEditMode && this.tdsTypeCode != '24Q') {
          if (this.selectedTdsSectionValue && this.tdsTypeCode != '24Q' && !this.selectedRowId) {
            // console.log('ngOninit');
            this.fetchTdsRates(this.selectedTdsSectionValue);
          }
        }

      }
      else {
        // If cleared completely, reset the form
        this.resetFormOnPanEdit();
      }
    });

}


  private canFetchRatesFromForm(): boolean {
    const tdsCode = this.transactionForm.get('tds_code')?.value;
    const rateType = this.transactionForm.get('rate_type')?.value;
    const countryCode = this.transactionForm.get('country_code')?.value;
    const natureOfRemittance = this.transactionForm.get('nature_of_remittance')?.value;
    const pan = this.transactionForm.get('deductee_panno')?.value;

    // return !!tdsCode && !!rateType && !!countryCode && !!natureOfRemittance && !!pan && pan.length === 10;
    // For 27Q (non-resident payments)
    if (this.tdsTypeCode === '27Q') {
      return !!tdsCode && !!rateType && !!countryCode && !!natureOfRemittance && !!pan && pan.length === 10;
    }

    // For 26Q (domestic payments)
    if (this.tdsTypeCode === '26Q') {
      return !!tdsCode && !!pan && pan.length === 10;
    }

    return false;
  }

  // Utility: Convert any date string/Date to yyyy-MM-dd
  private formatRoleDateForInput(date: any): string | null {
    if (!date) return null;
    const d = new Date(date);
    if (isNaN(d.getTime())) return null; // invalid date safeguard
    return d.toISOString().split('T')[0]; // gives yyyy-MM-dd
  }

  // Helper to update labels after patch
  private updateDisplayLabels(roleData: any) {
  
    if (roleData?.tds_code) {
      const tdsOption = this.tdsSectionOptions.find(o => o.value === roleData.tds_code);
       
      this.selectedTdsSectionLabel = tdsOption ? tdsOption.label : '';
      this.selectedTdsSectionValue = roleData.tds_code;
        
        
    }
    if (roleData?.tds_deduct_reason) {
      const reasonOption = this.filteredTdsReasonOptions?.find(o => o.value === roleData.tds_deduct_reason);
      this.selectedTdsReasonLabel = reasonOption ? reasonOption.label : '';
      this.selectedTdsReasonValue = roleData.tds_deduct_reason;
    }
    if (roleData.rate_type) {
      const rateOption = this.filteredRateTypeOptions.find(o => o.value === roleData.rate_type);
      this.selectedRateTypeLabel = rateOption ? rateOption.label : '';
      this.selectedRateTypeValue = roleData.rate_type;
    }
    if (roleData.country_code) {
      const countryOption = this.filteredCountryOptions.find(o => o.value === roleData.country_code);
      this.selectedCountryLabel = countryOption ? countryOption.label : '';
      this.selectedCountryValue = roleData.country_code;
    }
    if (roleData.nature_of_remittance) {
      const remitOption = this.filteredRemittanceOptions.find(o => o.value === roleData.nature_of_remittance);
      this.selectedRemittanceLabel = remitOption ? remitOption.label : '';
      this.selectedRemittanceValue = roleData.nature_of_remittance;
    }
  }


  isDelete: boolean = false;
  isDeletePopupOpen = false;

  deleteSingleDetails() {
    this.isDeletePopupOpen = false;
    this.isDelete = true;
    this.onSubmit();
  }

  openDeletePopup() {
    this.isDeletePopupOpen = true;
    this.isDrawerOpen = false;

  }
  deleteSingleDetailsCancel() {
    this.isDelete = false;
    this.isDeletePopupOpen = false;
    this.isDrawerOpen = true;
     this.detailsLoader = false;
  }

  isSubmittingUpdateLoader: boolean = false;

  onSubmit() {

    this.isSubmittingUpdateLoader = true;
    if (this.transactionForm.invalid) {
       this.isSubmittingUpdateLoader = false;
      // Get detailed error information
      this.transactionForm.markAllAsTouched();
      const validationInfo = this.getFormValidationErrors();
      const invalidFields: string[] = [];

      Object.keys(this.transactionForm.controls).forEach(key => {
        const control = this.transactionForm.get(key);
        if (control && control.invalid) {
          invalidFields.push(key);
        }
      });

      // Create a more detailed error message
      let errorMessage = `Please fill the following required fields: ${invalidFields.slice(0, 5).join(', ')}`;
      if (invalidFields.length > 5) {
        errorMessage += ` and ${invalidFields.length - 5} more...`;
      }

      this.toastService.showError(errorMessage);
      return;
    }

    const formData = this.transactionForm.value;
    // console.log(formData)

    const qData = {

      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_tiud_tds_tran_load",
      a_process_seqno: "",
      // a_iud_type: this.selectedRowId ? 'u' : 'i',
      a_iud_type: this.isDelete && this.selectedRowId ? 'd' : this.selectedRowId ? 'u' : 'i',
      a_process_status_code: "ZA",
      a_db_total_records: "1000",
      a_pagination_count: "0",
      tds_tran_load: {
        rowid_seq: this.selectedRowId ? this.roleData.rowid_seq : '',
        cust_id: this.sanitizeValue(formData.cust_id, true),
        deductee_panno: this.sanitizeValue(formData.deductee_panno, true),
        deductee_panno_valid: this.selectedRowId ? this.roleData.deductee_panno_valid : this.sanitizeValue(this.deductee_panno_status),
        deductee_panno_verified: this.selectedRowId ? this.roleData.deductee_panno_verified : this.sanitizeValue(this.pannoVerified),
        deductee_name: this.sanitizeValue(formData.deductee_name, true),
        tran_ref_no: this.sanitizeValue(formData.tran_ref_no, true),
        tran_ref_date: formatDatesend(formData.tran_ref_date),
        tran_amt: this.sanitizeValue(formData.tran_amt),
        tds_deduct_date: formatDatesend(formData.tds_deduct_date),
        tds_code: this.selectedRowId ? formData.tds_code : this.selectedTdsSectionValue,
        tds_deduct_reason: this.sanitizeValue(formData.tds_deduct_reason),
        rate_type: this.sanitizeValue(formData.rate_type),
        nature_of_remittance: this.sanitizeValue(formData.nature_of_remittance),
        country_code: this.sanitizeValue(formData.country_code),
        // tds_base_amt: this.sanitizeValue(formData.tds_base_amt),
        tds_rate: this.displayedTdsRate,
        // tds_rate: this.tdsRates.tdsRate,
        // tds_rate: this.sanitizeValue(formData.tds_rate),
        tds_base_amt: this.sanitizeValue(formData.tds_base_amt),
        tds_base_rate: this.displayedTdsRate, 
        // tds_base_rate: this.tdsRates.tdsRate,
        surcharge_rate: this.tdsRates.surchargeRate,
        // surcharge_rate: this.sanitizeValue(formData.surcharge_rate),
        surcharge_amt: this.sanitizeValue(formData.surcharge_amt),
        cess_rate: this.tdsRates.cessRate,
        // cess_rate: this.sanitizeValue(formData.cess_rate),
        cess_amt: this.sanitizeValue(formData.cess_amt),
        hecess_amt: this.sanitizeValue(formData.hecess_amt),
        certificate_no: this.sanitizeValue(formData.certificate_no, true),
        account_no: this.sanitizeValue(formData.account_no),
        deductee_email_id: this.sanitizeValue(formData.deductee_email_id),
        deductee_address: this.sanitizeValue(formData.deductee_address, true),
        deductee_phoneno: this.sanitizeValue(formData.deductee_phoneno),
        tin_uin_no: this.sanitizeValue(formData.tin_uin_no),
        partybillamt: this.sanitizeValue(formData.partybillamt),
        deductee_code: this.selectedRowId ? this.roleData.deductee_code : '',
        tds_challan_rowid_seq: this.sanitizeValue(formData.tds_challan_rowid_seq),
        tds_challan_slno: this.sanitizeValue(formData.tds_challan_slno),
        grossup_Indicator_flag: this.sanitizeValue(formData.grossup_Indicator_flag),
        ca15_ackno: this.sanitizeValue(formData.ca15_ackno),
        new_regime_flag: this.sanitizeValue(formData.new_regime_flag),
        n94_cash_20l_amt: this.sanitizeValue(formData.n94_cash_20l_amt),
        n94_cash_1cr_amt: this.sanitizeValue(formData.n94_cash_1cr_amt),
        n94_cash_3cr_amt: this.sanitizeValue(formData.n94_cash_3cr_amt),
        approvedby: '',
        approveddate: ''
      }


    };

    this.apiservice
      .miudApi('/Dashboard/get_tiud_tds_tran_load', qData).subscribe({
        next: (response: any) => {
          // Stabilize getters before any modifications to avoid ExpressionChangedAfterItHasBeenCheckedError
          this.cdr.detectChanges();

          if (response?.result[0]?.a_proc_error == 0) {
            this.isSubmittingUpdateLoader = false;
            this.toastService.showSuccess(response?.result[0]?.a_proc_error_message || (this.selectedRowId ? 'Transaction Updated Successfully!' : 'Transaction Added Successfully!')
            );

            this.close.emit();
            this.refreshdata.trigerRefresh('Transaction');
          }
          else {
            this.isSubmittingUpdateLoader = false;
            const result = response?.result?.[0];

            if (result?.a_errors && Array.isArray(result.a_errors) && result.a_errors.length > 0) {
              const errors = result.a_errors;
              const errorSections = new Set<string>();

              // Reset previous server errors
              this.serverErrors = {};

              // Iterate over backend errors
              errors.forEach((error: { field: string; message: string }) => {
                const backendField = error.field;
                const mappedField = this.fieldMap[backendField] || backendField;
                const control = this.transactionForm.get(mappedField);
              
                // Track which section the field belongs to
                const section = this.sectionFieldMap[mappedField];
                if (section) errorSections.add(section);
                // Store the error message for this field
                this.serverErrors[mappedField] = error.message;

                // console.log(this.serverErrors[mappedField]);

                // Set the error on the form control
                if (control) {
                  const existingErrors = control.errors || {};
                  control.setErrors({ ...existingErrors, serverError: error.message });
                  control.markAsTouched();
                  control.markAsDirty();
                }
              });

              // Open the first section with errors
              if (errorSections.size > 0) {
                const sectionPriority = ['deductee', 'transaction', 'other'];
                const firstErrorSection = sectionPriority.find(section => errorSections.has(section));
                if (firstErrorSection) this.activeSection = firstErrorSection;
              }

              // Do NOT show a_proc_error_message if a_errors exist
            } else {
              this.isSubmittingUpdateLoader = false;
              // Show global error if no field errors
              this.toastService.showError(result?.a_proc_error_message || 'Failed to add Transaction');
            }
          }


        },
        error: (error: any) => {
          console.error(error);
          this.isSubmittingUpdateLoader = false;
        },
      });

  }

  handleInput(field: string) {
    if (this.serverErrors[field]) {
      this.serverErrors[field] = '';
      this.transactionForm.get(field)?.setErrors(null);
    }
  }


  // Helper method to check if field has errors (client or server)
  hasFieldError(fieldName: string): boolean {
    const control = this.transactionForm.get(fieldName);
    return (control?.touched && control?.invalid) || !!this.serverErrors[fieldName];
  }

  // Helper method to get error message for a field
  getFieldErrorMessage(fieldName: string): string | null {
    return this.serverErrors[fieldName] || null;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  get isdeducteeDetailsComplete(): boolean {
    // List of only required fields for Deductee Details
    const requiredFields = [
      'deductee_name',
      'deductee_panno',
    ];

    // Ensure each required field exists, is valid, and not empty
    return requiredFields.every(field => {
      const control = this.transactionForm.get(field);
      return control && control.valid && control.value !== null && control.value !== '';
    });
  }

  get istransactionDetailsComplete(): boolean {
    // check all required text fields
    const requiredFields = [
      'tds_code',
      'tran_ref_date',
      'tran_amt',
    ];

    return requiredFields.every(field => {
      const control = this.transactionForm.get(field);
      return control && control.valid && control.value !== null && control.value !== '';
    });
  }


  isCompleted = false;
  istransactionCompleted = false;

  // Field to section mapping for error handling
  sectionFieldMap: { [key: string]: string } = {
    // Deductee Details section
    'deductee_name': 'deductee',
    'deductee_panno': 'deductee',
    'cust_id': 'deductee',
    'account_no': 'deductee',
    'tin_uin_no': 'deductee',
    'deductee_email_id': 'deductee',
    'deductee_phoneno': 'deductee',
    'deductee_address': 'deductee',

    // Transaction Details section
    'tran_ref_date': 'transaction',
    'tds_deduct_date': 'transaction',
    'tran_ref_no': 'transaction',
    'tds_code': 'transaction',
    'tds_deduct_reason': 'transaction',
    'certificate_no': 'transaction',
    'rate_type': 'transaction',
    'country_code': 'transaction',
    'nature_of_remittance': 'transaction',
    'tran_amt': 'transaction',
    'tds_base_amt': 'transaction',
    'surcharge_amt': 'transaction',
    'cess_amt': 'transaction',

    // Other Details section
    'grossup_Indicator_flag': 'other',
    'new_regime_flag': 'other',
    'ca15_ackno': 'other',
    'n94_cash_20l_amt': 'other',
    'n94_cash_1cr_amt': 'other',
    'n94_cash_3cr_amt': 'other',
  };

  onSaveAndNext() {

    if (!this.isCompleted && this.isdeducteeDetailsComplete) {
      this.isCompleted = true;
      this.activeSection = 'transaction';
      if (!this.completedSections.includes('deductee')) {
        this.completedSections.push('deductee');
      }
      return;
    }

    if (!this.istransactionCompleted && this.istransactionDetailsComplete && this.isdeducteeDetailsComplete) {
      this.istransactionCompleted = true;
      this.activeSection = 'other';
      // Also mark 'other' as completed if form data exists
      if (!this.completedSections.includes('other')) {
        this.completedSections.push('other');
      }
      return;
    }
    

  }

  goToMapAllocation() {
    this.fetchTable();
  }


  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  filterClause: any;
  selectedValue: string[] = [];
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  loading = false;
  localUserData: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  tranHeaders: any[] = [];
  tranTableBody: any[] = [];
  isMapAllocation: boolean = false;

  allocationFlag: string = '';

  fetchTable() {
    this.filterClause = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
    const values = Array.isArray(this.selectedValue)
      ? this.selectedValue
      : [this.selectedValue];

    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynamicUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynamicUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    if (this.selectedRowId) {
      newFilterClause.push({
        filter_col_field: 'rowid_seq',
        filter_col_depend_operator: '=',
        filter_col_value: this.selectedRowId,
        filter_col_field_alias: 'a.',
      });
    }
    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) {
        this.filterClause.push(nf);
      }
    });

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }

    const sdata = this.apiservice.generateSData(
      'get_gtdb_tds_tran_load',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiservice
      .getTableData('/Dashboard/get_gtdb_tds_tran_load', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_tran_load;

            if (userData?.get_gtdb_tds_tran_load_header) {
              this.tranHeaders = userData.get_gtdb_tds_tran_load_header.map(
                (header: any) => ({
                  ...header,
                  visible: header.display === 1,
                })
              );
            }

            this.tranTableBody =
              userData?.get_gtdb_tds_tran_load_detail || [];

            // ✅ now open the child component only after headers & body are ready
            this.isMapAllocation = true;
            this.allocationFlag = 'transactionFlag';
          }
        },
        error: (error) => {
          console.error(error);
        },
      });

  }

  closeMapAllocation() {
    this.isMapAllocation = false;
    this.close.emit();
  }


  amountGreaterThanZeroValidator() {
    return (control: any) => {
      const value = parseFloat(control.value);
      if (isNaN(value) || value <= 0) {
        return { greaterThanZero: true };
      }
      return null;
    };
  }

  allowNumbersOnly(event: KeyboardEvent) {
    const allowedKeys = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', 'Backspace', 'ArrowLeft', 'ArrowRight', 'Delete', 'Tab'];

    if (!allowedKeys.includes(event.key)) {
      event.preventDefault();
    }

    // prevent multiple decimals
    const input = event.target as HTMLInputElement;
    if (event.key === '.' && input.value.includes('.')) {
      event.preventDefault();
    }
  }

  showPopup = false;

  togglePopup() {
    this.showPopup = !this.showPopup;
  }

  iudType: any;
  filterValue: any;
  tiudfilterClause: any;
  isSubmittingUpdate: boolean = false;
  onAllocatedClick() {

    this.iudType = 'SELECTED-UN-ALLOC';
    this.filterValue = 'and a.tds_challan_rowid_seq is not null';
    this.tiudfilterClause = [
      {
        filter_col_field: 'tds_challan_rowid_seq',
        filter_col_depend_operator: '=',
        filter_col_value: this.roleChallanData?.rowid_seq,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'deductee_alloc_status',
        filter_col_depend_operator: 'wc',
        filter_col_value: this.filterValue,
        filter_col_field_alias: 'a.',
      },
    ];

    const requestBody = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_is_pen_flag: '',
      a_login_type: 'login_id',
      a_module_type_code: this.dynamicUserData?.default_module_type_code,
      a_sub_module_type_code: 'R',
      a_user_code: this.UserData.user_code,
      a_entity_code: this.dynamicUserData.entity_code,
      a_client_code: this.dynamicUserData.client_code,
      a_acc_year: this.dynamicUserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.dynamicUserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.dynamicUserData.client_code_level,
      a_user_level: this.dynamicUserData.user_level,
      a_proc_error: '0',
      a_process_seqno: '',
      a_alloc_group_str: '',
      a_iud_type: this.iudType,
      a_proc_type: 'get_tiud_challan_alloc_line',
      a_process_status_code: '',
      // a_db_total_records: '1000',
      // a_pagination_count: '0',
      tds_challan_tran_load: [
        {
          rowid_seq: this.roleChallanData?.rowid_seq,
          to_be_allocated_amt: this.roleChallanData?.to_be_allocated_amt,
        },
      ],

      tds_tran_load: [
        {
          rowid_seq: this.roleData.rowid_seq,
        }
      ],


      a_filter_clause: this.tiudfilterClause,
    };

    this.submitRequest(
      requestBody,
      'Challans  Record Created Successfully!',
      (value) => (this.isSubmittingUpdate = value)
    );
    this.closePopup()
  }
  //subbmit
  submitRequest(
    requestBody: any,
    successMessage: any,
    setSubmitting: (value: boolean) => void
  ) {
    setSubmitting(true);
    // this.isSubmitting = true;
    this.apiservice
      .createData('/Transaction/get_tiud_challan_alloc_line', requestBody)
      .subscribe({
        next: (response) => {
          setSubmitting(false);
          // this.isSubmitting = false;
          const result = response?.result?.[0];
          if (!result) {
            this.showError('Unexpected response format from the server.');
            return;
          }
          if (result.a_proc_error === 0) {
            this.showSuccess(result.a_proc_error_message || successMessage);
            this.togglePopup();
            this.refreshdata.trigerRefresh('Challans');
            this.refreshdata.trigerRefresh('Transaction');

          } else {
            if (result.a_errors && Array.isArray(result.a_errors)) {
              result.a_errors.forEach(
                (error: { field: string; message: string }) => {
                  const field = error.field;
                }
              );
              this.showError(result.a_proc_error_message);
            } else {
              this.showError(
                result.a_proc_error_message || 'Error while creating User.'
              );
              // this.isSubmitting = false;
            }
          }
        },
        error: () => {
          setSubmitting(false);
          this.showError('Something went wrong! Please try again later.');
          // this.isSubmitting = false;
        },
      });
  }


handleTabCloseCalendar(event: KeyboardEvent) {
  if (event.key === 'Tab') {
    console.log(event.key )
    this.datePicker?.closeSingleCalender(); // 👈 call child's close function
  }
}

  onCalendarClosed() {
     console.log('Calendar closed'); 
    // Optional: perform any additional UI logic here
  }

}
