import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FuvgenerationComponent } from './fuvgeneration.component';

describe('FuvgenerationComponent', () => {
  let component: FuvgenerationComponent;
  let fixture: ComponentFixture<FuvgenerationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FuvgenerationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FuvgenerationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
