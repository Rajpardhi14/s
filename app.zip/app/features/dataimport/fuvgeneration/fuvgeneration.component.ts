import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { getApiName } from '../../../shared/utils/passmatch';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fuvgeneration',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './fuvgeneration.component.html',
  styleUrl: './fuvgeneration.component.css',
})
export class FuvgenerationComponent {
  errorMessage = '';

  processMessage: string = '';
  FYYear: string = 'Yes';

  refnumber: any;
  filterClause: any;
  tableHeaders: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  myloaderloding: boolean = false
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  isloading: boolean = false;
  localUserData: any;
  dynaUserData: any;
  tabs = ['Statistics', 'Text File Gen', 'FUV File Gen'];
  activeTab = this.tabs[0];
  selectTab(tab: string) {
    this.activeTab = tab;

  }
  submoduleType: any;

  constructor(
    private toastService: ToastService,
    private apiService: ApiserviceService,
    private userlocaldataService: UserdataService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.submoduleType = this.dynaUserData.default_sub_module_type_code
    if (this.submoduleType === 'G') {
      this.tabs = ['Statistics', 'Text File Gen']; 
    } else {
      this.tabs = ['Statistics', 'Text File Gen', 'FUV File Gen']; 
    }
    this.getProceseqs();
  }
  processsts: any
  //  1 check process status
  getProceseqs() {
    this.isloading = true;
    const apiName = getApiName(
      'proc_tds_tran_load_error',
      this.dynaUserData?.default_sub_module_type_code
    );

    const sdata = this.apiService.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: apiName,
      }
    );

    this.apiService
      .getTableData('/dynamic-import/proc_utilf_get_process_seqno_status', sdata)
      .subscribe({
        next: (data) => {
          console.log(data, 'process status');
          if (data?.result?.a_proc_error == 0) {
            const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
            this.refnumber = row?.process_seqno;

            const statusCode = row?.process_status_code;
            this.processsts = statusCode;
            this.processMessage = row?.process_log_text;

            // ✅ Extract last character safely
            const lastChar = statusCode ? statusCode.slice(-1) : null;

            switch (lastChar) {
              case 'C':
                this.activeTab = 'Statistics';
                this.fuvTextStat();
                this.errorStat();
                break;

              case 'I':
              case 'H':
                this.activeTab = this.tabs[1];
                this.errorStatfinal();
                break;

              case null:
              case undefined:
              case 'K':
                this.activeTab = 'Statistics';
                break;

              default:
                this.activeTab = this.tabs[0];
                break;
            }
          } else {
            this.errorMessage = data.result[0].a_proc_error_message;
            this.toastService.showError(this.errorMessage);
            this.isloading = false;
          }
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch Data.';
          this.toastService.showError(this.errorMessage);
          this.isloading = false;
        },
        complete: () => {
          this.isloading = false;
        },
      });
  }


  //

  isStaticalInfo: any;
  fuvData: any;
  fuvTextStat() {
    this.isloading = true;

    const sdata = this.apiService.generateSData(
      'get_gtdb_gen_fvu_text_statitics',
      this.localUserData,
      this.filterClause = [],
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        a_process_level: 1,
      }
    );

    this.apiService.getTableData('/FUV/get_gtdb_gen_fvu_text_statitics', sdata)
      .subscribe({
        next: (data) => {
          // console.log(data, 'fuv');

          if (data?.result?.a_proc_error == 0) {
            this.fuvData = Object.keys(
              data.result.get_gtdb_gen_fvu_text_statitics
            ).map((key) => ({
              key,
              head: {
                val: data.result.get_gtdb_gen_fvu_text_statitics[key].statsTitle.main,
                bgcolor: null,
                color: null,
                coloums_req: [{ header_name: 'Count', field_name: 'val' }],
              },
              childs: data.result.get_gtdb_gen_fvu_text_statitics[key].childs,
            }));
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
          }

          this.isloading = false; // ✅ Always stop loader
        },
        error: (error) => {
          this.isloading = false;
          this.errorMessage = error.message || 'Failed to fetch statistics.';
          this.showError(this.errorMessage);
        },
      });
  }


  errorStat() {
    this.isloading = true;

    const apiName = getApiName(
      'get_gtdb_tran_load_error_statitics_challan',
      this.dynaUserData?.default_sub_module_type_code
    );

    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        a_process_level: 1,
      }
    );

    this.apiService
      .getTableData('/Comman/dynamic', sdata)
      .subscribe({
        next: (data) => {
          // console.log(data);

          if (data?.result?.a_proc_error == 0) {
            const userData =
              data?.result?.[apiName];
            this.isStaticalInfo = userData;
            console.log(this.isStaticalInfo)
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
            this.isloading = false;
          }
          this.isloading = false;
        },
        error: (error) => {
          this.isloading = false;
          this.errorMessage = error.message || 'Failed to fetch statistics.';
          this.showError(this.errorMessage);
        },
      });
  }

  processLogfuv() {
    this.isloading = true;

    const sdata = this.apiService.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause = [],
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        iudtype: 'get_tiud_file_tran_fvu',
        a_process_level: 1,
        processStatusCode: 'ZA',
      }
    );

    this.apiService.getTableData('/EPV/proc_utilf_get_process_seqno_status', sdata)
      .subscribe({
        next: (data) => {
          console.log(data);
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tran_load_error_statitics_challan;
            // process your userData if needed
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
          }

          this.isloading = false; // ✅ Stop loader always
        },
        error: (error) => {
          this.isloading = false;
          this.errorMessage = error.message || 'Failed to fetch statistics.';
          this.showError(this.errorMessage);
        },
      });
  }

  basename: any
  startGen() {
    this.myloaderloding = true;


    const apiName = getApiName(
      'proc_gen_tds_bulk_txt_file',
      this.dynaUserData?.default_sub_module_type_code
    );


    const subType = this.dynaUserData?.default_sub_module_type_code;

    this.basename =
      !subType || subType === 'R'
        ? '/dynamic-import/'
        : subType === 'G'
          ? '/VALIDATION15GH/'
          : subType === 'C'
            ? '/C15GH/'
            : '/dynamic-import/';



    const sdata = this.apiService.generateSData(
      'proc_gen_tds_bulk_txt_file',
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        seqnumber: this.refnumber,

        // refnumber: this.refnumber,

        a_process_level: 1,
      }
    );

    const fullPath = `${this.basename}${apiName}`;
    this.apiService.getTableData(fullPath, sdata).subscribe({
      next: (data) => {
        console.log(data);
        this.startPolling()

        // if (data?.result?.a_proc_error == 0) {
        //    this.getStatus();

        // } else {
        //   this.errorMessage = data.result[0]?.a_proc_error_message;
        //   this.showError(this.errorMessage);
        //   this.isloading = false;
        // }
      },
      error: (error) => {
        this.myloaderloding = false;
        this.errorMessage = error.message || 'Failed to fetch statistics.';
        this.showError(this.errorMessage);
      },
    });
  }

  processStatusCode: string | null = null;
  pollingInterval: any;

  getStatus() {
    this.myloaderloding = true;
    const apiName = getApiName(
      'proc_tds_tran_load_error',
      this.dynaUserData?.default_sub_module_type_code
    );



    const sdata = this.apiService.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: apiName,
        // seqnumber: this.refnumber,
      }
    );

    this.apiService
      .getTableData('/dynamic-import/proc_utilf_get_process_seqno_status', sdata)
      .subscribe({
        next: (data) => {
          console.log(data)
          if (data?.result?.a_proc_error == 0) {

            const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
            const statusCode = row?.process_status_code ?? '';
            this.processStatusCode = statusCode;

            this.processsts = statusCode
            this.processMessage = row?.process_log_text;
            // console.log(this.processStatusCode)
            const lastChar = statusCode.slice(-1).toUpperCase();
            const stopLetters = ['B', 'C', 'E', 'F', 'H', 'I', 'Z'];

            if (stopLetters.includes(lastChar)) {
              this.stopPolling();
              // this.activeTab = this.tabs[1];
              // this.errorStatfinal()
              this.myloaderloding = false;

              if (['B', 'C'].includes(lastChar)) {
                this.activeTab = this.tabs[0];
                this.fuvTextStat();
                this.errorStat();

              } else if (lastChar === 'Z' || !lastChar) {
                this.activeTab = this.tabs[0];
                this.fuvTextStat();
                this.errorStat();
              } else {
                this.activeTab = this.tabs[1];
                this.errorStatfinal()
              }
            }
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
            this.myloaderloding = false;
          }
        },
        error: (error) => {
          this.myloaderloding = false;
          this.errorMessage = error.message || 'Failed to fetch process status.';
          this.showError(this.errorMessage);
        },
      });
  }


  startPolling(intervalMs: number = 5000) {
    this.pollingInterval = setInterval(() => this.getStatus(), intervalMs);
  }


  stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
      this.myloaderloding = false;
      console.log('Polling stopped — last code:', this.processStatusCode);
    }
  }




  finalstats: any
  errorStatfinal() {
    this.isloading = true;
    const apiName = getApiName(
      'get_gtdb_gen_fvu_text_statitics_final_tds',
      this.dynaUserData?.default_sub_module_type_code
    );
    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        a_process_level: 1,
      }
    );

    this.apiService
      .getTableData('/Comman/dynamic', sdata)
      .subscribe({
        next: (data) => {
          console.log(data);

          if (data?.result?.a_proc_error == 0) {

            const statsData = data.result?.[apiName];

            this.finalstats = [
              {
                key: 'stats',
                head: {
                  val: statsData?.statsTitle?.main || 'Statistics',
                  bgcolor: null,
                  color: null,
                  coloums_req: [{ header_name: 'Count', field_name: 'val' }],
                },
                childs: statsData?.childs || [],
              },
            ];
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
            this.isloading = false;
          }
          this.isloading = false;
        },
        error: (error) => {
          this.isloading = false;
          this.errorMessage = error.message || 'Failed to fetch statistics.';
          this.showError(this.errorMessage);
        },
      });
  }
  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  getPercentage(val: number, max: number = 1000000): number {
    return Math.min((val / max) * 100, 100);
  }


  processKill() {
    this.myloaderloding = true;
    const sdata = this.apiService.generateSData(
      'proc_tds_tran_load_error',
      this.localUserData,
      this.filterClause = [],
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'PROCESS_CANCEL',
        a_process_level: 1,
        seqnumber: this.refnumber,
        processStatusCode: 'EC',
      }
    );

    // this.myloaderloding = true;
    this.apiService
      .getTableData('/Comman/dynamic', sdata)
      .subscribe({
        next: (data) => {
          console.log(data, 'Process Kill Response');

          if (data?.result?.a_proc_error == 0) {
            const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
            this.processMessage = row?.process_log_text;
            this.startPolling();

          } else {
            this.myloaderloding = false;
            this.errorMessage = data?.result?.[0]?.a_proc_error_message || 'Process kill failed.';
            this.toastService.showError(this.errorMessage);
          }
        },
        error: (error) => {
          this.myloaderloding = false;
          this.errorMessage = error.message || 'Failed to kill process.';
          this.toastService.showError(this.errorMessage);
        },
      });
  }



  downloadFile(refNumber: string) {
    this.router.navigate(['/home/reports'], {
      queryParams: { tab: 'downloads', ref: refNumber },
    });
  }

}
