import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-refnumbergenerator',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './refnumbergenerator.component.html',
  styleUrl: './refnumbergenerator.component.css'
})
export class RefnumbergeneratorComponent {




    tabs = ['Default', 'Hierachy'];
  activeTab = this.tabs[0];
  selectTab(tab: string) {
    this.activeTab = tab;

  }

}
