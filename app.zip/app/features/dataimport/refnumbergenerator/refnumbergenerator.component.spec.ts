import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RefnumbergeneratorComponent } from './refnumbergenerator.component';

describe('RefnumbergeneratorComponent', () => {
  let component: RefnumbergeneratorComponent;
  let fixture: ComponentFixture<RefnumbergeneratorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RefnumbergeneratorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RefnumbergeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
