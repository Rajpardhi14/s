import { Component, DestroyRef, EventEmitter, inject, Input, Output, SimpleChanges } from '@angular/core';
import { capitalizeAll, capitalizeEachWord, formatDatesend } from '../../../../shared/utils/passmatch';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { skip, Subject, Subscription } from 'rxjs';
import { RefreshdataService } from '../../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { CommonModule } from '@angular/common';
import { NodataComponent } from "../../../../shared/components/nodata/nodata.component";
import { TableskeletonComponent } from '../../../../shared/components/tableskeleton/tableskeleton.component';
import { GearboxComponent } from '../../../../shared/components/gearbox/gearbox.component';
import { BasicFilterComponent } from "../../../../shared/components/basic-filter/basic-filter.component";
import { AdvanceFilterComponent } from "../../../../shared/components/advance-filter/advance-filter.component";
import { DatepickerComponent } from "../../../../shared/components/datepicker/datepicker.component";
import { AuthService } from '../../../../core/services/auth/auth.service';
import { OutSideClickDirective } from '../../../../core/services/outclick/outside-click.directive';
@Component({
  selector: 'app-fixittable',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NodataComponent, TableskeletonComponent, GearboxComponent, BasicFilterComponent, AdvanceFilterComponent, OutSideClickDirective, DatepickerComponent],
  templateUrl: './fixittable.component.html',
  styleUrl: './fixittable.component.css'
})



export class FixittableComponent {
  capatilizeEachword = capitalizeEachWord
  @Input() isDrawerOpen: boolean = false;
  @Output() closeDrawer = new EventEmitter<void>();
  @Output() getErrorDb = new EventEmitter<void>();
  @Output() RefreshData = new EventEmitter<string>();

  @Input() iudtypeError: string = '';
  @Input() templateFilename: string = '';
  @Input() extensionfile: string = '';
  @Input() selectedValidationErrorCode: string = '';
  @Input() processStatusCode: string = '';
  @Input() refnumber: string = '';
  @Input() templateCode: string = '';
  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  @Output() rowIdEmitter = new EventEmitter<any>();
  matchingDependValue: any;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = "Yes";
  iudtype: string = 'ALL';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  isDeletePopupOpen = false;
  selectedIdsForDeletion: number = 0;
  selectedId: string | null = null;
  selectedRowDetails: any;
  capitalizeEachWord = capitalizeEachWord;

  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private authService: AuthService,
  ) {

  }


  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);


  ngOnChanges(changes: SimpleChanges): void {

  }
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.loadValidationRules();
    // this.dynamicUserData$
    //   .pipe(
    //     skip(1),
    //     takeUntilDestroyed(this.destroyRef)
    //   )
    //   .subscribe(dynamicData => {

    //     this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    //     this.offset = 0;

    //   });

    this.fetchData();
    this.fetchFilter();
    this.fetchGrandTotal();




    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

    this.refreshSubscription = this.refreshdata.onRefresh('Transaction').subscribe(() => {
      this.fetchData();
      this.fetchGrandTotal();

    });

  }










  buildMergeGroups() {
    this.headers?.forEach(header => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }
  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );

  }
  validationErrorFields: string[] = [];
  isDtPresent: any;
  values: any
  fixedCount: number = 0
  remainingCount: number = 0;
  errorColumname: string = ""
  fetchData() {


    this.filterClause = Array.isArray(this.filterClause) ? this.filterClause : [];
    const values = Array.isArray(this.selectedValue)
      ? this.selectedValue
      : [this.selectedValue];

    const newFilterClause = [
      {
        filter_col_field: 'validation_error_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.selectedValidationErrorCode,
      }

    ];
    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) {
        this.filterClause.push(nf);
      }
    });



    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }


    const sdata = this.apiService.generateSData(
      'get_gtdb_import_template',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtypeError,
        processStatusCode: this.processStatusCode,
        refnumber: this.refnumber,
        templateCode: this.templateCode,
        a_validation_error_code: this.selectedValidationErrorCode
      }
    );
    // const sdata = this.apiService.generateSData(
    //   'get_gtdb_import_template',
    //   finalFilterClause,
    //   this.limit,
    //   this.offset,
    //   this.currentPage,
    //   {
    //     FYYear: this.FYYear,
    //     iudtype: this.iudtypeError,
    //     processStatusCode: this.processStatusCode,
    //     refnumber: this.refnumber,
    //     templateCode: this.templateCode,
    //     a_validation_error_code: this.selectedValidationErrorCode,
    //   }
    // );
    this.apiService.getTableData('/dynamic-import/get_gtdb_import_template', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {

          const userData = data?.result?.get_gtdb_import_template;
          console.log(userData)
          if (userData?.get_gtdb_import_template_header) {
            this.validationErrorFields = (userData?.a_validation_error_code_field || []).map(
              (f: any) => f.column_name
            );

            // ✅ Step 2: Map headers — show even display=0 if it's an error field
            this.headers = userData.get_gtdb_import_template_header.map((header: any) => {
              const isErrorField = this.validationErrorFields.includes(header.field);
              return {
                ...header,
                visible: header.display === 1 || isErrorField, // force show if error field
              };
            });

            // this.headers = userData?.get_gtdb_import_template_header?.map(
            //   (header: any) => ({
            //     ...header,
            //     visible: header.display === 1,

            //   })
            // );
            // console.log(this.headers)

          }
          this.isDtPresent = this.headers
            .filter((header: any) => header.col_field_select)
            .map((header: any) => ({
              field: header.field,
              selectKey: header.col_field_select
            }));


          this.mergeGroups = {};
          this.fieldToMergeGroup = {};
          this.tableBody = userData?.get_gtdb_import_template_detail || [];
          this.fixedCount = this.tableBody.filter(
            (row: any) => row.status?.toLowerCase() === 'fixed' || row.status === 1
          ).length;

          this.remainingCount = this.tableBody.filter(
            (row: any) => row.status?.toLowerCase() !== 'fixed' && row.status !== 1
          ).length;
          this.validationErrorFields = (userData?.a_validation_error_code_field || []).map(
            (f: any) => f.column_name
          );

          console.log(this.validationErrorFields)



          // this.errorColumname= (userData?.a_validation_error_code_field || []).map(
          //   (f: any) => f.headerName
          // );

          this.buildMergeGroups()
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }



        } else {
          this.loading = false;

          this.toastService.showError(data?.result?.a_proc_error_message || 'Error fetching data');
        }
        this.loading = false;
      },
      error: (error) => {
        this.toastService.showError(error.message || 'Failed to fetch data.');
        this.loading = false;
        this.isLoadingMore = false;
      },
    });


  }

  myfilterfileds: any
  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchData();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }




  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_import_template',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,

      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        templateCode: this.templateCode,
        processStatusCode: this.processStatusCode,
      }

    );



    this.apiService.getFilterData('/dynamic-import/get_gtfb_import_template', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.get_gtfb_import_template?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.get_gtfb_import_template?.[1]?.advance_filter;

          this.initializeForm();
          this.advance_filter?.forEach((field: any) => {
            if (
              field.filter_col_external === 1 &&
              field.filter_col_type === 'filter-select'
            ) {
              const allOption = { value: 'ALL', label: 'All' };
              const exists = field.filter_col_depend_value?.some(
                (opt: any) => opt.value === 'ALL'
              );
              if (!exists) {
                field.filter_col_depend_value?.unshift(allOption);
              }
            }
          });

          const defaultField = this.advance_filter?.find(
            (field: any) =>
              field.filter_col_external === 1 &&
              (field.filter_col_type === 'filter-select' || field.filter_col_type === 'select')
          );

          const defaultOption = defaultField?.filter_col_depend_value?.find(
            (opt: any) => opt.value === 'ALL'
          );


          // Set default active tab
          this.defaultTabFilter = defaultOption;
          this.activeFilterTab = defaultOption?.value;


          if (defaultField && defaultOption) {
            const control = this.filterForm.get(defaultField.filter_col_field);
            if (control) {
              control.setValue(defaultOption.value, { emitEvent: false });
            }
          }

          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage = response.result?.[0].a_proc_error_message || "Please Check Endpoint";
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion




  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchData(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {

        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator;
        filterValue = controlValue.toString().trim();

        // if (filterValue && filterValue !== '') {
        //   filterClause.push({
        //     filter_col_field: filterConfig.filter_col_field,
        //     filter_col_depend_operator: operator,
        //     filter_col_value: filterValue.toUpperCase(),
        //     filter_col_field_alias: filterConfig.filter_col_field_alias,
        //   });
        // }
      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }

    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;
  }


  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return [];
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  // user grand total

  private fetchGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gtdg_import_template',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        templateCode: this.templateCode,
      }
    );

    this.apiService.getGrandTotal('/dynamic-import/get_gtdg_import_template', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {

          this.usergrandtotal =
            response?.result?.get_gtdg_import_template?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        this.showError('Something Went Wrong');
      },
    });
  }

  // Remove all filter label values
  clearAllFilters() {
    this.offset = 0;
    this.currentPage = 1;
    this.selectedFilters = [];
    this.filterClause = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (control) {
          control.setValue('');
        }
      });
    }
    this.filtercount = this.getSelectedFilterCount();
    this.fetchData();
    this.fetchGrandTotal();
  }





  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'LDC Data'
    );
  }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }


  statuskey: any;




  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  readonly MAX_EDITABLE_ROWS = 10;
  // Count selected rows
  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }





  // validationRules: { [key: string]: RegExp } = {

  //   deductee_panno: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
  //   email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  //   mobile: /^[6-9]\d{9}$/,
  //   aadhaar: /^\d{12}$/,
  //   amount: /^\d+(\.\d{1,2})?$/


  // };



  //    private getValidationRegx(): void {
  //   const storedData = sessionStorage.getItem('headermaster');
  //   if (!storedData) return;
  //   const parsedData = JSON.parse(storedData);
  //   const regx = parsedData?.get_gmdt_regex_validation || [];
  //   console.log(regx)

  // }

  validationRules: { [key: string]: RegExp } = {};



  private loadValidationRules(): void {
    const storedData = sessionStorage.getItem('headermaster');
    if (!storedData) return;

    const parsedData = JSON.parse(storedData);
    const regexList = parsedData?.get_gmdt_regex_validation || [];
    // Convert array into key-value pair object
    this.validationRules = regexList.reduce((acc: { [key: string]: RegExp }, item: any) => {
      if (item.label && item.value) {
        try {
          acc[item.label] = new RegExp(item.value);
        } catch (error) {
          console.error(`Invalid regex for field: ${item.label}`, error);
        }
      }
      return acc;
    }, {});

    console.log('Dynamic Validation Rules:', this.validationRules);
  }


  // Track invalid fields dynamically
  isFieldInvalid(row: any, field: string): boolean {
    const value = row[field];

    // Required check
    if (this.validationErrorFields.includes(field) && !value) return true;

    // Validation rules
    if (this.validationRules[field] && value && !this.validationRules[field].test(value)) return true;

    return false;
  }



  //   isFieldInvalid(row: any, field: string): boolean {
  //   const value = row[field];

  //   // 🔴 Case 1: Column name itself is in the error list → Always red
  //   if (this.validationErrorFields.includes(field)) return true;

  //   // ⚠️ Case 2: Has regex rule but fails
  //   if (this.validationRules[field] && value && !this.validationRules[field].test(value)) return true;

  //   // ✅ Everything okay
  //   return false;
  // }

  updateErrorCounts(): void {
    if (!this.tableBody?.length) return;

    this.fixedCount = this.tableBody.filter((row: any) => {
      return this.validationErrorFields.every((field: string) => {
        const value = row[field];
        if (!value || value.toString().trim() === '') return false;
        if (this.validationRules[field] && !this.validationRules[field].test(value)) return false;
        return true;
      });
    }).length;

    this.remainingCount = this.tableBody.length - this.fixedCount;
  }

  onFieldChange(row: any, field: string, event: any): void {
    // let value = event.target.value?.trim() ?? '';
    let value =
      typeof event === 'string' || typeof event === 'number'
        ? event
        : event?.target?.value ?? '';
    if (field === 'deductee_panno') {
      value = value.toUpperCase();
    }

    // if (this.isDateField(field)) {
    //   console.log(value)
    //   value = this.formatDate(value);
    //   console.log(value)
    // }

    row[field] = value;
    row.edited = true;

    this.updateErrorCounts();
  }


  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  // chekbox
  isAllSelected(): boolean {
    return this.paginatedList?.every((row: any) => row.selected);
  }
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }

  onClear() {
    this.paginatedList?.forEach((r: any) => r.selected = false);
  }

  getFirstBatchOfInvalidRows(): any[] {
    const invalidRows = this.tableBody.filter((row: any) =>
      this.validationErrorFields.some((field: string) => {
        const value = row[field];
        return !value || !this.validationRules[field]?.test(value);
      })
    );

    // Return only first MAX_EDITABLE_ROWS
    return invalidRows.slice(0, this.MAX_EDITABLE_ROWS);
  }



  // saveChanges(): void {
  //   const updatedFields: any[] = [];
  //   let hasError = false;

  //   this.paginatedList.forEach((row: any) => {
  //     this.validationErrorFields.forEach((field) => {
  //       let value = row[field];

  //       if (this.isDateField(field)) {
  //         value = this.formatDate(value);
  //       }

  //       if (!value) {
  //         // alert(`${field} is required.`);
  //         hasError = true;
  //         return;
  //       }

  //       // Apply validation rules if available
  //       if (this.validationRules[field] && !this.validationRules[field].test(value)) {
  //         console.log("eero")
  //         // alert(`Invalid value for ${field}: ${value}`);
  //         hasError = true;
  //         return;
  //       }

  //       updatedFields.push({
  //         rowid_seq: row.rowid_seq,
  //         col_name: field,
  //         col_value: value
  //       });
  //     });
  //   });

  //   if (hasError) return;

  //   const payload = {

  //     a_session_seqno: "",
  //     a_iud_seqno: "",
  //     a_is_pen_flag: "",
  //     a_login_type: "login_id",
  //     a_user_code: this.localUserData.user_code,
  //     a_user_level: this.localUserData.user_level,
  //     a_entity_code: this.localUserData.entity_code,
  //     a_client_code: this.localUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
  //     a_iud_type: "u",
  //     a_process_seqno: this.refnumber,
  //     a_proc_type: "get_tiud_import_template",
  //     import_template: updatedFields

  //   };

  //   this.apiService.miudApi('/dynamic-import/get_tiud_import_template', payload).subscribe({
  //     next: (res) => {
  //       const resultItem = res?.result?.[0];
  //       if (resultItem?.a_proc_error === 0) {
  //         this.closeDrawer.emit(); // now drawer will close
  //         this.showSuccess(resultItem?.a_proc_error_message || "Successfully Updated");
  //       } else {
  //         this.showError(resultItem?.a_proc_error_message || 'Something went wrong!');
  //       }
  //     },
  //     error: () => {
  //       this.showError('Something went wrong! Please try again later.');
  //     },
  //   });

  // }




  //   saveChanges(): void {
  //   const updatedFields: any[] = [];
  //   let hasError = false;

  //   // ✅ Allow only first 10 invalid rows to be processed
  //   const rowsToProcess = this.getFirstBatchOfInvalidRows();

  //   if (rowsToProcess.length === 0) {
  //     this.showSuccess("All records are valid and updated!");
  //     return;
  //   }

  //   if (rowsToProcess.length > this.MAX_EDITABLE_ROWS) {
  //     this.showError(`You can only fix ${this.MAX_EDITABLE_ROWS} rows at a time. Please correct these first.`);
  //     return;
  //   }

  //   rowsToProcess.forEach((row: any) => {
  //     this.validationErrorFields.forEach((field) => {
  //       let value = row[field];

  //       if (this.isDateField(field)) {
  //         value = this.formatDate(value);
  //       }

  //       if (!value) {
  //         hasError = true;
  //         return;
  //       }

  //       if (this.validationRules[field] && !this.validationRules[field].test(value)) {
  //         hasError = true;
  //         return;
  //       }

  //       updatedFields.push({
  //         rowid_seq: row.rowid_seq,
  //         col_name: field,
  //         col_value: value
  //       });
  //     });
  //   });

  //   if (hasError) return;

  //   const payload = {
  //     a_session_seqno: "",
  //     a_iud_seqno: "",
  //     a_is_pen_flag: "",
  //     a_login_type: "login_id",
  //     a_user_code: this.localUserData.user_code,
  //     a_user_level: this.localUserData.user_level,
  //     a_entity_code: this.localUserData.entity_code,
  //     a_client_code: this.localUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
  //     a_iud_type: "u",
  //     a_process_seqno: this.refnumber,
  //     a_proc_type: "get_tiud_import_template",
  //     import_template: updatedFields
  //   };

  //   this.apiService.miudApi('/dynamic-import/get_tiud_import_template', payload).subscribe({
  //     next: (res) => {
  //       const resultItem = res?.result?.[0];
  //       if (resultItem?.a_proc_error === 0) {
  //         this.closeDrawer.emit();
  //         this.showSuccess(resultItem?.a_proc_error_message || "Successfully updated 10 rows!");
  //       } else {
  //         this.showError(resultItem?.a_proc_error_message || 'Something went wrong!');
  //       }
  //     },
  //     error: () => {
  //       this.showError('Something went wrong! Please try again later.');
  //     },
  //   });
  // }



  // saveChanges(): void {
  //   const updatedFields: any[] = [];
  //   let hasError = false;

  //   // Get first 10 invalid rows
  //   const allInvalidRows = this.tableBody.filter((row: any) =>
  //     this.validationErrorFields.some((field: string) => {
  //       const value = row[field];
  //       return !value || !this.validationRules[field]?.test(value);
  //     })
  //   );

  //   // ✅ Allow only the first 10 invalid rows to be processed
  //   const rowsToProcess = allInvalidRows.slice(0, this.MAX_EDITABLE_ROWS);

  //   // 🔸 If no invalid rows remain, show success and exit
  //   if (rowsToProcess.length === 0) {
  //     this.showSuccess("All records are already valid!");
  //     return;
  //   }

  //   // 🔸 If total invalid > 10, warn but still allow saving current batch
  //   if (allInvalidRows.length > this.MAX_EDITABLE_ROWS) {
  //     this.showError(`You have more than ${this.MAX_EDITABLE_ROWS} invalid rows. Only the first ${this.MAX_EDITABLE_ROWS} are being processed now.`);
  //   }

  //   // ✅ Process whichever rows were actually edited (1–10)
  //   rowsToProcess.forEach((row: any) => {
  //     this.validationErrorFields.forEach((field) => {
  //       let value = row[field];

  //       if (this.isDateField(field)) {
  //         value = this.formatDate(value);
  //       }

  //       if (!value) {
  //         hasError = true;
  //         return;
  //       }

  //       if (this.validationRules[field] && !this.validationRules[field].test(value)) {
  //         hasError = true;
  //         return;
  //       }

  //       updatedFields.push({
  //         rowid_seq: row.rowid_seq,
  //         col_name: field,
  //         col_value: value
  //       });
  //     });
  //   });

  //   // 🔸 Prevent saving if any value is still invalid
  //   if (hasError) {
  //     this.showError("Please fix invalid fields before saving.");
  //     return;
  //   }

  //   // ✅ Prevent saving if no rows were actually changed
  //   if (updatedFields.length === 0) {
  //     this.showError("No changes detected to save.");
  //     return;
  //   }

  //   const payload = {
  //     a_session_seqno: "",
  //     a_iud_seqno: "",
  //     a_is_pen_flag: "",
  //     a_login_type: "login_id",
  //     a_user_code: this.localUserData.user_code,
  //     a_user_level: this.localUserData.user_level,
  //     a_entity_code: this.localUserData.entity_code,
  //     a_client_code: this.localUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
  //     a_iud_type: "u",
  //     a_process_seqno: this.refnumber,
  //     a_proc_type: "get_tiud_import_template",
  //     import_template: updatedFields
  //   };

  //   // ✅ API call allowed even if user fixes 1 or 2 rows
  //   this.apiService.miudApi('/dynamic-import/get_tiud_import_template', payload).subscribe({
  //     next: (res) => {
  //       const resultItem = res?.result?.[0];
  //       if (resultItem?.a_proc_error == 0) {
  //         this.closeDrawer.emit();
  //         this.showSuccess(resultItem?.a_proc_error_message || `Successfully updated ${updatedFields.length} row(s)!`);
  //       } else {
  //         this.showError(resultItem?.a_proc_error_message || 'Something went wrong!');
  //       }
  //     },
  //     error: () => {
  //       this.showError('Something went wrong! Please try again later.');
  //     },
  //   });
  // }

  myrowId: any

  isOpen: boolean = false;

  toggleDrawer() {
    this.isOpen = true;
  }
  closepDrawer() {
    this.isOpen = false
  }



  saveChanges(data: any): void {
    const updatedFields: any[] = [];
    const allRowIds: any[] = [];

    let validFixedRows = 0;

    // 🔹 Get only rows that user actually edited
    const editedRows = this.tableBody.filter((r: any) => r.edited);

    // 🔹 If user hasn’t edited anything
    if (editedRows.length === 0) {
      this.showError("No changes detected to save.");
      return;
    }

    // 🔹 Limit to max 10 edited rows
    const rowsToProcess = editedRows.slice(0, this.MAX_EDITABLE_ROWS);

    // 🔹 If more than 10 rows edited
    if (editedRows.length > this.MAX_EDITABLE_ROWS) {
      this.showError(`You have edited more than ${this.MAX_EDITABLE_ROWS} rows. Only the first ${this.MAX_EDITABLE_ROWS} will be processed.`);
    }

    rowsToProcess.forEach((row: any) => {
      let rowValid = true;
      const rowUpdates: any[] = [];

      this.validationErrorFields.forEach((field: string) => {
        if (!(field in row)) return;
        let value = row[field];

        if (this.isDateField(field)) {
          value = this.formatDate(value);
        }

        // Validate if rule exists
        if (this.validationRules[field] && !this.validationRules[field].test(value)) {
          rowValid = false;
        }

        // Skip empty values
        if (!value || value.toString().trim() === "") {
          rowValid = false;
        }
        const upperValue =
          typeof value === "string" ? value.toUpperCase().trim() : value;

        // Collect valid values only
        if (value && rowValid) {
          rowUpdates.push({
            rowid_seq: row.rowid_seq,
            col_name: field,
            col_value: upperValue
          });
          this.myrowId = row.rowid_seq;
        }

        // ✅ Collect all row IDs
        // if (!allRowIds.includes(row.rowid_seq)) {
        //   allRowIds.push(row.rowid_seq);
        // }

         if (!allRowIds.some(r => r.rowid_seq === row.rowid_seq)) {
           allRowIds.push({ rowid_seq: row.rowid_seq });
  }
      });


      if (rowValid) {
        validFixedRows++;
        updatedFields.push(...rowUpdates);
      }
    });


    if (validFixedRows === 0) {
      this.showError("Please fix at least one invalid field before saving.");
      return;
    }

    const payload = {
      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_user_code: this.localUserData.user_code,
      a_user_level: this.localUserData.user_level,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
      a_iud_type: "u",
      a_process_seqno: this.refnumber,
      a_proc_type: "get_tiud_import_template",
      import_template: updatedFields
    };


    // Save if at least 1 row validly fixed
    this.apiService.miudApi('/dynamic-import/get_tiud_import_template', payload).subscribe({
      next: (res) => {
        const resultItem = res?.result?.[0];
        if (resultItem?.a_proc_error == 0) {

          if (data == "Yes") {
               this.rowIdEmitter.emit(allRowIds);
              this.RefreshData.emit("Yes")
         
          } else {
            this.getErrorDb.emit();
          }
          this.closepDrawer();
          this.closeDrawer.emit();
          this.showSuccess(resultItem?.a_proc_error_message || `Successfully updated ${validFixedRows} row(s)!`);
        } else {
          this.showError(resultItem?.a_proc_error_message || 'Something went wrong!');
        }
      },
      error: () => {
        this.showError('Something went wrong! Please try again later.');
      },
    });
  }




  formatCurrency(value: any): string {
    if (value == null || value === '') return '';
    const numberValue = Number(value);
    if (isNaN(numberValue)) return value;

    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(numberValue);
  }

  isAmountField(field: string): boolean {
    // List all fields you want to format as currency
    const amountFields = ['challan_tds_amt', 'int_amt', 'other_amt', 'tran_amt', 'tds_amt', 'surcharge_amt', 'cess_amt', 'partybillamt', 'c20l_amt', 'c100l_amt', 'c300l_amt'];
    return amountFields.includes(field);
  }

  // isDateField(field: string): boolean {
  //   const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
  //   return dateFields.includes(field);
  // }

  isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date', 'certificate_valid_from', 'certificate_valid_upto'];
    return (
      dateFields.includes(field) ||
      field.toLowerCase().includes('date')
    );
  }

  capitalizeAll = capitalizeAll

  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

  getDateType(field: string): 'validFrom' | 'validTo' | 'po_end_date' | null {
    switch (field) {
      case 'challan_date': return 'validFrom';
      case 'tran_ref_date': return 'validTo';
      case 'tds_deduct_date': return 'po_end_date';
      default: return null;
    }
  }
  isDropdownField(field: string): boolean {
    return this.isDtPresent?.some((dt: any) => dt.field === field);
  }

  getDropdownField(field: string) {
    return this.mydrodownlistdata?.find((drop: any) => drop.field === field);
  }
  onDateChange(row: any, field: string, event: any) {
    const value = event.target.value;
    row[field] = this.formatDate(value);
    this.updateErrorCounts();
  }

  shouldCapitalize(field: string): boolean {
    const lowerField = field.toLowerCase();
    return !(lowerField.includes('pan') || lowerField.includes('tan'));
  }





  dropdownOptions: { [key: string]: any[] } = {};
  mydrodownlistdata: any
  getData(): void {
    const filterValues = this.isDtPresent?.map((col: any) => `##${col.selectKey.replace('gmdt', 'mmtx')}##`).join(',');


    // const filterValues = this.isDtPresent.map((col:any) => `##${col.selectKey}##`).join(',');
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: '',
        a_iud_seqno: '',
        a_is_pen_flag: '',
        a_login_type: 'login_id',
        a_module_type_code: this.localUserData?.default_module_type_code,
        a_sub_module_type_code: 'R',
        a_entity_code: this.localUserData?.entity_code,
        a_client_code: this.localUserData?.client_code,
        a_acc_year: this.localUserData?.default_acc_year,
        a_quarter_no: this.localUserData?.default_quarter_no,
        a_tran_month: this.localUserData?.default_tran_month,
        a_tran_from_date: this.localUserData?.default_from_date,
        a_tran_to_date: this.localUserData?.default_to_date,
        a_tds_type_code: this.localUserData?.default_tds_type_code,
        a_first_level_client_code: this.localUserData?.first_level_client_code,
        a_validation_client_level: this.localUserData.client_code_level,
        a_iud_type: '',
        a_db_total_records: '10',
        a_pagination_count: '0',
        a_proc_type: 'get_mmtx_multi_mast',
        a_filter_clause: [
          {
            filter_col_field: 'gd_proc_name',
            filter_col_depend_operator: 'wc',
            filter_col_value: `and gd_proc_name in (${filterValues})`,
            filter_col_field_alias: 'a.'
          }
        ]
      })
    };

    this.authService.fetchMultiMastData(requestBody).subscribe({
      next: (response: any) => {
        const multiMast = response?.body?.result?.get_mmtx_multi_mast;
        console.log(response)
        this.isDtPresent.forEach((item: any) => {
          const key = item.selectKey;
          this.dropdownOptions[item.field] = multiMast[key] || [];
        });

      },
      error: (err) => console.error(err)
    });
  }


  getDropdownLabel(field: string, value: string): string {
    const option = this.dropdownOptions[field]?.find((opt: any) => opt.value === value);
    return option ? option.label : '';
  }

  // Handle selecting an option
  selectDropdownOption(row: any, field: string, option: any): void {
    row[field] = option.value;
    row[field + '_open'] = false;
    this.updateErrorCounts();
  }

  // Clear selected option
  clearDropdownSelection(row: any, field: string, event: Event): void {
    event.stopPropagation();
    row[field] = '';
    row[field + '_search'] = '';
    row[field + '_filteredOptions'] = this.dropdownOptions[field];
    this.updateErrorCounts();
  }

  // Filter options as user types
  filterDropdownOptions(field: string, row: any): void {
    const searchTerm = (row[field + '_search'] || '').toLowerCase();
    row[field + '_filteredOptions'] = this.dropdownOptions[field].filter((opt: any) =>
      opt.label.toLowerCase().includes(searchTerm)
    );
  }


  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }





}
