import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FixittableComponent } from './fixittable.component';

describe('FixittableComponent', () => {
  let component: FixittableComponent;
  let fixture: ComponentFixture<FixittableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FixittableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FixittableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
