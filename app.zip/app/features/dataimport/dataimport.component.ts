import { CommonModule, Location } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FiledataimportComponent } from './filedataimport/filedataimport.component';
import { FixittableComponent } from "./validationtable/fixittable/fixittable.component";
import { DataallocationComponent } from "./dataallocation/dataallocation.component";
import { ErrorprocessingComponent } from "./dataprocessing/errorprocessing/errorprocessing.component";
import { FuvgenerationComponent } from "./fuvgeneration/fuvgeneration.component";
import { UserdataService } from '../../core/services/userdata/userdata.service';
import { RefnumbergeneratorComponent } from "./refnumbergenerator/refnumbergenerator.component";

@Component({

  selector: 'app-dataimport',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, FiledataimportComponent, DataallocationComponent, ErrorprocessingComponent, FuvgenerationComponent, RefnumbergeneratorComponent],
  templateUrl: './dataimport.component.html',
  styleUrl: './dataimport.component.css'
})
export class DataimportComponent {
  queryData: any;
  userData: any;
  assesse_singleDetail: any;
  baseQuery: any;
  dynaUserData: any

  submoduleType: any
  constructor(private route: ActivatedRoute, private router: Router, private location: Location,
    private userlocaldataService: UserdataService
  ) { }

  ngOnInit(): void {
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.submoduleType = this.dynaUserData.default_sub_module_type_code

  }



  handleOpenFuv() {
    this.selectedTabPurchases = 'FUV Generation';
  }
  selectedTabPurchases: string = 'Data Import';
  selectTabAllPurchases(tab: string) {
    this.selectedTabPurchases = tab;
  }

  formatDOB(dobStr: any): string {
    let str = dobStr?.toString?.();
    if (!str) return '';

    // Pad with leading zero if 7 digits (e.g., 8062017 → 08062017)
    if (str.length === 7) {
      str = '0' + str;
    }

    if (str.length !== 8) return '';

    const day = str.substring(0, 2);
    const month = str.substring(2, 4);
    const year = str.substring(4, 8);

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const monthIndex = parseInt(month, 10) - 1;
    if (monthIndex < 0 || monthIndex > 11) return '';

    return `${day} ${months[monthIndex]} ${year}`;
  }

  backtoClient() {
    // this.router.navigate(["/twentysixASdetails"], { queryParams: { data: this.queryData.param } });
    this.location.back();
  }







}

