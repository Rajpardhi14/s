import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataallocationComponent } from './dataallocation.component';

describe('DataallocationComponent', () => {
  let component: DataallocationComponent;
  let fixture: ComponentFixture<DataallocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DataallocationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DataallocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
