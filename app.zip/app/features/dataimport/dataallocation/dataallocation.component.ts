import { Component } from '@angular/core';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { MapAllocationComponent } from "../../map-allocation/map-allocation.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dataallocation',
  standalone: true,
  imports: [MapAllocationComponent, CommonModule],
  templateUrl: './dataallocation.component.html',
  styleUrl: './dataallocation.component.css'
})
export class DataallocationComponent {
  loading: boolean = false;
   FYYear:string= "Yes";
  constructor(private apiService: ApiserviceService, private userlocaldataService: UserdataService, private toastService: ToastService) {

  }

  allocationFlag: string = '';
  localUserData: any
  errorMessage = '';
  challanData: any;

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.fetchUsers();
   


  }



  fetchUsers() {
    this.loading = true;

    const sdata = this.apiService.generateSData(
      'get_gtdb_import_template_challan_statitics',
      this.localUserData,
      null,
      0,
      0,
      null,
       {
        FYYear: this.FYYear,
      }
    );

    this.apiService.getTableData('/Transaction/get_gtdb_import_template_challan_statitics', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data.result?.get_gtdb_import_template_challan_statitics;
          // console.log(userData);

          // Assign first record to challanData for template binding
          this.challanData = userData?.get_gtdb_import_template_challan_statitics_rec?.[0] || null;
          console.log(this.challanData)
        } else {
          this.errorMessage = data.result?.a_proc_error_message || 'Unknown error';
          this.showError(this.errorMessage);
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
      }
    });
  }

  hasChallanData(): boolean {
  if (!this.challanData) return false;

  const values = Object.values(this.challanData);
  // return true if any field has a non-null, non-zero, or truthy value
  return values.some(v => v !== null && v !== undefined && v !== 0);
}



  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }
  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }



  isMapAllocation: boolean = false;

  openMapalloc() {
    this.isMapAllocation = true;
     this.allocationFlag = 'dataAllocationFlag';
    console.log("click")
  }

  closeMapAllocation() {
    this.isMapAllocation = !this.isMapAllocation

  }

  refreshData() {
    this.fetchUsers(); 
  }


  


   
  
  


}


