import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Output,
} from '@angular/core';
import { FormBuilder, FormsModule } from '@angular/forms';
import { RefreshdataService } from '../../../../core/services/refreshdata/refreshdata.service';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import {
  catchError,
  interval,
  Observable,
  of,
  skip,
  switchMap,
  takeWhile,
  tap,
} from 'rxjs';
import { AuthService } from '../../../../core/services/auth/auth.service';
import { FixittableComponent } from '../../validationtable/fixittable/fixittable.component';
import { ValidationfixComponent } from './validationtable/validationfix/validationfix.component';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { OutSideClickDirective } from '../../../../core/services/outclick/outside-click.directive';
import { FuvgenerationComponent } from '../../fuvgeneration/fuvgeneration.component';
import { getApiName } from '../../../../shared/utils/passmatch';
import { basename } from 'path';
import { AlertpoupComponent } from '../../../../shared/components/alertpoup/alertpoup.component';

@Component({
  selector: 'app-errorprocessing',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ValidationfixComponent,
    OutSideClickDirective,
    FuvgenerationComponent,
    AlertpoupComponent,
  ],
  templateUrl: './errorprocessing.component.html',
  styleUrl: './errorprocessing.component.css',
})
export class ErrorprocessingComponent {
  @Output() openFuv = new EventEmitter<void>();
  processMessage: string = '';
  savedCodeLevel: any;
  selectedProcess: string = 'PRO1';
  client_level: string = 'Yesss';
  loading: boolean = false;
  headers: any[] = [];
  tableBody: any[] = [];
  steps: number = 0;
  localUserData: any;
  dynaUserData: any;
  FYYear: string = 'Yes';
  errorMessage = '';
  refnumber: any;
  filterClause: any;
  selectedValidationErrorCode: any;
  tableHeaders: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  tabs = ['Process Data Review', 'Data Validation', 'Reports'];
  activeTab = this.tabs[0];
  nestedTabs = ['Deductor', 'Chalan', 'Transactions'];
  submoduleType: string = '';
  activeNestedTab = this.nestedTabs[0];
  tabCounts: { [key: string]: number } = {
    Deductor: 0,
    Chalan: 0,
    Transactions: 0,
  };

  selectedCodeLevelLabel: string = '';
  selectedCodeLevelValue: string = '';
  initializingCodeLevel = false;
  basename: any;
  constructor(
    private refreshdata: RefreshdataService,

    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private authservice: AuthService
  ) {}

  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.submoduleType = this.dynaUserData.default_sub_module_type_code;
    this.getProceseqs();

    this.dynamicUserData$
      .pipe(skip(1), takeUntilDestroyed(this.destroyRef))
      .subscribe((dynamicData) => {
        this.dynaUserData =
          this.userlocaldataService.getAllDynamicUserData() || {};
        this.getProceseqs();
      });
  }

  disableConsoleLogs() {
    console.log = function () {};
    console.error = function () {};
    console.warn = function () {};
    console.info = function () {};
    console.debug = function () {};
    console.clear();
  }

  firstValidationSkipped: boolean = false;
  selectTab(tab: string) {
    this.activeTab = tab;

    if (tab === 'Data Validation') {
      this.activeNestedTab = this.nestedTabs[0];
    }
  }
  selectNestedTab(subTab: string) {
    this.activeNestedTab = subTab;
  }
  openDropdown: string | null = null;
  searchText = '';
  codeLevelOptions: { label: string; value: string }[] = [];

  selectedCodeLevel: any = { label: '', value: '' };

  toggleDropdown(field: string) {
    this.openDropdown = this.openDropdown === field ? null : field;
  }

  get activeTabIndex(): number {
    return this.tabs.indexOf(this.activeTab);
  }
  selectOption(option: any) {
    this.selectedCodeLevel = option;
    this.selectedCodeLevelLabel = option?.label;
    this.selectedCodeLevelValue = option?.value;
    console.log(this.selectedCodeLevelValue);
    this.openDropdown = null;
    if (!this.initializingCodeLevel) {
      this.getProceseqs();
    }
  }
  filteredOptions() {
    const query = this.searchText.toLowerCase();
    return this.codeLevelOptions.filter((opt) =>
      opt.label.toLowerCase().includes(query)
    );
  }
  reviewData: any;
  a_process_level: number = 1;
  statusCode: any;
  getProcessLog() {
    this.loading = true;
    const apiName = getApiName(
      'PROC_TDS_TRAN_LOAD_ERROR',
      this.dynaUserData?.default_sub_module_type_code
    );

    // Ensure filterClause is an array
    this.filterClause = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
    const newFilterClause = [
      {
        filter_col_field: 'process_type',
        filter_col_depend_operator: '=',
        filter_col_value: apiName,
      },
    ];

    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) this.filterClause.push(nf);
    });

    const sdata = this.apiService.generateSData(
      'get_gtdb_process_log_head',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        a_process_level: 1,
        processStatusCode: 'ZA',
        client_level: this.client_level,

        client_code_level: this.selectedCodeLevelValue,
      }
    );

    this.apiService
      .getTableData('/EPV/get_gtdb_process_log_head', sdata)
      .subscribe({
        next: (data: any) => {
          this.loading = false;
          if (data?.result?.a_proc_error == 1) {
            const userData = data.result.get_gtdb_process_log_head;
            console.log(userData);

            if (userData?.get_gtdb_process_log_head_header) {
              // Map headers dynamically
              this.headers = userData.get_gtdb_process_log_head_header.map(
                (h: any) => ({
                  field: h.field,
                  label: h.headerName,
                  visible: h.display === 1,
                })
              );
            }

            this.tableBody = userData.get_gtdb_process_log_head_detail || [];
          } else {
            this.errorMessage = data.result[0]?.a_proc_error_message;
            this.showError(this.errorMessage);
          }
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.message || 'Failed to fetch process log.';
          this.showError(this.errorMessage);
        },
      });
  }
  iudtype: string = 'proc_tds_tran_load_error';
  stats: { label: string; value: string | number }[] = [];
  isStaticalInfo: any;

  // regular/15gh
  getStatics() {
    const apiName = getApiName(
      'get_gtdb_tran_load_error_statitics_challan',
      this.dynaUserData?.default_sub_module_type_code
    );
    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
        a_process_level: 1,
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        console.log(data);
        this.loading = false;
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.[apiName];
          console.log(userData);
          this.isStaticalInfo = userData;

          const challanData = userData?.challan?.childs || [];
          this.stats = challanData.map((item: any) => {
            const head = item?.head?.val || '';
            const val = item?.headVal?.val;
            const isNumber = item?.headVal?.col_field_type === 'N';
            const decimalPlaces = item?.headVal?.decimalrate ?? 0;

            let formattedValue: string | number = '--';

            if (val !== null && val !== undefined) {
              if (isNumber && typeof val === 'number') {
                formattedValue = val.toLocaleString('en-IN', {
                  minimumFractionDigits: decimalPlaces,
                  maximumFractionDigits: decimalPlaces,
                });
              } else {
                formattedValue = val;
              }
            }

            return {
              label: head,
              value: formattedValue,
            };
          });
        } else {
          this.errorMessage = data.result[0]?.a_proc_error_message;
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.loading = false;
        this.errorMessage = error.message || 'Failed to fetch statistics.';
        this.showError(this.errorMessage);
      },
    });
  }
  mainheadeing: string = '';
  getStaticsDeducti() {
    this.loading = true;
    const apiName = getApiName(
      'get_gtdb_tran_load_error_statitics_deductee',
      this.dynaUserData?.default_sub_module_type_code
    );
    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
        a_process_level: 1,
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data: any) => {
        this.loading = false;
        console.log(data);
        if (data?.result?.a_proc_error == 0) {
          const stats = data.result?.[apiName];
          this.tableHeaders = stats.Subhead.map((h: any) => h.label);
          //  console.log(stats.statsTitle.main)
          this.mainheadeing = stats.statsTitle.main;
          this.reviewData = stats.childs.map((item: any) => ({
            label: item.head.val,
            count: item.headVal.val,
            redirect: item.headVal.redirect,
            filter: item.headVal.filter,
          }));
        } else {
          this.errorMessage = data.result[0]?.a_proc_error_message;
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.loading = false;
        this.errorMessage = error.message || 'Failed to fetch statistics.';
        this.showError(this.errorMessage);
      },
    });
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  StepCall(action: 'back' | 'start') {
    if (action == 'back') {
      this.activeTab = 'Process Data Review';
      this.steps = 1;
      this.firstValidationSkipped = true;
      this.getStaticsDeducti();
    } else if (action == 'start') {
      this.firstValidationSkipped = false;
      this.activeTab = 'Process Data Review';
      this.steps = 1;
      this.getStaticsDeducti();
    }

    // localStorage.setItem('steps', this.steps.toString());

    // if (this.isStaticalInfo) {
    //   this.firstValidationSkipped = true;
    //   this.getStaticsDeducti();
    // } else {
    //   // this.firstValidationSkipped = false;
    //   // this.getStatics();
    //   // this.getStaticsDeducti();
    // }
  }

  selectedRow: any = null;
  isDrawerOpenFix: boolean = false;
  openFixItDrawer(row: any) {
    this.selectedRow = row;
    this.isDrawerOpenFix = true;
  }

  redirectTo(route: string, filter: any) {
    console.log('Redirect to:', route, filter);
  }

  validationIud: string = 'PROCESS_INSERT';
  refnumbertwo: any;
  // Step 1
  validationStart(): Promise<any> {
    this.loading = true;
    const apiName = getApiName(
      'proc_tds_tran_load_error',
      this.dynaUserData?.default_sub_module_type_code
    );
    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.validationIud,
        a_process_level: 1,
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );

    return this.apiService
      .getTableData('/Comman/dynamic', sdata)
      .toPromise()
      .then((data: any) => {
        this.loading = false;
        if (data?.result?.a_proc_error == 0) {
          console.log(data);

          const row = data?.result?.[apiName]?.[0];
          this.refnumbertwo = row?.process_seqno;
          this.refnumber = row?.process_seqno;
          this.processMessage = row?.process_log_text;
          this.savedCodeLevel = row?.validation_client_level;

          return data.result.proc_tds_tran_load_error;
        } else {
          throw new Error(
            data.result[0]?.a_proc_error_message || 'Validation start  failed'
          );
        }
      });
  }
  // Step 2: Get Status
  getStatuss(iudtype: string = 'proc_tds_tran_load_error'): Promise<any> {
    const apiName = getApiName(
      'proc_tds_tran_load_error',
      this.dynaUserData?.default_sub_module_type_code
    );
    const sdata = this.apiService.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: apiName,
        a_process_level: 1,
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );

    return this.apiService
      .getTableData(
        '/dynamic-import/proc_utilf_get_process_seqno_status',
        sdata
      )
      .toPromise()
      .then((data: any) => {
        console.log(data, 'Process Sataus');
        if (data?.result?.a_proc_error == 0) {
          const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
          this.refnumbertwo = row?.process_seqno;
          this.refnumber = row?.process_seqno;
          this.statusCode = row?.process_status_code;
          this.processMessage = row?.process_log_text;

          return row;
        } else {
          throw new Error(
            data.result[0]?.a_proc_error_message || 'Failed to get status'
          );
        }
      });
  }
  // Step 3
  validationStartTwo(): Promise<any> {
    this.loading = true;
    const apiName = getApiName(
      'proc_tds_tran_load_error',
      this.dynaUserData?.default_sub_module_type_code
    );
    const subType = this.dynaUserData?.default_sub_module_type_code;
    this.basename =
      !subType || subType === 'R'
        ? '/EPV/'
        : subType === 'G'
        ? '/VALIDATION15GH/'
        : subType === 'C'
        ? '/C15GH/'
        : '/EPV/';
    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,

      {
        FYYear: this.FYYear,
        a_process_level: 1,
        seqnumber: this.refnumbertwo,
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );
    const fullPath = `${this.basename}${apiName}`;
    return this.apiService
      .getTableData(fullPath, sdata)
      .toPromise()
      .then((data: any) => {
        this.loading = false;
        if (data?.status === 0) {
          // console.log('Validation started:', data.status);
          return data;
        } else {
          throw new Error(data?.status || 'Validation start failed');
        }
      })
      .catch((err) => {
        this.loading = false;
        console.error('Validation start error:', err);
        throw err;
      });
  }

  pollForStatus(isKilledProcess = false): Promise<any> {
    this.attemptCount = 0;
    this.myloaderloding = true;
    return new Promise((resolve, reject) => {
      const subscription = interval(5000)
        .pipe(
          takeUntilDestroyed(this.destroyRef),
          switchMap(() => {
            this.attemptCount++;

            const apiName = getApiName(
              'proc_tds_tran_load_error',
              this.dynaUserData?.default_sub_module_type_code
            );

            const sdata = this.apiService.generateSData(
              'proc_utilf_get_process_seqno_status',
              this.localUserData,
              this.filterClause,
              this.limit,
              this.offset,
              this.currentPage,
              {
                FYYear: this.FYYear,
                iudtype: apiName,
                client_level: this.client_level,
                client_code_level: this.selectedCodeLevelValue,
              }
            );

            return this.apiService
              .getTableData(
                '/dynamic-import/proc_utilf_get_process_seqno_status',
                sdata
              )
              .pipe(
                catchError((err) => {
                  console.error('❌ API Error:', err);
                  return of(null);
                })
              );
          }),
          takeWhile((data: any) => {
            if (!data || !data.result) {
              console.warn('⚠️ Null API response – stopping polling');
              this.myloaderloding = false;
              subscription.unsubscribe();
              reject('No response from server');
              return false;
            }

            const row = data.result.proc_utilf_get_process_seqno_status?.[0];
            const status = row?.process_status_code ?? null;
            const lastChar = status?.slice(-1);

            this.processMessage = row?.process_log_text;
            console.log(`Attempt ${this.attemptCount}: Status = ${status}`);

            if (
              data.result.proc_utilf_get_process_seqno_status == null ||
              lastChar === 'K'
            ) {
              console.warn(
                '⚠️ Process killed (null/ZK detected) – stopping polling'
              );
              this.myloaderloding = false;
              subscription.unsubscribe();
              resolve('Cancelled');
              return false;
            }

            let continuePolling = true;

            // 🧭 Polling logic
            if (isKilledProcess) {
              continuePolling =
                this.attemptCount < this.maxAttempts &&
                status !== null &&
                lastChar !== 'K';
            } else {
              continuePolling =
                this.attemptCount < this.maxAttempts &&
                lastChar !== 'B' &&
                lastChar !== 'C';
            }

            if (!continuePolling) {
              this.myloaderloding = false;
              subscription.unsubscribe();

              if (isKilledProcess) {
                if (status === null || lastChar === 'K') {
                  console.log('⚠️ Process was cancelled');
                  resolve('Cancelled');
                } else {
                  reject(`Unexpected status after kill: ${status}`);
                }
              } else {
                if (lastChar === 'B' || lastChar === 'C') {
                  console.log(`✅ Process completed with status: ${status}`);
                  resolve(status);
                } else {
                  reject(`Process failed (status: ${status})`);
                }
              }
            }

            return continuePolling;
          })
        )
        .subscribe();
    });
  }

  // Step 5: Error Summary
  attemptCount: number = 0;
  maxAttempts: number = 100;
  errorTypes: any;
  isError: any;
  structuralCount: number = 0;
  validationCount: number = 0;
  deducteeErrors: any[] = [];
  chalanErrors: any[] = [];
  transactionErrors: any[] = [];

  errorSummary(): Promise<any> {
    this.loading = true;
    const apiName = getApiName(
      'get_gtdb_tran_load_error_type',
      this.dynaUserData?.default_sub_module_type_code
    );

    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber || '',
        client_level: this.client_level,
        client_code_level: this.selectedCodeLevelValue,
      }
    );

    return this.apiService
      .getTableData('/Comman/dynamic', sdata)
      .toPromise()
      .then((data: any) => {
        console.log(data);
        this.loading = false;
        if (data?.result?.a_proc_error === 0) {
          const errorsumm = data.result?.[apiName];
          this.isError = errorsumm?.[`${apiName}_detail`] || [];
          console.log(this.isError);
          const details = errorsumm?.[`${apiName}_detail`] || [];
          console.log(details);
          this.tabCounts = { Deductor: 0, Chalan: 0, Transactions: 0 };
          this.errorTypes = [];
          let structuralCount = 0;
          let validationCount = 0;
          const tabMapping: Record<string, string> = {
            DSE: 'Deductor',
            DVE: 'Deductor',
            CSE: 'Chalan',
            CVE: 'Chalan',
            TSE: 'Transactions',
            TVE: 'Transactions',
          };

          details.forEach((err: any) => {
            const code = err.validation_error_type_code;
            const totalRec = Number(err.total_rec) || 0;

            const mappedTab = tabMapping[code];

            if (mappedTab) {
              this.tabCounts[mappedTab] += totalRec;
            }
            if (!this.errorTypes.includes(code)) {
              this.errorTypes.push(code);
            }

            if (code.endsWith('SE')) {
              structuralCount += totalRec;
            } else if (code.endsWith('VE')) {
              validationCount += totalRec;
            }
          });

          const maxCountTab = Object.entries(this.tabCounts).reduce((a, b) =>
            b[1] > a[1] ? b : a
          )[0];
          this.activeNestedTab = maxCountTab;
          this.structuralCount = structuralCount;
          this.validationCount = validationCount;
          console.log(this.structuralCount);

          // this.errorCode();

          if (this.errorTypes.length > 0) {
            this.errorCode();
          }

          return data.result.get_gtdb_tran_load_error_type;
        } else {
          this.loading = false;
          throw new Error(
            data.result[0]?.a_proc_error_message || 'Error summary failed'
          );
        }
      });
  }
  errorCodeData: any;
  errorReviewInfo: any;
  errorCode() {
    this.loading = true;
    const apiName = getApiName(
      'get_gtdb_tran_load_error_code',
      this.dynaUserData?.default_sub_module_type_code
    );

    const filterValues = this.errorTypes.join(',');

    const nefilterClause = [
      {
        filter_col_field: 'validation_error_type_code',
        filter_col_depend_operator: 'in',
        filter_col_value: filterValues,
        filter_col_alias: 'a.',
      },
    ];

    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      nefilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: apiName,
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        this.loading = false;
        console.log(data, 'Error DB Data this run');

        if (data?.result?.a_proc_error == 0) {
          const baseKey = apiName;
          const detailKey = `${apiName}_detail`;
          const row = data?.result?.[baseKey]?.[0];
          const details: any[] = data?.result?.[baseKey]?.[detailKey] || [];
          this.errorCodeData = details;
          this.deducteeErrors = [];
          this.chalanErrors = [];
          this.transactionErrors = [];
          details.forEach((err) => {
            const code = err.validation_error_type_code;
            if (code.startsWith('D') || code.startsWith('Z'))
              this.deducteeErrors.push(err);
            else if (code.startsWith('C') || code.startsWith('A'))
              this.chalanErrors.push(err);
            else if (code.startsWith('T')) this.transactionErrors.push(err);
          });
          this.errorReviewInfo = details.map((err) => ({
            validation_error_review_required:
              err.validation_error_review_required,
            validation_error_reviewed: err.validation_error_reviewed,
          }));

          console.log(this.errorReviewInfo);
        } else {
          this.errorMessage = data.result[0].a_proc_error_message;
          this.toastService.showError(this.errorMessage);
          this.loading = false;
        }
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch Data.';
        this.toastService.showError(this.errorMessage);
        this.loading = false;
      },
    });
  }
  updateErrorCodeDataForActiveTab() {
    if (this.activeNestedTab === 'Deductor')
      this.errorCodeData = this.deducteeErrors;
    else if (this.activeNestedTab === 'Chalan')
      this.errorCodeData = this.chalanErrors;
    else if (this.activeNestedTab === 'Transactions')
      this.errorCodeData = this.transactionErrors;
  }

  loadingStatics: boolean = false;

  // 15gh/regular
  // getProceseqs() {
  //   this.loadingStatics = true;

  //   const apiName = getApiName(
  //     'proc_tds_tran_load_error',
  //     this.dynaUserData?.default_sub_module_type_code
  //   );
  //   const sdata = this.apiService.generateSData(
  //     'proc_utilf_get_process_seqno_status',
  //     this.localUserData,
  //     this.filterClause,
  //     this.limit,
  //     this.offset,
  //     this.currentPage,
  //     {
  //       FYYear: this.FYYear,
  //       iudtype: apiName,
  //     }
  //   );

  //   this.apiService
  //     .getTableData(
  //       '/dynamic-import/proc_utilf_get_process_seqno_status',
  //       sdata
  //     )
  //     .subscribe({
  //       next: (data) => {
  //         console.log(data, 'process status');
  //         if (data?.result?.a_proc_error == 0) {
  //           const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
  //           this.refnumber = row?.process_seqno;
  //           this.refnumbertwo = row?.process_seqno;
  //           const statusCode = row?.process_status_code;
  //           this.processMessage = row?.process_log_text;
  //           this.savedCodeLevel = row?.validation_client_level;
  //           this.getclientypeCodeData();
  //           // console.log(this.savedCodeLevel)

  //           const lastChar = statusCode?.slice(-1);

  //           // if (lastChar === 'A') {
  //           //   this.activeTab = 'Data Validation';

  //           //   this.pollForStatus();
  //           //   return;
  //           // }

  //           switch (lastChar) {
  //             case 'C':
  //             case 'I':
  //             case 'H':
  //             case 'G':
  //               this.activeTab = 'Data Validation';
  //               this.steps = 1;
  //               this.errorSummary();
  //               break;

  //             case 'B':
  //             case 'E':
  //               this.activeTab = 'Data Validation';
  //               this.steps = 1;
  //               break;

  //             case undefined:
  //             case null:
  //             case 'K':
  //               this.activeTab = 'Process Data Review';
  //               this.steps = 0;
  //               this.getStatics();
  //               this.getProcessLog();
  //               break;
  //           }
  //         } else {
  //           this.errorMessage = data.result[0].a_proc_error_message;
  //           this.toastService.showError(this.errorMessage);
  //         }
  //       },
  //       error: (error) => {
  //         this.errorMessage = error.message || 'Failed to fetch Data.';
  //         this.toastService.showError(this.errorMessage);
  //       },
  //       complete: () => {
  //         this.loadingStatics = false;
  //       },
  //     });
  // }


  getProceseqs() {
  this.loadingStatics = true;

  const apiName = getApiName(
    'proc_tds_tran_load_error',
    this.dynaUserData?.default_sub_module_type_code
  );

  const sdata = this.apiService.generateSData(
    'proc_utilf_get_process_seqno_status',
    this.localUserData,
    this.filterClause,
    this.limit,
    this.offset,
    this.currentPage,
    {
      FYYear: this.FYYear,
      iudtype: apiName,
    }
  );

  this.apiService
    .getTableData(
      '/dynamic-import/proc_utilf_get_process_seqno_status',
      sdata
    )
    .subscribe({
      next: (data) => {
        console.log(data, 'process status');

        if (data?.result?.a_proc_error == 0) {
          const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
          this.refnumber = row?.process_seqno;
          this.refnumbertwo = row?.process_seqno;

          const statusCode = row?.process_status_code;
          this.processMessage = row?.process_log_text;
          this.savedCodeLevel = row?.validation_client_level;
          this.getclientypeCodeData();

          const lastChar = statusCode?.slice(-1);

          // 🌀 START POLLING IF STATUS = A
          if (lastChar === 'A') {
            this.activeTab = 'Data Validation';
            this.steps = 1;
            this.startPollingStatus()
              .then((result) => {
                console.log('Polling finished:', result);
                this.getProceseqs(); // refresh UI after completion
              })
              .catch((err) => {
                console.error('Polling error:', err);
                this.toastService.showError(err);
              });
            return;
          }

          // 🛑 STOP CONDITIONS
          switch (lastChar) {
            case 'C':
            case 'I':
            case 'H':
            case 'G':
              this.activeTab = 'Data Validation';
              this.steps = 1;
              this.errorSummary();
              break;

            case 'B':
            case 'E':
              this.activeTab = 'Data Validation';
              this.steps = 1;
              break;

            case undefined:
            case null:
            case 'K':
              this.activeTab = 'Process Data Review';
              this.steps = 0;
              this.getStatics();
              this.getProcessLog();
              break;
          }
        } else {
          this.errorMessage = data.result[0].a_proc_error_message;
          this.toastService.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch Data.';
        this.toastService.showError(this.errorMessage);
      },
      complete: () => {
        this.loadingStatics = false;
      },
    });
}

  myloaderloding: boolean = false;
  async startProcessFlow(flag?: string) {
    this.myloaderloding = true;

    try {
      if (flag || this.firstValidationSkipped) {
        this.firstValidationSkipped = true;
      } else {
        console.log('Step 1: Validation Start');
        await this.validationStart();
        this.firstValidationSkipped = true;
      }

      console.log('Step 2: Get Status');
      await this.getStatuss();
      console.log('Step 3: Validation Start Two');
      await this.validationStartTwo();

      console.log('Step 4: Polling Status');
      await this.pollForStatus();

      console.log('Step 5: Error Summary');
      const summary = await this.errorSummary();
      console.log('Error Summary:', summary);

      this.activeTab = 'Data Validation';
      console.log('✅ Process flow completed successfully');
    } catch (err: any) {
      console.error('❌ Process flow error:', err);
      this.showError(err.message || err);
    } finally {
      this.myloaderloding = false;
    }
  }


  startPollingStatus(): Promise<string> {
  this.attemptCount = 0;
  this.myloaderloding = true;

  return new Promise((resolve, reject) => {
    const subscription = interval(5000)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        switchMap(() => {
          this.attemptCount++;

          const apiName = getApiName(
            'proc_tds_tran_load_error',
            this.dynaUserData?.default_sub_module_type_code
          );

          const sdata = this.apiService.generateSData(
            'proc_utilf_get_process_seqno_status',
            this.localUserData,
            this.filterClause,
            this.limit,
            this.offset,
            this.currentPage,
            {
              FYYear: this.FYYear,
              iudtype: apiName,
              client_level: this.client_level,
              client_code_level: this.selectedCodeLevelValue,
            }
          );

          return this.apiService
            .getTableData(
              '/dynamic-import/proc_utilf_get_process_seqno_status',
              sdata
            )
            .pipe(catchError(() => of(null)));
        }),
        takeWhile((data: any) => {
          if (!data?.result) {
            this.myloaderloding = false;
            subscription.unsubscribe();
            reject('❌ No response from server');
            return false;
          }

          const row = data.result.proc_utilf_get_process_seqno_status?.[0];
          const status = row?.process_status_code ?? null;
          const lastChar = status?.slice(-1);

          this.processMessage = row?.process_log_text;
          console.log(`Attempt ${this.attemptCount}: Status = ${status}`);

          // 🛑 Kill found
          if (lastChar === 'K' ||  data?.result?.proc_utilf_get_process_seqno_status == null) {
            this.myloaderloding = false;
            subscription.unsubscribe();
            resolve('Cancelled');
            return false;
          }

          // 🎉 Completed
          if (lastChar === 'B' || lastChar === 'C') {
            this.myloaderloding = false;
            subscription.unsubscribe();
            resolve(status);
            return false;
          }

          // ❌ Max attempts reached
          if (this.attemptCount >= this.maxAttempts) {
            this.myloaderloding = false;
            subscription.unsubscribe();
            reject(`Timeout: last status was ${status}`);
            return false;
          }

          return true; // keep polling
        })
      )
      .subscribe();
  });
}


  validationConfirm: boolean = false;
  pendingAction: (() => void) | null = null;
  // Open confirmation popup with action
  confirmValidation(action: () => void) {
    this.pendingAction = action;
    this.validationConfirm = true;
  }

  // Cancel popup
  cancelAction() {
    this.validationConfirm = false;
    this.pendingAction = null;
  }

  // Confirm popup
  executeAction() {
    if (this.pendingAction) this.pendingAction();
    this.cancelAction(); // close popup
  }

  isReviewPending: boolean = false;
  nextProcess() {
    if (this.activeTab === 'Process Data Review') {
      this.confirmValidation(() => this.startProcessFlow());
    }
    if (this.activeTab === 'Data Validation') {
      const pendingReview = this.errorReviewInfo?.some(
        (err: any) =>
          err.validation_error_review_required === 'T' &&
          err.validation_error_reviewed !== 1
      );
      if (pendingReview) {
        this.isReviewPending = true;
      } else {
        this.activeTab = 'Reports';
        this.Repots();
      }
    }
  }

  closeReportReviewPopup() {
    this.isReviewPending = false;
  }

  private getclientypeCodeData(): void {
    const storedData = sessionStorage.getItem('headermaster');
    if (!storedData) return;

    const parsedData = JSON.parse(storedData);
    const clientLevelMast = parsedData?.get_gmdt_client_level_mast || [];
    if (!Array.isArray(clientLevelMast) || clientLevelMast.length === 0) return;

    this.codeLevelOptions = clientLevelMast.map((item: any) => ({
      label: item.label || item.client_level_name,
      value: item.value || item.client_level_code,
    }));
    const defaultValue =
      this.selectedCodeLevelValue ||
      this.savedCodeLevel ||
      this.dynaUserData?.client_code_level;

    const baseLevel =
      this.savedCodeLevel || this.dynaUserData?.client_code_level;

    if (defaultValue) {
      const defaultOption = this.codeLevelOptions.find(
        (opt) => opt.value === defaultValue
      );
      if (defaultOption) {
        this.initializingCodeLevel = true;
        this.selectOption(defaultOption);
        this.initializingCodeLevel = false;
        this.codeLevelOptions = this.codeLevelOptions.filter(
          (opt) => opt.value >= baseLevel
        );
        return;
      }
    }

    this.selectedCodeLevel = null;
    this.selectedCodeLevelLabel = '';
    this.selectedCodeLevelValue = '';
  }

  processStatusCode: string = 'ZK';
  processKill() {
    const sdata = this.apiService.generateSData(
      'proc_tds_tran_load_error',
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'PROCESS_CANCEL',
        a_process_level: 1,
        seqnumber: this.refnumbertwo,
        processStatusCode: this.processStatusCode,
      }
    );

    this.myloaderloding = true;
    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        console.log(data, 'Process Kill Response');

        if (data?.result?.a_proc_error == 0) {
          const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
          this.processMessage = row?.process_log_text;
          this.pollForStatus(true)
            .then((status) => {
              this.activeTab = 'Process Data Review';
              this.getProceseqs();
              this.firstValidationSkipped = false;
              this.steps = 0;
              localStorage.setItem('steps', this.steps.toString());

              this.toastService.showSuccess('Process cancelled successfully.');
            })
            .catch((err) => {
              console.error('Error while polling after kill:', err);
              this.toastService.showError('Failed to detect cancelled status.');
            });
        } else {
          this.myloaderloding = false;
          this.errorMessage =
            data?.result?.[0]?.a_proc_error_message || 'Process kill failed.';
          this.toastService.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.myloaderloding = false;
        this.errorMessage = error.message || 'Failed to kill process.';
        this.toastService.showError(this.errorMessage);
      },
    });
  }
  isDrawerOpen: boolean = false;
  openDrawer(detail?: any) {
    console.log(detail);
    this.isDrawerOpen = true;
    this.selectedValidationErrorCode = detail?.validation_error_code;
  }
  closeDrawer() {
    this.isDrawerOpen = false;
  }
  activeDropdownIndex: number | null = null;
  openonId(index: number) {
    if (this.activeDropdownIndex === index) {
      this.activeDropdownIndex = null;
    } else {
      this.activeDropdownIndex = index;
    }
  }

  handleClickOutside(index: number) {
    if (this.activeDropdownIndex === index) {
      this.activeDropdownIndex = null;
    }
  }

  performOption(err: any, option: string) {
    console.log('Selected', option, 'for', err);

    this.activeDropdownIndex = null; // close after selection
  }

  isDropdownOpen: boolean = false;
  // popupType: 'review' | 'reprocess' | null = null;
  popupType: 'review' | 'reprocess' | 'reviewsingle' | 'updatedefault' | null =
    null;
  popupContent = '';
  selectedError: any = null;

  bulkActions = [
    { label: 'Review All', handler: () => this.openPopup('review') },
    { label: 'Re-process All', handler: () => this.openPopup('reprocess') },
  ];

  toggleDropdownR() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  // openPopup(type: 'review' | 'reprocess') {
  //   this.popupType = type;
  //   this.isDropdownOpen = false;
  // }

  openPopup(
    type: 'review' | 'reprocess' | 'reviewsingle' | 'updatedefault',
    err?: any
  ) {
    this.popupType = type;
    this.selectedError = err || null;
    this.popupContent = '';
    this.isDropdownOpen = false;
  }
  closePopup() {
    this.popupType = null;
    this.selectedError = null;
  }
  openReviewPopup() {
    this.popupType = 'review';
  }
  openReprocessPopup() {
    this.popupType = 'reprocess';
  }

  // confirmAction(mydcode?: string, err?: any) {

  //   if (this.popupType === 'review') {
  //     this.ReviewAll();
  //   } else if (this.popupType === 'reprocess') {
  //     this.startProcessFlow("Yes")
  //   } else if (mydcode === "reviewsingle") {
  //     this.ReviewAll(err)

  //   }
  //   this.closePopup();

  // }

  confirmAction() {
    if (this.popupType === 'review') {
      this.ReviewAll();
    } else if (this.popupType === 'reprocess') {
      this.startProcessFlow('Yes');
    } else if (this.popupType === 'reviewsingle') {
      this.ReviewAll(this.selectedError);
    } else if (this.popupType === 'updatedefault') {
      this.UpdateDefault(this.selectedError);
    }
    this.closePopup();
  }

  ReviewAll(err?: any) {
    this.isDropdownOpen = false;
    this.activeDropdownIndex = null;
    this.loadingStatics = true;
    const mycodeerror = err?.validation_error_code;
    const apiName = getApiName(
      'get_tiud_tran_load_error_review',
      this.dynaUserData?.default_sub_module_type_code
    );

    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        a_validation_error_code: mycodeerror,
        a_validation_error_review_remark: this.popupContent,
        // iudtype: 'get_tiud_tran_load_error_review',
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        console.log(data);
        this.loadingStatics = false;
        if (data?.result?.a_proc_error == 0) {
          this.toastService.showSuccess('Review submitted successfully!');
        } else {
          this.errorMessage = data.result[0].a_proc_error_message;
          this.errorSummary();
          this.toastService.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.loadingStatics = false;
        this.errorMessage = error.message || 'Failed to fetch Data.';
        this.toastService.showError(this.errorMessage);
      },
    });
  }
  errorSections: any;
  Repots() {
    this.steps = 0;
    localStorage.setItem('steps', this.steps.toString());
    this.loadingStatics = true;
    const sdata = this.apiService.generateSData(
      'get_gtdb_tran_load_error_statitics_final',
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
      }
    );

    this.apiService
      .getTableData('/EPV/get_gtdb_tran_load_error_statitics_final', sdata)
      .subscribe({
        next: (data) => {
          console.log(data);
          this.loadingStatics = false;
          if (data?.result?.a_proc_error == 0) {
            // this.errorSections = this.formatErrorSections(data.result.get_gtdb_tran_load_error_statitics_final);

            this.errorSections =
              data?.result?.get_gtdb_tran_load_error_statitics_final ?? [];

            // this.toastService.showSuccess('Review submitted successfully!');
          } else {
            this.errorMessage = data.result[0].a_proc_error_message;
            this.toastService.showError(this.errorMessage);
          }
        },
        error: (error) => {
          this.loadingStatics = false;
          this.errorMessage = error.message || 'Failed to fetch Data.';
          this.toastService.showError(this.errorMessage);
        },
      });
  }

  UpdateDefault(err: any) {
    const mycodeerror = err?.validation_error_code;
    this.loadingStatics = true;

    let apiName = 'get_tiud_tran_load_error_bulk_updt_other';
    const submoduleType = this.dynaUserData?.default_sub_module_type_code;
    if (submoduleType && submoduleType !== 'R' && submoduleType !== '') {
      const prefix = apiName.replace(/_other$/i, '');

      switch (submoduleType) {
        case 'G':
          apiName = `${prefix}_15gh_other`;
          break;
        case 'C':
          apiName = `${prefix}_corrs_other`;
          break;
      }
    }

    const sdata = this.apiService.generateSData(
      apiName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        a_validation_error_code: mycodeerror,
        refnumber: this.refnumber,
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        console.log(data);
        this.loadingStatics = false;
        if (data?.result?.a_proc_error == 0) {
        } else {
          this.errorMessage = data.result[0].a_proc_error_message;
          this.toastService.showError(this.errorMessage);
          this.errorSummary();
        }
      },
      error: (error) => {
        this.loadingStatics = false;
        this.errorMessage = error.message || 'Failed to fetch Data.';
        this.toastService.showError(this.errorMessage);
      },
    });
  }

  StartOver() {
    this.activeTab = 'Process Data Review';
    this.steps = 0;
    // localStorage.setItem('steps', this.steps.toString());
    this.getStatics();
    this.getProcessLog();
    this.firstValidationSkipped = false;
  }

  getSubModuleLabel(subTab: string, index: number): string {
    const type = this.dynaUserData?.default_sub_module_type_code || 'R';

    // 🟦 Tab 1
    if (index === 0) {
      if (type === 'G') return 'Master Transaction';
      if (type === 'C') return 'Correction';
      return 'Deductor';
    }

    // 🟩 Tab 2
    if (index === 1) {
      if (type === 'G') return 'Account Transaction';
      if (type === 'C') return 'Correction';
      return 'Chalan';
    }

    // 🟨 Tab 3
    if (index === 2) {
      if (type === 'G') return 'Deductor Transaction';
      if (type === 'C') return 'Correction';
      return 'Transaction';
    }

    return subTab; // fallback
  }

  generateFuv() {
    console.log('Generate FUV clicked');
    this.openFuv.emit(); // 🔹 Tell parent to open FUV Generation
  }

  isDeletePopupOpen: boolean = false;
  openAlert() {
    this.isDeletePopupOpen = true;
  }

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.processKill();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;
  }
}
