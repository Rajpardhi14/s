import { CommonModule } from '@angular/common';
import { Component, DestroyRef, EventEmitter, inject, Input, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { capitalizeAll, capitalizeEachWord, formatDatesend, getApiName } from '../../../../../../shared/utils/passmatch';
import { skip, Subject, Subscription } from 'rxjs';
import { RefreshdataService } from '../../../../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../../../../core/services/componentservice/apiservice.service';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { BasicFilterComponent } from "../../../../../../shared/components/basic-filter/basic-filter.component";
import { AdvanceFilterComponent } from "../../../../../../shared/components/advance-filter/advance-filter.component";
import { TableskeletonComponent } from "../../../../../../shared/components/tableskeleton/tableskeleton.component";
import { NodataComponent } from "../../../../../../shared/components/nodata/nodata.component";
import { GearboxComponent } from "../../../../../../shared/components/gearbox/gearbox.component";
import { AuthService } from '../../../../../../core/services/auth/auth.service';
import { OutSideClickDirective } from '../../../../../../core/services/outclick/outside-click.directive';
import { DatepickerComponent } from "../../../../../../shared/components/datepicker/datepicker.component";

@Component({
  selector: 'app-validationfix',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicFilterComponent, AdvanceFilterComponent, TableskeletonComponent, NodataComponent, GearboxComponent, OutSideClickDirective, DatepickerComponent],
  templateUrl: './validationfix.component.html',
  styleUrl: './validationfix.component.css'
})




export class ValidationfixComponent {
  capatilizeEachword = capitalizeEachWord
  @Input() isDrawerOpen: boolean = false;
  @Output() rowIdEmitter = new EventEmitter<any>();
  @Output() getErrorDb = new EventEmitter<void>();
  @Output() RefreshData = new EventEmitter<string>();
  @Output() closeDrawer = new EventEmitter<void>();
  @Input() iudtypeError: string = '';
  @Input() templateFilename: string = '';
  @Input() extensionfile: string = '';
  @Input() selectedValidationErrorCode: string = '';
  @Input() processStatusCode: string = '';
  @Input() refnumber: string = '';
  @Input() templateCode: string = '';

  scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];

  loginUserdata: any;
  loading = false;
  errorMessage = '';
  selectedFilters: { label: string; field: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = "Yes";
  iudtype: string = 'ALL';
  private destroy$ = new Subject<void>();
  dynaUserData: any;
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  isDeletePopupOpen = false;
  selectedIdsForDeletion: number = 0;
  selectedId: string | null = null;
  selectedRowDetails: any;
  capitalizeEachWord = capitalizeEachWord;

  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
    private authService: AuthService,
  ) {

  }


  private destroyRef = inject(DestroyRef);


  apiMapping: any = {
    DEDUCTOR: { baseProc: 'get_gmdb_tran_load_error_deductor' },
    CH: { baseProc: 'get_gtdb_tran_load_error_challan' },
    TR: { baseProc: 'get_gtdb_tran_load_error_deductee' },
    M: { baseProc: 'get_gtdb_tran_load_error' }, // 🔹 New for ZDE (Master Transaction)
  };

  private getApiDetailsFromCode(code: string) {
    const upperCode = (code || '').toUpperCase();
    let mappingKey = '';
    let suffix = '';

    // 🔹 Deductor cases (regular / 15GH)
    if (upperCode.includes('DSE') || upperCode.includes('DVE')) {
      mappingKey = 'DEDUCTOR';
      suffix = upperCode.includes('DSE') ? 'dse' : 'dve';

      // 🔹 Challan cases (regular / 15GH)
    } else if (upperCode.includes('CSE') || upperCode.includes('CVE') || upperCode.includes('ADE')) {
      mappingKey = 'CH';
      if (upperCode.includes('CSE')) suffix = 'cse';
      else if (upperCode.includes('CVE')) suffix = 'cve';
      else if (upperCode.includes('ADE')) suffix = 'ade';

      // 🔹 Transaction cases
    } else if (upperCode.includes('TSE') || upperCode.includes('TVE')) {
      mappingKey = 'TR';
      suffix = upperCode.includes('TSE') ? 'tse' : 'tve';

      // 🔹 Master transaction (ZDE)
    } else if (upperCode.includes('ZDE')) {
      mappingKey = 'M';
      suffix = 'dm_zde';

    } else {
      console.error('Unknown validation code:', code);
    }

    return { mappingKey, suffix };
  }

  private getEndpointDetails(type: 'table' | 'filter' | 'grandtotal') {
    const { mappingKey, suffix } = this.getApiDetailsFromCode(this.selectedValidationErrorCode);
    if (!mappingKey) return null;

    let baseProc = this.apiMapping[mappingKey].baseProc;

    // 🔹 Step 1: Add _15gh or _corrs dynamically
    const submoduleType = this.dynaUserData?.default_sub_module_type_code;
    if (submoduleType && submoduleType !== 'R' && submoduleType !== '') {
      const isUpperCase = baseProc === baseProc.toUpperCase();
      switch (submoduleType) {
        case 'G':
          baseProc = `${baseProc}_${isUpperCase ? '15GH' : '15gh'}`;
          break;
        case 'C':
          baseProc = `${baseProc}_${isUpperCase ? 'CORRS' : 'corrs'}`;
          break;
      }
    }

    // 🔹 Step 2: Adjust for type (filter / grandtotal)
    if (type === 'filter') baseProc = baseProc.replace('db', 'fb');
    if (type === 'grandtotal') baseProc = baseProc.replace('db', 'dg');

    // 🔹 Step 3: Build final names
    const procName = `${baseProc}_${suffix}`;
    const endpoint = `/EPV/${procName}`;
    const headerField = `${procName}_header`;
    const detailField = `${procName}_detail`;

    return { procName, endpoint, headerField, detailField };
  }


  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnChanges(changes: SimpleChanges): void {
  }
  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.dynamicUserData$
      .pipe(
        skip(1),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(dynamicData => {

        this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
        this.offset = 0;

      });

    this.fetchData();
    this.loadValidationRules();
    this.fetchFilter();
    this.fetchGrandTotal();




    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();



  }










  buildMergeGroups() {
    this.headers?.forEach(header => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }
  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );

  }
  validationErrorFields: string[] = [];
  values: any
  fixedCount: number = 0
  remainingCount: number = 0;
  errorColumname: string = ""


  isDtPresent: any;
  fetchData() {
    this.filterClause = Array.isArray(this.filterClause) ? this.filterClause : [];

    const newFilterClause = [
      {
        filter_col_field: 'validation_error_code',
        filter_col_field_alias: 'd.',
        filter_col_depend_operator: '=',
        filter_col_value: this.selectedValidationErrorCode,
      },
    ];

    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) this.filterClause.push(nf);
    });

    this.loading = this.offset === 0;
    this.isLoadingMore = this.offset > 0;

    const details = this.getEndpointDetails('table');
    if (!details) return;

    const sdata = this.apiService.generateSData(
      details.procName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        a_validation_error_code: this.selectedValidationErrorCode,
      }
    );

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {


          const userData = data?.result?.[details.procName];

          this.validationErrorFields = userData?.a_validation_error_code_field
            ? [userData.a_validation_error_code_field.column_name.toLowerCase()]
            : [];
          if (userData?.[details.headerField]) {

            // this.headers = userData[details.headerField].map((header: any) => ({
            //   ...header,
            //   visible: header.display === 1,
            // }));

            this.headers = userData[details.headerField].map((header: any) => {
              const isErrorField = this.validationErrorFields.includes(header.field);
              return {
                ...header,
                visible: header.display === 1 || isErrorField, // force show if error field
              };
            });
          }



          this.isDtPresent = this.headers
            .filter((header: any) => header.col_field_select)
            .map((header: any) => ({
              field: header.field,
              selectKey: header.col_field_select
            }));

          console.log(this.isDtPresent)

          this.tableBody = userData?.[details.detailField] || [];
          this.getData()
          // this.loadDropdownOptions();
          this.fixedCount = this.tableBody.filter(
            (row: any) => row.status?.toLowerCase() === 'fixed' || row.status === 1
          ).length;

          this.remainingCount = this.tableBody.filter(
            (row: any) => row.status?.toLowerCase() !== 'fixed' && row.status !== 1
          ).length;

          this.validationErrorFields = userData?.a_validation_error_code_field
            ? [userData.a_validation_error_code_field.column_name.toLowerCase()]
            : [];
          this.buildMergeGroups();
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {

          this.toastService.showError(data?.result?.[0]?.a_proc_error_message
 || 'Error fetching data');
        }

        this.loading = false;
      },
      error: (error) => {
        // this.errorMessage = error.message || 'Failed to fetch data.';
        this.toastService.showError(error.message || 'Failed to fetch data.');
        this.loading = false;
        this.isLoadingMore = false;
      },
    });
  }



  dropdownOptions: { [key: string]: any[] } = {};

  // loadDropdownOptions() {
  //   this.isDtPresent.forEach((dt: any) => {
  //     const endpointKey = dt.selectKey;
  //     // this.apiService.getDropdownData(endpointKey).subscribe({
  //     //   next: (res: any) => {
  //     //     this.dropdownOptions[dt.field] = res || [];
  //     //   },
  //     //   error: () => {
  //     //     this.dropdownOptions[dt.field] = [];
  //     //   }
  //     // });
  //   });
  // }


  isDropdownField(field: string): boolean {
    return this.isDtPresent?.some((dt: any) => dt.field === field);
  }

  myfilterfileds: any
  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchData();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }






  private fetchFilter(): void {
    if (this.isFirstLoad) this.isSkeletonshow = true;

    const details = this.getEndpointDetails('filter');
    if (!details) return;

    const sdata = this.apiService.generateSData(
      details.procName,
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        templateCode: this.templateCode,
        processStatusCode: this.processStatusCode,
      }
    );

    this.apiService.getFilterData('/Comman/dynamic', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          const resultData = response?.result?.[details.procName];
          this.basic_filter = resultData?.[0]?.basic_filter;
          this.advance_filter = resultData?.[1]?.advance_filter;

          this.initializeForm();

          this.advance_filter?.forEach((field: any) => {
            if (field.filter_col_external === 1 && field.filter_col_type === 'filter-select') {
              const allOption = { value: 'ALL', label: 'All' };
              const exists = field.filter_col_depend_value?.some((opt: any) => opt.value === 'ALL');
              if (!exists) field.filter_col_depend_value?.unshift(allOption);
            }
          });

          const defaultField = this.advance_filter?.find(
            (field: any) =>
              field.filter_col_external === 1 &&
              (field.filter_col_type === 'filter-select' || field.filter_col_type === 'select')
          );

          const defaultOption = defaultField?.filter_col_depend_value?.find(
            (opt: any) => opt.value === 'ALL'
          );

          this.defaultTabFilter = defaultOption;
          this.activeFilterTab = defaultOption?.value;

          if (defaultField && defaultOption) {
            const control = this.filterForm.get(defaultField.filter_col_field);
            if (control) control.setValue(defaultOption.value, { emitEvent: false });
          }

          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage =
            response.result?.[0]?.a_proc_error_message || 'Please Check Endpoint';
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error fetching filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion




  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchData(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {

        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator;
        filterValue = controlValue.toString().trim();

        // if (filterValue && filterValue !== '') {
        //   filterClause.push({
        //     filter_col_field: filterConfig.filter_col_field,
        //     filter_col_depend_operator: operator,
        //     filter_col_value: filterValue.toUpperCase(),
        //     filter_col_field_alias: filterConfig.filter_col_field_alias,
        //   });
        // }
      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;
  }


  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  getSelectedFilters() {
    if (!this.filtersSubmitted) {
      return [];
    }
    const selectedFilters: { label: string; value: string }[] = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_col_external === 1)) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }



  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }



  private fetchGrandTotal(): void {
    this.filterClause = Array.isArray(this.filterClause) ? this.filterClause : [];

    const newFilterClause = [
      {
        filter_col_field: 'validation_error_code',
        filter_col_field_alias: 'd.',
        filter_col_depend_operator: '=',
        filter_col_value: this.selectedValidationErrorCode,
      },
    ];

    newFilterClause.forEach((nf) => {
      const exists = this.filterClause.some(
        (f: any) => f.filter_col_field === nf.filter_col_field
      );
      if (!exists) this.filterClause.push(nf);
    });
    const details = this.getEndpointDetails('grandtotal');
    if (!details) return;

    const sdata = this.apiService.generateSData(
      details.procName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        refnumber: this.refnumber,
        templateCode: this.templateCode,
      }
    );

    this.apiService.getGrandTotal('/Comman/dynamic', sdata).subscribe({
      next: (response) => {
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          this.usergrandtotal = response?.result?.[details.procName]?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: () => {
        this.isLoadingMore = false;
        this.showError('Something went wrong');
      },
    });
  }

  // Remove all filter label values








  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.selectedFilters = [];
    this.filterClause = [];
    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (control) {
          control.setValue('');
        }
      });
    }
    this.filtercount = this.getSelectedFilterCount();
    this.fetchData();
    this.fetchGrandTotal();
  }




  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'LDC Data'
    );
  }



  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }


  statuskey: any;




  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }


  // Count selected rows
  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }





  // validationRules: { [key: string]: RegExp } = {

  //   deductee_panno: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,  
  //   email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,            
  //   mobile: /^[6-9]\d{9}$/,                         
  //   aadhaar: /^\d{12}$/,
  //   amount: /^\d+(\.\d{1,2})?$/
  // };


  validationRules: { [key: string]: RegExp } = {};



  private loadValidationRules(): void {
    const storedData = sessionStorage.getItem('headermaster');
    if (!storedData) return;

    const parsedData = JSON.parse(storedData);
    const regexList = parsedData?.get_gmdt_regex_validation || [];
    // Convert array into key-value pair object
    this.validationRules = regexList.reduce((acc: { [key: string]: RegExp }, item: any) => {
      if (item.label && item.value) {
        try {
          acc[item.label] = new RegExp(item.value);
        } catch (error) {
          console.error(`Invalid regex for field: ${item.label}`, error);
        }
      }
      return acc;
    }, {});

    console.log('Dynamic Validation Rules:', this.validationRules);
  }

  // onFieldChange(row: any, field: string, event: any): void {
  //   let value = event.target.value?.trim() ?? '';

  //   if (field === 'deductee_panno') {
  //     value = value.toUpperCase();
  //   }

  //   if (this.isDateField(field)) {
  //     value = this.formatDate(value);
  //   }

  //   row[field] = value;
  //   row.edited = true;

  //   this.updateErrorCounts();
  // }




  onFieldChange(row: any, field: string, event: any): void {
    // let value = event.target.value?.trim() ?? '';
    let value =
      typeof event === 'string' || typeof event === 'number'
        ? event
        : event?.target?.value ?? '';
    if (field === 'deductee_panno') {
      value = value.toUpperCase();
    }

    // if (this.isDateField(field)) {
    //   console.log(value)
    //   value = this.formatDate(value);
    //   console.log(value)
    // }

    row[field] = value;
    row.edited = true;

    this.updateErrorCounts();
  }


  // Track invalid fields dynamically
  isFieldInvalid(row: any, field: string): boolean {
    const value = row[field];

    // Required check
    if (this.validationErrorFields.includes(field) && (!value || value.toString().trim() === '')) return true;

    // Validation rules
    if (this.validationRules[field] && value && !this.validationRules[field].test(value)) return true;

    return false;
  }
  updateErrorCounts(): void {
    if (!this.tableBody?.length) return;

    this.fixedCount = this.tableBody.filter((row: any) => {
      return this.validationErrorFields.every((field: string) => {
        const value = row[field];
        if (!value || value.toString().trim() === '') return false;
        if (this.validationRules[field] && !this.validationRules[field].test(value)) return false;
        return true;
      });
    }).length;

    this.remainingCount = this.tableBody.length - this.fixedCount;
  }


  getDropdownField(field: string) {
    return this.mydrodownlistdata?.find((drop: any) => drop.field === field);
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  // chekbox
  isAllSelected(): boolean {
    return this.paginatedList?.every((row: any) => row.selected);
  }
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }

  onClear() {
    this.paginatedList?.forEach((r: any) => r.selected = false);
  }








  readonly MAX_EDITABLE_ROWS = 10;
  // Centralized API mapping
  private apiMappings: Record<string, { proc: string; key: string; }> = {
    DSE: { proc: 'get_miud_tran_load_error_deductor', key: 'client_mast', },
    DVE: { proc: 'get_miud_tran_load_error_deductor', key: 'client_mast', },
    CSE: { proc: 'get_tiud_tran_load_error_challan', key: 'tds_challan_tran_load', },
    CVE: { proc: 'get_tiud_tran_load_error_challan', key: 'tds_challan_tran_load', },
    TSE: { proc: 'get_tiud_tran_load_error_deductee', key: 'tds_tran_load', },
    TVE: { proc: 'get_tiud_tran_load_error_deductee', key: 'tds_tran_load', },
    ZDE: { proc: 'get_tiud_tran_load_error', key: 'zde', },
  };








  isOpen: boolean = false;
  toggleDrawer() {
    this.isOpen = true;
  }
  closepDrawer() {
    this.isOpen = false
  }


  saveChanges(data: any): void {
    const updatedFields: any[] = [];
    let validFixedRows = 0;

    // 🔹 Get only rows that user actually edited
    const editedRows = this.paginatedList.filter((r: any) => r.edited);

    // 🔹 If user hasn’t edited anything
    if (editedRows.length === 0) {
      this.showError("No changes detected to save.");
      return;
    }

    // 🔹 Limit to max 10 edited rows
    const rowsToProcess = editedRows.slice(0, this.MAX_EDITABLE_ROWS);

    // 🔹 If more than 10 rows edited
    if (editedRows.length > this.MAX_EDITABLE_ROWS) {
      this.showError(`You have edited more than ${this.MAX_EDITABLE_ROWS} rows. Only the first ${this.MAX_EDITABLE_ROWS} will be processed.`);
    }

    // 🔹 Validate and collect updated fields
    rowsToProcess.forEach((row: any) => {
      let rowValid = true;
      const rowUpdates: any[] = [];

      this.validationErrorFields.forEach((field: string) => {
        if (!(field in row)) return; // Skip missing fields
        let value = row[field];

        if (this.isDateField(field)) {
          value = this.formatDate(value);
        }

        // Validate rule if exists
        if (this.validationRules[field] && !this.validationRules[field].test(value)) {
          rowValid = false;
        }

        // Skip empty values
        if (!value || value.toString().trim() === "") {
          rowValid = false;
        }

        const upperValue =
          typeof value === "string" ? value.toUpperCase().trim() : value;

        // Collect valid values only
        if (value && rowValid) {
          rowUpdates.push({
            rowid_seq: row.rowid_seq,
            col_name: field,
            col_value: upperValue
          });
        }
      });


      if (rowValid && rowUpdates.length > 0) {
        validFixedRows++;
        updatedFields.push(...rowUpdates);
      }

      console.log('Row Updates:', rowUpdates);
    });

    // ❌ No valid edited rows found
    if (validFixedRows === 0) {
      this.showError("Please fix at least one invalid field before saving.");
      return;
    }

    // ✅ Determine mapping dynamically (includes check)
    const code = (this.selectedValidationErrorCode || '').toUpperCase();
    const mapping = Object.entries(this.apiMappings).find(([key]) => code.includes(key))?.[1];

    if (!mapping) {
      this.showError('Invalid validation code type.');
      return;
    }



    let { proc, key } = mapping;
    let extraSuffix = '';
    if (code.includes('ZDE')) {
      extraSuffix = 'dm';
    } else if (code.includes('ADE')) {
      extraSuffix = 'ad';
    }
    proc = getApiName(proc, this.dynaUserData?.default_sub_module_type_code, extraSuffix);


    const payload: any = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_is_pen_flag: '',
      a_login_type: 'login_id',
      a_user_code: this.localUserData.user_code,
      a_user_level: this.localUserData.user_level,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_process_level: 1,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? 'R',
      a_iud_type: 'u',
      a_process_seqno: this.refnumber || '',
      a_proc_type: proc,
      [key]: updatedFields
    };

    // ✅ API call
    this.apiService.miudApi('/Comman/dynamic', payload).subscribe({
      next: (res) => {
        const resultItem = res?.result?.[0];
        if (resultItem?.a_proc_error == 0) {

          if (data == "Yes") {
            //  this.rowIdEmitter.emit(allRowIds);
            // this.RefreshData.emit("Yes")

          } else {
            // this.getErrorDb.emit();
          }
          this.closepDrawer();
          this.closeDrawer.emit();


          this.showSuccess(resultItem?.a_proc_error_message || `Successfully updated ${validFixedRows} row(s)!`);
        } else {
          this.showError(resultItem?.a_proc_error_message || 'Something went wrong!');
        }
      },
      error: () => this.showError('Something went wrong! Please try again later.'),
    });
  }

  formatCurrency(value: any): string {
    if (value == null || value === '') return '';
    const numberValue = Number(value);
    if (isNaN(numberValue)) return value;

    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(numberValue);
  }

  isAmountField(field: string): boolean {
    // List all fields you want to format as currency
    const amountFields = ['challan_tds_amt', 'int_amt', 'other_amt', 'tran_amt', 'tds_amt', 'surcharge_amt', 'cess_amt', 'partybillamt', 'c20l_amt', 'c100l_amt', 'c300l_amt'];
    return amountFields.includes(field);
  }

  // isDateField(field: string): boolean {
  //   const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
  //   return dateFields.includes(field);
  // }


  isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
    return (
      dateFields.includes(field) ||
      field.toLowerCase().includes('date')
    );
  }
  capitalizeAll = capitalizeAll
  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

  getDateType(field: string): 'validFrom' | 'validTo' | 'po_end_date' | null {
    switch (field) {
      case 'challan_date': return 'validFrom';
      case 'tran_ref_date': return 'validTo';
      case 'tds_deduct_date': return 'po_end_date';
      default: return null;
    }
  }


  onDateChange(row: any, field: string, event: any) {
    if (!this.isDateField(field)) {
      row[field] = event.target.value;
    } else {
      row[field] = this.formatDate(event.target.value);
    }
    this.updateErrorCounts();
  }


  shouldCapitalize(field: string): boolean {
    const lowerField = field.toLowerCase();
    return !(lowerField.includes('pan') || lowerField.includes('tan'));
  }


  mydrodownlistdata: any
  getData(): void {
    const filterValues = this.isDtPresent?.map((col: any) => `##${col.selectKey.replace('gmdt', 'mmtx')}##`).join(',');


    // const filterValues = this.isDtPresent.map((col:any) => `##${col.selectKey}##`).join(',');
    const requestBody = {
      sdata: JSON.stringify({
        a_session_seqno: '',
        a_iud_seqno: '',
        a_is_pen_flag: '',
        a_login_type: 'login_id',
        a_module_type_code: this.localUserData?.default_module_type_code,
        a_sub_module_type_code: 'R',
        a_entity_code: this.localUserData?.entity_code,
        a_client_code: this.localUserData?.client_code,
        a_acc_year: this.localUserData?.default_acc_year,
        a_quarter_no: this.localUserData?.default_quarter_no,
        a_tran_month: this.localUserData?.default_tran_month,
        a_tran_from_date: this.localUserData?.default_from_date,
        a_tran_to_date: this.localUserData?.default_to_date,
        a_tds_type_code: this.localUserData?.default_tds_type_code,
        a_first_level_client_code: this.localUserData?.first_level_client_code,
        a_validation_client_level: this.localUserData.client_code_level,
        a_iud_type: '',
        a_db_total_records: '10',
        a_pagination_count: '0',
        a_proc_type: 'get_mmtx_multi_mast',
        a_filter_clause: [
          {
            filter_col_field: 'gd_proc_name',
            filter_col_depend_operator: 'wc',
            filter_col_value: `and gd_proc_name in (${filterValues})`,
            filter_col_field_alias: 'a.'
          }
        ]
      })
    };

    this.authService.fetchMultiMastData(requestBody).subscribe({
      next: (response: any) => {
        const multiMast = response?.body?.result?.get_mmtx_multi_mast;
        console.log(response)
        this.isDtPresent.forEach((item: any) => {
          const key = item.selectKey;
          this.dropdownOptions[item.field] = multiMast[key] || [];
        });






      },
      error: (err) => console.error(err)
    });
  }





  getDropdownLabel(field: string, value: string): string {
    const option = this.dropdownOptions[field]?.find((opt: any) => opt.value === value);
    return option ? option.label : '';
  }

  // Handle selecting an option
  selectDropdownOption(row: any, field: string, option: any): void {
    row[field] = option.value;
    row[field + '_open'] = false;
    this.updateErrorCounts();
  }

  // Clear selected option
  clearDropdownSelection(row: any, field: string, event: Event): void {
    event.stopPropagation();
    row[field] = '';
    row[field + '_search'] = '';
    row[field + '_filteredOptions'] = this.dropdownOptions[field];
    this.updateErrorCounts();
  }

  // Filter options as user types
  filterDropdownOptions(field: string, row: any): void {
    const searchTerm = (row[field + '_search'] || '').toLowerCase();
    row[field + '_filteredOptions'] = this.dropdownOptions[field].filter((opt: any) =>
      opt.label.toLowerCase().includes(searchTerm)
    );
  }




  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }
}