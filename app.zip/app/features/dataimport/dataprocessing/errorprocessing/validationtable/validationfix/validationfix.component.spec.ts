import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationfixComponent } from './validationfix.component';

describe('ValidationfixComponent', () => {
  let component: ValidationfixComponent;
  let fixture: ComponentFixture<ValidationfixComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ValidationfixComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ValidationfixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
