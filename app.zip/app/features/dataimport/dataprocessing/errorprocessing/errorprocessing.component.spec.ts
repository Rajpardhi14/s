import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorprocessingComponent } from './errorprocessing.component';

describe('ErrorprocessingComponent', () => {
  let component: ErrorprocessingComponent;
  let fixture: ComponentFixture<ErrorprocessingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrorprocessingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ErrorprocessingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
