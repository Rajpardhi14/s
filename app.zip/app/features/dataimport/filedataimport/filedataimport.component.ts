import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  inject,
  NgZone,
  Renderer2,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastService } from '../../../core/services/toaster/toast.service';
import JSZip, { file } from 'jszip';
import { saveAs } from 'file-saver';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { interval, Subscription, switchMap, timer } from 'rxjs';
import { of, throwError } from 'rxjs';
import * as ExcelJS from 'exceljs';
import {
  concatMap,
  catchError,
  tap,
  filter,
  take,
  timeout,
  takeWhile,
  finalize,
  skip,
} from 'rxjs/operators';
import { capitalizeEachWord } from '../../../shared/utils/passmatch';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { FixittableComponent } from "../validationtable/fixittable/fixittable.component";
import { AuthService } from '../../../core/services/auth/auth.service';
import * as XLSX from 'xlsx';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';


@Component({
  selector: 'app-filedataimport',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, FixittableComponent, OutSideClickDirective, AlertpoupComponent],
  templateUrl: './filedataimport.component.html',
  styleUrl: './filedataimport.component.css',
})

export class FiledataimportComponent {
  processlogtxt: any;
  streamApplicableFlag: string = '';
  headers: any[] = [];
  tableBody: any[] = [];
  templateCode: string = ""
  selectedRows: { [rowId: number]: 'Y' | 'N' } = {};
  selectedTab: string = 'Upload';
  selectedTemplate: string = 'Select Template';
  selectedApplyTag: string = 'Select Tag';
  showTemplate: boolean = false;
  showError: boolean = false;
  showApplyTag: boolean = false;
  selectedTemplateData: any;
  selectedTagData: any;
  isFileSelected: boolean = false;
  templateheader: any;
  errorRecord: any;
  errorTotalrecords: any;
  isErrorGrandTotal: any;
  fileExtension: any;
  binaryZipData: any;
  selectedFile: any;
  noError: boolean = false;
  showLoaderGif: boolean = false;
  allBlobs: any;
  fileInfo: any;
  summaryData: any;
  selectedProcess: string = 'Process 1';
  errorRows: any[] = [];
  invalidData: any[] = [];
  closedButton: boolean = false;
  baseFileInfo: any[] = [];
  selectedFiles: any[] = [];
  errorSummary: any[] = [];
  templateOptions: any[] = [];
  refnumber: any;
  isFileUploaded: boolean = false;
  processStatusCode: string = '';
  localUserData: any;
  isTemplateLocked = false;

  tagList: any[] = [

  ];
  dynaUserData: any;
  captilize = capitalizeEachWord;
  templateFilename: any;

  passCode: any
  templateFile: any;
  extensionfile: any;
  stored_template_code: string = '';
  stored_template_based_on: string = '';
  stored_template_type: string = '';
  stored_template_file_type: string = '';
  stored_no_of_process: any;
  stored_template_process_type: string = "";
  templateCodeFromUrl: string = ""
  constructor(
    private renderer: Renderer2,
    private toastService: ToastService,
    private userlocaldataService: UserdataService,
    private apiservice: ApiserviceService,
    private ngZone: NgZone,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private router: Router,

  ) {
    this.renderer.listen('window', 'click', (event: Event) => {
      this.closePopupOnOutsideClick(event);
    });
  }

  private destroyRef = inject(DestroyRef);
  private templatePreselectedFromUrl = false;

  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.route.queryParams.subscribe((params) => {
      this.templateCodeFromUrl = params['code'] || null;
      this.passCode = this.templateCodeFromUrl
     

   if (this.templateCodeFromUrl) {
  this.templatePreselectedFromUrl = true;
  this.isTemplateLocked = true;
}

this.getTemplateOptions();
    });
    this.getTaglist()
    this.getProceseqs();
    this.dynamicUserData$
      .pipe(skip(1), takeUntilDestroyed(this.destroyRef))
      .subscribe((dynamicData) => {
        this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

        if (this.selectedTab === "Upload") {
          this.selectedTemplate = 'Select Template';
          this.selectedApplyTag = 'Select Tag';
          this.uploadedFile = [];
          this.selectedFiles = [];
          this.isFileSelected = false;
        }

        this.getTemplateOptions();

        this.getTaglist()
        this.getProceseqs();

      });

  }
  isDisabled(process: string): boolean {
    return this.selectedProcess !== process;
  }
  closePopupOnOutsideClick(event: Event) {
    const target = event.target as Element;
    if (!target.closest('.popup-container')) {
      this.showTemplate = false;
      this.showApplyTag = false;
    }
  }

  myrowIdFromChild: any[] = [];

  handleRowId(rowId: any) {
    this.myrowIdFromChild = rowId;
    console.log('Received rowId from child:', rowId);


  }

  selectProcess(process: string) {
    this.selectedProcess = process;
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }

  btnshowtemplate(event: Event) {
    event.stopPropagation();
    this.showTemplate = !this.showTemplate;
  }

  btnshowApplyTag(event: Event) {
    event.stopPropagation();
    this.showApplyTag = !this.showApplyTag;
  }

  canUploadFile(): boolean {
    if (this.selectedTemplate === 'Select Template') return false;
    if (this.streamApplicableFlag === 'Y' && this.selectedApplyTag === 'Select Tag') return false;

    return true;
  }

  finalJSON: any;
  selectTemplate(option: any) {
    // console.log(option);
    this.selectedTemplate = option.template_name;
    this.selectedTemplateData = option;
    const templateValidation = this.selectedTemplateData?.sl_arr?.[0];
    const arr = Object.entries(
      templateValidation[0]?.templateValidation || {}
    ).map(([key, value]) => ({
      fieldName: key,
      ...(value as Record<string, any>),
    }));

    this.templateheader = arr;

    this.streamApplicableFlag = option.stream_applicable_flag;
    this.showTemplate = false;
  }
  clearTemplate(event: MouseEvent) {
    event.stopPropagation();
    this.selectedTemplate = 'Select Template';
    this.selectedTemplateData = null;
    this.showTemplate = false;
  }

  mystreamCode: number | string = 0
  selectApplyTag(option: any) {
    this.selectedApplyTag = option.label;
    this.mystreamCode = option.value;
    console.log(this.mystreamCode)
    this.selectedTagData = option;
    this.showApplyTag = false;
    console.log(option);
  }

  clearApplyTag(event: MouseEvent) {
    event.stopPropagation(); // Prevent dropdown from toggling
    this.selectedApplyTag = 'Select Tag';
    // this.mystreamCode = null;
    this.selectedTagData = null;
    console.log('Tag cleared');
  }

  uploadedFile: any;
  // handleFileSelection(event: any) {
  //   const input = event.target as HTMLInputElement;



  //   if (this.selectedTemplate === 'Select Template') {
  //     this.toastService.showError(
  //       'Please select a template before choosing a file.'
  //     );


  //     this.resetFileStates(input)
  //     return;
  //   }

  //   if (this.streamApplicableFlag == "Y" && this.selectedApplyTag === 'Select Tag') {
  //     this.toastService.showError(
  //       'Please select a Tag before choosing a file.'
  //     );
  //     this.resetFileStates(input)
  //     return;
  //   }
  //   this.uploadedFile = Array.from(event.target.files);

  //   if (!input.files || input.files.length === 0) return;

  //   if (input.files && input.files.length > 0) {
  //     const file = input.files[0];
  //     Array.from(input.files).forEach((file) => {
  //       this.selectedFiles.push({ name: file.name });
  //     });
  //     this.selectedFile = file;
  //     const fileNew = event.target.files[0];
  //     if (fileNew) {
  //       const fileDetails = {
  //         name: fileNew.name,
  //         lastModified: fileNew.lastModified,
  //         size: fileNew.size,
  //         type: fileNew.type,
  //         webkitRelativePath: fileNew.webkitRelativePath,
  //       };
  //       this.fileExtension = fileNew.type;
  //       this.selectedFiles = [fileDetails];
  //       this.isFileSelected = true;
  //       this.noError = true;
  //       const reader = new FileReader();
  //       reader.onload = () => {
  //         const arrayBuffer = reader.result as ArrayBuffer;
  //         const fixedBuffer = arrayBuffer.slice(0);
  //         const cleanBinary = new Uint8Array(fixedBuffer);
  //         this.binaryZipData = cleanBinary;
  //       };

  //       reader.readAsArrayBuffer(file);
  //     }

  //     this.isFileSelected = true;
  //     this.noError = true;
  //   }

  //   this.isFileSelected = true;

  //   console.log('Selected files:', this.selectedFiles);


  // }


  handleFileSelection(event: any) {
    const input = event.target as HTMLInputElement;

    /** Validation: Template must be selected */
    if (this.selectedTemplate === 'Select Template') {
      this.toastService.showError('Please select a template before choosing a file.');
      this.resetFileStates(input);
      return;
    }

    /** Validation: Tag required for Stream */
    if (this.streamApplicableFlag === "Y" && this.selectedApplyTag === 'Select Tag') {
      this.toastService.showError('Please select a Tag before choosing a file.');
      this.resetFileStates(input);
      return;
    }

    if (!input.files || input.files.length === 0) return;

    // Always pick the first file
    const file = input.files[0];

    // Update selected file
    this.selectedFile = file;
    this.uploadedFile = [file];
    // Reset previous states
    this.selectedFiles = [{
      name: file.name,
      size: file.size,
      type: file.type,
      ext: this.fileExtension
    }];

    this.fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
    this.isFileSelected = true;
    this.noError = true;

    console.log(this.fileExtension);
  }



  zipBlob: any;
  async generateZip(files: File[]): Promise<Blob> {
    const zip = new JSZip();

    for (const file of files) {
      const fileData = await file.arrayBuffer();
      zip.file(file.name, fileData);
    }

    // Generate ZIP as a Blob
    const zipBlob = await zip.generateAsync({ type: 'blob' });



    return zipBlob;
  }

  removeFile(index: number): void {
    this.selectedFiles.splice(index, 1);
    if (this.selectedFiles.length === 0) {
      this.isFileSelected = false;
      this.selectedFile = null;
      this.uploadedFile = [];

      console.log(index);
    }
  }

  private resetFileStates(input: HTMLInputElement) {
    this.isFileUploaded = false;

    this.uploadedFile = [];

    this.isFileSelected = false;
    this.noError = false;
    input.value = '';
  }
  iudtype: string = 'get_tiud_import_tran';
  iudtypeError: string = 'FIRST';
  // async processFile() {
  //   const isStreamApplicable = this.streamApplicableFlag === 'Y';
  //   // console.log(this.mystreamCode)
  //   const isFirstUpload = this.selectedTab === 'Upload';
  //   if (isFirstUpload) {
  //     if (
  //       this.selectedTemplate === 'Select Template'
  //     ) {
  //       this.toastService.showError(
  //         'Please select a Template .'
  //       );
  //       return;
  //     }
  //     if (this.selectedTemplate === 'Select Template') {
  //       this.toastService.showError(
  //         'Please select a template before choosing a file.'
  //       );
  //       return;
  //     }
  //     if (isStreamApplicable && this.selectedApplyTag === 'Select Tag') {
  //       this.toastService.showError(
  //         'Please select a Tag before choosing a file.'
  //       );
  //       return;
  //     }

  //     if (!this.selectedFile) {
  //       this.toastService.showError('Please upload a file first.');
  //       return;
  //     }
  //   } else {

  //     if (!this.selectedFile) {
  //       this.toastService.showError(
  //         'No file available for reprocessing. Please upload again.'
  //       );
  //       return;
  //     }
  //   }


  //   this.ngZone.run(() => (this.showLoaderGif = true));
  //   if (typeof Worker !== 'undefined') {
  //     const worker = new Worker(
  //       new URL(
  //         '../../../core/worker/file-processor.worker.ts',
  //         import.meta.url
  //       ),
  //       { type: 'module' }
  //     );

  //     worker.postMessage({
  //       file: this.selectedFile,
  //       selectedOptionReturn: '',
  //       selectedOptionTemp: this.selectedTemplate,
  //       expectedHeaders: this.templateheader,
  //     });

  //     worker.onmessage = async (event) => {
  //       if (event.data.error) {
  //         this.toastService.showError(event.data.error);
  //         this.showLoaderGif = false;
  //         worker.terminate();
  //         return;
  //       }

  //       this.allBlobs = event.data.allBlobs;
  //       if (
  //         !this.allBlobs ||
  //         !Array.isArray(this.allBlobs) ||
  //         this.allBlobs.length === 0 ||
  //         this.allBlobs.every((b: any) => b === undefined || b === null)
  //       ) {
  //         this.toastService.showError(
  //           'Please try again. File data is empty or invalid.'
  //         );
  //         this.showLoaderGif = false;
  //         worker.terminate();
  //         return;
  //       }

  //       this.fileInfo = Array.isArray(event.data.fileInfo)
  //         ? event.data.fileInfo
  //         : [event.data.fileInfo];
  //       this.baseFileInfo = Array.isArray(event.data.fileInfo)
  //         ? event.data.fileInfo
  //         : [event.data.fileInfo];

  //       // Group files
  //       if (this.allBlobs) {
  //         const groupedFiles = this.allBlobs.reduce((acc: any, curr: any) => {
  //           const existingFile = acc.find(
  //             (file: any) => file.fileName === curr.fileName
  //           );
  //           if (existingFile) {
  //             existingFile.records += curr.recordCount;
  //             existingFile.chunks += 1;
  //           } else {
  //             acc.push({
  //               sheetName: curr.fileName,
  //               records: curr.recordCount,
  //               chunks: 1,
  //             });
  //           }
  //           return acc;
  //         }, []);

  //         this.baseFileInfo = groupedFiles.reduce((acc: any, curr: any) => {
  //           const existing = acc.find(
  //             (item: any) => item.sheetName === curr.sheetName
  //           );
  //           if (existing) {
  //             existing.records += curr.records;
  //           } else {
  //             acc.push({ ...curr });
  //           }
  //           return acc;
  //         }, [] as { sheetName: string; records: number; chunks: number }[]);
  //       }

  //       this.noError = true;

  //       // Prepare summary and zip
  //       this.summaryData = {
  //         fileName: this.selectedFile.name,
  //         fileSize: this.formatBytes(this.selectedFile.size),
  //         totalRecords: this.baseFileInfo?.[0]?.records,
  //         totalAmount: '',
  //         totalProcessed: this.baseFileInfo?.[0]?.records,
  //       };

  //       this.zipBlob = await this.generateZip(this.uploadedFile);



  //       // saveAs(this.zipBlob, "debug_myFiles.zip");
  //       this.finalJSON = {
  //         fields: this.templateheader,
  //         metadata: {
  //           a_session_seqno: '',
  //           a_iud_seqno: '',
  //           a_is_pen_flag: '',
  //           a_login_type: 'login_id',
  //           a_user_code: this.localUserData.user_code,
  //           a_user_level: this.localUserData.user_level,
  //           a_module_type_code: this.dynaUserData.default_module_type_code,
  //           a_sub_module_type_code:
  //             this.dynaUserData.default_sub_module_type_code ?? "R",
  //           a_entity_code: this.dynaUserData.entity_code,
  //           a_client_code: this.dynaUserData.client_code,
  //           a_acc_year: this.dynaUserData.default_acc_year,
  //           a_quarter_no: this.dynaUserData.default_quarter_no,
  //           a_tran_month: this.dynaUserData.default_tran_month,
  //           a_tran_from_date: this.dynaUserData.default_from_date,
  //           a_tran_to_date: this.dynaUserData.default_to_date,
  //           a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //           a_validation_client_level: this.dynaUserData.client_code_level,
  //           a_first_level_client_code:
  //             this.dynaUserData.first_level_client_code,
  //           a_process_seqno: "",
  //           a_iud_type: 'i',
  //           a_template_process_type:
  //             this.selectedTemplateData.template_process_type,
  //           a_proc_type: 'get_tiud_import_tran',
  //           a_db_total_records: '1000',
  //           a_pagination_count: '0',
  //           a_process_status_code: 'TA',
  //           a_template_based_on: this.selectedTemplateData.template_based_on,
  //           a_stream_code: `#${this.mystreamCode}#`,
  //           a_import_type: 'A',
  //           a_template_code: this.selectedTemplateData.template_code,
  //           a_upload_file_name: this.selectedFile?.name || '',
  //           a_no_of_process: this.selectedTemplateData.no_of_process,
  //           record_insert_flag: 'S',
  //           a_template_tds_type_code: this.dynaUserData.default_tds_type_code,
  //           import_tran: [
  //             {
  //               text_file: this.selectedFile?.name || '',
  //               header_file_template_code:
  //                 this.selectedTemplateData.template_code,
  //               text_file_delimeter:
  //                 this.selectedTemplateData.template_file_delimeter,
  //               text_file_date_format:
  //                 this.selectedTemplateData.template_file_date_format,
  //               template_file_type:
  //                 this.selectedTemplateData.template_file_type,
  //               text_file_os_platform:
  //                 this.selectedTemplateData.template_file_os_platform,
  //               text_file_skip_records:
  //                 this.selectedTemplateData.template_file_skip_records,
  //             },
  //           ],
  //         },
  //         data: {
  //           compute: this.selectedTemplateData.sl_arr[0][0].compute,
  //           allowedExt: this.selectedTemplateData.sl_arr[0][0].allowedExt,
  //           sl_row_count: this.selectedTemplateData.sl_arr[0][0].sl_row_count,
  //           sl_chunk_size: this.selectedTemplateData.sl_arr[0][0].sl_chunk_size,
  //           statusArr: this.selectedTemplateData.sl_arr[0][0].statusArr,
  //         },
  //       };

  //       this.stored_template_process_type =
  //         this.selectedTemplateData.template_process_type;
  //       this.stored_no_of_process = this.selectedTemplateData.no_of_process;
  //       this.stored_template_based_on = this.selectedTemplateData.template_based_on;
  //       this.stored_template_code = this.selectedTemplateData.template_code;
  //       // console.log(this.stored_template_process_type)

  //       const jsonBlob = new Blob([JSON.stringify(this.finalJSON, null, 2)], {
  //         type: 'application/json',
  //       });
  //       //  saveAs(jsonBlob, "debug_myFiles.zip");

  //       saveAs(jsonBlob, 'debug_myFiles.json');


  //       this.apiservice
  //         .uploadZipAndJson(
  //           this.zipBlob,
  //           jsonBlob,
  //           this.dynaUserData.client_code,
  //           this.dynaUserData.user_code,
  //           this.selectedFile.name
  //         )
  //         .then((uploadResult: any) => {
  //           this.a_process_seqno = uploadResult.process_No;
  //           this.refnumber = uploadResult.process_No;
  //           this.selectedTab = 'Verify';
  //           this.selectedProcess = 'Process 1';
  //           // this.toastService.showSuccess('Files uploaded successfully!');
  //           this.startProcessCheck();
  //         })
  //         .catch((err) => {
  //           console.error('Upload failed', err);
  //           this.toastService.showError('File upload failed!');
  //         })
  //         .finally(() => {
  //           this.showLoaderGif = false;
  //         });

  //       worker.terminate();
  //     };

  //     worker.onerror = (error) => {
  //       console.error('Worker error:', error);
  //       this.showLoaderGif = false;
  //       worker.terminate();
  //     };
  //   } else {
  //     console.error('Web Workers are not supported in this environment.');
  //     this.showLoaderGif = false;
  //   }
  // }


  // process File



  // async processFile() {
  //    const isStreamApplicable = this.streamApplicableFlag === 'Y';
  //   // console.log(this.mystreamCode)
  //   const isFirstUpload = this.selectedTab === 'Upload';
  //   if (isFirstUpload) {
  //     if (
  //       this.selectedTemplate === 'Select Template'
  //     ) {
  //       this.toastService.showError(
  //         'Please select a Template .'
  //       );
  //       return;
  //     }
  //     if (this.selectedTemplate === 'Select Template') {
  //       this.toastService.showError(
  //         'Please select a template before choosing a file.'
  //       );
  //       return;
  //     }
  //     if (isStreamApplicable && this.selectedApplyTag === 'Select Tag') {
  //       this.toastService.showError(
  //         'Please select a Tag before choosing a file.'
  //       );
  //       return;
  //     }

  //     if (!this.selectedFile) {
  //       this.toastService.showError('Please upload a file first.');
  //       return;
  //     }
  //   } else {

  //     if (!this.selectedFile) {
  //       this.toastService.showError(
  //         'No file available for reprocessing. Please upload again.'
  //       );
  //       return;
  //     }
  //   }

  //   // Start Loader
  //   this.ngZone.run(() => {
  //     this.showLoaderGif = true;
  //   });

  //   try {
  //     /** 1️⃣ Generate ZIP File */
  //     this.zipBlob = await this.generateZip(this.uploadedFile);

  //     /** 2️⃣ Build Final JSON Metadata */
  //     this.finalJSON = {
  //       fields: this.templateheader,
  //       metadata: {
  //         a_session_seqno: '',
  //         a_iud_seqno: '',
  //         a_is_pen_flag: '',
  //         a_login_type: 'login_id',
  //         a_user_code: this.localUserData.user_code,
  //         a_user_level: this.localUserData.user_level,
  //         a_module_type_code: this.dynaUserData.default_module_type_code,
  //         a_sub_module_type_code:
  //           this.dynaUserData.default_sub_module_type_code ?? "R",
  //         a_entity_code: this.dynaUserData.entity_code,
  //         a_client_code: this.dynaUserData.client_code,
  //         a_acc_year: this.dynaUserData.default_acc_year,
  //         a_quarter_no: this.dynaUserData.default_quarter_no,
  //         a_tran_month: this.dynaUserData.default_tran_month,
  //         a_tran_from_date: this.dynaUserData.default_from_date,
  //         a_tran_to_date: this.dynaUserData.default_to_date,
  //         a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //         a_validation_client_level: this.dynaUserData.client_code_level,
  //         a_first_level_client_code:
  //           this.dynaUserData.first_level_client_code,
  //         a_process_seqno: "",
  //         a_iud_type: 'i',
  //         a_template_process_type:
  //           this.selectedTemplateData.template_process_type,
  //         a_proc_type: 'get_tiud_import_tran',
  //         a_db_total_records: '1000',
  //         a_pagination_count: '0',
  //         a_process_status_code: 'TA',
  //         a_template_based_on: this.selectedTemplateData.template_based_on,
  //         a_stream_code: `#${this.mystreamCode}#`,
  //         a_import_type: 'A',
  //         a_template_code: this.selectedTemplateData.template_code,
  //         a_upload_file_name: this.selectedFile?.name || '',
  //         a_no_of_process: this.selectedTemplateData.no_of_process,
  //         record_insert_flag: 'S',
  //         a_template_tds_type_code: this.dynaUserData.default_tds_type_code,
  //         import_tran: [
  //           {
  //             text_file: this.selectedFile?.name || '',
  //             header_file_template_code:
  //               this.selectedTemplateData.template_code,
  //             text_file_delimeter:
  //               this.selectedTemplateData.template_file_delimeter,
  //             text_file_date_format:
  //               this.selectedTemplateData.template_file_date_format,
  //             template_file_type:
  //               this.selectedTemplateData.template_file_type,
  //             text_file_os_platform:
  //               this.selectedTemplateData.template_file_os_platform,
  //             text_file_skip_records:
  //               this.selectedTemplateData.template_file_skip_records,
  //           },
  //         ],
  //       },
  //       data: {
  //         compute: this.selectedTemplateData.sl_arr[0][0].compute,
  //         allowedExt: this.selectedTemplateData.sl_arr[0][0].allowedExt,
  //         sl_row_count: this.selectedTemplateData.sl_arr[0][0].sl_row_count,
  //         sl_chunk_size: this.selectedTemplateData.sl_arr[0][0].sl_chunk_size,
  //         statusArr: this.selectedTemplateData.sl_arr[0][0].statusArr,
  //       },
  //     };

  //     this.stored_template_process_type =
  //       this.selectedTemplateData.template_process_type;
  //     this.stored_no_of_process = this.selectedTemplateData.no_of_process;
  //     this.stored_template_based_on = this.selectedTemplateData.template_based_on;
  //     this.stored_template_code = this.selectedTemplateData.template_code;

  //     const jsonBlob = new Blob(
  //       [JSON.stringify(this.finalJSON, null, 2)],
  //       { type: 'application/json' }
  //     );

  //     // // saveAs(this.zipBlob, "debug_myFiles.zip");
  //     saveAs(jsonBlob, 'debug_myFiles.json');
  //     /** 3️⃣ Validate ZIP + JSON Before Upload */
  //     const validation = await this.apiservice.validateExcelAndJson(
  //       this.zipBlob,
  //       jsonBlob
  //     );

  //     if (validation?.status !== '0') {
  //       if (validation?.missingHeaders?.length) {
  //         this.toastService.showError(
  //           `Missing Headers: ${validation.missingHeaders.join(', ')}`
  //         );
  //       } else {
  //         this.toastService.showError(validation?.message || 'Header validation failed!');
  //       }

  //       this.showLoaderGif = false;
  //       return;
  //     }


  //     // if (validation?.status !== '1') {
  //     //   if (validation?.missingHeaders?.length) {
  //     //     this.toastService.showError(
  //     //       `Missing Headers: ${validation.missingHeaders.join(', ')}`
  //     //     );
  //     //   } else {
  //     //     this.toastService.showError(validation?.message || 'Header validation failed!');
  //     //   }

  //     //   this.showLoaderGif = false;
  //     //   return;
  //     // }

  //     if (validation?.status !== "0") {
  //       this.toastService.showError(
  //         validation?.missingHeaders?.length
  //           ? `Missing Headers: ${validation.missingHeaders.join(", ")}`
  //           : (validation?.message || "Header validation failed.")
  //       );
  //       return;
  //     }


  //     /** 4️⃣ Upload ZIP + JSON Only After Validation */
  //     const uploadResponse = await this.apiservice.uploadZipAndJson(
  //       this.zipBlob,
  //       jsonBlob,
  //       this.dynaUserData.client_code,
  //       this.dynaUserData.user_code,
  //       this.selectedFile.name
  //     );
  //     this.a_process_seqno = uploadResponse.process_No;
  //     this.refnumber = uploadResponse.process_No;
  //     this.selectedTab = 'Verify';
  //     this.selectedProcess = 'Process 1';
  //     this.startProcessCheck();

  //   } catch (err) {
  //     console.error(err);
  //     this.toastService.showError('Something went wrong! Please try again.');
  //   }

  //   this.showLoaderGif = false;
  // }



  isZipFile(file: File): boolean {
    return file && file.name.toLowerCase().endsWith('.zip');
  }

  async processFile() {
    const isStreamApplicable = this.streamApplicableFlag === 'Y';
    const isFirstUpload = this.selectedTab === 'Upload';

    // ====== VALIDATIONS ======
    if (isFirstUpload) {
      if (this.selectedTemplate === 'Select Template') {
        this.toastService.showError('Please select a Template.');
        return;
      }

      if (isStreamApplicable && this.selectedApplyTag === 'Select Tag') {
        this.toastService.showError('Please select a Tag before choosing a file.');
        return;
      }

      if (!this.selectedFile) {
        this.toastService.showError('Please upload a file first.');
        return;
      }
    } else {
      if (!this.selectedFile) {
        this.toastService.showError('No file available for reprocessing. Please upload again.');
        return;
      }
    }

    // ====== START LOADER ======
    this.ngZone.run(() => (this.showLoaderGif = true));

    try {

      if (this.isZipFile(this.selectedFile)) {

        this.zipBlob = this.selectedFile; // no generateZip
      } else {

        this.zipBlob = await this.generateZip(this.uploadedFile);
      }


      /** 2️⃣ Build Final JSON Metadata */
      this.finalJSON = {
        fields: this.templateheader,
        metadata: {
          a_session_seqno: '',
          a_iud_seqno: '',
          a_is_pen_flag: '',
          a_login_type: 'login_id',
          a_user_code: this.localUserData.user_code,
          a_user_level: this.localUserData.user_level,
          a_module_type_code: this.dynaUserData.default_module_type_code,
          a_sub_module_type_code:
            this.dynaUserData.default_sub_module_type_code ?? "R",
          a_entity_code: this.dynaUserData.entity_code,
          a_client_code: this.dynaUserData.client_code,
          a_acc_year: this.dynaUserData.default_acc_year,
          a_quarter_no: this.dynaUserData.default_quarter_no,
          a_tran_month: this.dynaUserData.default_tran_month,
          a_tran_from_date: this.dynaUserData.default_from_date,
          a_tran_to_date: this.dynaUserData.default_to_date,
          a_tds_type_code: this.dynaUserData.default_tds_type_code,
          a_validation_client_level: this.dynaUserData.client_code_level,
          a_first_level_client_code: this.dynaUserData.first_level_client_code,
          a_process_seqno: "",
          a_iud_type: 'i',
          a_template_process_type: this.selectedTemplateData.template_process_type,
          a_proc_type: 'get_tiud_import_tran',
          a_db_total_records: '1000',
          a_pagination_count: '0',
          a_process_status_code: 'TA',
          a_template_based_on: this.selectedTemplateData.template_based_on,
          a_stream_code: `#${this.mystreamCode}#`,
          a_import_type: 'A',
          a_template_code: this.selectedTemplateData.template_code,
          a_upload_file_name: this.selectedFile?.name || '',
          a_no_of_process: this.selectedTemplateData.no_of_process,
          record_insert_flag: 'S',
          a_template_tds_type_code: this.dynaUserData.default_tds_type_code,
          import_tran: [
            {
              text_file: this.selectedFile?.name || '',
              header_file_template_code: this.selectedTemplateData.template_code,
              text_file_delimeter:
                this.selectedTemplateData.template_file_delimeter,
              text_file_date_format:
                this.selectedTemplateData.template_file_date_format,
              template_file_type:
                this.selectedTemplateData.template_file_type,
              text_file_os_platform:
                this.selectedTemplateData.template_file_os_platform,
              text_file_skip_records:
                this.selectedTemplateData.template_file_skip_records,
            },
          ],
        },
        data: {
          compute: this.selectedTemplateData.sl_arr[0][0].compute,
          allowedExt: this.selectedTemplateData.sl_arr[0][0].allowedExt,
          sl_row_count: this.selectedTemplateData.sl_arr[0][0].sl_row_count,
          sl_chunk_size: this.selectedTemplateData.sl_arr[0][0].sl_chunk_size,
          statusArr: this.selectedTemplateData.sl_arr[0][0].statusArr,
        },
      };

      this.stored_template_process_type = this.selectedTemplateData.template_process_type;
      this.stored_no_of_process = this.selectedTemplateData.no_of_process;
      this.stored_template_based_on = this.selectedTemplateData.template_based_on;
      this.stored_template_code = this.selectedTemplateData.template_code;

      const jsonBlob = new Blob(
        [JSON.stringify(this.finalJSON, null, 2)],
        { type: 'application/json' }
      );

      // saveAs(jsonBlob, 'debug_myFiles.json');

      /** 3️⃣ Validate Before Upload */
      const validation = await this.apiservice.validateExcelAndJson(
        this.zipBlob,
        jsonBlob
      );

      if (validation?.status !== "0") {
        this.toastService.showError(
          validation?.missingHeaders?.length
            ? `Missing Headers: ${validation.missingHeaders.join(", ")}`
            : (validation?.message || "Header validation failed.")
        );
        this.showLoaderGif = false;
        return;
      }

      /** 4️⃣ Upload ZIP + JSON */
      const uploadResponse = await this.apiservice.uploadZipAndJson(
        this.zipBlob,
        jsonBlob,
        this.dynaUserData.client_code,
        this.dynaUserData.user_code,
        this.selectedFile.name
      );

      this.a_process_seqno = uploadResponse.process_No;
      this.refnumber = uploadResponse.process_No;
      this.selectedTab = 'Verify';
      this.selectedProcess = 'Process 1';
      this.startProcessCheck();

    } catch (err) {
      console.error(err);
      this.toastService.showError('Something went wrong! Please try again.');
    }

    this.showLoaderGif = false;
  }






  reprocessFisrt(key?: string) {
    this.showLoaderGif = true;
    this.isProcessing = true;
    this.selectedTab = 'Verify';
    this.selectedProcess = 'Process 1';
    if (key) {
      for (const rowId in this.selectedRows) {
        const flag = this.selectedRows[rowId];
        this.SkipRecords(Number(rowId), flag);
      }
      this.templateInsertApi();
    } else {
      this.templateInsertApi();
    }

  }
  ProcessFileTwo(key?: string) {
    this.showLoaderGif = true;
    this.isProcessing = true;
    this.selectedTab = 'Verify';
    this.selectedProcess = 'Process 2';

    if (key) {
      for (const rowId in this.selectedRows) {
        const flag = this.selectedRows[rowId];
        this.SkipRecords(Number(rowId), flag);
      }
      this.templateInsertApi();
    } else {
      this.templateInsertApi();
    }
  }
  ProcessFileThree() {
    this.showLoaderGif = true;
    this.isProcessing = true;
    this.selectedTab = 'Verify';
    this.selectedProcess = 'Process 3';
    this.templateInsertApi();
  }

  nextProcess() {
    if (this.selectedProcess === 'Process 1') {
      this.ProcessFileTwo();
    } else if (this.selectedProcess === 'Process 2') {
      this.ProcessFileThree();
    } else if (this.selectedProcess === 'Process 3') {
    }
  }

  RefreshData(key: string) {
    if (this.selectedProcess === 'Process 1') {
      this.reprocessFisrt(key);
      // console.log('one');
    } else if (this.selectedProcess === 'Process 2') {
      // this.ProcessFileThree();
      this.ProcessFileTwo(key);
    } else if (this.selectedProcess === 'Process 3') {
      this.ProcessFileThree();
    }
  }

  myIUDType: string = '';
  templateInsertApi() {
    if (this.selectedProcess === 'Process 1') {
      this.myIUDType = 'FIRST';
    }
    else if (this.selectedProcess === 'Process 2') {
      this.myIUDType = 'SECOND';
    } else if (this.selectedProcess === 'Process 3') {
      this.myIUDType = 'THIRD';
    }

    const sdata = this.apiservice.generateSData(
      'proc_template_insert',
      this.dynaUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        teplateProcessType: this.stored_template_process_type,
        iudtype: this.myIUDType,
        seqnumber: this.a_process_seqno,
        import_template: this.myrowIdFromChild
      }
    );
    this.apiservice
      .getTableDatatwo('/dynamic-import/proc_template_insert', sdata, 'text')
      .subscribe({
        next: (data) => {
          console.log(data)
          this.startPolling();
        },
        error: (err) => {
          this.toastService.showError(err.message || 'Insert failed.');
          this.showLoaderGif = false;
          this.isProcessing = false;
        },
      });
  }

  formatBytes(bytes: number): string {
    const kb = bytes / 1024;
    return `${kb.toFixed(0)} KB`;
  }

  getFileExtension(fileName: string): string {
    const ext = fileName.split('.').pop()?.toLowerCase();
    if (ext === 'zip') return 'ZIP';
    if (ext === 'txt') return 'TXT';
    return ext ? ext.toUpperCase() : 'UNKNOWN';
  }

  getReadableFileSize(sizeInBytes: number): string {
    if (sizeInBytes === 0) return '0 Bytes';
    const units = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const index = Math.floor(Math.log(sizeInBytes) / Math.log(1024));
    const size = sizeInBytes / Math.pow(1024, index);
    return `${size.toFixed(2)} ${units[index]}`;
  }



  a_process_seqno: any;
  // getTemplateOptions() {
  //   const requestBody = {
  //     a_proc_type: 'get_gmlb_template_config_head',
  //     a_user_code: this.localUserData.user_code,
  //     a_entity_code: this.localUserData.entity_code,
  //     a_client_code: this.dynaUserData.client_code,
  //     a_acc_year: this.dynaUserData.default_acc_year,
  //     a_quarter_no: this.dynaUserData.default_quarter_no,
  //     a_tran_month: this.dynaUserData.default_tran_month,
  //     a_validation_client_level: this.dynaUserData.client_code_level,
  //     a_tran_from_date: this.dynaUserData.default_from_date,
  //     a_tran_to_date: this.dynaUserData.default_to_date,
  //     a_tds_type_code: this.dynaUserData.default_tds_type_code,
  //     a_module_type_code: this.localUserData.default_module_type_code,
  //     a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
  //     a_first_level_client_code: this.dynaUserData.first_level_client_code,
  //     a_user_level: this.localUserData.user_level,
  //     a_client_code_level: this.dynaUserData.client_code_level,
  //     a_process_status_code: '',
  //     a_filter_clause: '',
  //     a_template_based_on: '',
  //     a_template_type: '',
  //   };

  //   this.apiservice
  //     .getsingleDetails(
  //       '/dynamic-import/get_gmlb_template_config_head',
  //       requestBody
  //     )
  //     .subscribe({
  //       next: (response) => {
  //         console.log(response);
  //         const templateconfig =
  //           response?.result?.get_gmlb_template_config_head;
  //         // this.templateOptions = templateconfig;
  //         const moduleType = this.dynaUserData?.default_sub_module_type_code;
  //         console.log(moduleType)

  //         if (moduleType == 'G') {
  //           // Show only templates of type G
  //           this.templateOptions = templateconfig.filter(
  //             (item: any) => item.sub_module_type_code === 'G'
  //           );
  //         } else if (moduleType == 'R' || moduleType == null || moduleType === '') {

  //           this.templateOptions = templateconfig.filter(
  //             (item: any) =>
  //               item.sub_module_type_code === 'R'
  //           );
  //         } else {

  //           this.templateOptions = templateconfig;
  //         }


  //         // this condtion for quaryparams
  //         if (this.templateCodeFromUrl) {
  //           const foundTemplate = this.templateOptions.find(
  //             (t: any) => t.template_code === this.templateCodeFromUrl
  //           );

  //           if (foundTemplate) {
  //             this.selectTemplate(foundTemplate);


  //             this.router.navigate([], {
  //               queryParams: {},
  //               replaceUrl: true,
  //             });
  //           }
  //         }

  //       },
  //       error: () => {
  //         this.toastService.showError('Failed to fetch .');
  //       },
  //     });
  // }


  getTemplateOptions() {
    this.isLoading = true;

    const requestBody = {
      a_proc_type: 'get_gmlb_template_config_head',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? 'R',
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_user_level: this.localUserData.user_level,
      a_client_code_level: this.dynaUserData.client_code_level,
      a_process_status_code: '',
      a_filter_clause: '',
      a_template_based_on: '',
      a_template_type: '',
    };

    this.apiservice
      .getsingleDetails('/dynamic-import/get_gmlb_template_config_head', requestBody)
      .subscribe({
        next: (response) => {
          this.isLoading = false;
          // console.log(response);
          if (response?.result?.a_proc_error == 0) {
            const templateconfig = response?.result?.get_gmlb_template_config_head || [];
            const moduleType = this.dynaUserData?.default_sub_module_type_code;
            console.log(moduleType);


            if (moduleType === 'G') {
              this.templateOptions = templateconfig.filter(
                (item: any) => item.sub_module_type_code === 'G'
              );
            } else if (moduleType === 'R' || !moduleType) {
              this.templateOptions = templateconfig.filter(
                (item: any) => item.sub_module_type_code === 'R'
              );
            } else {
              this.templateOptions = templateconfig;
            }
            if (this.templatePreselectedFromUrl) {
              const foundTemplate = this.templateOptions.find(
                (t: any) => t.template_code === this.templateCodeFromUrl
              );

              if (foundTemplate) {
                this.selectTemplate(foundTemplate);
                this.router.navigate([], {
                  queryParams: {},
                  replaceUrl: true,
                });
              }
            }
          } else {

            this.errorMessage =
              response?.result?.a_proc_error_message || 'Unknown error occurred.';
            this.toastService.showError(this.errorMessage);
          }
        },
        error: (err) => {
          this.isLoading = false;
          this.errorMessage = err.message || 'Failed to fetch template options.';
          this.toastService.showError(this.errorMessage);
        },
      });
  }
  errorMessage: any;
  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }
  processMessage: string = '';
  processCheckSub: Subscription | null = null;
  processStatus: string = '';
  isProcessing: boolean = false;
  startProcessCheck() {
    this.isProcessing = true;
    if (!this.processStatus) {
      this.processStatus = 'P1';
      this.processMessage = 'Process Started';
    }
    this.processCheckSub = interval(1000)
      .pipe(
        switchMap(() =>
          this.apiservice.checkProcessStatus(this.dynaUserData.user_code)
        )
      )
      .subscribe({
        next: (res: any) => {
          if (!res || !res.status) {
            this.processStatus = 'P1';
            this.processMessage = 'Process Started';
          } else {
            this.updateProcessStatus(res);
          }
        },
        error: (err) => {
          console.error('Process check failed', err);
          this.toastService.showError('Error checking process!');
          this.stopProcessCheck();
        },
      });
  }
  updateProcessStatus(res: any) {
    if (!res) return;
    const status = res.status;

    let msgText = '';

    switch (status) {
      case 'P1':
        this.processStatus = 'P1';
        this.processMessage = 'Process Started';
        break;

      case 'P2':
        this.processStatus = 'P2';
        this.processMessage = '';
        break;

      case 'P3':
        this.processStatus = 'P3';
        this.processMessage = '';
        this.stopProcessCheck();
        this.startPolling();
        break;
      case 'E1':
        this.processStatus = 'E1';
        this.processMessage = `Error during validation! ${msgText}`;
        this.stopProcessCheck();
        break;
      default:
        this.processStatus = 'P1';
        this.processMessage = 'Process Started';
    }
  }
  stopProcessCheck() {
    this.isProcessing = false;
    this.showLoaderGif = false;
    if (this.processCheckSub) {
      this.processCheckSub.unsubscribe();
      this.processCheckSub = null;
    }
  }
  filterClause: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  FYYear: string = 'Yes';
  pollingInterval: any;
  startPolling() {
    this.getStatus();
    this.pollingInterval = setInterval(() => {
      this.getStatus();
    }, 5000);
  }

  startStatusPolling() {
    this.pollingInterval = setInterval(() => {
      this.getStatus();
    }, 5000);
  }


  getStatus() {
    const sdata = this.apiservice.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
        seqnumber: this.a_process_seqno,
      }
    );

    this.apiservice
      .getTableData('/dynamic-import/proc_utilf_get_process_seqno_status', sdata)
      .subscribe({
        next: (data) => {
          const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
          const statusCode = row?.process_status_code;
          const lastChar = statusCode?.slice(-1);
          this.processStatusCode = statusCode;
          this.a_process_seqno = row?.process_seqno;
          this.refnumber = row?.process_seqno;
          this.templateFilename = row?.text_file1;
          this.templateFile = row?.template_name;
          this.processlogtxt = row?.process_log_text;
          this.extensionfile = this.templateFilename
            ? this.templateFilename.split('.').pop()
            : '';
          this.templateCode = row?.template_code;



          const expectedCharsMap: Record<string, string[]> = {
            'Process 1': ['B', 'C'],
            'Process 2': ['E', 'F'],
            'Process 3': ['H', 'I', 'K', 'L'],
          };

          const expectedChars = expectedCharsMap[this.selectedProcess] || [];

          if (expectedChars.includes(lastChar)) {
            console.log(
              `✅ Expected status '${statusCode}' (ending with '${lastChar}') received for ${this.selectedProcess}`
            );

            this.getErrorDb();
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
            this.isProcessing = false;
            this.showLoaderGif = false;
            // ✅ Handle finish condition based on last char
            if (lastChar === 'I') {
              this.selectedProcess = 'Process 4';
              this.selectedTab = 'Finish';
              this.getStatics();
              // console.log('TI (ends with I) detected → navigating to Process 4 & Finish tab');
            }
          } else {
            console.log(
              `⏳ Still waiting for codes ending with [${expectedChars.join(', ')}], current: '${statusCode}'`
            );
          }

          // ✅ Handle API-level error
          if (data?.result?.a_proc_error) {
            const errorMsg = data.result.a_proc_error_message || 'Unknown error';
            this.toastService.showError(errorMsg);
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
          }
        },
        error: (err) => {
          this.toastService.showError(err.message || 'Failed to fetch status.');
          clearInterval(this.pollingInterval);
          this.pollingInterval = null;
        },
      });
  }
  tableRecords: any[] = [];
  getErrorDb() {
    const lastChar = this.processStatusCode?.slice(-1);

    if (['C', 'B'].includes(lastChar)) {
      this.iudtypeError = 'FIRST';
    } else if (['E', 'F'].includes(lastChar)) {
      this.iudtypeError = 'SECOND';
    } else if (['H', 'I'].includes(lastChar)) {
      this.iudtypeError = 'THIRD';
    }
    const sdata = this.apiservice.generateSData(
      'get_gtdb_import_tran_bulk_tds_error',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtypeError,
        seqnumber: this.a_process_seqno,
        refnumber: this.refnumber || '',
      }
    );

    this.apiservice
      .getTableData(
        '/dynamic-import/get_gtdb_import_tran_bulk_tds_error',
        sdata
      )
      .subscribe({
        next: (data) => {
          console.log(data)
          if (data?.result?.a_proc_error == 0) {
            const userData = data.result?.get_gtdb_import_tran_bulk_tds_error;
            // this.isErrorGrandTotal = userData?.a_grand_total_error_rec ?? 0;
            // console.log(this.isErrorGrandTotal)
            this.isErrorGrandTotal = Number(userData?.a_grand_total_error_rec ?? 0);

            const firstDetail =
              userData?.get_gtdb_import_tran_bulk_tds_error_detail?.[0] || {};
            this.errorRecord = firstDetail.total_rec || 0;
            // console.log(this.errorRecord, "Error Record");
            this.errorTotalrecords = firstDetail.total_erec || 0;

            const errorDetails =
              userData?.get_gtdb_import_tran_bulk_tds_error_detail || [];

            this.tableRecords = errorDetails.map((row: any) => {
              return {
                rowid_seq: row.rowid_seq,
                validation_error_name: row.validation_error_name,
                total_rec: row.total_rec,
                total_erec: row.total_erec,
                process_db_required: row.process_db_required,
                process_skip_required: row.process_skip_required,
                process_skip_flag: row.process_skip_flag,
                process_fixit_required: row.process_fixit_required,
                tanno_str: row.tanno_str,
              };
            });
          } else {
            // this.loading = false;
            this.errorMessage = data?.result[0]?.a_proc_error_message;
            this.toastService.showError(this.errorMessage);
          }
          // this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch Data.';
          this.toastService.showError(this.errorMessage);
          // this.loading = false;
          // this.isLoadingMore = false;
        },
      });
  }
  getProceseqs() {
    this.isLoading = true;
    const sdata = this.apiservice.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'get_tiud_import_tran',
        ...(this.passCode ? { passCode: this.passCode } : {})

      }
    );

    this.apiservice
      .getTableData('/dynamic-import/proc_utilf_get_process_seqno_status', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            console.log(data)
            const row = data?.result?.proc_utilf_get_process_seqno_status?.[0];
            this.a_process_seqno = row?.process_seqno;
            this.refnumber = row?.process_seqno;
            const statusCode = row?.process_status_code;
            const lastChar = statusCode?.slice(-1);
            this.processlogtxt = row?.process_log_text;
            this.processStatusCode = statusCode;
            this.templateFilename = row?.text_file1;
            this.templateFile = row?.template_name;
            this.extensionfile = this.templateFilename
              ? this.templateFilename.split('.').pop()
              : '';
            this.templateCode = row?.template_code;
            this.stored_template_process_type = row?.template_process_type;
            this.stored_no_of_process = row?.no_of_process;
            this.stored_template_based_on = row?.template_based_on,
              this.stored_template_code = row?.template_code;

            switch (lastChar) {
              case 'B':
              case 'C':
                this.selectedProcess = 'Process 1';
                this.selectedTab = 'Verify';
                this.getErrorDb();
                break;

              case 'E':
              case 'F':
                this.selectedProcess = 'Process 2';
                this.selectedTab = 'Verify';
                this.getErrorDb();
                break;

              case 'H':
              case 'I':
                this.selectedTab = 'Finish';
                this.getStatics();
                break;

              case 'K':
              case 'L':
                this.selectedProcess = 'Process 3';
                this.selectedTab = 'Verify';
                this.getErrorDb();
                break;



              case 'N':
              case 'O':
                this.selectedProcess = 'Process 3';
                this.selectedTab = 'Verify';
                this.getErrorDb();
                break;

              case 'Q':
              case 'R':
                this.selectedProcess = 'Process 3';
                this.selectedTab = 'Verify';
                this.getErrorDb();
                break;



              case 'A':
              case 'Z':

                // this.selectedProcess = '';
                // this.selectedTab = 'Upload';
                break;
              default:
                this.selectedProcess = '';
                this.selectedTab = 'Upload';
                break;
            }
          } else {
            this.errorMessage = data.result[0].a_proc_error_message;
            this.toastService.showError(this.errorMessage);
          }

          this.isLoading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch Data.';
          this.toastService.showError(this.errorMessage);
          this.isLoading = false;
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }


  isExpanded: boolean = false;
  toggleDetails(): void {
    this.isExpanded = !this.isExpanded;
  }
  onCheckboxChange(event: any, rowId: number): void {
    const isChecked = event.target.checked;
    console.log(`Row ${rowId} checkbox value: ${event.target.checked}`);
    this.selectedRows[rowId] = isChecked ? 'Y' : 'N';
  }



  isDeletePopupOpen: boolean = false;
  openAlert() {
    this.isDeletePopupOpen = true;
  }

  expandedRows = new Set<number>();
  myCodeforDelete: string = '';
  isDeleting: boolean = false;

  handleDeleteConfirm() {
    this.isDeletePopupOpen = false;
    this.runKillSequence();
  }

  handleDeleteCancel() {
    this.isDeletePopupOpen = false;

  }

  runKillSequence() {
    this.isProcessing = true;
    this.isDeleting = true;
    const prefix = this.processStatusCode?.startsWith('L') ? 'L' : 'T';
    const lastChar = this.processStatusCode?.slice(-1);

    // if (['TC', 'TB'].includes(this.processStatusCode)) {
    //   this.iudtypeError = 'FIRST';
    //   this.processStatusCode = 'ZK';
    // } else if (['TE', 'TF'].includes(this.processStatusCode)) {
    //   this.iudtypeError = 'SECOND';
    //   this.processStatusCode = 'TD';
    // } else if (['TH', 'TI'].includes(this.processStatusCode)) {
    //   this.iudtypeError = 'THIRD';
    //   this.processStatusCode = 'TG';
    // }

    // if (this.selectedProcess === 'Process 1') {
    //   this.myCodeforDelete = 'ZK';
    // } else if (this.selectedProcess === 'Process 2') {
    //   this.myCodeforDelete = 'TC';
    // } else if (this.selectedProcess === 'Process 3') {
    //   this.myCodeforDelete = 'TF';
    // }


    switch (lastChar) {
      case 'B':
      case 'C':
        this.iudtypeError = 'FIRST';
        this.processStatusCode = 'ZK';
        break;

      case 'E':
      case 'F':
        this.iudtypeError = 'SECOND';
        this.processStatusCode = `${prefix}D`;
        break;

      case 'H':
      case 'I':
        this.iudtypeError = 'THIRD';
        this.processStatusCode = `${prefix}G`;
        break;

      default:
        this.iudtypeError = '';
        this.processStatusCode = `${prefix}Z`;
        break;
    }
    switch (this.selectedProcess) {
      case 'Process 1':
        this.myCodeforDelete = 'ZK';
        break;
      case 'Process 2':
        this.myCodeforDelete = `${prefix}C`; // TC/LC
        break;
      case 'Process 3':
        this.myCodeforDelete = `${prefix}F`; 
        break;
      default:
        this.myCodeforDelete = `${prefix}Z`;
        break;
    }




    const processType = this.stored_template_process_type?.toLowerCase() || 'excel_tdsb';
    const apiName = `get_gtdb_import_template_statitics_${processType}`;
    // Payloads
    const sdataKill = this.apiservice.generateSData(
      'get_tiud_import_tran',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'PROCESS_STATUS_UPDATE',
        processStatusCode: this.processStatusCode,
        seqnumber: this.a_process_seqno,
      }
    );

    const sdataTemplate = this.apiservice.generateSData(
      apiName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtypeError,
        processStatusCode: this.myCodeforDelete,
        refnumber: this.a_process_seqno,
      }
    );

    const sdataFinalCancel = this.apiservice.generateSData(
      'get_tiud_import_tran',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'PROCESS_CANCEL',
        processStatusCode: this.myCodeforDelete,
        seqnumber: this.a_process_seqno,
      }
    );

    // Helper functions
    const getProcError = (res: any) => {
      if (!res?.result) return 1;
      if (Array.isArray(res.result))
        return Number(res.result[0]?.a_proc_error || 1);
      if (typeof res.result === 'object')
        return Number(res.result.a_proc_error || 1);
      return 1;
    };

    const getProcErrorMsg = (res: any, defaultMsg: string) => {
      if (!res?.result) return defaultMsg;
      if (Array.isArray(res.result))
        return res.result[0]?.a_proc_error_message || defaultMsg;
      return res.result?.a_proc_error_message || defaultMsg;
    };

    // Sequential API calls
    this.apiservice
      .miudApi('/Transaction/get_tiud_import_tran', sdataKill)
      .pipe(
        concatMap((killRes) => {
          if (getProcError(killRes) !== 0)
            return throwError(
              () => new Error(getProcErrorMsg(killRes, 'Kill process failed'))
            );
          return this.getProceseq$();
        }),

        concatMap((seqRes) => {
          if (getProcError(seqRes) !== 0)
            return throwError(
              () =>
                new Error(
                  getProcErrorMsg(seqRes, 'Get process sequence failed')
                )
            );
          return this.apiservice.miudApi(
            '/Comman/dynamic',
            sdataTemplate
          );
        }),

        concatMap((templateRes) => {
          return this.apiservice.miudApi(
            '/Transaction/get_tiud_import_tran',
            sdataFinalCancel
          );
        }),

        concatMap((finalRes) => {
          if (getProcError(finalRes) !== 0)
            return throwError(
              () => new Error(getProcErrorMsg(finalRes, 'Final cancel failed'))
            );

          // let attempts = 0;
          // const maxAttempts = 12;
          // const pollInterval = 5000;
          // return interval(pollInterval).pipe(
          //   concatMap(() => this.getProceseq$()),
          //   takeWhile((seq) => {
          //     attempts++;
          //     console.log(seq)

          //     this.processlogtxt = seq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_log_text
          //     const code =
          //       seq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
          //       seq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;
          //     const isComplete = !code || ['ZK', 'TC', 'TF', 'TG'].includes(code);
          //     return !isComplete && attempts < maxAttempts;
          //   }, true),
          //   tap((finalSeq) => {
          //     const code =
          //       finalSeq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
          //       finalSeq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;
          //     if (!code || ['ZK', 'TC', 'TF', 'TG'].includes(code)) {
          //       this.toastService.showSuccess('Process Delete successfully.');
          //       this.resetFileState();
          //     } else if (attempts >= maxAttempts) {
          //       this.toastService.showError(
          //         'Process did not complete within expected time, please try again.'
          //       );
          //     }
          //   })
          // );

          let attempts = 0;
          const maxAttempts = 12;
          const pollInterval = 5000;

          return interval(pollInterval).pipe(
            concatMap(() => this.getProceseq$()),
            takeWhile((seq) => {
              attempts++;
              console.log(seq);

              this.processlogtxt =
                seq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_log_text || '';
              const code =
                seq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
                seq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;
              const lastChar = code ? code.slice(-1) : '';
              const isKilled =
                !seq?.result?.proc_utilf_get_process_seqno_status ||
                seq?.result?.proc_utilf_get_process_seqno_status === null;
              const isComplete =
                isKilled || !code || ['K', 'C', 'F', 'G'].includes(lastChar);

              return !isComplete && attempts < maxAttempts;
            }, true),
            tap((finalSeq) => {
              const code =
                finalSeq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
                finalSeq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;
              const lastChar = code ? code.slice(-1) : '';

              const isKilled =
                !finalSeq?.result?.proc_utilf_get_process_seqno_status ||
                finalSeq?.result?.proc_utilf_get_process_seqno_status === null;

              if (isKilled || !code || ['K', 'C', 'F', 'G'].includes(lastChar)) {
                this.toastService.showSuccess('Process deleted successfully.');
                this.resetFileState();
              } else if (attempts >= maxAttempts) {
                this.toastService.showError(
                  'Process did not complete within expected time, please try again.'
                );
              }
            })
          );


        }),

        finalize(() => {
          this.isProcessing = false;
          this.isDeleting = false;
        }),

        catchError((err) => {
          this.isProcessing = false;
          this.toastService.showError(err?.message || 'Sequence failed');
          return of(null);
        })
      )
      .subscribe();
  }
  getProceseq$() {
    const prefix = this.processStatusCode?.startsWith('L') ? 'L' : 'T';

    if (this.selectedProcess === 'Process 1') {
      this.myCodeforDelete = 'ZK';
    } else if (this.selectedProcess === 'Process 2') {
      // this.processStatusCode = 'TC';
      this.processStatusCode = `${prefix}C`;
    } else if (this.selectedProcess === 'Process 3') {
      this.processStatusCode = `${prefix}F`;
      // this.processStatusCode = 'TF';
    }
    const sdata = this.apiservice.generateSData(
      'proc_utilf_get_process_seqno_status',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'get_tiud_import_tran',
        processStatusCode: this.myCodeforDelete,
      }
    );
    return this.apiservice
      .getTableData(
        '/dynamic-import/proc_utilf_get_process_seqno_status',
        sdata
      )
      .pipe(tap((res) => { }));
  }

  resetFileState() {
    if (this.selectedProcess === 'Process 1') {
      this.selectedTab = 'Upload';
      this.selectedProcess = '';
      this.isFileUploaded = false;
      this.selectedFile = null;
      this.uploadedFile = [];
      this.selectedFiles = [];
      this.isFileSelected = false;
      this.noError = false;
      this.selectedTemplate = 'Select Template';
      this.selectedApplyTag = 'Select Tag';
    } else if (this.selectedProcess === 'Process 2') {
      this.selectedTab = 'Verify';
      this.selectedProcess = 'Process 1';
      this.getErrorDb();
    } else if (this.selectedProcess === 'Process 3') {
      this.selectedTab = 'Verify';
      this.selectedProcess = 'Process 2';
      this.getErrorDb();
    }
  }


  toggleRow(row: any): void {
    row.isExpanded = !row.isExpanded;

    if (row.isExpanded && !row.details) {
      this.getErrorDbdynamic(row);
    }
  }

  // API call per row
  getErrorDbdynamic(row: any) {
    const sdata = this.apiservice.generateSData(
      'get_gtdb_import_tran_error_DIB_ERRPROC',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtypeError,
        refnumber: this.refnumber,
      }
    );

    this.apiservice
      .getTableData(
        '/dynamic-import/get_gtdb_import_tran_error_DIB_ERRPROC',
        sdata
      )
      .subscribe({
        next: (data) => {
          if (
            data?.result?.get_gtdb_import_tran_error_DIB_ERRPROC
              ?.get_gtdb_import_tran_error_DIB_ERRPROC_detail

          ) {

            row.details =
              data.result.get_gtdb_import_tran_error_DIB_ERRPROC.get_gtdb_import_tran_error_DIB_ERRPROC_detail;
          } else {
            this.toastService.showError('No details found for this row.');
          }
        },
        error: (err) => {
          this.toastService.showError(
            err.message || 'Failed to fetch row details.'
          );
        },
      });
  }


  selectedValidationErrorCode: string = ""
  isDrawerOpen: boolean = false;
  openDrawer(detail?: any) {
    this.isDrawerOpen = true;
    this.selectedValidationErrorCode = detail.validation_error_code;
  }

  closeDrawer() {
    this.isDrawerOpen = false;
  }




  private getTaglist(): void {
    const storedData = sessionStorage.getItem('headermaster');
    if (!storedData) return;
    const parsedData = JSON.parse(storedData);
    const allStreams = parsedData?.get_gmdt_stream_mast || [];

    const tdsType = this.dynaUserData?.default_tds_type_code?.trim();
    this.tagList = allStreams.filter((s: any) => s.tds_type_code === tdsType);
  }

  SkipRecords(rowId: number, flag: 'Y' | 'N') {
    console.log(rowId, flag);
    const sdata = {
      a_session_seqno: '',
      a_iud_seqno: '',
      a_process_seqno: '',
      a_login_type: 'login_id',
      a_iud_type: 'u',
      a_proc_type: 'get_tiud_import_tran_process_skip',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.localUserData.entity_code,
      a_client_code: this.localUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.localUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_sub_module_type_code: this.localUserData?.subModuleTypeCode ?? "R",
      a_user_level: this.localUserData.user_level,
      a_client_code_level: this.dynaUserData.client_code_level,
      a_template_based_on: this.stored_template_based_on,
      a_no_of_process: this.stored_no_of_process,
      a_process_status_code: 'ZA',
      record_insert_flag: 'S',
      a_template_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_db_total_records: '1000',
      a_pagination_count: '0',
      import_tran: [
        {
          rowid_seq: String(rowId),
          process_skip_flag: flag,
        },
      ],
    };

    this.apiservice
      .miudApi('/dynamic-import/get_tiud_import_tran_process_skip', sdata)
      .subscribe({
        next: (data) => {
          console.log(data, 'Skip Record API response');

        },
        error: (err) => {
          this.toastService.showError(
            err.message || 'Failed to fetch row details.'
          );
        },
      });
  }

  // get statics reports
  isLoading: boolean = false;
  staticData: any;
  data: any;
  getStatics() {
    this.isLoading = true;
    const processType = this.stored_template_process_type?.toLowerCase() || 'excel_tdsb';
    console.log(processType)
    const apiName = `get_gtdb_import_template_statitics_${processType}`;

    const sdata = this.apiservice.generateSData(
      apiName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: '',
        refnumber: this.refnumber || '',
      }
    );

    this.apiservice
      .getTableData('/Comman/dynamic', sdata)
      .subscribe({
        next: (data) => {
          this.isLoading = false;
          console.log(data);
          if (data?.result?.a_proc_error == 0) {
            const resultKey = apiName;
            console.log(resultKey)

            const resultData =
              data?.result?.[resultKey]?.[`${resultKey}_header`];

            this.staticData = resultData;

            this.data = resultData;
          } else {

            this.errorMessage =
              data?.result?.a_proc_error_message || 'Unknown error occurred.';
            this.toastService.showError(this.errorMessage);
          }
        },
        error: (err) => {
          this.isLoading = false;
          this.errorMessage = err.message || 'Failed to fetch row details.';
          this.toastService.showError(this.errorMessage);
        },
      });
  }

  // get report statics table nested
  getValueFromNestedChild(childs: any[], colRef: string): number {
    if (!childs) return 0;
    const found = childs.find((c: any) => c.headVal?.col_ref === colRef);
    return found?.headVal?.val ?? 0;
  }
  startOver() {
    this.selectedTab = 'Upload';
    this.selectedProcess = '';
    this.isFileUploaded = false;
    this.selectedFile = null;
    this.uploadedFile = [];
    this.selectedFiles = [];
    this.isFileSelected = false;
    this.noError = false;
    this.selectedTemplate = 'Select Template';
    this.selectedApplyTag = 'Select Tag';
  }
  // download reports
  async formatExcelReport(data: any) {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("TDS_BULK_IMPORT");

    // ===== TITLE =====
    const title = worksheet.addRow([data.statsTitle.main]);
    title.font = { size: 16, bold: true };
    title.alignment = { horizontal: "center" };

    // dynamic merge
    worksheet.mergeCells(
      `A${title.number}:${String.fromCharCode(64 + data.statsHead.keyPair.length + 2)}${title.number}`
    );

    const desc = worksheet.addRow([data.statsTitle.desc]);
    desc.font = { size: 12, italic: true };
    desc.alignment = { horizontal: "center" };

    worksheet.mergeCells(
      `A${desc.number}:${String.fromCharCode(64 + data.statsHead.keyPair.length + 2)}${desc.number}`
    );

    worksheet.addRow([""]);

    // ===== FILE INFO =====
    data.statsHead.keyPair.forEach((pair: any) => {
      const r = worksheet.addRow([pair.label, pair.value]);
      r.getCell(1).font = { bold: true };
    });

    worksheet.addRow([""]);

    // ===== MAIN BLOCK LOOP =====
    data.statsArr.forEach((block: any) => {

      // ===== SECTION HEADER =====
      const headerRow = worksheet.addRow([block.head.val]);

      headerRow.font = {
        bold: true,
        size: 14,
        color: { argb: block.head.color?.replace("#", "") || "FFFFFFFF" }
      };

      headerRow.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: block.head.bgcolor?.replace("#", "") || "FF0B2643" }
      };

      // ALIGN LEFT (FLEX: not centered)
      headerRow.alignment = { horizontal: "left" };

      const colCount = block.head.coloums_req.length + 1;
      const lastColLetter = String.fromCharCode(64 + colCount);

      worksheet.mergeCells(`A${headerRow.number}:${lastColLetter}${headerRow.number}`);

      // ===== TABLE HEADERS =====
      const tableHeaders = [
        "Details",
        ...block.head.coloums_req.map((c: any) => c.header_name),
      ];

      const headRow = worksheet.addRow(tableHeaders);
      headRow.font = { bold: true };
      headRow.alignment = { horizontal: "center" };

      headRow.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFF5F7FF" }
      };

      headRow.eachCell((cell) => {
        cell.border = {
          top: { style: "thin" },
          left: { style: "thin" },
          bottom: { style: "thin" },
          right: { style: "thin" },
        };
      });

      // ===== TABLE ROWS (NO DUPLICATES) =====
      block.childs.forEach((child: any) => {
        const nested = child.childs?.[0];   // FIX: Only take first entry, avoids repetition
        if (!nested) return;

        const rowData = [child.head.val];

        block.head.coloums_req.forEach((col: any) => {
          const val =
            nested.childs?.find((x: any) => x.field === col.field_name)?.val ?? '';

          // formatting
          if (col.field_name === "figure_01") {
            rowData.push(
              Number(val).toLocaleString("en-IN", { minimumFractionDigits: 0 })
            );
          } else {
            let formatted = Number(val).toLocaleString("en-IN", {
              minimumFractionDigits: 2,
            });
            rowData.push(`₹ ${formatted}`);
          }
        });

        const row = worksheet.addRow(rowData);

        row.getCell(1).alignment = { horizontal: "left" };
        for (let i = 2; i <= rowData.length; i++) {
          row.getCell(i).alignment = { horizontal: "right" };
        }

        row.eachCell((cell) => {
          cell.border = {
            top: { style: "thin", color: { argb: "FFCCCCCC" } },
            left: { style: "thin", color: { argb: "FFCCCCCC" } },
            bottom: { style: "thin", color: { argb: "FFCCCCCC" } },
            right: { style: "thin", color: { argb: "FFCCCCCC" } },
          };
        });
      });

      worksheet.addRow([""]); // GAP
    });

    // ===== AUTO-FIT COLUMNS =====
    worksheet.columns.forEach((col) => {
      let maxLength = 12;
      col.eachCell?.({ includeEmpty: true }, (cell) => {
        const v = cell.value ? cell.value.toString() : "";
        maxLength = Math.max(maxLength, v.length);
      });
      col.width = maxLength + 2;
    });

    // ===== EXPORT =====
    const buffer = await workbook.xlsx.writeBuffer();
    this.saveAsExcelFile(buffer, `TDS_Bulk_Import_Report.xlsx`);
  }




  private saveAsExcelFile(buffer: ArrayBuffer, fileName: string): void {
    const blob = new Blob([buffer], { type: 'application/octet-stream' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  }





  /// template download

  templates = [
    { name: 'All In One Transaction', url: '../../../../assets/temp/All In One Transaction.xlsx' },
    { name: 'Chalan', url: '../../../../assets/temp/Challan Import.xlsx' },
    { name: 'Lower Deduction Certificate', url: '../../../../assets/temp/Lower Deduction Certificate.xlsx' },
    { name: 'Pan Verification ', url: '../../../../assets/temp/Pan Verification.xlsx' },
    { name: 'Chalan Allocation', url: '../../../../assets/temp/Challan Allocation.xlsx' },
    { name: 'Deductee 15GH', url: '../../../../assets/temp/Deductee 15GH.xlsx' },
    // { name: 'Deductee 15GH', url: '../../../../assets/temp/Deductee 15GH.xlsx' },

  ];

  isModalOpen = false;

  openModal(): void {
    this.isModalOpen = true;
  }

  closeModal(): void {
    this.isModalOpen = false;
  }
  downloadTemplate(template: { name: string; url: string }) {
    const link = document.createElement('a');
    link.href = template.url;
    link.download = template.name + '.xlsx';
    link.click();
    this.isModalOpen = false;
  }
  formatProcessLogText(logText: string): string {
    if (!logText || !logText.includes('^')) {
      return logText;
    }

    const [message, datePart] = logText.split('^');
    const formattedDate = this.formatIndianDate(datePart.trim());

    return `${message.trim()} ^ ${formattedDate}`;
  }

  private formatIndianDate(dateStr: string): string {
    // Example input: "28-OCT-2025 05:10:27"
    const dateParts = dateStr.split(' ');
    const [day, mon, year] = dateParts[0].split('-');
    const time = dateParts[1];

    const monthMap: Record<string, number> = {
      JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
      JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11
    };

    const dateObj = new Date(
      Number(year),
      monthMap[mon.toUpperCase()],
      Number(day),
      Number(time.split(':')[0]),
      Number(time.split(':')[1]),
      Number(time.split(':')[2])
    );

    return dateObj.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata'
    });
  }


}
