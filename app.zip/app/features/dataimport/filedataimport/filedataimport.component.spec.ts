import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiledataimportComponent } from './filedataimport.component';

describe('FiledataimportComponent', () => {
  let component: FiledataimportComponent;
  let fixture: ComponentFixture<FiledataimportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FiledataimportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FiledataimportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
