import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SalaryCalculationService {

  constructor() { }

  /**
   * Evaluates a formula string with the given form values
   * @param formula - Formula string like "(g2h_sg1_f0+g2h_sg2_f0+g2h_sg3_f0)"
   * @param formValues - Object containing all form field values
   * @returns Calculated result
   */
  evaluateFormula(formula: string, formValues: any): number {
    if (!formula) return 0;

    try {
      // Clean the formula and replace field names with values
      let processedFormula = this.processFormula(formula, formValues);

      // Evaluate the mathematical expression
      return this.safeEvaluate(processedFormula);
    } catch (error) {
      console.error('Error evaluating formula:', formula, error);
      return 0;
    }
  }

  /**
   * Processes the formula by replacing field names with actual values
   */
  private processFormula(formula: string, formValues: any): string {
    let processedFormula = formula;

    // Remove parentheses for processing
    processedFormula = processedFormula.replace(/[()]/g, '');

    // Split by operators to get field names
    const fieldPattern = /[a-zA-Z][a-zA-Z0-9_]*/g;
    const fieldMatches = processedFormula.match(fieldPattern);

    if (fieldMatches) {
      fieldMatches.forEach(fieldName => {
        const value = formValues[fieldName] || 0;
        const numericValue = this.parseNumericValue(value);
        processedFormula = processedFormula.replace(new RegExp(fieldName, 'g'), numericValue.toString());
      });
    }

    // Restore parentheses structure from original formula
    const originalParentheses = formula.match(/[()]/g) || [];
    let parenIndex = 0;

    for (let i = 0; i < processedFormula.length; i++) {
      if (formula[i] === '(' || formula[i] === ')') {
        processedFormula =
          processedFormula.slice(0, i) +
          originalParentheses[parenIndex] +
          processedFormula.slice(i);
        parenIndex++;
      }
    }

    return processedFormula;
  }

  /**
   * Safely evaluates a mathematical expression
   */
  private safeEvaluate(expression: string): number {
    // Remove any potential security risks
    const sanitized = expression.replace(/[^0-9+\-*/.() ]/g, '');

    try {
      // Use Function constructor for safe evaluation
      return new Function('return ' + sanitized)() || 0;
    } catch (error) {
      console.error('Error in safe evaluation:', error);
      return 0;
    }
  }

  /**
   * Parses a value to ensure it's numeric
   */
  private parseNumericValue(value: any): number {
    if (value === null || value === undefined || value === '') {
      return 0;
    }

    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  }

  /**
   * Calculates tax based on income and deductions
   */
  calculateIncomeTax(taxableIncome: number, category: string = 'G'): {
    baseTax: number;
    surcharge: number;
    cess: number;
    totalTax: number;
    rebate: number;
  } {
    let baseTax = 0;
    let surcharge = 0;
    let cess = 0;
    let rebate = 0;

    // Calculate base tax based on slabs
    baseTax = this.calculateBaseTax(taxableIncome, category);

    // Calculate surcharge if applicable
    surcharge = this.calculateSurcharge(taxableIncome, baseTax);

    // Calculate health and education cess (4% of (tax + surcharge))
    cess = (baseTax + surcharge) * 0.04;

    // Calculate rebate under section 87A
    rebate = this.calculateRebate(taxableIncome, baseTax);

    const totalTax = baseTax + surcharge + cess - rebate;

    return {
      baseTax: Math.round(baseTax),
      surcharge: Math.round(surcharge),
      cess: Math.round(cess),
      totalTax: Math.max(0, Math.round(totalTax)),
      rebate: Math.round(rebate)
    };
  }

  /**
   * Calculates base income tax based on tax slabs
   */
  private calculateBaseTax(income: number, category: string): number {
    let tax = 0;

    if (category === 'S') { // Senior Citizen
      if (income <= 300000) return 0;
      if (income <= 500000) tax = (income - 300000) * 0.05;
      else if (income <= 1000000) tax = 200000 * 0.05 + (income - 500000) * 0.20;
      else tax = 200000 * 0.05 + 500000 * 0.20 + (income - 1000000) * 0.30;
    } else { // General and Others
      if (income <= 250000) return 0;
      if (income <= 500000) tax = (income - 250000) * 0.05;
      else if (income <= 1000000) tax = 250000 * 0.05 + (income - 500000) * 0.20;
      else tax = 250000 * 0.05 + 500000 * 0.20 + (income - 1000000) * 0.30;
    }

    return tax;
  }

  /**
   * Calculates surcharge based on income level
   */
  private calculateSurcharge(income: number, baseTax: number): number {
    if (income <= 5000000) return 0;
    if (income <= 10000000) return baseTax * 0.10;
    if (income <= 20000000) return baseTax * 0.15;
    if (income <= 50000000) return baseTax * 0.25;
    return baseTax * 0.37;
  }

  /**
   * Calculates rebate under section 87A
   */
  private calculateRebate(income: number, baseTax: number): number {
    if (income <= 500000) {
      return Math.min(baseTax, 12500);
    }
    return 0;
  }

  /**
   * Validates field dependencies and returns validation result
   */
  validateFieldDependencies(fieldName: string, value: any, dependencies: any[], formValues: any): {
    isValid: boolean;
    shouldDisable: boolean;
    maxValue?: number;
    message?: string;
  } {
    const result = {
      isValid: true,
      shouldDisable: false,
      maxValue: undefined as number | undefined,
      message: undefined as string | undefined
    };

    dependencies.forEach(dependency => {
      const dependentValue = formValues[dependency.field_name];

      // Check disable dependencies
      if (dependency.disable && dependentValue === dependency.field_name_value) {
        result.shouldDisable = dependency.disable === 'Y';
      }

      // Check max value dependencies
      if (dependency.value && dependentValue === dependency.field_name_value) {
        result.maxValue = parseFloat(dependency.value);
      }
    });

    // Validate against max value
    if (result.maxValue !== undefined && parseFloat(value) > result.maxValue) {
      result.isValid = false;
      result.message = `Maximum allowed value is ${result.maxValue}`;
    }

    return result;
  }

  /**
   * Calculates professional tax based on salary and state
   */
  calculateProfessionalTax(salary: number, state: string = 'MH'): number {
    // Maharashtra PT slabs as example
    if (state === 'MH') {
      if (salary <= 21000) return 0;
      if (salary <= 25000) return 175;
      return 200;
    }

    // Default minimal PT
    return salary > 21000 ? 200 : 0;
  }

  /**
   * Calculates HRA exemption
   */
  calculateHRAExemption(basicSalary: number, hraReceived: number, rentPaid: number, isMetro: boolean): number {
    const metroPercentage = isMetro ? 0.50 : 0.40;

    const exemptions = [
      hraReceived,
      basicSalary * metroPercentage,
      rentPaid - (basicSalary * 0.10)
    ];

    return Math.max(0, Math.min(...exemptions));
  }

  /**
   * Formats currency for display
   */
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  }

  /**
   * Calculates standard deduction (currently Rs. 50,000)
   */
  calculateStandardDeduction(salary: number): number {
    return Math.min(salary, 50000);
  }

  /**
   * Validates PAN number format
   */
  validatePAN(pan: string): boolean {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panRegex.test(pan);
  }

  /**
   * Calculates 80C deduction limit
   */
  calculate80CLimit(investments: number[]): number {
    const totalInvestment = investments.reduce((sum, inv) => sum + (inv || 0), 0);
    return Math.min(totalInvestment, 150000);
  }

  /**
   * Calculates NPS additional deduction under 80CCD(1B)
   */
  calculateNPSDeduction(npsContribution: number): number {
    return Math.min(npsContribution, 50000);
  }
}