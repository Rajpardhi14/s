import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SalaryCalculationService } from './salary-calculation.service';

interface SalaryField {
  field_name: string;
  header_name: string;
  header_type: string;
  formula?: string;
  max_value?: string | number;
  min_value?: string | number;
  default_value?: any;
  disable_depend?: DisableDependency[];
  max_value_depend?: MaxValueDependency[];
  filter_col_validate?: Validation[];
  viewable?: string;
  childs?: SalaryField[];
}

interface DisableDependency {
  field_name: string;
  field_name_value: string;
  value: string;
  disable: string;
}

interface MaxValueDependency {
  field_name: string;
  field_name_value: string;
  value: string;
}

interface Validation {
  type: string;
  value: string;
  message: string;
}

interface SalaryGroup {
  main?: SalaryField;
  sub_group?: SalaryField[][];
}

interface SalaryHeader {
  g1h?: SalaryField[];
  g2h?: SalaryGroup;
  g3h?: SalaryGroup;
  g4h?: SalaryGroup;
}

@Component({
  selector: 'app-salary-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './salary-details.component.html',
  styleUrl: './salary-details.component.css'
})
export class SalaryDetailsComponent implements OnInit {

  salaryForm!: FormGroup;
  salaryStructure: SalaryHeader = {};
  isLoading = false;

  // Sample data structure based on provided JSON
  salaryData = {
    "salary_tran_load_header": {
      "g1h": [
        {
          "field_name": "afgr1_total_amt",
          "header_name": "Total Tax Liability",
          "header_type": "0",
          "formula": "g4h_main_f0"
        },
        {
          "field_name": "deductee_panno",
          "header_name": "PAN",
          "header_type": "0"
        },
        {
          "field_name": "identification_no",
          "header_name": "Employee Code/ID",
          "header_type": "0"
        },
        {
          "field_name": "deductee_phoneno",
          "header_name": "Phone Number",
          "header_type": "0"
        },
        {
          "field_name": "tax_115bac_flag",
          "header_name": "Whether opting for taxation under Section 115BAC?",
          "header_type": "0"
        },
        {
          "field_name": "deductee_catg",
          "header_name": "Category",
          "header_type": "0"
        }
      ],
      "g2h": {
        "main": {
          "field_name": "g2h_main_f0",
          "header_name": "Gross Total Income",
          "header_type": "0",
          "formula": "(g2h_sg1_f0+g2h_sg2_f0+g2h_sg3_f0)"
        },
        "sub_group": [
          [
            {
              "field_name": "g2h_sg1_f0",
              "header_name": "Income From Salary",
              "header_type": "0",
              "formula": "(g2h_sg1_f3-(g2h_sg1_f4+g2h_sg1_f5))"
            },
            {
              "field_name": "g2h_sg1_f1",
              "header_name": "Gross Salary",
              "header_type": "1",
              "formula": "(g2h_sg1_f3-g2h_sg1_f4)"
            },
            {
              "field_name": "afg01_pes_amt",
              "header_name": "Total amount of previous employer salary",
              "header_type": "3"
            },
            {
              "field_name": "afg01_ces_amt",
              "header_name": "a. Gross salary of current employer (17/1)",
              "header_type": "3"
            },
            {
              "field_name": "afg05_hra_amt",
              "header_name": "House rent allowances 10(13A)",
              "header_type": "3",
              "disable_depend": [
                {
                  "field_name": "tax_115bac_flag",
                  "field_name_value": "Y",
                  "value": "0",
                  "disable": "Y"
                }
              ]
            }
          ]
        ]
      },
      "g3h": {
        "main": {
          "field_name": "g3h_main_f0",
          "header_name": "Total Deductions",
          "header_type": "0",
          "formula": "(g3h_s1_f0+g3h_s2_f0+g3h_s3_f0)"
        },
        "sub_group": [
          [
            {
              "field_name": "g3h_s1_f0",
              "header_name": "Under Section 80C",
              "header_type": "0",
              "formula": "(g3h_s1_f3)"
            },
            {
              "field_name": "afg10_pt_amt",
              "header_name": "Professional Tax 16(iii)",
              "header_type": "3",
              "min_value": "0",
              "max_value": "2500",
              "disable_depend": [
                {
                  "field_name": "tax_115bac_flag",
                  "field_name_value": "Y",
                  "value": "0",
                  "disable": "Y"
                }
              ]
            }
          ]
        ]
      },
      "g4h": {
        "main": {
          "field_name": "g4h_main_f0",
          "header_name": "Total Taxable Income",
          "header_type": "0",
          "formula": "(g2h_main_f0-g3h_main_f0)"
        }
      }
    }
  };

  constructor(
    private fb: FormBuilder,
    private calculationService: SalaryCalculationService
  ) {}

  ngOnInit(): void {
    this.initializeSalaryStructure();
    this.createDynamicForm();
    this.setupCalculations();
  }

  initializeSalaryStructure(): void {
    this.salaryStructure = this.salaryData.salary_tran_load_header;
  }

  createDynamicForm(): void {
    const formControls: any = {};

    // Add basic header fields
    if (this.salaryStructure.g1h) {
      this.salaryStructure.g1h.forEach(field => {
        formControls[field.field_name] = [
          field.default_value || '',
          this.getValidators(field)
        ];
      });
    }

    // Add income fields from g2h
    this.addGroupFields(this.salaryStructure.g2h, formControls);

    // Add deduction fields from g3h
    this.addGroupFields(this.salaryStructure.g3h, formControls);

    // Add tax calculation fields from g4h
    this.addGroupFields(this.salaryStructure.g4h, formControls);

    this.salaryForm = this.fb.group(formControls);
  }

  private addGroupFields(group: SalaryGroup | undefined, formControls: any): void {
    if (!group) return;

    // Add main field
    if (group.main) {
      formControls[group.main.field_name] = [
        group.main.default_value || 0,
        this.getValidators(group.main)
      ];
    }

    // Add sub group fields
    if (group.sub_group) {
      group.sub_group.forEach(subGroup => {
        subGroup.forEach(field => {
          formControls[field.field_name] = [
            field.default_value || (field.header_type === '3' ? '' : 0),
            this.getValidators(field)
          ];

          // Add child fields if they exist
          if (field.childs) {
            field.childs.forEach(child => {
              formControls[child.field_name] = [
                child.default_value || '',
                this.getValidators(child)
              ];
            });
          }
        });
      });
    }
  }

  private getValidators(field: SalaryField): any[] {
    const validators: any[] = [];

    if (field.header_type === '3') {
      validators.push(Validators.required);
    }

    if (field.min_value !== undefined) {
      validators.push(Validators.min(Number(field.min_value)));
    }

    if (field.max_value !== undefined && typeof field.max_value === 'number') {
      validators.push(Validators.max(Number(field.max_value)));
    }

    if (field.filter_col_validate) {
      field.filter_col_validate.forEach(validation => {
        if (validation.type === 'regex') {
          validators.push(Validators.pattern(validation.value));
        }
      });
    }

    return validators;
  }

  setupCalculations(): void {
    // Listen to form changes and trigger calculations
    this.salaryForm.valueChanges.subscribe(values => {
      this.calculateFields(values);
      this.updateDependentFields(values);
    });
  }

  calculateFields(formValues: any): void {
    // Calculate formula-based fields
    this.calculateGroupFormulas(this.salaryStructure.g2h, formValues);
    this.calculateGroupFormulas(this.salaryStructure.g3h, formValues);
    this.calculateGroupFormulas(this.salaryStructure.g4h, formValues);

    // Calculate g1h fields that depend on others
    if (this.salaryStructure.g1h) {
      this.salaryStructure.g1h.forEach(field => {
        if (field.formula) {
          const calculatedValue = this.calculationService.evaluateFormula(field.formula, formValues);
          this.salaryForm.patchValue({ [field.field_name]: calculatedValue }, { emitEvent: false });
        }
      });
    }
  }

  private calculateGroupFormulas(group: SalaryGroup | undefined, formValues: any): void {
    if (!group) return;

    // Calculate main field
    if (group.main?.formula) {
      const calculatedValue = this.calculationService.evaluateFormula(group.main.formula, formValues);
      this.salaryForm.patchValue({ [group.main.field_name]: calculatedValue }, { emitEvent: false });
    }

    // Calculate sub group formulas
    if (group.sub_group) {
      group.sub_group.forEach(subGroup => {
        subGroup.forEach(field => {
          if (field.formula) {
            const calculatedValue = this.calculationService.evaluateFormula(field.formula, formValues);
            this.salaryForm.patchValue({ [field.field_name]: calculatedValue }, { emitEvent: false });
          }
        });
      });
    }
  }

  updateDependentFields(formValues: any): void {
    // Handle disable dependencies
    if (this.salaryStructure.g2h?.sub_group) {
      this.salaryStructure.g2h.sub_group.forEach(subGroup => {
        subGroup.forEach(field => {
          this.handleFieldDependencies(field, formValues);
        });
      });
    }
  }

  private handleFieldDependencies(field: SalaryField, formValues: any): void {
    if (field.disable_depend) {
      field.disable_depend.forEach(dependency => {
        const dependentFieldValue = formValues[dependency.field_name];
        const control = this.salaryForm.get(field.field_name);

        if (dependentFieldValue === dependency.field_name_value) {
          control?.setValue(dependency.value);
          if (dependency.disable === 'Y') {
            control?.disable();
          }
        } else {
          control?.enable();
        }
      });
    }

    // Handle child dependencies
    if (field.childs) {
      field.childs.forEach(child => {
        this.handleFieldDependencies(child, formValues);
      });
    }
  }

  isFieldDisabled(fieldName: string): boolean {
    const control = this.salaryForm.get(fieldName);
    return control?.disabled || false;
  }

  isFieldVisible(field: SalaryField): boolean {
    return field.viewable !== '0';
  }

  getFieldError(fieldName: string): string {
    const control = this.salaryForm.get(fieldName);
    if (control?.errors && control?.touched) {
      if (control.errors['required']) return 'This field is required';
      if (control.errors['min']) return `Minimum value is ${control.errors['min'].min}`;
      if (control.errors['max']) return `Maximum value is ${control.errors['max'].max}`;
      if (control.errors['pattern']) return 'Invalid format';
    }
    return '';
  }

  onSubmit(): void {
    if (this.salaryForm.valid) {
      console.log('Salary Form Data:', this.salaryForm.value);
      // Handle form submission
    } else {
      this.salaryForm.markAllAsTouched();
    }
  }

  resetForm(): void {
    this.salaryForm.reset();
    this.createDynamicForm();
  }
}