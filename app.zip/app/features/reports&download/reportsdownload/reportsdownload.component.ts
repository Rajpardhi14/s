import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TableskeletonComponent } from '../../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../../shared/components/nodata/nodata.component';
import { capitalizeEachWord, formatDatesend } from '../../../shared/utils/passmatch';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { GearboxComponent } from '../../../shared/components/gearbox/gearbox.component';
import { BasicFilterComponent } from '../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../shared/components/advance-filter/advance-filter.component';
import { ReportfilterpopupComponent } from '../../../shared/components/reportfilterpopup/reportfilterpopup.component';

@Component({
  selector: 'app-reportsdownload',
  standalone: true,
  imports: [CommonModule, TableskeletonComponent, NodataComponent, GearboxComponent, BasicFilterComponent, AdvanceFilterComponent, ReportfilterpopupComponent],
  templateUrl: './reportsdownload.component.html',
  styleUrl: './reportsdownload.component.css'
})
export class ReportsdownloadComponent {
@Input() refNumber: string | null = null;


  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  localUserData: any;
  dynaUserData: any;
  filterClause: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  errorMessage = '';
  selectedValue: string[] = [];
  myfilterfileds: any;
  values: any;
  selectedLabel: any;
  selectedTab: any;
  isLoading: boolean = false;
  loading = false;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  headers: any[] = [];
  tableBody: any[] = [];
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  paginatedList: any;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  usergrandtotal: number = 0;
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  capitalizeEachWord = capitalizeEachWord;
  matchingDependValue: any;
  userData: any;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  totalcount: any;
  Math = Math;
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };

  skeletonList = Array(7);
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  filtersSubmitted = false;



  constructor(private apiService: ApiserviceService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private screenSizeService: ScreensizeService,
  ) {

  }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    this.fetchData();
    this.fetchFilter();
    this.fetchGrandTotal();
    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();

  }


  activeTab: string = 'reports';
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
  //#region filetr
  private fetchFilter(): void {
    
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gmfb_file_tran',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );

    this.apiService
      .getFilterData('/DownloadReport/get_gmfb_file_tran', sdata)
      .subscribe({
        next: (response) => {
          console.log(response.result);
          if (response?.result?.a_proc_error == '0') {
            this.basic_filter =
              response?.result?.get_gmfb_file_tran?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gmfb_file_tran?.[1]?.advance_filter;
            console.log(this.basic_filter);
            this.initializeForm();
            this.advance_filter?.forEach((field: any) => {
              if (
                field.filter_external_location === 'top' &&
                field.filter_col_type === 'filter-select'
              ) {
                const allOption = { value: 'ALL', label: 'All' };
                const exists = field.filter_col_depend_value?.some(
                  (opt: any) => opt.value === 'ALL'
                );
                if (!exists) {
                  field.filter_col_depend_value?.unshift(allOption);
                }
              }
            });

            const defaultField = this.advance_filter?.find(
              (field: any) =>
                field.filter_external_location === 'top' &&
                (field.filter_col_type === 'filter-select' ||
                  field.filter_col_type === 'select')
            );

            const defaultOption = defaultField?.filter_col_depend_value[0]

            console.log(defaultOption);

            // Set default active tab
            this.defaultTabFilter = defaultOption;
            this.activeFilterTab = defaultOption?.value;

            console.log(this.activeFilterTab);

            this.defaultFilterVal = defaultOption?.value;

            if (defaultField && defaultOption) {
              const control = this.filterForm.get(
                defaultField.filter_col_field
              );
              if (control) {
                control.setValue(defaultOption.value, { emitEvent: false });
              }
            }

            this.menuOptions = this.basic_filter?.map((filter: any) => ({
              label: filter.filter_col_prompt,
              field: filter.filter_col_field,
              operator: filter.filter_col_depend_operator,
              alias: filter.filter_col_field_alias,
              placeholder: filter.filter_col_placeholder,
            }));
            this.selectedOption = this.menuOptions?.[0];


          } else {
            this.errorMessage =
              response.result?.a_proc_error_message ||
              'Please Check Endpoint';
            this.showError(this.errorMessage);
          }

          if (this.isFirstLoad) {
            this.isSkeletonshow = false;
            this.isFirstLoad = false;
          }
        },
        error: (error) => {
          console.error('Error user filter:', error);
          this.isSkeletonshow = false;
        },
      });
  }


  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_external_location === 'top') {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_external_location !== 'top') {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }
  gearboxState: { [key: string]: boolean } = {};

  saveGearboxState() {
  this.headers.forEach(h => {
    this.gearboxState[h.field] = h.visible;
  });
}

  onSubmit() {
      // 1️⃣ Save the gearbox state before table refresh
  this.saveGearboxState(); // save current visibility
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });


      this.syncBasicAndAdvanceFilters()
      this.filterClause = this.buildFilterClause();
      console.log(this.filterClause);

      Promise.all([this.fetchData(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
   filtercount: number = 0;
  selectedFilters: { label: string; field?: string; value: string }[] = [];
    clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();

    // Check if user applied any filters different from defaults
    const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      const value = control?.value;
      const defaultVal = field._isDefaultValue ?? '';
      return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
    });

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (!control) return;

        const defaultVal = field._isDefaultValue ?? null;

        if (hasUserAppliedFilters) {
          // ✅ Keep default filters intact
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue(''); // clear user-only filters
          }
        } else {
          // ✅ If no user filters were applied — reset to defaults, not empty
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue('');
          }
        }
      });
    }

    // ✅ Rebuild filterClause including defaults
    this.selectedFilters = this.getSelectedFilters();
    this.filterClause = this.buildFilterClause();
    this.filtercount = this.getSelectedFilterCount();

    // 🚫 Don’t treat this as a full clear for fetchTable()
    this.fetchData;
    this.fetchGrandTotal();
  }
  defaultFilterVal: any;
  selectedTabFilter(filterField: string, value: any, label: any): void {
    console.log(value)
    this.selectedValue = value;
    this.defaultTabFilter = value;
    this.myfilterfileds = filterField;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    this.defaultFilterVal = value;
    console.log(this.activeFilterTab)
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }

    console.log('Active filter tab after update:', this.selectedValue);
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }


   private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value !== basicValue) {
      this.searchTerm = control.value;
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (controlValue && controlValue !== 'ALL' && filterConfig) {
        // <-- KEY CHANGE HERE
        let filterValue: string;
        const operator = filterConfig.filter_col_depend_operator || 'like';
        filterValue = controlValue.toString().trim();

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.trim().toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
    const uniqueFilters = Array.from(
      new Map(
        filterClause.map((item) => [item.filter_col_field, item])
      ).values()
    );

    return uniqueFilters;
    // return filterClause;
  }


  getSelectedFilters() {
    const selectedFilters: { label: string; field?: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_external_location === 'top')) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  buildMergeGroups() {
    this.headers?.forEach((header) => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }

  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );
    console.log(filterToRemove);

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );

    console.log(filterRemove);
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    console.log(this.filterClause);
    // ✅ If no filters left → pass empty array (not defaultFilters)
    const isLastFilterCleared = !this.filterClause || this.filterClause.length === 0;

    if (isLastFilterCleared) {
      this.fetchData(); // 'true' means clear action, same as clearAllFilters
    } else {
      this.fetchData(); // normal behavior
    }

    this.fetchGrandTotal();
    
    // this.fetchTable();
    // this.fetchGrandTotal();
  }
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    // this.selectedFilters = [];
  }

  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  fetchData() {



    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }


      const mydefaultfilter = [
      {
        filter_col_field: "process_seqno",
        filter_col_depend_operator: "=",
        filter_col_value: this.refNumber,
        filter_col_field_alias: "a."
      }
    ]

    const sdata = this.apiService.generateSData(
      'get_gmdb_file_tran',
      this.localUserData,
      this.refNumber ? mydefaultfilter : this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService
      .getTableData('/DownloadReport/get_gmdb_file_tran', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gmdb_file_tran;
            if (userData?.get_gmdb_file_tran_header) {
              this.headers =
                userData?.get_gmdb_file_tran_header?.map(
                  (header: any) => ({
                    ...header,
                    visible:
        this.gearboxState.hasOwnProperty(header.field)
          ? this.gearboxState[header.field] // restore previous state
          : header.display === 1,   // default if no previous state
                  })
                );
            }
            console.log(data);
            console.log(this.headers);
            console.log(data);
            // this.allUsersData = userData || {};
            this.mergeGroups = {};
            this.fieldToMergeGroup = {};
            this.tableBody =
              userData?.get_gmdb_file_tran_detail || [];
            this.buildMergeGroups();
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }


  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchData();
        this.fetchGrandTotal();
        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }




  isDateField(field: string): boolean {
    const dateFields = [
      'challan_date',
      'certificate_valid_upto',
      'certificate_valid_from',
    ];
    return dateFields.includes(field);
  }
  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  // user grand total
gtdgData:any;
showFooter: boolean = false; 

toggleFooter() {
  this.showFooter = !this.showFooter;
}
getVisibleHeaders() {
  return this.headers?.filter(h => h.visible) || [];
}

  private fetchGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_gmdg_file_tran',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { FYYear: this.FYYear }
    );

    this.apiService
      .getGrandTotal('/DownloadReport/get_gmdg_file_tran', sdata)
      .subscribe({
        next: (response) => {
          // this.loading = false;
          this.isLoadingMore = false;
               if (response?.result?.a_proc_error == 0) {
           this.gtdgData =
    response?.result?.get_gmdg_tds_spl_rate_mast_alloc?.[0] || null;

  this.usergrandtotal = this.gtdgData?.rec || null;
  this.totalcount = this.usergrandtotal;
          } else {
            this.showError(this.errorMessage);
          }
        },
        error: (error) => {
          // this.loading = false;
          this.isLoadingMore = false;
          this.showError('Something Went Wrong');
        },
      });
  }


  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // 🔹 Popup state variables
  isGeneratePopupOpenD: boolean = false;
  selectedRowD: any = null;

  // 🔹 For backward compatibility if old logic still uses these
  // isGeneratePopupOpen: boolean = false;
  // selectedRow: any = null;

  // 🔹 Popup type identifier ('downloadPopup', 'filterPopup', etc.)
  popupType: 'generateFormat' | 'filterPopup' | 'downloadPopup' | null = null;

  downloadCallbacksD: string[] = [];
  // downloadFormat(row: any) {
  //   this.selectedRowD = row; // ✅ set first

  //   try {
  //     const operation =
  //       typeof row.operation === 'string'
  //         ? JSON.parse(row.operation)
  //         : row.operation;

  //     const downloadCallbacksD =
  //       operation?.download_callbacks || operation?.downlaod_callbacks || [];

  //     if (Array.isArray(downloadCallbacksD) && downloadCallbacksD.length > 0) {
  //       // ✅ open popup immediately
  //       this.popupType = 'downloadPopup';
  //       this.isGeneratePopupOpenD = true;
  // console.log(this.selectedRowD);
  //       console.log('✅ Opening popup with:', downloadCallbacksD);
  //       console.log('PopupType:', this.popupType);
  //       console.log('isGeneratePopupOpenD:', this.isGeneratePopupOpenD);
  //     } else {
  //       // fallback to direct download
  //       this.isGeneratePopupOpenD = false;
  //       this.popupType = null;
  //       this.downloadReportFile(
  //         row.download_file_name,
  //         row.download_file_path,
  //         row.branch_name,
  //         row.report_heading
  //       );
  //     }
  //   } catch (error) {
  //     console.error('❌ Failed to parse operation JSON:', error);
  //     this.isGeneratePopupOpenD = false;
  //     this.popupType = null;
  //   }
  // }


  // 🔹 Handle popup close event

  downloadFormat(row: any) {
    this.selectedRowD = row; // ✅ set selected row first

    try {
      // const operation =
      //   typeof row.operation === 'string'
      //     ? JSON.parse(row.operation)
      //     : row.operation;

      // ✅ assign to class-level variable, not local variable
      const operation =
        typeof row.operation === 'string' ? JSON.parse(row.operation) : row.operation;

      this.downloadCallbacksD =
        operation?.download_callbacks || operation?.downlaod_callbacks || [];

      if (Array.isArray(this.downloadCallbacksD) && this.downloadCallbacksD.length > 0) {
        // ✅ open popup immediately
        this.popupType = 'downloadPopup';
        this.isGeneratePopupOpenD = true;

        console.log('✅ Opening popup with:', this.downloadCallbacksD);
        console.log('PopupType:', this.popupType);
        console.log('isGeneratePopupOpenD:', this.isGeneratePopupOpenD);
      } else {
        // fallback to direct download
        this.isGeneratePopupOpenD = false;
        this.popupType = null;
        this.downloadReportFile(
          row.download_file_name,
          row.download_file_path,
          row.branch_name,
          row.report_heading
        );
      }
    } catch (error) {
      console.error('❌ Failed to parse operation JSON:', error);
      this.isGeneratePopupOpenD = false;
      this.popupType = null;
    }
  }

  handleClosePopup(): void {
    this.isGeneratePopupOpenD = false;
    this.popupType = null;
  }

  async downloadAllReports(): Promise<void> {
    if (!this.tableBody || this.tableBody.length === 0) return;

    for (const row of this.tableBody) {
      if (!row.download_file_name) continue;

      // Example: "TDS_TEXT_FILES#93304946.txt#xlsx"
      const filename = row.download_file_name;
      const source = row.source || 's3';

      // Header data
      const headerJson = {
        ReportName: row.report_heading || 'Report',
        GeneratedBy: this.dynaUserData?.client_code_details || 'Admin',
        Branch: row.branch_name || 'Main Branch'
      };

      // Split and format the file path
      const parts = filename.split('#');
      const folder = parts[0] || '';
      const fileNamePart = parts[1] || ''; // 93304946.txt
      let baseName = fileNamePart.replace(/\.[^/.]+$/, ''); // remove any extension (.txt, .pdf, etc.)

      // ✅ Force ZIP extension
      const formattedFileName = `${folder}/${baseName}.zip`;

      try {
        // Call the existing API download function
        this.apiService.reportFileDownload(formattedFileName, source, headerJson);

        // Optional small delay between downloads
        await new Promise(resolve => setTimeout(resolve, 800));
      } catch (error) {
        console.error(`❌ Failed to download ${formattedFileName}:`, error);
      }
    }

    console.log('✅ All report downloads initiated.');
  }



  downloadReportFile(filename: string, source: string, branchName: string, reportHeading: string): void {
    if (!filename) return;

    // Example: "TDS_TEXT_FILES#18616318.txt#xlsx"
    const parts = filename.split('#');

    const folder = parts[0] || '';
    const fileNamePart = parts[1] || '';
    const extension = parts[2] || '';

    // Always replace existing extension (like .txt) with the correct one (like .xlsx)
    let baseName = fileNamePart.split('.')[0]; // remove .txt, .csv, etc.
    const correctedFileName = `${baseName}${extension ? '.' + extension : ''}`;

    // Construct final file path
    const formattedFilename = `${folder}/${correctedFileName}`;

    // Convert DB source → s3
    const finalSource = source === 'DB' ? 's3' : source;

    // Build and encode header JSON
    const headerJson = {
      ReportName: this.selectedRowD?.process_type_name || '',
      GeneratedBy: this.dynaUserData?.client_code_details || '',
      Branch: this.selectedRowD?.bank_branch_code || ''
    };

    // ✅ Properly encode before sending to API
    const encodedHeadersJson = encodeURIComponent(JSON.stringify(headerJson));

    console.log('✅ Final Formatted Filename:', formattedFilename);
    console.log('✅ Final Source:', finalSource);
    console.log('✅ Encoded Header JSON:', encodedHeadersJson);

    // Call API with encoded JSON
    this.apiService.reportFileDownload(formattedFilename, finalSource, encodedHeadersJson);
  }




   sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";


   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }

}
