import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsdownloadComponent } from './reportsdownload.component';

describe('ReportsdownloadComponent', () => {
  let component: ReportsdownloadComponent;
  let fixture: ComponentFixture<ReportsdownloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReportsdownloadComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ReportsdownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
