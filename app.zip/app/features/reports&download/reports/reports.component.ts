import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { ApiserviceService } from '../../core/services/componentservice/apiservice.service';
// import { UserdataService } from '../../core/services/userdata/userdata.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NodataComponent } from '../../../shared/components/nodata/nodata.component';
import { TableskeletonComponent } from '../../../shared/components/tableskeleton/tableskeleton.component';
import {
  capitalizeEachWord,
  formatDatesend,
} from '../../../shared/utils/passmatch';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { ReportsdownloadComponent } from '../reportsdownload/reportsdownload.component';
import { ReportfilterpopupComponent } from '../../../shared/components/reportfilterpopup/reportfilterpopup.component';
import { ViewReportComponent } from './view-report/view-report.component';
import { Router } from '@angular/router';
// import { ToastService } from '../../core/services/toaster/toast.service';
// import { TableskeletonComponent } from '../../shared/components/tableskeleton/tableskeleton.component';
// import { NodataComponent } from '../../shared/components/nodata/nodata.component';
// import {
//   capitalizeEachWord,
//   formatDatesend,
// } from '../../shared/utils/passmatch';
// import { ScreensizeService } from '../../core/services/screensize/screensize.service';

interface Report {
  misName: string;
  lastGeneratedStatus: string;
  lastGeneratedTime: string;
  generateStatus: string;
  statusType?: 'successful' | 'in-process' | 'na';
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [
    CommonModule,
    TableskeletonComponent,
    NodataComponent,
    ReportsdownloadComponent,
    ReportfilterpopupComponent,
    ViewReportComponent,
  ],
  templateUrl: './reports.component.html',
  styleUrl: './reports.component.css',
})
export class ReportsComponent {
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  localUserData: any;
  dynaUserData: any;
  filterClause: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  activeFilterTab: string = '';
  defaultTabFilter: any;
  errorMessage = '';
  selectedValue: string[] = [];
  myfilterfileds: any;
  values: any;
  selectedLabel: any;
  selectedTab: any;
  isLoading: boolean = false;
  loading = false;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  FYYear: string = 'Yes';
  iudtype: string = 'View';
  headers: any[] = [];
  tableBody: any[] = [];
  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};
  paginatedList: any;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  usergrandtotal: number = 0;
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  capitalizeEachWord = capitalizeEachWord;
  matchingDependValue: any;
  userData: any;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  totalcount: any;
  Math = Math;
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };

  skeletonList = Array(7);
  refNumber: string | null = null;
  constructor(
    private apiService: ApiserviceService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private screenSizeService: ScreensizeService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

    this.route.queryParams.subscribe(params => {
      const tabParam = params['tab'];
      const refParam = params['ref'];

      if (tabParam) {
        this.activeTab = tabParam;
      }

      if (refParam) {
        this.refNumber = refParam;
        this.activeTab = 'download';
      }
    });

    // this.fetchData();
    this.fetchFilter();
    // this.fetchData();
    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();
    console.log(this.selectedRow?.gd_filter_proc_name);
    this.procesSeqNo = this.selectedRow?.a_process_seqno;
    this.procesStatusCode = this.selectedRow?.process_status_code;
    console.log(this.procesSeqNo);
  }

  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_grfb_mis_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );

    this.apiService.getFilterData('/MIS/get_grfb_mis_mast', sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error === '0') {
          this.basic_filter =
            response?.result?.get_grfb_mis_mast?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.get_grfb_mis_mast?.[1]?.advance_filter;

          this.initializeForm();
          this.advance_filter?.forEach((field: any) => {
            if (
              field.filter_external_location === 'top' &&
              field.filter_col_type === 'filter-select'
            ) {
              const allOption = { value: 'ALL', label: 'All' };
              const exists = field.filter_col_depend_value?.some(
                (opt: any) => opt.value === 'ALL'
              );
              if (!exists) {
                field.filter_col_depend_value?.unshift(allOption);
              }
            }
          });

          const defaultField = this.advance_filter?.find(
            (field: any) =>
              field.filter_external_location === 'top' &&
              (field.filter_col_type === 'filter-select' ||
                field.filter_col_type === 'select')
          );

          const defaultOption = defaultField?.filter_col_depend_value[0];
          console.log(defaultOption);

          // Set default active tab
          this.defaultTabFilter = defaultOption;
          this.activeFilterTab = defaultOption?.value;
          console.log(this.activeFilterTab);
          this.defaultFilterVal = defaultOption?.value;
          if (defaultField && defaultOption) {
            const control = this.filterForm.get(defaultField.filter_col_field);
            if (control) {
              control.setValue(defaultOption.value, { emitEvent: false });
            }
          }
          this.fetchData();
          this.fetchGrandTotal();
          // this.menuOptions = this.basic_filter?.map((filter: any) => ({
          //   label: filter.filter_col_prompt,
          //   field: filter.filter_col_field,
          //   operator: filter.filter_col_depend_operator,
          //   alias: filter.filter_col_field_alias,
          //   placeholder: filter.filter_col_placeholder,
          // }));
          // this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage =
            response.result?.[0].a_proc_error_message ||
            'Please Check Endpoint';
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_external_location === 'top') {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_external_location !== 'top') {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => { });
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  defaultFilterVal: any;
  selectedTabFilter(filterField: string, value: any, label: any): void {
    console.log(value);
    this.selectedValue = value;
    this.defaultTabFilter = value;
    this.myfilterfileds = filterField;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    this.defaultFilterVal = value;
    console.log(this.activeFilterTab);
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }

    console.log('Active filter tab after update:', this.selectedValue);
    this.filterClause = this.buildFilterClause();
    this.fetchData();
    this.fetchGrandTotal();
  }

  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {
          console.log('wc');
          console.log(controlValue);
          // For "wc", find the condition based on selected value
          console.log(filterConfig.filter_col_depend_value);
          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue.toUpperCase()
          );
          console.log(selectedOption);
          filterValue = selectedOption ? selectedOption.condition : '';
          console.log(filterValue);
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });
    return filterClause;
  }

  getSelectedFilters() {
    const selectedFilters: { label: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (!(field.filter_external_location === 'top')) {
          const control = this.filterForm.get(field.filter_col_field);

          if (
            control &&
            control.value &&
            !field.filter_col_external_default_value &&
            control.value.toString().trim() !== ''
          ) {
            this.matchingDependValue = field.filter_col_depend_value.find(
              (dependValue: any) => dependValue.value === control.value
            );

            if (this.matchingDependValue) {
              selectedFilters.push({
                label: this.matchingDependValue.label,
                value: control.value.toString().trim(),
              });
            } else if (!this.matchingDependValue) {
              selectedFilters.push({
                label: field.filter_col_prompt,
                value: control.value.toString().trim(),
              });
            }
          }
        }
      });
    }
    return selectedFilters;
  }

  buildMergeGroups() {
    this.headers?.forEach((header) => {
      const mergeCol = header.mergeColumn;
      if (mergeCol) {
        if (!this.mergeGroups[mergeCol]) {
          this.mergeGroups[mergeCol] = [];
        }
        this.mergeGroups[mergeCol].push(header);
        this.fieldToMergeGroup[header.field] = mergeCol;
      }
    });
  }

  isFirstInMergeGroup(header: any): boolean {
    const mergeCol = header.mergeColumn;

    return (
      mergeCol &&
      this.mergeGroups[mergeCol]?.length &&
      this.mergeGroups[mergeCol][0].field === header.field
    );
  }

  fetchData() {
    const userFilters = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
    this.selectedTab = this.selectedValue;
    console.log(this.defaultFilterVal);
    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'mis_group_code',
        filter_col_depend_operator: '=',
        filter_col_field_alias: 'a.',
        filter_col_value: this.defaultFilterVal,
      },
    ];

    // Always rebuild final filterClause fresh:
    const finalFilterClause = [
      ...newFilterClause,
      ...userFilters.filter(
        (uf: any) =>
          !newFilterClause.some(
            (nf) => nf.filter_col_field === uf.filter_col_field
          )
      ),
    ];
    console.log(finalFilterClause);

    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(
      'get_grdb_mis_mast',
      this.localUserData,
      finalFilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService.getTableData('/MIS/get_grdb_mis_mast', sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == 0) {
          const userData = data?.result?.get_grdb_mis_mast;
          if (userData?.get_grdb_mis_mast_header) {
            this.headers = userData?.get_grdb_mis_mast_header?.map(
              (header: any) => ({
                ...header,
                visible: header.display === 1,
              })
            );
          }
          console.log(data);
          console.log(this.headers);
          console.log(data);
          // this.allUsersData = userData || {};
          this.mergeGroups = {};
          this.fieldToMergeGroup = {};
          this.tableBody = userData?.get_grdb_mis_mast_detail || [];
          this.buildMergeGroups();
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
          this.loading = false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
      },
    });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchData();
        this.fetchGrandTotal();
        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  isDateField(field: string): boolean {
    const dateFields = [
      'challan_date',
      'certificate_valid_upto',
      'certificate_valid_from',
    ];
    return dateFields.includes(field);
  }
  formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  isGenerateVisible(row: any): boolean {
    const disableStatuses = ['RA', 'RB', 'RC'];
    return (
      row.isgenerated === 1 &&
      !disableStatuses.includes(row.process_status_code)
    );
  }

  isDownloadVisible(row: any): boolean {
    return row.isDownloadable === 1 && !!row.download_file_name;
  }
  popupOptions: any[] = []; // For generation popup options
  // To toggle generation popup visibility
  // selectedRow: any = null;          // To store currently selected row data
  downloadOptions: any[] = []; // For download popup options
  showDownloadPopup: boolean = false; // To toggle download popup visibility

  // onDownload(row: any) {
  //   if (row.callBackKey === 'downlaod_callbacks') {
  //     const operation = JSON.parse(row.operation || '{}');
  //     this.downloadOptions = operation.downlaod_callbacks || [];
  //     this.showDownloadPopup = true;
  //     this.selectedRow = row;

  //   }
  // }

  // user grand total

  private fetchGrandTotal(): void {
    const sdata = this.apiService.generateSData(
      'get_grdg_mis_mast',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { FYYear: this.FYYear }
    );

    this.apiService.getGrandTotal('/MIS/get_grdg_mis_mast', sdata).subscribe({
      next: (response) => {
        // this.loading = false;
        this.isLoadingMore = false;
        if (response?.result?.a_proc_error == 0) {
          this.usergrandtotal =
            response?.result?.get_grdg_mis_mast?.[0]?.rec || null;
          this.totalcount = this.usergrandtotal;
        } else {
          this.showError(this.errorMessage);
        }
      },
      error: (error) => {
        // this.loading = false;
        this.isLoadingMore = false;
        this.showError('Something Went Wrong');
      },
    });
  }

  activeTab: string = 'reports';
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  selectedRow: any = null;
  isGeneratePopupOpen: boolean = false;
  filterProcName = this.selectedRow?.gd_filter_proc_name;
  procesStatusCode = this.selectedRow?.process_status_code;
  operation = this.selectedRow?.operation;
  rowId: any;
  filterClauseGenerate: any;


  handleGenerate(event: { rowId: string; filterClauseGenerate: string }) {
    console.log(
      'Generate clicked from popup, calling fetchDetails with rowId:',
      event
    );

    // this.fetchGenerateTable(event.rowId, event.filterClauseGenerate);
    this.fetchGenerateTable(event.rowId, event.filterClauseGenerate, true);
    this.isGeneratePopupOpen = false; // close popup after generating
  }

  popupType: any;
  gdProcName: any;
  procesSeqNo: any;



  generationCallbacks: string[] = [];

  // onGenerate(fullRow?: any) {
  //   this.selectedRow = fullRow ?? null;
  //   console.log('called', this.selectedRow);

  //   this.filterProcName = this.selectedRow?.gd_filter_proc_name;
  //   this.procesStatusCode = this.selectedRow?.process_status_code;
  //   this.rowId = this.selectedRow?.rowid_seq;
  //   this.operation = this.selectedRow?.operation;
  //   this.gdProcName = this.selectedRow?.gd_proc_name;
  //   this.procesSeqNo = this.selectedRow?.process_seqno;

  //   // Parse operation JSON if available
  //   if (this.operation) {
  //     try {
  //       const parsedOp = JSON.parse(this.operation);
  //       this.generationCallbacks = parsedOp?.generation_callbacks || [];
  //     } catch (err) {
  //       console.error('Invalid operation JSON:', err);
  //       this.generationCallbacks = [];
  //     }
  //   } else {
  //     this.generationCallbacks = [];
  //   }

  //   // CASE 1: Show Generate Format Popup
  //   if (
  //     this.operation != null &&
  //     this.procesStatusCode == 'RC' &&
  //     this.filterProcName == null
  //   ) {
  //     this.popupType = 'generateFormat';
  //     this.isGeneratePopupOpen = true;
  //   }

  //   // CASE 2: Filter Popup
  //   else if (this.filterProcName != null && this.filterProcName !== 'null') {
  //     this.popupType = 'filterPopup';
  //     this.isGeneratePopupOpen = true;
  //   }

  //   // CASE 3: Direct API Call
  //   else {
  //     console.log('Direct API Call without Popup');
  //     this.isGeneratePopupOpen = false;
  //     this.fetchGenerateTable(this.rowId, this.filterClauseGenerate, false);
  //   }
  // }

  // downloadFormat(row?: any) {
  //   // Check if download_callbacks exist and have values
  //   if (row?.downlaod_callbacks && row.downlaod_callbacks.length > 0) {
  //     this.popupType = 'downloadPopup';
  //     this.isGeneratePopupOpen = true;
  //     this.generationCallbacks = row.downlaod_callbacks; // pass data dynamically
  //   } else {
  //     // Don’t open popup if not present
  //     console.log("No download callbacks found — skipping popup");
  //     this.isGeneratePopupOpen = false;
  //   }
  // }
  onGenerate(fullRow?: any) {
    this.selectedRow = fullRow ?? null;
    const rowId = this.selectedRow?.rowid_seq;

    this.filterProcName = this.selectedRow?.gd_filter_proc_name;
    this.procesStatusCode = this.selectedRow?.process_status_code;
    this.rowId = rowId;
    this.operation = this.selectedRow?.operation;
    this.gdProcName = this.selectedRow?.gd_proc_name;
    this.procesSeqNo = this.selectedRow?.process_seqno;

    console.log(this.operation);

    if (this.operation) {
      try {
        const parsedOp = JSON.parse(this.operation);
        this.generationCallbacks = parsedOp?.generation_callbacks || [];
      } catch (err) {
        console.error('Invalid operation JSON:', err);
        this.generationCallbacks = [];
      }
    } else {
      this.generationCallbacks = [];
    }

    // ✅ First check for popup condition before marking as in-process
    if (this.operation != null && (this.procesStatusCode == 'RC' || this.procesStatusCode == 'ZC') && this.filterProcName == null) {
      this.popupType = 'generateFormat';
      this.isGeneratePopupOpen = true;
      return; // stop here so we don’t set RA or call API
    } else if (this.filterProcName != null && this.filterProcName !== 'null') {
      this.popupType = 'filterPopup';
      this.isGeneratePopupOpen = true;
      return;
    }

    // 🔹 Show "In process" only when no popup is shown
    this.loadingFields[rowId] = true;
    this.selectedRow.process_status_code = 'RA';
    this.selectedRow.process_status_code = 'ZA';

    this.isGeneratePopupOpen = false;
    this.fetchGenerateTable(rowId, this.filterClauseGenerate, false);
  }


  downloadFormat(row: any) {
    this.selectedRow = row; // ✅ ensure this happens before popup opens

    try {
      const operation =
        typeof row.operation === 'string'
          ? JSON.parse(row.operation)
          : row.operation;

      const downloadCallbacks = Array.isArray(operation?.downlaod_callbacks)
        ? operation.downlaod_callbacks
        : [];

      if (downloadCallbacks.length > 0) {
        this.popupType = 'downloadPopup';
        this.isGeneratePopupOpen = true;
        console.log('✅ Opening popup with:', downloadCallbacks);
      } else {
        this.isGeneratePopupOpen = false;
        console.warn('⚠️ No download callbacks found.');
      }
    } catch (error) {
      console.error('❌ Failed to parse operation JSON:', error);
      this.isGeneratePopupOpen = false;
    }
  }

  getGenerateStatus: any;

  fetchGenerateTable(
    rowId: any,
    filterClauseGenerate: any,
    fromPopup: boolean
  ) {
    console.log('called fetchGenerateTable');
    const userFilters = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];

    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    // Merge user filters and defaults: user filters take priority
    const finalFilterClause = [
      ...userFilters, // user-selected filters first
      ...newFilterClause.filter(
        (df) =>
          !userFilters.some(
            (uf) => uf.filter_col_field === df?.filter_col_field
          )
      ),
    ];
    // ✅ Conditionally decide which filter to send
    const selectedFilterClause = fromPopup
      ? filterClauseGenerate
      : finalFilterClause;

    const sdata: any = {
      a_iud_seqno: '',
      a_db_total_records: '100',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: this.dynaUserData.default_sub_module_type_code,
      a_session_seqno: '',
      a_proc_type: this.gdProcName,
      a_user_code: this.localUserData.user_code,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_process_seqno: '',
      a_iud_type: this.iudtype,
      a_filter_clause: selectedFilterClause,
      a_rowid_seq: rowId,
      dashboard: 'View'
    };
    this.apiService.getTableData(`/Comman/generate_dynamic_report`, sdata).subscribe({
      next: (data) => {
        const firstResult = data?.result?.[0];


        // Fetch details to refresh table
        this.fetchDetails(rowId, selectedFilterClause);


        // ✅ Stop loader for this row
        delete this.loadingFields[rowId];
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;

        // ❌ Stop loader even if error
        delete this.loadingFields[rowId];
      },
    });

    // this.apiService.getTableData(`/comman/dynamic`, sdata).subscribe({
    //   next: (data) => {
    //     console.log('Raw response:', data);

    //     const firstResult = data?.result?.[0]; // get the first object in array
    //     if (firstResult?.a_proc_error == 1) {
    //       // or '1' if your API returns string
    //       console.log('✅ fetchGenerateTable success:', firstResult);

    //       // Call fetchDetails
    //       this.fetchDetails(rowId, selectedFilterClause);
    //     }

    //     console.log('this.userData:', this.userData);
    //   },
    //   error: (error) => {
    //     this.errorMessage = error.message || 'Failed to fetch users.';
    //     this.showError(this.errorMessage);
    //     this.loading = false;
    //     this.isLoadingMore = false;
    //   },
    // });
  }


  fetchDetails(rowId: any, filterClauseGenerate: any, skipFullFetch: boolean = false) {
    const requestBody = {
      a_iud_seqno: '',
      a_db_total_records: '1000',
      a_pagination_count: '0',
      a_is_pen_flag: '',
      a_sub_module_type_code: this.dynaUserData.default_sub_module_type_code,
      a_session_seqno: '',
      a_proc_type: 'get_grdt_mis_mast',
      a_user_code: this.localUserData.user_code,
      a_entity_code: this.dynaUserData.entity_code,
      a_client_code: this.dynaUserData.client_code,
      a_acc_year: this.dynaUserData.default_acc_year,
      a_quarter_no: this.dynaUserData.default_quarter_no,
      a_tran_month: this.dynaUserData.default_tran_month,
      a_validation_client_level: this.dynaUserData.client_code_level,
      a_tran_from_date: this.dynaUserData.default_from_date,
      a_tran_to_date: this.dynaUserData.default_to_date,
      a_tds_type_code: this.dynaUserData.default_tds_type_code,
      a_module_type_code: this.dynaUserData.default_module_type_code,
      a_first_level_client_code: this.dynaUserData.first_level_client_code,
      a_client_code_level: this.dynaUserData.client_code_level,
      a_user_level: this.dynaUserData.user_level,
      a_login_type: 'login_id',
      a_email_id: this.dynaUserData.email_id,
      a_filter_clause: filterClauseGenerate,
      a_in_parameter_json: [{ a_rowid_seq: rowId }],
    };

    this.apiService
      .getsingleDetails('/MIS/get_grdt_mis_mast', requestBody)
      .subscribe({
        next: (response) => {
          const roleData =
            response?.result?.get_grdt_mis_mast?.get_grdt_mis_mast_detail?.[0];

          if (!roleData) {
            if (!skipFullFetch) {
               this.fetchData();
            }
            return;
          }

          const index = this.paginatedList.findIndex(
            (r: any) => r.rowid_seq === rowId
          );

          if (index !== -1) {
            // ✅ Replace array immutably to trigger UI refresh
            const updatedList = [...this.paginatedList];
            updatedList[index] = {
              ...updatedList[index],
              ...roleData,
            };
            this.paginatedList = updatedList;
          }

          // ✅ Stop loader for this row after update
          this.loadingFields[rowId] = false;
        },
        error: () => {
          this.showError('Failed to fetch User details.');
          this.loadingFields[rowId] = false;
        },
      });
  }

  handleClosePopup() {
    this.isGeneratePopupOpen = false; // or any logic to close popup
    this.isViewReportOpen = false;
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }
  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  myloaderloding: boolean = false;
  loadingFields: { [rowid_seq: string]: boolean } = {};


  processKill(row: any) {
    const sdata = this.apiService.generateSData(
      'get_tiud_import_tran',
      this.localUserData,
      (this.filterClause = []),
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: 'PROCESS_CANCEL',
        a_process_level: 1,
        processStatusCode: 'ZK',
        seqnumber: row?.process_seqno,
      }
    );

    this.myloaderloding = true;

    this.apiService.getTableData('/Comman/dynamic', sdata).subscribe({
      next: (data) => {
        console.log(data, 'Process Kill Response');

        if (data?.result?.a_proc_error == 0) {
          this.toastService.showSuccess('Process cancelled successfully.');

          // ✅ Update only this row — clear fields
          const targetRow = this.paginatedList.find(
            (r: any) => r.rowid_seq === row.rowid_seq
          );
          if (targetRow) {
            targetRow.last_generated_time = '';
            targetRow.download = 'ZK';
            targetRow.download_file_name = 'ZK';
            // targetRow.download_file_name_pdf = 'ZK';
            targetRow.process_status_code = 'ZK';
            this.paginatedList = [...this.paginatedList]; // Force refresh
          }

          // ✅ Now call fetchDetails only for that row
          this.fetchDetails(row.rowid_seq, this.filterClause, true);
        } else {
          this.myloaderloding = false;
          this.errorMessage =
            data?.result?.[0]?.a_proc_error_message || 'Process kill failed.';
          this.toastService.showError(this.errorMessage);
        }
      },
      error: (error) => {
        this.myloaderloding = false;
        this.errorMessage = error.message || 'Failed to kill process.';
        this.toastService.showError(this.errorMessage);
      },
    });
  }

  isViewReportOpen: boolean = false;
  toggleDrawer(row: any) {
    console.log(row);
    this.selectedRow = row;

    this.isViewReportOpen = true;
  }

  // downloadReportFile(filename: string, source: string) {
  //   if (!filename) return;

  //   // Replace '#' → '/' and remove any trailing '/zip'
  //   let formattedFilename = filename.replace(/#/g, '/').replace(/\/zip$/, '');

  //   // ✅ Ensure it starts with a leading '/'
  //   if (!formattedFilename.startsWith('/')) {
  //     formattedFilename = '/' + formattedFilename;
  //   }

  //   // If download_file_path === 'DB', route to S3
  //   const finalSource = source === 'DB' ? 's3' : source;

  //   console.log('Formatted Filename:', formattedFilename);
  //   console.log('Final Source:', finalSource);

  //   this.apiService.reportFileDownload(formattedFilename, finalSource);
  // }


   sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";


   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }

}
