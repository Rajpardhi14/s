import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BasicFilterComponent } from '../../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../../shared/components/advance-filter/advance-filter.component';
import { UserdataService } from '../../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../../core/services/componentservice/apiservice.service';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import {
  capitalizeEachWord,
  formatDatesend,formatValue
} from '../../../../shared/utils/passmatch';
import { NodataComponent } from '../../../../shared/components/nodata/nodata.component';
import { TableskeletonComponent } from '../../../../shared/components/tableskeleton/tableskeleton.component';
import { ScreensizeService } from '../../../../core/services/screensize/screensize.service';
@Component({
  selector: 'app-view-report',
  standalone: true,
   imports: [CommonModule, BasicFilterComponent,
    NodataComponent, AdvanceFilterComponent,TableskeletonComponent],
  templateUrl: './view-report.component.html',
  styleUrl: './view-report.component.css'
})
export class ViewReportComponent {
  @Input() isViewReportOpen: any;
  @Input() selectedRow: any = null;
  @Output() close = new EventEmitter<void>();

  capitalizeEachWord = capitalizeEachWord;
filterProcName: any;
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  localUserData: any;
  dynaUserData: any;
  filterClause: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  FYYear: string = 'Yes';
  iudtype: string = 'View';
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  errorMessage = '';
  filtersSubmitted = false;
  isLoading: boolean = false;
  selectedValue: string[] = [];
  selectedLabel: any;
  procesStatusCode: any;
  // filterProcName:any;
  operation: any;
  rowId: any;
headers: any[] = [];
  tableBody: any[] = [];
    paginatedList: any;
  scrollTimeout: any = null;
  //  isLoading: boolean = false;
  loading = false;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  userData: any;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  totalcount: any;
  Math = Math;
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
   heightToSubtract: number = 460;
  remainingHeight: number = 0;
  dgProcName:any;
    detailsLoader:boolean =false;
      formatValue =formatValue;
constructor(
    private toastService: ToastService,
    private apiService: ApiserviceService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
     private screenSizeService: ScreensizeService
  ) {}


  ngOnChanges(changes: SimpleChanges): void {
     this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

     console.log(this.selectedRow);
     console.log( this.selectedRow?.gd_filter_proc_name);

    this.filterProcName = this.selectedRow?.gd_filter_proc_name;
    this.procesStatusCode = this.selectedRow?.process_status_code;
     this.rowId = this.selectedRow?.rowid_seq;
    this.operation = this.selectedRow?.operation;
    // console.log(this.operation,'operation');
  this.gdProcName = this.selectedRow?.gd_proc_name;
  this.dgProcName = this.selectedRow?.gt_proc_name;
    // console.log(this.filterProcName, this.procesStatusCode);
    console.log('dgProcName', this.dgProcName);
    
    if (this.selectedRow?.gd_filter_proc_name !== null && this.selectedRow?.gd_filter_proc_name !== undefined) {
  this.fetchFilter();
}
   if (this.selectedRow?.gt_proc_name !== null && this.selectedRow?.gt_proc_name !== undefined) {
  this.fetchGrandTotal();
}
    this.fetchGenerateTable(this.rowId)
    this.fetchGrandTotal();
     this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();
    
  }



  
  //#region filetr
  private fetchFilter(): void {
    const filterProcName = this.selectedRow?.gd_filter_proc_name;
    //  console.log(filterProcName);
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      filterProcName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );

    this.apiService.getFilterData(`/comman/dynamic`, sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.[filterProcName]?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.[filterProcName]?.[1]?.advance_filter;
          setTimeout(() => {
            this.setDefaultFilters();
          }, 0);
          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage =
            response.result?.[0].a_proc_error_message ||
            'Please Check Endpoint';
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion
  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => {});
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }
  setDefaultFilters() {
    if (!this.advance_filter || !this.filterForm) return;

    this.advance_filter.forEach((field: any) => {
      // Set default for quarter_no
      if (field.filter_col_field === 'quarter_no') {
        const defaultQuarter = this.dynaUserData?.default_quarter_no || 'Q1';
        this.filterForm.get(field.filter_col_field)?.setValue(defaultQuarter);
      }

      // Set default for tds_type_code
      if (field.filter_col_field === 'tds_type_code') {
        const defaultTdsType =
          this.dynaUserData?.default_tds_type_code || '26Q';
        this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
      }
      // if (field.filter_col_external === 0 ) {
      //   const dvs=field.filter_col_external_default_value
      //  this.filterForm.get(field.filter_col_field)?.setValue(dvs);
      // }

      if (
        field.filter_col_external === 0 &&
        field.filter_col_external_default_value &&
        field.filter_col_external_default_value !== ''
      ) {
        this.filterForm
          .get(field.filter_col_field)
          ?.setValue(field.filter_col_external_default_value);
      }
    });

    // this.selectedFilters = this.getSelectedFilters();
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }
  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }
  gearboxState: { [key: string]: boolean } = {};

  saveGearboxState() {
  this.headers.forEach(h => {
    this.gearboxState[h.field] = h.visible;
  });
}

  onSubmit() {
      // 1️⃣ Save the gearbox state before table refresh
  this.saveGearboxState(); // save current visibility
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

      this.filterClause = this.buildFilterClause();

      Promise.all([this.fetchGenerateTable(this.rowId), this.fetchGrandTotal()]).finally(() => {

        // this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {
          // For "wc", find the condition based on selected value
          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue
          );
          filterValue = selectedOption ? selectedOption.condition : '';
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    // Include search term if present
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }

    return filterClause;
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  selectedFilters: { label: string; field?: string; value: string }[] = [];

  getSelectedFilters() {
    const selectedFilters: { label: string; field?: string; value: string }[] =
      [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);

        if (
          control &&
          control.value != null &&
          control.value.toString().trim() !== ''
        ) {
          let label = field.filter_col_prompt;
          const dependValue = field.filter_col_depend_value?.find(
            (dv: any) => dv.value == control.value
          );
          if (dependValue?.label) {
            label = dependValue.label;
          }

          selectedFilters.push({
            label,
            field: field.filter_col_field,
            value: control.value.toString().trim(),
          });
        }
      });
    }

    // // Add search term filter (if applicable)
    // if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
    //   selectedFilters.push({
    //     label: this.selectedOption.label,
    //     field: this.selectedOption.field,
    //     value: this.searchTerm.toUpperCase(),
    //   });
    // }

    return selectedFilters;
  }
  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }


  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }
  onClose() {
    this.close.emit();
  }
  gdProcName: any;

  userHasScrolled: boolean = false;
  usergrandtotal: number = 0;

  fetchGenerateTable(rowId: any,) {
      this.detailsLoader = true;
    const userFilters = Array.isArray(this.filterClause)
      ? this.filterClause
      : [];
if (this.offset === 0) {
      this.loading = true;
    } else {
       this.detailsLoader = false;
      this.isLoadingMore = true;
      
    }
    // Your default filters (always applied)
    const newFilterClause = [
      {
        filter_col_field: 'quarter_no',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_quarter_no,
        filter_col_field_alias: 'a.',
      },
      {
        filter_col_field: 'tds_type_code',
        filter_col_depend_operator: '=',
        filter_col_value: this.dynaUserData.default_tds_type_code,
        filter_col_field_alias: 'a.',
      },
    ];
    // Merge user filters and defaults: user filters take priority
    const finalFilterClause = [
      ...userFilters, // user-selected filters first
      ...newFilterClause.filter(
        (df) =>
          !userFilters.some(
            (uf) => uf.filter_col_field === df?.filter_col_field
          )
      ),
    ];
      // ✅ Conditionally decide which filter to send
  const selectedFilterClause =finalFilterClause;

    // const sdata: any = {
    //   a_iud_seqno: '',
    //   a_db_total_records: this.limit,
    //   a_pagination_count: this.offset,
    //   a_is_pen_flag: '',
    //   a_sub_module_type_code: '',
    //   a_session_seqno: '',
    //   a_proc_type: this.gdProcName,
    //   a_user_code: this.localUserData.user_code,
    //   a_tran_from_date: this.dynaUserData.default_from_date,
    //   a_tran_to_date: this.dynaUserData.default_to_date,
    //   a_entity_code: this.dynaUserData.entity_code,
    //   a_client_code: this.dynaUserData.client_code,
    //   a_acc_year: this.dynaUserData.default_acc_year,
    //   a_quarter_no: this.dynaUserData.default_quarter_no,
    //   a_tran_month: this.dynaUserData.default_tran_month,
    //   a_validation_client_level: this.dynaUserData.client_code_level,
    //   a_tds_type_code: this.dynaUserData.default_tds_type_code,
    //   a_module_type_code: this.dynaUserData.default_module_type_code,
    //   a_first_level_client_code: this.dynaUserData.first_level_client_code,
    //   a_process_seqno: '',
    //   a_iud_type: this.iudtype,
    //   a_filter_clause: selectedFilterClause,
    //   a_rowid_seq: rowId,
    // };


       const sdata = this.apiService.generateSData(

      this.gdProcName,
      this.localUserData,
      selectedFilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService.getTableData(`/comman/dynamic`, sdata).subscribe({
      next: (data) => {
        if (data?.result?.a_proc_error == '0') {
          const userData = data?.result?.[this.gdProcName];
          
         if (userData?.[`${this.gdProcName}_header`]) {
            this.headers = userData[`${this.gdProcName}_header`].map(
              (header: any) => ({
                ...header,
                visible:
        this.gearboxState.hasOwnProperty(header.field)
          ? this.gearboxState[header.field] // restore previous state
          : header.display === 1,   // default if no previous state
              })
            );
          }
          // console.log(data);
          // console.log(this.headers);
          // console.log(data);
          // this.allUsersData = userData || {};
          // this.mergeGroups = {};
          // this.fieldToMergeGroup = {};
          this.tableBody = userData[`${this.gdProcName}_detail`] || [];
          // this.buildMergeGroups();
          if (this.offset > 0) {
            setTimeout(() => {
              this.paginatedList = [...this.paginatedList, ...this.tableBody];
              this.isLoadingMore = false;
            }, 300);
          } else {
            this.paginatedList = this.tableBody;
          }
        } else {
         this.detailsLoader =false;
          this.errorMessage = data.result[0].a_proc_error_message;
          this.showError(this.errorMessage);
        }
        this.detailsLoader =false;
          this.loading = false;
      },
      error: (error) => {
         this.detailsLoader =false;
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
      },
    });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchGenerateTable(this.rowId);
        this.fetchGrandTotal();
        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  isGenerateStatus:any;
 private fetchGrandTotal(): void {
const sdata = this.apiService.generateSData(

      this.dgProcName,
      this.localUserData,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService.getGrandTotal(`/comman/dynamic`, sdata).subscribe({
     next: (data) => {
        this.isLoadingMore = false;
        if (data?.result?.a_proc_error == 0) {
          this.usergrandtotal =
        data?.result?.[this.dgProcName]?.[0]?.rec || null;
            this.totalcount = this.usergrandtotal;
        }
        console.log(this.usergrandtotal);
      },
      error: (error) => {
        this.errorMessage = error.message || 'Failed to fetch users.';
        this.showError(this.errorMessage);
        this.loading = false;
        this.isLoadingMore = false;
      },
    });
  }


    calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

    isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
    return dateFields.includes(field);
  }
    formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

  sortedColumn: string = "";
  sortDirection: "asc" | "desc" = "asc";


   sortBy(column: string) {
    if (this.sortedColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortedColumn = column;
      this.sortDirection = "asc";
    }
    this.paginatedList?.sort((a: any, b: any) => {
      if (this.sortDirection === "asc") {
        return a[this.sortedColumn] > b[this.sortedColumn] ? 1 : -1;
      } else {
        return a[this.sortedColumn] < b[this.sortedColumn] ? 1 : -1;
      }
    });
  }
}
