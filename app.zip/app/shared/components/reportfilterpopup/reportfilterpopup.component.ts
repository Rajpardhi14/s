import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
} from '@angular/core';
import { BasicFilterComponent } from '../basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../advance-filter/advance-filter.component';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reportfilterpopup',
  standalone: true,
  imports: [CommonModule, BasicFilterComponent, AdvanceFilterComponent],
  templateUrl: './reportfilterpopup.component.html',
  styleUrl: './reportfilterpopup.component.css',
})
export class ReportfilterpopupComponent {
  @Input() isGeneratePopupOpen: any;
    @Input() isGeneratePopupOpenD: any;
@Input() selectedRowD: any;
@Input() selectedRow: any;
@Input() downloadCallbacksD: string[] = []; 

  @Output() close = new EventEmitter<void>();
  // @Input() popupType: 'generateFormat' | 'filterPopup' | 'downloadPopup' | null = null;
  // @Input() popupType: string | null = null;
  @Input() popupType: 'generateFormat' | 'filterPopup' | 'downloadPopup' | null = null;


  @Output() generate = new EventEmitter<{
    rowId: string;
    filterClauseGenerate: string;
  }>();
 generationCallbacks: string[] = [];
 downloadCallbacks: string[] = [];
  filterProcName: any;
  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  localUserData: any;
  dynaUserData: any;
  filterClause: any;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;
  errorMessage = '';
  filtersSubmitted = false;
  isLoading: boolean = false;
  selectedValue: string[] = [];
  selectedLabel: any;
  procesStatusCode: any;
  // filterProcName:any;
  operation: any;
  downloadFileName:any;
  downloadFilePath:any;
  constructor(
    private toastService: ToastService,
    private apiService: ApiserviceService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder
  ) {}

//   ngOnChanges(changes: SimpleChanges): void {
//     this.localUserData = this.userlocaldataService.getLocalUserData();
//     this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

//      console.log(this.selectedRow);
//     //  console.log( this.selectedRow?.gd_filter_proc_name);
// console.log( this.dynaUserData);
//     this.filterProcName = this.selectedRow?.gd_filter_proc_name;
//     this.procesStatusCode = this.selectedRow?.process_status_code;

//     this.operation = this.selectedRow?.operation;
//     // console.log(this.operation,'operation');

//     // console.log(this.filterProcName, this.procesStatusCode);
//     this.fetchFilter();
//      this.downloadFileName = this.selectedRow.download_file_name || '';
//     this.downloadFilePath = this.selectedRow.download_file_path || 'DB';

//          this.downloadFileName = this.selectedRowD.download_file_name || '';
//     this.downloadFilePath = this.selectedRowD.download_file_path || 'DB';
//   }

get activeDownloadCallbacks(): string[] {
  return this.downloadCallbacksD?.length
    ? this.downloadCallbacksD
    : this.downloadCallbacks || [];
}


ngOnChanges(changes: SimpleChanges): void {
  this.localUserData = this.userlocaldataService.getLocalUserData();
  this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};

  console.log('selectedRow:', this.selectedRow);
  console.log('selectedRowD:', this.selectedRowD);
  console.log('dynaUserData:', this.dynaUserData);

  this.filterProcName = this.selectedRow?.gd_filter_proc_name;
  this.procesStatusCode = this.selectedRow?.process_status_code;
  this.operation = this.selectedRow?.operation;

  this.fetchFilter();

  // ✅ Use selectedRowD if available, otherwise selectedRow
  if (this.selectedRowD) {
    this.downloadFileName = this.selectedRowD.download_file_name || '';
    this.downloadFilePath = this.selectedRowD.download_file_path || 'DB';
  } else if (this.selectedRow) {
    this.downloadFileName = this.selectedRow.download_file_name || '';
    this.downloadFilePath = this.selectedRow.download_file_path || 'DB';
  } else {
    this.downloadFileName = '';
    this.downloadFilePath = 'DB';
  }
   console.log('✅ Opening popup with:', this.downloadCallbacksD);
}

  ngOnInit(): void {

// if (this.selectedRow?.operation) {
//       try {
//         const parsedOp = JSON.parse(this.selectedRow.operation);
//         this.generationCallbacks = parsedOp?.generation_callbacks || [];
//          this.downloadCallbacks = parsedOp?.downlaod_callbacks || []; 
//       } catch (err) {
//         console.error('Invalid operation JSON:', err);
//       }
//     }
if (this.operation) {
  try {
    let parsedOp = this.operation;

    // 🔹 If it's a string, parse it
    if (typeof parsedOp === 'string') {
      parsedOp = JSON.parse(parsedOp);
    }

    // 🔹 Handle wrong spelling in key ("downlaod_callbacks")
    this.generationCallbacks = parsedOp?.generation_callbacks || [];
    this.downloadCallbacks =
      parsedOp?.download_callbacks || parsedOp?.downlaod_callbacks || [];

  } catch (err) {
    console.error('Invalid operation JSON:', err, this.operation);
    this.generationCallbacks = [];
  }
} else {
  this.generationCallbacks = [];
}

  }




  
  //#region filetr
  private fetchFilter(): void {
    const filterProcName = this.selectedRow?.gd_filter_proc_name;
    //  console.log(filterProcName);
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      filterProcName,
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { iudtype: this.iudtype }
    );

    this.apiService.getFilterData(`/comman/dynamic`, sdata).subscribe({
      next: (response) => {
        if (response?.result?.a_proc_error == '0') {
          this.basic_filter =
            response?.result?.[filterProcName]?.[0]?.basic_filter;
          this.advance_filter =
            response?.result?.[filterProcName]?.[1]?.advance_filter;
          setTimeout(() => {
            this.setDefaultFilters();
          }, 0);
          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          this.errorMessage =
            response.result?.[0].a_proc_error_message ||
            'Please Check Endpoint';
          // this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
  }
  //#endregion
  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => {});
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }
  setDefaultFilters() {
    if (!this.advance_filter || !this.filterForm) return;

    this.advance_filter.forEach((field: any) => {
      // Set default for quarter_no
      if (field.filter_col_field === 'quarter_no') {
        const defaultQuarter = this.dynaUserData?.default_quarter_no || 'Q1';
        this.filterForm.get(field.filter_col_field)?.setValue(defaultQuarter);
      }

      // Set default for tds_type_code
      if (field.filter_col_field === 'tds_type_code') {
        const defaultTdsType =
          this.dynaUserData?.default_tds_type_code || '26Q';
        this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
      }
      // if (field.filter_col_external === 0 ) {
      //   const dvs=field.filter_col_external_default_value
      //  this.filterForm.get(field.filter_col_field)?.setValue(dvs);
      // }

      if (
        field.filter_col_external === 0 &&
        field.filter_col_external_default_value &&
        field.filter_col_external_default_value !== ''
      ) {
        this.filterForm
          .get(field.filter_col_field)
          ?.setValue(field.filter_col_external_default_value);
      }
    });

    // this.selectedFilters = this.getSelectedFilters();
  }

  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }
  clearInput() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
    this.filterClause = this.buildFilterClause();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue === 'string') {
          controlValue = controlValue.trim().toLowerCase();
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

      this.filterClause = this.buildFilterClause();

      Promise.all([]).finally(() => {
        // this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {
          // For "wc", find the condition based on selected value
          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue
          );
          filterValue = selectedOption ? selectedOption.condition : '';
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue !== '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    // Include search term if present
    if (
      this.searchTerm &&
      this.searchTerm.trim() !== '' &&
      this.selectedOption
    ) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
        filter_col_value: this.searchTerm.toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }

    return filterClause;
  }

  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() !== '') {
      count++;
    }
    return count;
  }
  selectedFilters: { label: string; field?: string; value: string }[] = [];

  getSelectedFilters() {
    const selectedFilters: { label: string; field?: string; value: string }[] =
      [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);

        if (
          control &&
          control.value != null &&
          control.value.toString().trim() !== ''
        ) {
          let label = field.filter_col_prompt;
          const dependValue = field.filter_col_depend_value?.find(
            (dv: any) => dv.value == control.value
          );
          if (dependValue?.label) {
            label = dependValue.label;
          }

          selectedFilters.push({
            label,
            field: field.filter_col_field,
            value: control.value.toString().trim(),
          });
        }
      });
    }

    // // Add search term filter (if applicable)
    // if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
    //   selectedFilters.push({
    //     label: this.selectedOption.label,
    //     field: this.selectedOption.field,
    //     value: this.searchTerm.toUpperCase(),
    //   });
    // }

    return selectedFilters;
  }
  clearFilter(index: number) {
    const selectedFilters = this.getSelectedFilters();
    const selectedFilter = selectedFilters[index];
    if (!selectedFilter) return;
    const filterToRemove = this.advance_filter.find((field: any) =>
      field.filter_col_depend_value?.some(
        (dependValue: any) => dependValue.label === selectedFilter.label
      )
    );

    const filterRemove = this.advance_filter.find(
      (field: any) => field.filter_col_prompt === selectedFilter.label
    );
    if (filterToRemove) {
      const control = this.filterForm.get(filterToRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    } else if (filterRemove) {
      const control = this.filterForm.get(filterRemove.filter_col_field);
      if (control) {
        control.reset();
      }
    }
    this.filterClause = this.buildFilterClause();
    // this.fetchTable();
    // this.fetchGrandTotal();
  }

  resetFilter() {
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }


  onGenerateClick() {
    const rowId = this.selectedRow?.rowid_seq;
    const filterClauseGenerate = this.filterClause;
    console.log('Generate button clicked in popup with rowId:', rowId);
    console.log(this.filterProcName);
    if (this.filterProcName != null) {
      console.log(this.filterProcName);
      this.popupType = 'filterPopup'
    }
    // console.log(filterClauseGenerate)
    this.generate.emit({ rowId, filterClauseGenerate }); // 👈 send rowId back to parent
  }


  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  selected: string | null = null;
  // selectOption(type: string) {
  //   this.selected = type;
  //   // this.formatSelected(type);
  // }
// selectOption(format: string): void {
//   if (!this.selectedRow?.download_file_name) return;

//   let rawFileName = this.selectedRow.download_file_name;
//   // Example: "#TDS_TEXT_FILES#47246443.zip#zip" or "TDS_TEXT_FILES#47246443.txt#txt"

//   // 🧹 Clean up the filename
//   let formattedFile = rawFileName
//     .replace(/^#/, '')          // remove leading '#'
//     .replace(/#/g, '/');        // replace all '#' with '/'

//   // Ensure single leading slash
//   if (!formattedFile.startsWith('/')) {
//     formattedFile =  formattedFile;
//   }

//   // 🧠 Remove any trailing "/pdf", "/txt", "/xlsx", or "/zip" after extension
//   formattedFile = formattedFile.replace(/(\.\w+)(\/\w+)?$/, '$1');

//   // 🧠 Replace the file extension based on selected format
//   if (format === 'pdf') {
//     formattedFile = formattedFile.replace(/\.\w+$/, '.pdf');
//   } else if (format === 'excel') {
//     formattedFile = formattedFile.replace(/\.\w+$/, '.xlsx');
//   } else if (format === 'text' || format === 'zip') {
//     // If it's already .txt or .zip, don't add extra
//     if (!formattedFile.match(/\.(txt|zip)$/)) {
//       formattedFile = formattedFile.replace(/\.\w+$/, '.txt');
//     }
//   }

//   const source = 's3';

//   console.log('✅ Final formattedFile:', formattedFile);

//   this.apiService.reportFileDownload(formattedFile, source)
//     .then(() => console.log(`${format.toUpperCase()} file download started`))
//     .catch(err => console.error(`${format.toUpperCase()} download failed:`, err));

//   this.onClose();
// }



selectOption(format: string): void {
  const row = this.selectedRowD || this.selectedRow;
  if (!row?.download_file_name) return;

  let rawFileName = row.download_file_name;
  let formattedFile = rawFileName
    .replace(/^#/, '')
    .replace(/#/g, '/')
    .replace(/\/(zip|txt|pdf|xlsx)$/i, ''); // remove trailing /txt, /pdf, etc.

  if (formattedFile.startsWith('/')) {
    formattedFile = formattedFile.slice(1);
  }

  // 🧹 Remove extension like ".txt", ".pdf", etc.
  formattedFile = formattedFile.replace(/\.\w+$/, '');

  // ✅ Fix specifically for text format — remove any extra "/txt"
  if (format === 'text') {
    formattedFile = formattedFile.replace(/\/txt$/i, '');
    formattedFile += '.zip';
  } else if (format === 'pdf') {
    formattedFile += '.pdf';
  } else if (format === 'excel') {
    formattedFile += '.xlsx';
  }

  const source = 's3';

  let headerJson: any;
  if (this.selectedRowD) {
    headerJson = {
      ReportName: this.selectedRowD?.process_type_name || '',
      ClientName: this.dynaUserData?.client_code_details || '',
      userName:this.localUserData?.user_name || '',
      Branch: this.selectedRowD?.bank_branch_code || '',
      quater_no: this.dynaUserData?.default_quarter_no || '',
      FormType:this.dynaUserData?.default_tds_type_code || '',
    };
  } else if (this.selectedRow) {
    headerJson = {
      ReportName: this.selectedRow?.report_heading || '',
      ClientName: this.dynaUserData?.client_code_details || '',
      Branch: this.selectedRow?.branch_name || '',
    };
  } else {
    headerJson = {};
  }

  console.log('✅ Final formattedFile for API:', formattedFile);
  console.log('✅ Header JSON:', headerJson);

  this.apiService
    .reportFileDownload(formattedFile, source, headerJson)
    .then(() => console.log(`${format.toUpperCase()} download started`))
    .catch(err => console.error(`${format.toUpperCase()} download failed:`, err));

  this.onClose();
}







// selectOption(format: string): void {
//   const row = this.selectedRowD || this.selectedRow;
//   if (!row?.download_file_name) return;

//   let rawFileName = row.download_file_name;
//   let formattedFile = rawFileName
//     .replace(/^#/, '')
//     .replace(/#/g, '/')
//     .replace(/\/(zip|txt|pdf|xlsx)$/i, '');

//   if (formattedFile.startsWith('/')) {
//     formattedFile = formattedFile.slice(1);
//   }

//   // Replace extension properly
//   formattedFile = formattedFile.replace(/\.\w+$/, '');
//   if (format === 'pdf') {
//     formattedFile += '.pdf';
//   } else if (format === 'excel') {
//     formattedFile += '.xlsx';
//   } else if (format === 'text') {
//     formattedFile += '.txt';
//   }

//   const source = 's3';

//   // ✅ Use correct row for header JSON
//   let headerJson: any;
//   if (this.selectedRowD) {
//     headerJson = {
//       ReportName: this.selectedRowD?.process_type_name || '',
//       ClientName: this.dynaUserData?.client_code_details || '',
//       Branch: this.selectedRowD?.bank_branch_code || '',
//       quater_no: this.dynaUserData?.quarter_no || '',
      
//     };
//   } else if (this.selectedRow) {
//     headerJson = {
//       ReportName: this.selectedRow?.report_heading || '',
//       ClientName: this.dynaUserData?.client_code_details || '',
//       Branch: this.selectedRow?.branch_name || ''
//     };
//   } else {
//     headerJson = {};
//   }

//   console.log('✅ Final formattedFile for API:', formattedFile);
//   console.log('✅ Header JSON:', headerJson);

//   this.apiService
//     .reportFileDownload(formattedFile, source, headerJson)
//     .then(() => console.log(`${format.toUpperCase()} ZIP download started`))
//     .catch(err => console.error(`${format.toUpperCase()} ZIP download failed:`, err));

//   this.onClose();
// }









  onClose() {
    this.close.emit();
  }


  //   downloadReportFile(filename: string, source: string,headerJson:any) {
  //   if (!filename) return;

  //   // Replace '#' → '/' and remove any trailing '/zip'
  //   let formattedFilename = filename.replace(/#/g, '/').replace(/\/zip$/, '');

  //   // ✅ Ensure it starts with a leading '/'
  //   if (!formattedFilename.startsWith('/')) {
  //     formattedFilename =  formattedFilename;
  //   }

  //   // If download_file_path === 'DB', route to S3
  //   const finalSource = source === 'DB' ? 's3' : source;

  //   console.log('Formatted Filename:', formattedFilename);
  //   console.log('Final Source:', finalSource);

  //   this.apiService.reportFileDownload(formattedFilename, finalSource,headerJson);
  // }
}
