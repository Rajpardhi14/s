import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DateservicesService } from '../../../core/services/dateservices/dateservices.service';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
// import { OutSideClickDirective } from '../../../services/outclick/outside-click.directive';
// import { DateservicesService } from '../../../services/dateservices/dateservices.service';
// import { AddgeneralpurchasedrawerComponent } from '../../../expensesmanager/generalpurchaseorder/addgeneralpurchasedrawer/addgeneralpurchasedrawer.component';

@Component({
  selector: 'app-datepicker',
  standalone: true,
  imports: [CommonModule, FormsModule, OutSideClickDirective],
  templateUrl: './datepicker.component.html',
  styleUrl: './datepicker.component.css',
})
export class DatepickerComponent {
  @Output() calendarClosed = new EventEmitter<void>();
  @Input() key: string = '';
  @Input() dateKey: string = '';
  @Input() dateType: 'validFrom' | 'validTo' | 'po_end_date' = 'validFrom';
  @Input() preselectedDate: string = '';
  @Input() disabled: boolean = false;
  @Output() dateSelected = new EventEmitter<string>();
  @ViewChild('yearListContainer') yearListContainer!: ElementRef;
  formattedDate: string = '';
  inputValue: string = '';
  isCalendarVisible: boolean = false;
  isYearListVisible: boolean = false;
  isMonthListVisible = false;
  currentYear: number = new Date().getFullYear();
  currentMonth: number = new Date().getMonth();
  selectedDate: Date | null = null;
  // NEW: min/max date inputs
  @Input() minDate: string | null = null; // dd-MMM-yyyy
  @Input() maxDate: string | null = null; // dd-MMM-yyyy


  yearsPerPage: number = 16;
  currentPageStartYear: number = 0;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['preselectedDate']) {
      const newDate = changes['preselectedDate'].currentValue;

      if (newDate) {
        this.formattedDate = this.formatDate(new Date(newDate));
      } else {
        // Clear the displayed date if null or empty
        this.formattedDate = '';
      }
    }
    if (changes['dateType'] && !changes['dateType'].firstChange) {
      this.generateCalendar(); // Generate fresh calendar based on new type
    }

    if (changes['minDate'] || changes['maxDate']) {
      this.generateCalendar();
      this.generateYearPage();
      this.updateCalendarRange();
    }

  }

  // ngOnInit(): void {
  //     this.generateCalendar();
  //   this.generateYearPage();

  // }

  ngOnInit(): void {
    const min = this.minDate ? this.parseDate(this.minDate) : null;
    const max = this.maxDate ? this.parseDate(this.maxDate) : null;
    // console.log('Min Date datepicke:', min);
    // console.log('Max Date: datepicke', max);
    if (max) {
      // Use quarter end of maxDate
      this.currentYear = max.getFullYear();
      this.currentMonth = this.getQuarterEndMonth(max);
    } else if (min) {
      // Use quarter end of minDate
      this.currentYear = min.getFullYear();
      this.currentMonth = this.getQuarterEndMonth(min);
    } else {
      // fallback to today if no bounds
      const today = new Date();
      this.currentYear = today.getFullYear();
      this.currentMonth = today.getMonth();
    }

    this.generateCalendar();   // ✅ generate with adjusted month/year
    this.generateYearPage();   // ✅ your existing year page logic
  }

  dayNames: string[] = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  monthNames: string[] = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  calendarDays: any[] = [];
  yearsList: number[] = [];

  constructor(private dateService: DateservicesService) {
    this.generateCalendar();
    this.generateInitialYears();

    if (this.dateType === 'validTo') {
      this.dateService.validFromDate$.subscribe(() => this.generateCalendar());
    } else if (this.dateType === 'validFrom') {
      this.dateService.validToDate$.subscribe(() => this.generateCalendar());
    }
  }

  toggleCalendar() {
    this.isCalendarVisible = !this.isCalendarVisible;
    this.isYearListVisible = false;
  }

  closeSingleCalender() {
    this.isCalendarVisible = false;
    this.isYearListVisible = false;
    // ✅ Emit the close event
    this.calendarClosed.emit();

  }

  // previousMonth() {
  //   if (this.currentMonth === 0) {
  //     this.currentMonth = 11;
  //     this.currentYear--;
  //   } else {
  //     this.currentMonth--;
  //   }
  //   this.generateCalendar();
  // }
  previousMonth() {
    if (this.currentMonth === 0) {
      if (!this.minDate || this.currentYear > this.parseDate(this.minDate)!.getFullYear()) {
        this.currentMonth = 11;
        this.currentYear--;
      }
    } else {
      this.currentMonth--;
    }
    this.generateCalendar();
  }


  nextMonth() {
    if (this.currentMonth === 11) {
      if (!this.maxDate || this.currentYear < this.parseDate(this.maxDate)!.getFullYear()) {
        this.currentMonth = 0;
        this.currentYear++;
      }
    } else {
      this.currentMonth++;
    }
    this.generateCalendar();
  }


  // nextMonth() {
  //   if (this.currentMonth === 11) {
  //     this.currentMonth = 0;
  //     this.currentYear++;
  //   } else {
  //     this.currentMonth++;
  //   }
  //   this.generateCalendar();
  // }

  toggleMonthList() {
    this.isMonthListVisible = !this.isMonthListVisible;
    this.isYearListVisible = false;
  }

  selectYear(year: number) {

    this.currentYear = year;
    this.isYearListVisible = false;

    this.generateCalendar();
  }

  selectMonth(monthIndex: number) {

    this.currentMonth = monthIndex;
    this.isMonthListVisible = false;
    this.generateCalendar();
  }


  selectDate(date: any) {
    if (!date.isCurrentMonth) return;

    this.selectedDate = new Date(this.currentYear, this.currentMonth, date.day);

    if (this.selectedDate) {
      this.formattedDate = this.formatDate(this.selectedDate);
      this.dateSelected.emit(this.formattedDate);

      // Update the validFromDate in the service
      if (this.dateType === 'validFrom') {
        this.dateService.updateValidFromDate(this.formattedDate);
      }
    }

    this.isCalendarVisible = false;
  }
  formatDate(date: Date): string {
    const day = `0${date.getDate()}`.slice(-2);
    const month = this.monthNames[date.getMonth()];
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  isSelectedDate(date: any): boolean {
    if (!this.selectedDate) return false;
    return (
      this.selectedDate.getDate() === date.day &&
      this.selectedDate.getMonth() === date.month &&
      this.selectedDate.getFullYear() === date.year
    );
  }


  //  private parseDate(dateStr: string): Date | null {
  //      console.log(dateStr)
  //   if (!dateStr) return null;
  //   const parts = dateStr.split('-');
  //   if (parts.length !== 3) return null;

  //   const day = parseInt(parts[0], 10);
  //   const monthIndex = this.monthNames.findIndex(m =>
  //     m.toLowerCase().startsWith(parts[1].toLowerCase())
  //   );
  //   const year = parseInt(parts[2], 10);

  //   if (isNaN(day) || monthIndex === -1 || isNaN(year)) return null;
  //   return new Date(year, monthIndex, day);
  // }

  //   private parseDate(dateStr: string): Date | null {
  //   if (!dateStr) return null;
  //   const parts = dateStr.split('-');
  //   if (parts.length !== 3) return null;
  //   const year = parseInt(parts[0], 10);
  //   const month = parseInt(parts[1], 10) - 1;
  //   const day = parseInt(parts[2], 10);
  //   return new Date(year, month, day);
  // }
  private parseDate(dateStr: any): Date | null {
    if (!dateStr) return null;

    // ✅ Handle Date object directly
    if (dateStr instanceof Date) {
      return new Date(dateStr.getFullYear(), dateStr.getMonth(), dateStr.getDate());
    }

    // ✅ Handle "dd-MMM-yyyy" or "yyyy-MM-dd" formats
    if (typeof dateStr === 'string') {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        // Case: dd-MMM-yyyy (e.g. 01-Apr-2025)
        const monthAbbrev = parts[1].substring(0, 3).toLowerCase();
        const monthIndex = this.monthNames.findIndex(m =>
          m.toLowerCase().startsWith(monthAbbrev)
        );

        // Case: yyyy-MM-dd (e.g. 2025-04-01)
        if (monthIndex === -1 && !isNaN(+parts[1])) {
          const year = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10) - 1;
          const day = parseInt(parts[2], 10);
          return new Date(year, month, day);
        }

        const day = parseInt(parts[0], 10);
        const year = parseInt(parts[2], 10);
        return new Date(year, monthIndex, day);
      }
    }

    return null;
  }



  private isPoEndDateDisabled(year: number, month: number, day: number): boolean {
    if (this.dateType !== 'po_end_date') return false;

    const today = new Date();
    const currentDate = new Date(year, month, day);

    // Reset time for proper comparison
    today.setHours(0, 0, 0, 0);
    currentDate.setHours(0, 0, 0, 0);

    return currentDate < today;
  }



  //  generateCalendar() {
  //   const daysInMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
  //   const startDay = new Date(this.currentYear, this.currentMonth, 1).getDay();
  //   this.calendarDays = [];

  //   // Fill previous month
  //   const prevMonthDays = new Date(this.currentYear, this.currentMonth, 0).getDate();
  //   const prevMonth = this.currentMonth === 0 ? 11 : this.currentMonth - 1;
  //   const prevYear = this.currentMonth === 0 ? this.currentYear - 1 : this.currentYear;
  //   for (let i = startDay - 1; i >= 0; i--) {
  //     const day = prevMonthDays - i;
  //     this.calendarDays.push({
  //       day,
  //       isCurrentMonth: false,
  //       month: prevMonth,
  //       year: prevYear,
  //       disabled: this.isDateDisabled(prevYear, prevMonth, day),
  //     });
  //   }

  //   // Current month
  //   for (let i = 1; i <= daysInMonth; i++) {
  //     this.calendarDays.push({
  //       day: i,
  //       isCurrentMonth: true,
  //       month: this.currentMonth,
  //       year: this.currentYear,
  //       disabled: this.isDateDisabled(this.currentYear, this.currentMonth, i),
  //     });
  //   }

  //   // Fill next month
  //   let nextDay = 1;
  //   const nextMonth = this.currentMonth === 11 ? 0 : this.currentMonth + 1;
  //   const nextYear = this.currentMonth === 11 ? this.currentYear + 1 : this.currentYear;
  //   while (this.calendarDays.length % 7 !== 0) {
  //     this.calendarDays.push({
  //       day: nextDay,
  //       isCurrentMonth: false,
  //       month: nextMonth,
  //       year: nextYear,
  //       disabled: this.isDateDisabled(nextYear, nextMonth, nextDay),
  //     });
  //     nextDay++;
  //   }
  // }


  generateCalendar() {
    const daysInMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
    const startDay = new Date(this.currentYear, this.currentMonth, 1).getDay();
    this.calendarDays = [];

    const prevMonthDays = new Date(this.currentYear, this.currentMonth, 0).getDate();
    const prevMonth = this.currentMonth === 0 ? 11 : this.currentMonth - 1;
    const prevYear = this.currentMonth === 0 ? this.currentYear - 1 : this.currentYear;

    for (let i = startDay - 1; i >= 0; i--) {
      const day = prevMonthDays - i;
      this.calendarDays.push({
        day,
        isCurrentMonth: false,
        month: prevMonth,
        year: prevYear,
        disabled: this.isDateDisabled(prevYear, prevMonth, day),
        isToday: this.isToday(prevYear, prevMonth, day)
      });
    }

    for (let i = 1; i <= daysInMonth; i++) {
      this.calendarDays.push({
        day: i,
        isCurrentMonth: true,
        month: this.currentMonth,
        year: this.currentYear,
        disabled: this.isDateDisabled(this.currentYear, this.currentMonth, i),
        isToday: this.isToday(this.currentYear, this.currentMonth, i)
      });
    }

    let nextDay = 1;
    const nextMonth = this.currentMonth === 11 ? 0 : this.currentMonth + 1;
    const nextYear = this.currentMonth === 11 ? this.currentYear + 1 : this.currentYear;

    while (this.calendarDays.length % 7 !== 0) {
      this.calendarDays.push({
        day: nextDay,
        isCurrentMonth: false,
        month: nextMonth,
        year: nextYear,
        disabled: this.isDateDisabled(nextYear, nextMonth, nextDay),
        isToday: this.isToday(nextYear, nextMonth, nextDay)
      });
      nextDay++;
    }
  }

  generateInitialYears() {
    const numberOfYears = 50;
    this.yearsList = [];

    for (let i = 0; i < numberOfYears; i++) {
      this.yearsList.push(this.currentYear + i);
    }
  }



  onScrollYearList(event: any) {
    const element = event.target;

    if (element.scrollTop <= 10) {
      this.loadPreviousYears();
      setTimeout(() => {
        element.scrollTop = 50;
      }, 0);
    }
  }

  loadPreviousYears() {
    const previousYears = 10;
    const firstYear = this.yearsList[0];
    for (let i = previousYears; i >= 1; i--) {
      this.yearsList.unshift(firstYear - i);
    }
  }
  loadNextYears() {
    const lastYear = this.yearsList[this.yearsList.length - 1];
    for (let i = 1; i <= 20; i++) {
      this.yearsList.push(lastYear + i);
    }
  }


  // toggleYearList() {
  //   this.isYearListVisible = !this.isYearListVisible;
  //   if (this.isYearListVisible) {
  //     // Center the current year in the initial view
  //     this.currentPageStartYear = this.currentYear - 6;
  //     this.generateYearPage();
  //   }
  //   this.isMonthListVisible = false;
  // }

  // generateYearPage() {
  //   this.yearsList = [];
  //   for (let i = 0; i < this.yearsPerPage; i++) {
  //     this.yearsList.push(this.currentPageStartYear + i);
  //   }
  // }

  generateYearPage() {
    const minYear = this.minDate ? this.parseDate(this.minDate)!.getFullYear() : this.currentYear - 50;
    const maxYear = this.maxDate ? this.parseDate(this.maxDate)!.getFullYear() : this.currentYear + 50;
    this.yearsList = [];
    for (let i = 0; i < this.yearsPerPage; i++) {
      const year = this.currentPageStartYear + i;
      if (year >= minYear && year <= maxYear) this.yearsList.push(year);
    }
  }


  // previousYearPage() {
  //   this.currentPageStartYear -= 16;
  //   this.generateYearPage();
  // }

  previousYearPage() {
    this.currentPageStartYear -= this.yearsPerPage;
    this.generateYearPage();
  }

  // ṭo prevent to past years
  // previousYearPage() {
  //   if (this.currentPageStartYear > this.currentYear) {
  //     this.currentPageStartYear -= this.yearsPerPage;
  //     this.generateYearPage();
  //   }
  // }

  nextYearPage() {
    this.currentPageStartYear += this.yearsPerPage;
    this.generateYearPage();
  }

  // Remove these deprecated functions:
  // onScrollYearList(), loadPreviousYears(), loadNextYears(), generateInitialYears()

  handlePrevious() {
    if (this.isYearListVisible) {
      this.previousYearPage();
    } else {
      this.previousMonth();
    }
  }

  handleNext() {
    if (this.isYearListVisible) {
      this.nextYearPage();
    } else {
      this.nextMonth();
    }
  }

  toggleYearList() {
    this.isYearListVisible = !this.isYearListVisible;
    if (this.isYearListVisible) {
      this.currentPageStartYear = this.currentYear;
      this.generateYearPage();
    }
    this.isMonthListVisible = false;
  }

  private isDateDisabled(year: number, month: number, day: number): boolean {
    const date = new Date(year, month, day);

    date.setHours(0, 0, 0, 0);

    const min = this.minDate ? this.parseDate(this.minDate) : null;
    const max = this.maxDate ? this.parseDate(this.maxDate) : null;

    if (min && date < min) return true;
    if (max && date > max) return true;

    if (this.dateType === 'po_end_date') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return date < today;
    }

    if (this.dateType === 'validFrom') {
      return false;
    }

    // Only apply date disabling for validTo date picker
    if (this.dateType === 'validTo') {
      const currentDate = new Date(year, month, day);
      const validFrom = this.dateService.getValidFromDate();

      if (validFrom) {
        const compareDate = this.parseFormattedDate(validFrom);
        return compareDate ? currentDate < compareDate : false;
      }
    }

    return false;
  }

  private parseFormattedDate(dateStr: string): Date | null {
    const parts = dateStr.split('-');
    if (parts.length !== 3) return null;

    const day = parseInt(parts[0], 10);
    const monthAbbrev = parts[1].substring(0, 3).toLowerCase();
    const monthIndex = this.monthNames.findIndex((m) =>
      m.toLowerCase().startsWith(monthAbbrev)
    );
    const year = parseInt(parts[2], 10);

    if (isNaN(day) || monthIndex === -1 || isNaN(year)) return null;
    return new Date(year, monthIndex, day);
  }

  getSelectableMonths(): number[] {
    const months: number[] = [];
    const min = this.minDate ? this.parseDate(this.minDate) : null;
    const max = this.maxDate ? this.parseDate(this.maxDate) : null;

    for (let i = 0; i < 12; i++) {
      const testDate = new Date(this.currentYear, i, 1);
      if ((min && testDate < new Date(min.getFullYear(), min.getMonth(), 1)) ||
        (max && testDate > new Date(max.getFullYear(), max.getMonth(), 1))) {
        continue;
      }
      months.push(i);
    }
    return months;
  }

  get isPreviousDisabled(): boolean {
    if (!this.minDate) return false;
    const min = this.parseDate(this.minDate)!;
    return this.currentYear < min.getFullYear() ||
      (this.currentYear === min.getFullYear() && this.currentMonth <= min.getMonth());
  }

  get isNextDisabled(): boolean {
    if (!this.maxDate) return false;
    const max = this.parseDate(this.maxDate)!;
    return this.currentYear > max.getFullYear() ||
      (this.currentYear === max.getFullYear() && this.currentMonth >= max.getMonth());
  }

  get availableMonths(): { index: number; name: string }[] {
    const min = this.minDate ? this.parseDate(this.minDate) : null;
    const max = this.maxDate ? this.parseDate(this.maxDate) : null;

    return this.monthNames
      .map((name, idx) => ({ index: idx, name }))
      .filter(m => {
        const date = new Date(this.currentYear, m.index, 1);
        let valid = true;
        if (min && date < new Date(min.getFullYear(), min.getMonth(), 1)) valid = false;
        if (max && date > new Date(max.getFullYear(), max.getMonth(), 1)) valid = false;
        return valid;
      });
  }

  private getQuarterEndMonth(date: Date): number {
    const month = date.getMonth(); // 0-based
    if (month <= 2) return 2;   // Q1 → March (2)
    if (month <= 5) return 5;   // Q2 → June (5)
    if (month <= 8) return 8;   // Q3 → September (8)
    return 11;                  // Q4 → December (11)
  }



  handleKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Tab') {
      this.closeSingleCalender();
    }
  }

  onManualDateInput(event: Event): void {
    const input = (event.target as HTMLInputElement);
    let value = input.value;
    const cursorPos = input.selectionStart || 0;

    // Remove any extra dashes for processing
    let processed = value.replace(/-/g, '');

    // Limit length based on expected format: DD + MMM (3 letters) + YYYY = 9 characters without dashes
    if (processed.length > 9) {
      processed = processed.slice(0, 9);
    }

    // Auto-format: DD-MMM-YYYY
    let formatted = '';

    if (processed.length > 0) {
      // Add DD
      formatted = processed.slice(0, 2);

      if (processed.length >= 2) {
        // Add first dash after DD
        formatted += '-';

        if (processed.length > 2) {
          // Add MMM (up to 3 characters)
          formatted += processed.slice(2, 5);

          if (processed.length >= 5) {
            // Add second dash after MMM
            formatted += '-';

            if (processed.length > 5) {
              // Add YYYY
              formatted += processed.slice(5, 9);
            }
          }
        }
      }
    }

    this.formattedDate = formatted;

    // Update cursor position after formatting
    setTimeout(() => {
      let newCursorPos = cursorPos;
      if (cursorPos === 2 && formatted.length > 2) newCursorPos = 3; // After DD
      if (cursorPos === 6 && formatted.length > 6) newCursorPos = 7; // After MMM
      input.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);

    // Only validate and emit if the input looks complete (at least 11 chars: DD-MMM-YYYY)
    if (formatted.length < 11) return;

    const parsed = this.tryParseDate(formatted);
    if (!parsed) return; // Invalid format, skip

    const min = this.minDate ? this.parseDate(this.minDate) : null;
    const max = this.maxDate ? this.parseDate(this.maxDate) : null;

    if (min && parsed < min) return;
    if (max && parsed > max) return;

    // ✅ Update internal date
    this.selectedDate = parsed;
    this.formattedDate = this.formatDate(parsed);
    this.dateSelected.emit(this.formattedDate);

    // ✅ Sync calendar view to typed date
    this.currentYear = parsed.getFullYear();
    this.currentMonth = parsed.getMonth();

    // ✅ Regenerate the visible calendar
    this.generateCalendar();

    // Update validFrom service if applicable
    if (this.dateType === 'validFrom') {
      this.dateService.updateValidFromDate(this.formattedDate);
    }
  }




  private tryParseDate(input: string): Date | null {
    const monthMap: { [key: string]: number } = {
      jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
      jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
    };

    const dmy1 = /^(\d{1,2})[-/](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[-/](\d{4})$/i;
    const dmy2 = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/;

    let day: number, month: number, year: number;

    if (dmy1.test(input)) {
      const [, d, m, y] = input.match(dmy1)!;
      day = +d;
      month = monthMap[m.toLowerCase().slice(0, 3)];
      year = +y;
    } else if (dmy2.test(input)) {
      const [, d, m, y] = input.match(dmy2)!;
      day = +d;
      month = +m - 1;
      year = +y;
    } else {
      return null;
    }

    const parsed = new Date(year, month, day);
    return isNaN(parsed.getTime()) ? null : parsed;
  }


  onManualBlur() {
    const trimmed = this.formattedDate.trim();

    if (!trimmed) {
      // If empty, reset everything
      this.selectedDate = null;
      this.formattedDate = '';
      return;
    }

    const parsed = this.tryParseDate(trimmed);
    if (parsed) {
      // Validate date range
      const min = this.minDate ? this.parseDate(this.minDate) : null;
      const max = this.maxDate ? this.parseDate(this.maxDate) : null;

      if ((min && parsed < min) || (max && parsed > max)) {
        // Invalid date range - reset to previous valid date or empty
        this.formattedDate = this.selectedDate ? this.formatDate(this.selectedDate) : '';
        return;
      }

      // Valid date - format and emit
      this.selectedDate = parsed;
      this.formattedDate = this.formatDate(parsed);
      this.currentYear = parsed.getFullYear();
      this.currentMonth = parsed.getMonth();
      this.generateCalendar();
      this.dateSelected.emit(this.formattedDate);

      // Update validFrom service if applicable
      if (this.dateType === 'validFrom') {
        this.dateService.updateValidFromDate(this.formattedDate);
      }
    } else {
      // Invalid format - reset to previous valid date or empty
      this.formattedDate = this.selectedDate ? this.formatDate(this.selectedDate) : '';
    }
  }


  updateCalendarRange() {
    if (this.minDate && this.maxDate) {
      // Adjust your internal logic here if you have a datepicker library
      // console.log('Updated Range →', this.minDate, this.maxDate);
    }
  }


  private isToday(year: number, month: number, day: number): boolean {
    const today = new Date();
    return (
      today.getFullYear() === year &&
      today.getMonth() === month &&
      today.getDate() === day
    );
  }

}
