import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorrectionpoupComponent } from './correctionpoup.component';

describe('CorrectionpoupComponent', () => {
  let component: CorrectionpoupComponent;
  let fixture: ComponentFixture<CorrectionpoupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CorrectionpoupComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CorrectionpoupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
