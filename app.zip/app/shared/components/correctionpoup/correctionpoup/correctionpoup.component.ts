import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-correctionpoup',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './correctionpoup.component.html',
  styleUrl: './correctionpoup.component.css'
})
export class CorrectionpoupComponent {

    selectedPurpose: string | null = null;
    @Output() process = new EventEmitter<string>();
    @Output() close = new EventEmitter<void>();

  onProcess() {
    if (this.selectedPurpose) {
      console.log('Processing for:', this.selectedPurpose);
      this.process.emit(this.selectedPurpose);
    }
  }

  onClose() {
    console.log('Dialog closed');
    this.close.emit();
  }

}
