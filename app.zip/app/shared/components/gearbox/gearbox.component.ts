import { CommonModule } from '@angular/common';
import { Component, input, Input } from '@angular/core';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { capitalizeEachWord } from '../../utils/passmatch';



@Component({
  selector: 'app-gearbox',
  standalone: true,
  imports: [CommonModule, OutSideClickDirective,],
  templateUrl: './gearbox.component.html',
  styleUrl: './gearbox.component.css'
})
export class GearboxComponent {
  @Input() headers: any[] = [];
  @Input () key:string='';
 capatilize=capitalizeEachWord
  isOpenGearBox: boolean = false;
  constructor(){
 
  }

  get isNoColumnAvailable(): boolean {
    return this.headers.length > 0 && this.headers.every(header => header.display !== 0);
  }

  get isColumnAvailable(): boolean {
    return this.headers.length > 0 && this.headers.some(header => header.display === 0);
  }


  gearBox() {
    this.isOpenGearBox = !this.isOpenGearBox;
  }


  gearboxOutside() {
    this.isOpenGearBox = false;
  }


  toggleColumnVisibility(header: any) {
    header.visible = !header.visible;
  }





}
