import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { capitalizeEachWord } from '../../utils/passmatch';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';


@Component({
  selector: 'app-advance-filter',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OutSideClickDirective,
    ButtoneventlisnerDirective

  ],
  templateUrl: './advance-filter.component.html',
  styleUrl: './advance-filter.component.css',
})
export class AdvanceFilterComponent {
  @Input() filterForm!: FormGroup;
  @Input() selectedValue: any;
  @Input() selectedLabel: any;
  @Input() advance_filter: any[] = [];
  @Input() filterCount: number = 0;
  @Output() onSubmit = new EventEmitter<void>();
  @Output() onReset = new EventEmitter<void>();
  @Input() key: string = '';
  @Input() disabled = false;

  capitalizeEachWord = capitalizeEachWord;
  isOpen = false;
  searchTexts: { [key: string]: string } = {};
  filteredOptions: { [key: string]: any[] } = {};
  dynamicUserData: any;
  UserData: any;

  toggle() {
    if (this.disabled) return;
    this.isOpen = !this.isOpen;
  }
  close() {
    this.isOpen = false;
  }
  handleClickOutside() {
    this.isOpen = false;
  }

  ngOnInit(): void {
    this.getLabel(this.selectedValue);
    // this.initializeForm();
    // this.getLocalUserData();
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};

  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedValue']) {
      this.getLabel(this.selectedValue);
    }
  }

  constructor(

    private userlocaldataService: UserdataService,
    private apiservice: ApiserviceService,

  ) {
    this.UserData = this.userlocaldataService.getLocalUserData() || {};
    this.dynamicUserData = this.userlocaldataService.getAllDynamicUserData() || {};


  }


  //

  get gridClass() {
    return this.advance_filter?.length > 10
      ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4'
      : 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4';
  }

  get filterWidth(): string {
    return this.advance_filter?.length > 10 ? 'w-[70%] 2xl:w-[50%]' : 'w-[50%] 2xl:w-[36%]';
  }
  openDropdown: string | null = null;
  toggleDropdown(field: string) {
    this.openDropdown = this.openDropdown === field ? null : field;
  }

  closeDropdownOutside(field: string) {
    if (this.openDropdown === field) {
      this.openDropdown = null;
    }
  }

  // selectOptionFilter(field: string, value: any, event: Event) {
  //   event.stopPropagation();
  //   this.filterForm.get(field)?.setValue(value);
  //   this.openDropdown = null;
  // }

  selectOptionFilter(field: string, value: any, event: Event) {
    event.stopPropagation();
    this.filterForm.get(field)?.setValue(value);
    this.openDropdown = null;

    // ✅ If user selects "code_level", handle dependency
    if (field === 'code_level') {
      this.filterForm.get('parent_code')?.reset(); // clear parent code
      this.updateCodeLevelFilterClause(value);
      this.getParentCodeList();
    }

    // ✅ If user selects "parent_code", store value & label
    if (field === 'parent_code') {
      const selectedOption = this.filteredOptions['parent_code'].find(
        (opt) => opt.value === value
      );

      if (selectedOption) {
        // store label for display
        this.selectedLabel = selectedOption.label;
        this.selectedValue = selectedOption.value;
      }
    }
  }


  selectedCodeLevelValue: any;
  filterClause: any[] = [];


  updateCodeLevelFilterClause(selectedCodeLevel: number) {
    this.selectedCodeLevelValue = selectedCodeLevel
    console.log(this.selectedCodeLevelValue);
    this.filterClause = [
      {
        filter_col_field: 'code_level',
        filter_col_depend_operator: 'wc',
        filter_col_value: `and a.code_level=(select max(c.client_level_code)
        from client_level_mast c
        where c.entity_code=a.entity_code
        and c.client_level_code < ${this.selectedCodeLevelValue})`
      }
    ];
  }


  //   private getParentCodeList(): void {

  //     // if (!this.codeLevelOptions || !this.codeLevelOptions.length) return;
  //     // const selectedValue = this.codeLevelOptions[0].value;

  //     if (!this.selectedCodeLevelValue) return; // Ensure a selection exists

  //     const selectedValue = this.selectedCodeLevelValue;

  //     const requestBody = {

  //       a_session_seqno: "",
  //       a_iud_seqno: "",
  //       a_is_pen_flag: "",
  //       a_login_type: "login_id",
  //       a_module_type_code: this.UserData?.default_module_type_code,
  //       a_sub_module_type_code: "R",
  //       a_user_code: this.UserData.user_code,
  //       a_entity_code: this.UserData.entity_code,
  //       a_client_code: this.UserData.client_code,
  //       a_acc_year: this.UserData.default_acc_year,
  //       a_quarter_no: this.dynamicUserData.default_quarter_no,
  //       a_tran_month: this.dynamicUserData.default_tran_month,
  //       a_validation_client_level: this.UserData.client_code_level,
  //       a_tran_from_date: this.dynamicUserData.default_from_date,
  //       a_tran_to_date: this.dynamicUserData.default_to_date,
  //       a_tds_type_code: this.dynamicUserData.default_tds_type_code,
  //       a_first_level_client_code: this.dynamicUserData.first_level_client_code,
  //       a_client_code_level: this.UserData.client_code_level,
  //       a_user_level: this.UserData.user_level,
  //       a_proc_error: "0",
  //       a_proc_type: "get_gmlb_client_parent_mast",
  //       a_process_seqno: "",
  //       a_process_status_code: "ZA",
  //       a_db_total_records: "1000",
  //       a_pagination_count: "0",
  //      a_filter_clause: this.filterClause,

  //     };

  //     this.apiservice.fetchparentmastLbData('/ClientMast/get_gmlb_client_parent_mast', requestBody).subscribe({
  //       next: (response: any) => {
  //  const data = response?.result?.get_gmlb_client_parent_mast ?? [];
  //  console.log(data)

  //       // ✅ Directly map it to dropdown options
  //       this.filteredOptions['parent_code'] = data.map((item: any) => ({
  //         value: item.parent_code,
  //         label: item.parent_code_details, // show raw value
  //       }));
  //       // this.filteredOptions['parent_code'] = data.map((item: any) => ({
  //       //   value: item.parent_code,
  //       //   label: item.parent_code_details, // show raw value
  //       // }));

  //       console.log( this.filteredOptions);

  //       },
  //       error: (error: any) => {
  //         console.error(error);
  //       },
  //     });
  //   }

  private getParentCodeList(): void {

    const requestBody = {
      a_session_seqno: "",
      a_iud_seqno: "",
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_module_type_code: this.UserData?.default_module_type_code,
      a_sub_module_type_code: "R",
      a_user_code: this.UserData.user_code,
      a_entity_code: this.UserData.entity_code,
      a_client_code: this.UserData.client_code,
      a_acc_year: this.UserData.default_acc_year,
      a_quarter_no: this.dynamicUserData.default_quarter_no,
      a_tran_month: this.dynamicUserData.default_tran_month,
      a_validation_client_level: this.UserData.client_code_level,
      a_tran_from_date: this.dynamicUserData.default_from_date,
      a_tran_to_date: this.dynamicUserData.default_to_date,
      a_tds_type_code: this.dynamicUserData.default_tds_type_code,
      a_first_level_client_code: this.dynamicUserData.first_level_client_code,
      a_client_code_level: this.UserData.client_code_level,
      a_user_level: this.UserData.user_level,
      a_proc_error: "0",
      a_proc_type: "get_gmlb_client_parent_mast",
      a_process_seqno: "",
      a_process_status_code: "ZA",
      a_db_total_records: "1000",
      a_pagination_count: "0",
      a_filter_clause: this.filterClause,
      // ✅ Must be stringified for API to read properly
      // a_filter_clause: JSON.stringify(this.filterClause),
    };

    this.apiservice.fetchparentmastLbData('/ClientMast/get_gmlb_client_parent_mast', requestBody)
      .subscribe({
        next: (response: any) => {
          const data = response?.result?.get_gmlb_client_parent_mast ?? [];
          console.log('Parent code API response:', data);

          this.filteredOptions['parent_code'] = (data || []).map((item: any) => ({
            value: item.parent_code,
            label: item.parent_code_details,
          }));

          console.log('Updated filteredOptions:', this.filteredOptions);
        },
        error: (error: any) => {
          console.error('Error fetching parent codes:', error);
        },
      });
  }


  // getLabels(field: string, value: any): string {
  //   const filter = this.advance_filter.find(
  //     (f) => f.filter_col_field === field
  //   );
  //   const match = filter?.filter_col_depend_value?.find(
  //     (opt: any) => opt.value === value
  //   );
  //   return match ? match.label : '';
  // }


  //   getLabels(field: string, value: any): string {
  //   const filter = this.advance_filter.find(
  //     (f) => f.filter_col_field === field
  //   );

  //   // 🧠 Safety checks: ensure filter_col_depend_value is an array
  //   if (!Array.isArray(filter?.filter_col_depend_value)) {
  //     return '';
  //   }

  //   const match = filter.filter_col_depend_value.find(
  //     (opt: any) => opt.value === value
  //   );

  //   return match ? match.label : '';
  // }


  getLabels(field: string, value: any): string {
    // 1️⃣ First check static filters (normal dropdowns)
    const filter = this.advance_filter.find(f => f.filter_col_field === field);
    const match = Array.isArray(filter?.filter_col_depend_value)
      ? filter.filter_col_depend_value.find((opt: any) => opt.value === value)
      : null;
    if (match) return match.label;

    // 2️⃣ Then check dynamically loaded options (like parent_code)
    const dynamicMatch = this.filteredOptions[field]?.find(
      (opt: any) => opt.value === value
    );
    return dynamicMatch ? dynamicMatch.label : '';
  }



  submitAndClose() {
    this.onSubmit.emit();
    this.close();
  }


  selectedTab: string = '';
  getLabel(selectedvalue: string | string[] | null | undefined) {
    const value = Array.isArray(selectedvalue)
      ? selectedvalue[0]
      : selectedvalue;
    if (value === 'A') {
      this.selectedTab = 'Approved';
    } else if (value === 'R') {
      this.selectedTab = 'Rejected';
    } else {
      this.selectedTab = 'Pending';
    }
  }




  filterDropdownOptions(field: string) {
    const filter = this.advance_filter?.find(f => f.filter_col_field === field);

    const searchText = this.searchTexts[field]?.toLowerCase() || '';
    if (filter) {
      this.filteredOptions[field] = filter.filter_col_depend_value.filter((opt: any) =>
        opt.label.toLowerCase().includes(searchText)
      );
    }
  }

  // toggleDropdowns(field: string) {
  //   this.openDropdown = this.openDropdown === field ? null : field;
  //   if (this.openDropdown === field) {
  //     const filter = this.advance_filter.find(f => f.filter_col_field === field);
  //     this.filteredOptions[field] = filter?.filter_col_depend_value || [];
  //     this.searchTexts[field] = '';
  //   }
  // }


  toggleDropdowns(field: string) {
    this.openDropdown = this.openDropdown === field ? null : field;

    if (this.openDropdown === field) {
      if (field !== 'parent_code') {
        const filter = this.advance_filter.find(f => f.filter_col_field === field);
        this.filteredOptions[field] = filter?.filter_col_depend_value || [];
      }

      this.searchTexts[field] = '';
    }
  }



  clearSelection(field: string, event: Event) {
    event.stopPropagation(); // prevent dropdown toggle
    this.filterForm.get(field)?.setValue(null);
    this.openDropdown = null;  // close the dropdown
  }



  getDisplayText(filterField: string, text: string): string {
    const noCapitalize = ['quarter_no', 'tds_type_code'];
    return noCapitalize.includes(filterField) ? text : this.capitalizeEachWord(text);
  }

}
