import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SessionexpairedComponent } from './sessionexpaired.component';

describe('SessionexpairedComponent', () => {
  let component: SessionexpairedComponent;
  let fixture: ComponentFixture<SessionexpairedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SessionexpairedComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SessionexpairedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
