
import {
  Component,
  OnDestroy,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
  Input,
  ChangeDetectorRef,
} from '@angular/core';

import { Router } from '@angular/router';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';
import { FiledOptionService } from '../../../core/services/session/timer-session/filed-option.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { SessiontimerService } from '../../../core/services/session/timer-session/sessiontimer.service';
import { EventlisnerService } from '../../../core/services/session/timer-session/eventlisner.service';


@Component({
  selector: 'app-sessionexpaired',
  standalone: true,
  imports: [CommonModule, ButtoneventlisnerDirective],
  templateUrl: './sessionexpaired.component.html',
  styleUrls: ['./sessionexpaired.component.css'],
})
export class SessionexpairedComponent implements OnInit, OnDestroy {
  @Output() openSlowInternetPopup = new EventEmitter<void>();
  @Output() closePopup = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();
  @Input() isPopupOpen: boolean = false;
  @Input() popupType: string = '';
  @Input() onsuccessmsg: string = '';
  @Input() requestedid: string = '';
  sessionExpired = false;
  networkExpired = false;
  isExhausted: boolean = false;
  timertigger: boolean = false;
  timertiggerstart: boolean = false;
  remainingTime: number = 60; // The time remaining for the popup (in seconds)
  timerInterval: any;
  private destroy$ = new Subject<void>();
  private timerSubscription: Subscription | null = null;
  maxTime = 60;
  circumference = 2 * Math.PI * 45;
  constructor(
    private sessionService: FiledOptionService,
    private router: Router,
    private userlocaldataService: UserdataService,
    private ApiserviceService: ApiserviceService,
    private sessionTimer: SessiontimerService,
    private cdr: ChangeDetectorRef,
    private eventLisnerService: EventlisnerService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {}

  ngOnInit() {
    this.subscribeToSessionExpired();
    this.subscribeToNetworkExpired();
    this.subscribeToTimmerExpired();
    setTimeout(() => {
      this.closeTrans();
    }, 2000);
  }

  private subscribeToSessionExpired() {
    this.sessionService.sessionExpired$
      .pipe(takeUntil(this.destroy$))
      .subscribe((expired) => {
        this.sessionExpired = expired;
      });
  }

  private subscribeToNetworkExpired() {
    this.sessionService.networkExpired$
      .pipe(takeUntil(this.destroy$))
      .subscribe((expired) => {
        this.networkExpired = expired;
      });
  }

  private subscribeToTimmerExpired() {
    this.timerSubscription = this.sessionTimer.timertigger$.subscribe(
      (timeLeft) => {
        if (timeLeft > 0) {
          this.timertigger = true; // Show the popup
          this.remainingTime = timeLeft; // Update the remaining time

          this.timertiggerstart = true; // Start the timer display
          this.cdr.detectChanges();
        } else {
          this.timertigger = false;
          this.timertiggerstart = false; // Stop the timer display
        }
      }
    );
  }
  closeSessionPopup() {
    this.sessionExpired = false;
    this.sessionService.resetSessionExpired();
    this.userlocaldataService.clearLocalUserData();

    localStorage.clear();
    sessionStorage.clear();

    this.closePopup.emit();
    this.router.navigate(['/']);
  }

  closeSuccess() {
    this.popupType = '';
    this.onsuccessmsg = '';
    this.requestedid = '';
    this.isPopupOpen = false;
    this.cancel.emit();
  }

  closeTrans() {
    this.isPopupOpen = false;
    this.popupType = '';
    this.onsuccessmsg = '';
    this.requestedid = '';
  }

  // Extend session on user interaction
  extendSession() {
    // this.remainingTime = 60; // Reset to 60 seconds

    this.timertigger = false;
    this.timertiggerstart = false;
    // this.sessionTimer.updateSessionTime(); // Reset session timeout
    // this.eventLisnerService.extendSessionWithAPI();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe(); // Unsubscribe when the component is destroyed
    }
  }
}