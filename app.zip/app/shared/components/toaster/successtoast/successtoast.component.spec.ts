import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccesstoastComponent } from './successtoast.component';

describe('SuccesstoastComponent', () => {
  let component: SuccesstoastComponent;
  let fixture: ComponentFixture<SuccesstoastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SuccesstoastComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SuccesstoastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
