import { Component } from '@angular/core';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-successtoast',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './successtoast.component.html',
  styleUrl: './successtoast.component.css'
})
export class SuccesstoastComponent {
  //successMessage: string | null = null;

  // constructor(private toastService: ToastService) {}

  // ngOnInit() {
  //   this.toastService.successMessage$.subscribe((message) => {
  //     this.successMessage = message;

  //   });
   
  // }

  // closeToast() {
  //   this.successMessage = null;
  //   this.toastService.clearMessages();
  // }

    successMessage: string | null = null;
  processingMessage: string | null = null;

  constructor(private toastService: ToastService) {}

  ngOnInit() {
    // Success toast
    this.toastService.successMessage$.subscribe((message) => {
      this.successMessage = message;
    });

    // Processing toast
    this.toastService.processingMessage$.subscribe((message) => {
      this.processingMessage = message;
    });
  }

  closeToast(type: 'success' | 'processing') {
    if (type === 'success') {
      this.successMessage = null;
      this.toastService.clearMessages();
    } else {
      this.processingMessage = null;
      this.toastService.clearProcessing();
    }
  }


}
