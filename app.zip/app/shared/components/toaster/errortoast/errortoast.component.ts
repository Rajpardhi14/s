import { Component } from '@angular/core';
import { ToastService } from '../../../../core/services/toaster/toast.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-errortoast',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './errortoast.component.html',
  styleUrl: './errortoast.component.css'
})
export class ErrortoastComponent {
    errorMessage: string | null = null;

  constructor(private toastService: ToastService) {}

  ngOnInit() {
    this.toastService.errorMessage$.subscribe((message) => {
      this.errorMessage = message;
    });
  }

  closeToast() {
    this.errorMessage = null;
    this.toastService.clearMessages();
  }

}
