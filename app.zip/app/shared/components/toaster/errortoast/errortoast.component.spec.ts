import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrortoastComponent } from './errortoast.component';

describe('ErrortoastComponent', () => {
  let component: ErrortoastComponent;
  let fixture: ComponentFixture<ErrortoastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrortoastComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ErrortoastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
