import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tableskeleton',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tableskeleton.component.html',
  styleUrl: './tableskeleton.component.css'
})
export class TableskeletonComponent {
  @Input() rows: number = 5;
  @Input() columns: number = 5;
  @Input() show: boolean = true;

}
