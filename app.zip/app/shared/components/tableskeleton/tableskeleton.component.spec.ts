import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableskeletonComponent } from './tableskeleton.component';

describe('TableskeletonComponent', () => {
  let component: TableskeletonComponent;
  let fixture: ComponentFixture<TableskeletonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TableskeletonComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TableskeletonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
