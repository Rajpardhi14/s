import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthloaderComponent } from './authloader.component';

describe('AuthloaderComponent', () => {
  let component: AuthloaderComponent;
  let fixture: ComponentFixture<AuthloaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AuthloaderComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AuthloaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
