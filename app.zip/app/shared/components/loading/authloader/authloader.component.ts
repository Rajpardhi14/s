import { Component } from '@angular/core';

@Component({
  selector: 'app-authloader',
  standalone: true,
  imports: [],
  templateUrl: './authloader.component.html',
  styleUrl: './authloader.component.css'
})
export class AuthloaderComponent {

}
