import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-alertpoup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './alertpoup.component.html',
  styleUrl: './alertpoup.component.css'
})
export class AlertpoupComponent {
   @Input() title: string = 'Confirm Action';
   @Input() subheading: string = '';
   @Input() message: string = ''; // Custom message (overrides default delete message)
   @Input() confirmButtonText: string = 'Delete'; // Customizable confirm button text
   @Input() cancelButtonText: string = 'Cancel'; // Customizable cancel button text
   @Input() isDelete: boolean = true; // Flag to show delete-specific styling/message
  @Output() confirm = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();

  onConfirm() {
    this.confirm.emit();
  }

  onCancel() {
    this.cancel.emit();
  }

}
