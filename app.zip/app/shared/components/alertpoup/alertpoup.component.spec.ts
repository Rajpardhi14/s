import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertpoupComponent } from './alertpoup.component';

describe('AlertpoupComponent', () => {
  let component: AlertpoupComponent;
  let fixture: ComponentFixture<AlertpoupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AlertpoupComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AlertpoupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
