import { CommonModule } from '@angular/common';
import { Component, Input, input } from '@angular/core';
import { capitalizeEachWord } from '../../utils/passmatch';

@Component({
  selector: 'app-nodata',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './nodata.component.html',
  styleUrl: './nodata.component.css'
})
export class NodataComponent {
  @Input() headers: any[] = [];
  capatilize=capitalizeEachWord
}
