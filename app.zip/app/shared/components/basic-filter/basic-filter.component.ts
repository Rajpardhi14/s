import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { capitalizeEachWord } from '../../utils/passmatch';
import { ButtoneventlisnerDirective } from '../../../core/services/session/timer-session/buttoneventlisner.directive';
// import { OutSideClickDirective } from '../../services/outclick/outside-click.directive';
// import { ButtoneventlisnerDirective } from '../../services/buttoneventlisner.directive';

@Component({
  selector: 'app-basic-filter',
  standalone: true,
  imports: [CommonModule, FormsModule,OutSideClickDirective,ButtoneventlisnerDirective],
  templateUrl: './basic-filter.component.html',
  styleUrl: './basic-filter.component.css'
})
export class BasicFilterComponent {
  @Input() menuOptions: any[] = [];
  @Input() selectedOption: any = null;
  @Input() searchTerm: string = '';
  @Output() clearOption = new EventEmitter<void>();
  @Output() selectedOptionChange = new EventEmitter<any>();
  @Output() searchTermChange = new EventEmitter<string>();
  @Output() submit = new EventEmitter<void>();
  dropdownOpen = false;
@Input() disabled = false;

   capitalizeEachWord= capitalizeEachWord;
  toggleDropdown() {
     if (this.disabled) return;
    this.dropdownOpen = !this.dropdownOpen;
  }

  selectOption(option: any) {
    this.selectedOptionChange.emit(option);
    this.dropdownOpen = false;
  }

  onInput(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.searchTermChange.emit(value);
    if (value.length === 0) {
      this.clearInput();
    }
  }

  clearInput() {
    this.searchTermChange.emit('');
    this.clearOption.emit();
  }

  onSubmit() {
    this.submit.emit();
  }


    handleClickOutside() {
    this.dropdownOpen = false;
  }


  handleOutclick(){
    this.dropdownOpen=false
  }

}