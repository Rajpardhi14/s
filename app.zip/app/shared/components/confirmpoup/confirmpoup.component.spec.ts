import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmpoupComponent } from './confirmpoup.component';

describe('ConfirmpoupComponent', () => {
  let component: ConfirmpoupComponent;
  let fixture: ComponentFixture<ConfirmpoupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConfirmpoupComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ConfirmpoupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
