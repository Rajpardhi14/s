import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-confirmpoup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './confirmpoup.component.html',
  styleUrl: './confirmpoup.component.css'
})
export class ConfirmpoupComponent {
  isOpen:boolean=false

fileName:string='form26Q'
downloadedOn:string="19-9-2026"
  //   @Input() isOpen = false;
  // @Input() fileName: string = '';
  // @Input() downloadedOn: string = '';

  animateIn = false;

  // ngOnChanges() {
  //   if (this.isOpen) {
  //     setTimeout(() => (this.animateIn = true), 50); // Trigger animation
  //   } else {
  //     this.animateIn = false;
  //   }
  // }

  onConfirm() {
    console.log('File confirmed:', this.fileName);
    this.close();
  }

  onCancel() {
    console.log('Action cancelled');
    this.close();
  }

  private close() {
    this.isOpen = false;
    this.animateIn = false;
  }

}
