import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class DisplayValueUtilService {
  constructor() {}


  getLabelFromMaster(masterData: any, colFieldSelect: string, value: any): string {
    if (!colFieldSelect || value === null || value === undefined) return value ?? '-';

    const masterList = masterData?.[colFieldSelect];
    if (!masterList || !Array.isArray(masterList)) return value;

    const found = masterList.find(
      (item: any) => item.code == value || item.value == value
    );

    return found ? (found.name || found.label || value) : value;
  }

 
  getDisplayValue(header: any, row: any, masterData: any): string {
    let value = row?.[header?.field];
// console.log(header?.col_field_select);
    // If column is linked to master data
    if (header?.col_field_select) {
      value = this.getLabelFromMaster(masterData, header.col_field_select, value);
      
    }

    // Optional: Special handling for specific fields (customizable)
    // Example:
    // if (header.field === 'tds_code' && value) {
    //   value = value.split('-')[0].trim();
    // }

    return value ?? '-';
  }
}
