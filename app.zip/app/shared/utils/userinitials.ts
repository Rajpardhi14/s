// user-initials.util.ts

export function getUserInitials(fullName: string): string {
  if (!fullName) return "";

  // Split the name by spaces
  const nameParts = fullName.trim().split(" ");

  // If only one word (e.g., "Suraj"), return first letter
  if (nameParts.length === 1) {
    return nameParts[0].charAt(0).toUpperCase();
  }

  // Otherwise, take first letter of first and last words
  const firstInitial = nameParts[0].charAt(0).toUpperCase();
  const lastInitial = nameParts[nameParts.length - 1].charAt(0).toUpperCase();

  return `${firstInitial}${lastInitial}`;
}


export function getFullNameWithoutTilde(fullName: string): string {
  if (!fullName) return "";
  return fullName.replace(/~/g, " ").replace(/\s+/g, " ").trim();
}

export function getFirstNameWithoutTilde(fullName: string): string {
  if (!fullName) return "";

  // Clean unwanted characters (~, extra spaces)
  const cleanedName = fullName.replace(/~/g, " ").replace(/\s+/g, " ").trim();

  // Take the first part as first name
  const nameParts = cleanedName.split(" ");
  return nameParts[0] || "";
}