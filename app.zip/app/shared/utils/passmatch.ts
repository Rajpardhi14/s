import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function passwordMatchValidator(passwordField: string, confirmPasswordField: string): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const password = formGroup.get(passwordField)?.value;
    const confirmPassword = formGroup.get(confirmPasswordField)?.value;

    if (password !== confirmPassword) {
      formGroup.get(confirmPasswordField)?.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    } else {
      formGroup.get(confirmPasswordField)?.setErrors(null);
      return null;
    }
  };



}


// export function capitalizeEachWord(value: any): string {
//   if (!value) return '-';
//   return value
//     .toString()
//     .split(' ')
//     .map((word:any) => word ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase() : '')
//     .join(' ');
// }


export function capitalizeEachWord(
  value: any,
  skipHeaders: string[] = [],
  rawField?: string
): string {
  if (!value) return '-';

  const strValue = value.toString();

  // If rawField matches skipHeaders → keep first word same, rest capitalized
  if (rawField && skipHeaders.some(s => s.toLowerCase() === rawField.toLowerCase())) {
    const words = strValue.split(' ');
    return words
      .map((word: string, index: number) => {
        if (!word) return '';
        return index === 0
          ? word // keep first word exactly as-is
          : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      })
      .join(' ');
  }

  // Default → capitalize all words
  return strValue
    .split(' ')
    .map((word: string) =>
      word ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase() : ''
    )
    .join(' ');
}



export function capitalizeOnlyFirst(value: string | string[]): string {
  if (!value) return '-';

  if (Array.isArray(value)) {
    // Capitalize first element in array only
    if (value.length === 0) return '-';
    const first = value[0]
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
    return first;
  } else if (typeof value === 'string') {
    // Capitalize the string directly
    return value
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  } else {
    return '-';
  }
}





export function capitalizeAll(
  value: any,
  skipHeaders: string[] = [],
  rawField?: string
): string {
  if (!value) return '-';

  const strValue = value.toString();

  // If rawField matches skipHeaders → keep first word same, rest capitalized
  if (rawField && skipHeaders.some(s => s.toLowerCase() === rawField.toLowerCase())) {
    const words = strValue.split(' ');
    return words
      .map((word: string, index: number) => {
        if (!word) return '';
        return index === 0
          ? word // keep first word exactly as-is
          : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      })
      .join(' ');
  }

  // Default → capitalize all words
  return strValue
    .split(' ')
    .map((word: string) =>
      word ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase() : ''
    )
    .join(' ');
}


// export function formatDatesend(date: Date | string | null | undefined): string {
//   if (!date) {
//     return ""; // nothing selected
//   }

//   const d = new Date(date);

//   if (isNaN(d.getTime())) {
//     return ""; // invalid date string
//   }

//   const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
//   const day = String(d.getDate()).padStart(2, "0");
//   const month = months[d.getMonth()];
//   const year = d.getFullYear();

//   return `${day}-${month}-${year}`;
// }


// export function formatDatesend(date: Date | string | null | undefined): string {
//   if (!date) {
//     return "-"; // show '-' if date is null/undefined
//   }

//   const d = new Date(date);

//   if (isNaN(d.getTime())) {
//     return "-"; // invalid date
//   }

//   const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
//   const day = String(d.getDate()).padStart(2, "0");
//   const month = months[d.getMonth()];
//   const year = d.getFullYear();

//   const hours = String(d.getHours()).padStart(2, "0");
//   const minutes = String(d.getMinutes()).padStart(2, "0");
//   const seconds = String(d.getSeconds()).padStart(2, "0");

//   return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
// }



// export function noWhitespaceValidator(): ValidatorFn {
//   return (control: AbstractControl): ValidationErrors | null => {
//     const value = control.value;
//     if (typeof value === 'string' && value.trim().length === 0) {
//       return { whitespace: true };
//     }
//     return null;
//   };
// }



// export function formatDatesend(date: Date | string | null | undefined): string {
//   if (!date) return "-"; // null/undefined

//   const d = new Date(date);
//   if (isNaN(d.getTime())) return "-"; // invalid date

//   const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
//   const day = String(d.getDate()).padStart(2, "0");
//   const month = months[d.getMonth()];
//   const year = d.getFullYear();

//   const hours = d.getHours();
//   const minutes = d.getMinutes();
//   const seconds = d.getSeconds();

//   const datePart = `${day}-${month}-${year}`;

//   // Show time only if it's not 00:00:00
//   if (hours === 0 && minutes === 0 && seconds === 0) {
//     return datePart;
//   } else {
//     const timePart = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
//     return `${datePart} ${timePart}`;
//   }
// }


export function formatDatesend(date: Date | string | null | undefined): string {
  if (!date) {
    return "";
  }

  const d = new Date(date);

  if (isNaN(d.getTime())) {
    return "";
  }

  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const day = String(d.getDate()).padStart(2, "0");
  const month = months[d.getMonth()];
  const year = d.getFullYear();

  return `${day}-${month}-${year}`;
}



export function noWhitespaceValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0) {
      return { noWhitespaceValidator: true };
    }
    return null;
  };
}


// // src/app/utils/table-utils.ts
// export function formatValue(h: any, row: any): string {
//   const value = row[h.field];

//   if (value == null || value === '') {
//     return '0.00';
//   }

//   // If docount = 1 → show plain number (no currency)
//   if (h.docount === 1) {
//     return Number(value).toLocaleString('en-IN', {
//       minimumFractionDigits: h.decimalrate ?? 0,
//       maximumFractionDigits: h.decimalrate ?? 0
//     });
//   }

//   // Default → show currency formatted
//   const decimalPlaces = h.decimalrate ?? 2;
//   return new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//     minimumFractionDigits: decimalPlaces,
//     maximumFractionDigits: decimalPlaces
//   }).format(value);
// }



export function formatValue(h: any, row: any): string {
  const value = row?.[h.field];

  // Apply formatting only for numeric fields
  if (h.col_field_type === 'N' && h.field !== 'deductee_phoneno') {
  console.log(h);
    // Null / undefined / empty → treat as 0 (currency format)
    if (value == null || value === '') {
      const decimalPlaces = h.decimalrate ?? 2;

      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: decimalPlaces,
        maximumFractionDigits: decimalPlaces,
      }).format(0);
    }

    const numValue = Number(value);
    if (isNaN(numValue)) {
      return String(value); // return raw if not convertible to number
    }

    // If docount === 1 → show as plain number (not currency)
    if (h.docount === 1) {
      return numValue.toLocaleString('en-IN', {
        minimumFractionDigits: h.decimalrate ?? 0,
        maximumFractionDigits: h.decimalrate ?? 0,
      });
    }

    // Default: Currency formatting
    const decimalPlaces = h.decimalrate ?? 2;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: decimalPlaces,
      maximumFractionDigits: decimalPlaces,
    }).format(numValue);
  }

    // For NON-N fields → show "-" when empty
  if (value == null || value === '') {
    return '-';
  }


  // Non-N fields → return as is
  return String(value);
}


// export function formatValue(h: any, row: any): string {
//   let value = row?.[h.field];

//   // Treat null/undefined/empty as 0 for currency fields
//   if (value == null || value === undefined || value === '') {
//     // If field name contains 'am' → show currency
//     if (h.field && h.field.toLowerCase().includes('am')) {
//       const decimalPlaces = h.decimalrate ?? 2;
//       return new Intl.NumberFormat('en-IN', {
//         style: 'currency',
//         currency: 'INR',
//         minimumFractionDigits: decimalPlaces,
//         maximumFractionDigits: decimalPlaces,
//       }).format(0);
//     }
//     return '-'; // default for non-currency fields
//   }

//   const numValue = Number(value);

//   if (isNaN(numValue)) {
//     return String(value);
//   }

//   // Plain number formatting
//   if (h.docount === 1) {
//     return numValue.toLocaleString('en-IN', {
//       minimumFractionDigits: h.decimalrate ?? 0,
//       maximumFractionDigits: h.decimalrate ?? 0,
//     });
//   }

//   // Currency formatting for fields with 'am'
//   if (h.field && h.field.toLowerCase().includes('am')) {
//     const decimalPlaces = h.decimalrate ?? 2;
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       minimumFractionDigits: decimalPlaces,
//       maximumFractionDigits: decimalPlaces,
//     }).format(numValue);
//   }

//   return String(value);
// }


export function toLowerCaseValue(value: any): string {
  if (typeof value !== 'string' || !value.trim()) {
    return 'NA';
  }
  return value.trim().toLowerCase();
}

// export function getApiName(baseName: string, submoduleType?: string | null): string {
//   if (!submoduleType || submoduleType === 'R' || submoduleType === '') {
//     return baseName;
//   }

//   const isUpperCase = baseName === baseName.toUpperCase(); 

//   switch (submoduleType) {
//     case 'G':
//       return `${baseName}_${isUpperCase ? '15GH' : '15gh'}`;
//     case 'C':
//       return `${baseName}_${isUpperCase ? 'CORRS' : 'corrs'}`;
//     default:
//       return baseName;
//   }
// }



//new 17/1/025

export function getApiName(
  baseName: string,
  submoduleType?: string | null,
  extraSuffix?: string | null
): string {
  if (!baseName) return '';

  const isUpperCase = baseName === baseName.toUpperCase();
  let finalName = baseName;

  // ✅ Add submodule suffix if applicable
  if (submoduleType && submoduleType !== 'R' && submoduleType !== '') {
    switch (submoduleType) {
      case 'G':
        finalName = `${baseName}_${isUpperCase ? '15GH' : '15gh'}`;
        break;
      case 'C':
        finalName = `${baseName}_${isUpperCase ? 'CORRS' : 'corrs'}`;
        break;
      default:
        finalName = baseName;
        break;
    }
  }

  // ✅ Add extra suffix like `_dm` or `_ad` if present
  if (extraSuffix) {
    finalName = `${finalName}_${extraSuffix}`;
  }

  return finalName;
}




