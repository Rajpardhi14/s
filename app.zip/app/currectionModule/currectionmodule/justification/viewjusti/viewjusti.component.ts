import { Component } from '@angular/core';

@Component({
  selector: 'app-viewjusti',
  standalone: true,
  imports: [],
  templateUrl: './viewjusti.component.html',
  styleUrl: './viewjusti.component.css'
})
export class ViewjustiComponent {

}
