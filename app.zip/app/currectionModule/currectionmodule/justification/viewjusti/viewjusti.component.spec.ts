import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewjustiComponent } from './viewjusti.component';

describe('ViewjustiComponent', () => {
  let component: ViewjustiComponent;
  let fixture: ComponentFixture<ViewjustiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewjustiComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewjustiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
