import { Component, DestroyRef, inject } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { skip, Subject, Subscription } from 'rxjs';

import { CommonModule } from '@angular/common';

import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';


import { Router } from '@angular/router';
import { BasicFilterComponent } from '../../../shared/components/basic-filter/basic-filter.component';
import { AdvanceFilterComponent } from '../../../shared/components/advance-filter/advance-filter.component';
import { GearboxComponent } from '../../../shared/components/gearbox/gearbox.component';
import { TableskeletonComponent } from '../../../shared/components/tableskeleton/tableskeleton.component';
import { NodataComponent } from '../../../shared/components/nodata/nodata.component';
import { AddchallansComponent } from '../../../features/challans/addchallans/addchallans.component';
import { AlertpoupComponent } from '../../../shared/components/alertpoup/alertpoup.component';
import { OutSideClickDirective } from '../../../core/services/outclick/outside-click.directive';
import { capitalizeEachWord, formatDatesend, formatValue } from '../../../shared/utils/passmatch';
import { RefreshdataService } from '../../../core/services/refreshdata/refreshdata.service';
import { ScreensizeService } from '../../../core/services/screensize/screensize.service';
import { UserdataService } from '../../../core/services/userdata/userdata.service';
import { ToastService } from '../../../core/services/toaster/toast.service';
import { XldownloadService } from '../../../core/services/excel/xldownload.service';
import { ApiserviceService } from '../../../core/services/componentservice/apiservice.service';
import { DisplayValueUtilService } from '../../../shared/utils/displayValue';
@Component({
  selector: 'app-justification',
  standalone: true,
 imports: [
     BasicFilterComponent,
     AdvanceFilterComponent,
     GearboxComponent,
     TableskeletonComponent,
     NodataComponent,
     CommonModule,
     FormsModule,
     ReactiveFormsModule,
     AddchallansComponent,
     AlertpoupComponent,
     OutSideClickDirective,
   ],
  templateUrl: './justification.component.html',
  styleUrl: './justification.component.css'
})
export class JustificationComponent {
scrollPosition: number = 0;
  totalHeight: number = 0;
  visibleHeight: number = 0;
  localUserData: any;
  allUsersData: any[] = [];

  basic_filter: any[] = [];
  basic_filterPlaceholder: string = '';
  advance_filter: any[] = [];
  advance_filterPlaceholder: string = '';
  filterForm!: FormGroup;
  selectedFilter: string | null = null;
  filterClause: any;
  selectedFilterValue: string = '';
  filtercount: number = 0;
  usergrandtotal: number = 0;
  limit: number = 100;
  offset: number = 0;
  currentPage: number = 1;
  newOffset: any;
  isLoadingMoreData: boolean = false;
  isLoadingMore: boolean = false;
  paginatedList: any;
  totalcount: any;
  userData: any;
  Math = Math;
    formatValue =formatValue;
  // Table data variable
  headers: any[] = [];
  tableBody: any[] = [];
  loginUserdata: any;
  loading = false;
  errorMessage = '';
   selectedFilters: { label: string; field?: string; value: string }[] = [];
  selectedUser: any;
  private refreshSubscription: Subscription | null = null;
  isLoading: boolean = false;
  menuOptions: {
    field: string;
    label: string;
    operator: string;
    alias: string;
    placeholder: string;
  }[] = [];
  selectedOption: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  } | null = null;
  searchTerm: string = '';
  matchingDependValue: any;

  // selectedMaster: string = 'USER_MASTER';
  activeFilterTab: string = '';
  captilize = capitalizeEachWord;
  defaultTabFilter: any;
  selectedValue: string[] = [];
  selectedLabel: any;
  isOpenAddUaser: boolean = false;
  selectedRoleCode: string | null = null;
  dropdownOpenselect = false;
  scrollTimeout: any = null;
  userHasScrolled: boolean = false;
  filtersSubmitted = false;
  showOptions: boolean = false;
  openInfoId: number | null = null;
  screenWidth: number = 0;
  screenHeight: number = 0;
  deviceType: string = '';
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  heightToSubtract: number = 460;
  remainingHeight: number = 0;
  skeletonList = Array(7);
  FYYear: string = 'Yes';
  iudtype: string = 'ALL';
  private destroy$ = new Subject<void>();
  dynaUserData: any;

  capitalizeEachWord = capitalizeEachWord;
  visible: boolean = false;
    multiMast:any;
      dynamicUserData: any;
  constructor(
    private refreshdata: RefreshdataService,
    private screenSizeService: ScreensizeService,
    private userlocaldataService: UserdataService,
    private fb: FormBuilder,
    private toastService: ToastService,
    private exceldownload: XldownloadService,
    private apiService: ApiserviceService,
      private displayValueUtil: DisplayValueUtilService,
      private router:Router,
  ) {}

  private destroyRef = inject(DestroyRef);
  dynamicUserData$ = toObservable(this.userlocaldataService.dynamicUserData);
  ngOnInit(): void {


    this.localUserData = this.userlocaldataService.getLocalUserData();
    this.dynaUserData = this.userlocaldataService.getAllDynamicUserData() || {};
    // console.log(this.dynaUserData.default_quarter_no);
    // console.log(this.dynaUserData.default_tds_type_code);
    // this.dynamicUserData$
    //   .pipe(skip(1), takeUntilDestroyed(this.destroyRef))
    //   .subscribe((dynamicData) => {
    //     // console.log('Dynamic user data changed:', dynamicData);
    //     this.dynaUserData =
    //       this.userlocaldataService.getAllDynamicUserData() || {};
    //     this.offset = 0;
    //     this.fetchTable();
    //     this.fetchFilter();
    //     this.fetchGrandTotal();
    //   });

    this.fetchTable();
    this.fetchFilter();
    this.fetchGrandTotal();
    // this.selectedDelete();
    this.refreshSubscription = this.refreshdata
      .onRefresh('Justification')
      .subscribe(() => {
        this.fetchTable();
        this.fetchGrandTotal();
      });

    this.screenWidth = this.screenSizeService.screenWidth;
    this.screenHeight = this.screenSizeService.screenHeight;
    this.deviceType = this.screenSizeService.getDeviceType();
    this.fullScreenResolution =
      this.screenSizeService.getFullScreenResolution();
    this.calculateRemainingHeight();


  }

  // Check if all rows are selected
  isAllSelected(): boolean {
    
    return this.paginatedList?.every((row: any) => row.selected);
    
  }

  // Toggle all rows
  toggleAllSelection(event: any) {
    const checked = event.target.checked;
    this.paginatedList.forEach((row: any) => (row.selected = checked));
  }

  // Get selected rows (optional helper)
  getSelectedRows() {
    return this.paginatedList.filter((row: any) => row.selected);
  }

  mergeGroups: { [key: number]: any[] } = {};
  fieldToMergeGroup: { [key: string]: number } = {};

  // buildMergeGroups() {
  //   this.headers?.forEach(header => {
  //     const mergeCol = header.mergeColumn;
  //     if (mergeCol) {
  //       if (!this.mergeGroups[mergeCol]) {
  //         this.mergeGroups[mergeCol] = [];
  //       }
  //       this.mergeGroups[mergeCol].push(header);
  //       this.fieldToMergeGroup[header.field] = mergeCol;
  //     }
  //   });
  // }

  // isFirstInMergeGroup(header: any): boolean {
  //   const mergeCol = header.mergeColumn;

  //   return (
  //     mergeCol &&
  //     this.mergeGroups[mergeCol]?.length &&
  //     this.mergeGroups[mergeCol][0].field === header.field
  //   );

  // }


  fetchTable() {
    // Ensure filterClause is always an array
  const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];

  // Your default filters (always applied)
  const newFilterClause = [
    {
      filter_col_field: 'quarter_no',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_quarter_no,
      filter_col_field_alias: 'a.',
    },
    {
      filter_col_field: 'tds_type_code',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_tds_type_code,
      filter_col_field_alias: 'a.',
    },
  ];

  // // Always rebuild final filterClause fresh:
  // const finalFilterClause = [
  //   ...newFilterClause,
  //   ...userFilters.filter(
  //     (uf: any) =>
  //       !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
  //   ),
  // ];
  // Merge user filters and defaults: user filters take priority
    const finalFilterClause = [
      ...userFilters, // user-selected filters first
      ...newFilterClause.filter(
        (df) => !userFilters.some((uf) => uf.filter_col_field === df?.filter_col_field)
      ),
    ];
    if (this.offset === 0) {
      this.loading = true;
    } else {
      this.isLoadingMore = true;
    }
    const sdata = this.apiService.generateSData(

      'get_gtdb_tds_traces_default_tran',
      this.localUserData,
      finalFilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      {
        FYYear: this.FYYear,
        iudtype: this.iudtype,
      }
    );
    this.apiService
      .getTableData('/Traces/get_gtdb_tds_traces_default_tran', sdata)
      .subscribe({
        next: (data) => {
          if (data?.result?.a_proc_error == 0) {
            const userData = data?.result?.get_gtdb_tds_traces_default_tran;
            // console.log(userData);
            if (userData?.get_gtdb_tds_traces_default_tran_header) {
              this.headers =
                userData?.get_gtdb_tds_traces_default_tran_header?.map(
                  (header: any) => ({
                    ...header,
                    visible: header.display === 1,
                  })
                );
              // console.log(this.headers);
            }
            // this.allUsersData = userData || {};
            this.tableBody =
              userData?.get_gtdb_tds_traces_default_tran_detail || [];
            // this.buildMergeGroups()
            if (this.offset > 0) {
              setTimeout(() => {
                this.paginatedList = [...this.paginatedList, ...this.tableBody];
                this.isLoadingMore = false;
              }, 300);
            } else {
              this.paginatedList = this.tableBody;
            }
          } else {
            this.loading = false;
            this.errorMessage = data.result[0].a_proc_error_message;
            this.showError(this.errorMessage);
          }
          this.loading = false;
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to fetch users.';
          this.showError(this.errorMessage);
          this.loading = false;
          this.isLoadingMore = false;
        },
      });
  }

  onScroll(event: any): void {
    this.userHasScrolled = true;

    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }

    this.scrollTimeout = setTimeout(() => {
      const scrollTop = Math.ceil(event.target.scrollTop);
      const clientHeight = event.target.clientHeight;
      const scrollHeight = Math.ceil(event.target.scrollHeight);

      const margin = 5;
      const atBottom = scrollHeight <= scrollTop + clientHeight + margin;

      if (atBottom && !this.isLoadingMoreData) {
        this.loadMoreData();
      }
    }, 100);
  }

  loadMoreData(): void {
    const newOffset = this.currentPage * 100;

    if (newOffset < this.usergrandtotal) {
      if (newOffset <= 400) {
        this.currentPage += 1;
        this.offset = (this.currentPage - 1) * 100;

        this.isLoadingMoreData = true;
        this.errorMessage = '';

        this.fetchTable();

        setTimeout(() => {
          this.isLoadingMoreData = false;
        }, 100);
      } else {
        this.errorMessage = 'Kindly use filter for appropriate data';
      }
    }
  }

  isSkeletonshow: boolean = false;
  isFirstLoad: boolean = true;
  //#region filetr
  private fetchFilter(): void {
    if (this.isFirstLoad) {
      this.isSkeletonshow = true;
    }
    const sdata = this.apiService.generateSData(
      'get_gtfb_tds_traces_default_tran',
      this.localUserData,
      this.filterClause,
      this.limit,
      this.offset,
      this.currentPage,
       { iudtype: this.iudtype }
    );

    this.apiService
      .getFilterData('/Traces/get_gtfb_tds_traces_default_tran', sdata)
      .subscribe({
        next: (response) => {
          if (response?.result?.a_proc_error === '0') {
            this.basic_filter =
              response?.result?.get_gtfb_tds_traces_default_tran?.[0]?.basic_filter;
            this.advance_filter =
              response?.result?.get_gtfb_tds_traces_default_tran?.[1]?.advance_filter;
 setTimeout(() => {
            this.setDefaultFilters();
          }, 0);
          this.initializeForm();
          this.menuOptions = this.basic_filter?.map((filter: any) => ({
            label: filter.filter_col_prompt,
            field: filter.filter_col_field,
            operator: filter.filter_col_depend_operator,
            alias: filter.filter_col_field_alias,
            placeholder: filter.filter_col_placeholder,
          }));
          this.selectedOption = this.menuOptions?.[0];
        } else {
          // this.errorMessage = response.result?.[0].a_proc_error_message || "Please Check Endpoint";
          this.showError(this.errorMessage);
        }

        if (this.isFirstLoad) {
          this.isSkeletonshow = false;
          this.isFirstLoad = false;
        }
      },
      error: (error) => {
        console.error('Error user filter:', error);
        this.isSkeletonshow = false;
      },
    });
      //       this.advance_filter?.forEach((field: any) => {
      //         if (
      //           field.filter_col_external === 1 &&
      //           field.filter_col_type === 'filter-select'
      //         ) {
      //           const allOption = { value: 'ALL', label: 'All' };
      //           const exists = field.filter_col_depend_value?.some(
      //             (opt: any) => opt.value === 'ALL'
      //           );
      //           if (!exists) {
      //             field.filter_col_depend_value?.unshift(allOption);
      //           }
      //         }
      //       });
      //       //Find the first external filter-select field
      //       const defaultField = this.advance_filter?.find(
      //         (field: any) =>
      //           field.filter_col_external === 1 &&
      //           field.filter_col_type === 'filter-select'
      //       );
      //       //Get the default option with value 'ALL'
      //       const defaultOption = defaultField?.filter_col_depend_value?.find(
      //         (opt: any) => opt.value === 'ALL'
      //       );
      //       //Store default tab info
      //       this.defaultTabFilter = defaultOption;
      //       this.activeFilterTab = defaultOption?.value;
      //       //Initialize form and menu
      //       this.initializeForm();
      //       this.menuOptions = this.basic_filter?.map((filter: any) => ({
      //         label: filter.filter_col_prompt,
      //         field: filter.filter_col_field,
      //         operator: filter.filter_col_depend_operator,
      //         alias: filter.filter_col_field_alias,
      //         placeholder: filter.filter_col_placeholder,
      //       }));
      //       this.selectedOption = this.menuOptions?.[0];
      //     } else {
      //       this.errorMessage =
      //         response.result?.[0].a_proc_error_message ||
      //         'Please Check Endpoint';
      //       this.showError(this.errorMessage);
      //     }

      //     if (this.isFirstLoad) {
      //       this.isSkeletonshow = false;
      //       this.isFirstLoad = false;
      //     }
      //   },
      //   error: (error) => {
      //     console.error('Error user filter:', error);
      //     this.isSkeletonshow = false;
      //   },
      // });
  }
  //#endregion
  // setDefaultFilters() {
  //   if (!this.advance_filter || !this.filterForm) return;

  //   this.advance_filter.forEach((field: any) => {
  //     // Set default for quarter_no
  //     if (field.filter_col_field === 'quarter_no') {
  //       const defaultQuarter = this.dynaUserData?.default_quarter_no || 'Q1';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultQuarter);
  //     }

  //     // Set default for tds_type_code
  //     if (field.filter_col_field === 'tds_type_code') {
  //       const defaultTdsType = this.dynaUserData?.default_tds_type_code || '26Q';
  //       this.filterForm.get(field.filter_col_field)?.setValue(defaultTdsType);
  //     }
  //     // if (field.filter_col_external === 0 ) {
  //     //   const dvs=field.filter_col_external_default_value
  //     //  this.filterForm.get(field.filter_col_field)?.setValue(dvs);
  //     // }

  //     if (
  //       field.filter_col_external === 0 &&
  //       field.filter_col_external_default_value &&
  //       field.filter_col_external_default_value !== ''
  //     ) {
  //       this.filterForm
  //         .get(field.filter_col_field)
  //         ?.setValue(field.filter_col_external_default_value);
  //     }
  //   });


  //   this.selectedFilters = this.getSelectedFilters();
  // }

setDefaultFilters() {
  if (!this.advance_filter || !this.filterForm) return;

  this.advance_filter.forEach((field: any) => {
    let defaultValue: any;

    switch (field.filter_col_field) {
      case 'quarter_no':
        defaultValue = this.dynaUserData?.default_quarter_no || 'Q1';
        break;
      case 'tds_type_code':
        defaultValue = this.dynaUserData?.default_tds_type_code || '26Q';
        break;
      case 'shord_deduction_remark_status':
        defaultValue = field.filter_col_external_default_value;
        break;
      default:
        if (field.filter_col_external_default_value) {
          defaultValue = field.filter_col_external_default_value;
        }
    }

    if (defaultValue !== undefined) {
      this.filterForm.get(field.filter_col_field)?.setValue(defaultValue);

      // Store the default value itself to detect in getSelectedFilters
      field._isDefaultValue = defaultValue;
    }
  });

  this.selectedFilters = this.getSelectedFilters();
  // console.log(this.selectedFilter)
}


  selectedTabFilter(filterField: string, value: any, label: any): void {
    this.selectedValue = value;
    this.selectedLabel = label;
    this.activeFilterTab = value;
    //Always run logic even if the tab value is the same as previous
    if (this.activeFilterTab !== value) {
      this.activeFilterTab = value;
    } else {
      this.activeFilterTab = '';
      setTimeout(() => {
        this.activeFilterTab = value;
      }, 100);
    }
    const control = this.filterForm.get(filterField);
    if (control) {
      control.setValue(null, { emitEvent: false });
      control.setValue(value, { emitEvent: true });
    }
    Object.keys(this.filterForm.controls).forEach((key) => {
      const ctrl = this.filterForm.get(key);
      if (ctrl && typeof ctrl.value === 'string') {
        ctrl.setValue(ctrl.value.toUpperCase(), { emitEvent: false });
      }
    });
    this.filterClause = this.buildFilterClause();
    this.fetchTable();
    this.fetchGrandTotal();
  }

  private initializeForm(): void {
    if (this.advance_filter && this.advance_filter.length > 0) {
      this.filterForm = this.fb.group({});
      this.advance_filter.forEach((field: any) => {
        const control = this.fb.control(field.defaultValue || '');
        if (field.filter_col_external === 1) {
          control.disable();
          this.filterForm.addControl(field.filter_col_field, control);
        } else if (control && field.filter_col_external !== 1) {
          this.filterForm.addControl(field.filter_col_field, control);
        }
      });
      this.filterForm.valueChanges.subscribe((values) => {});
    } else {
      console.warn('advanceFilter is empty or undefined.');
    }
  }

  selectOption(option: {
    label: string;
    field: string;
    operator: string;
    alias: string;
    placeholder: string;
  }) {
    this.selectedOption = option;
    this.dropdownOpenselect = false;
  }

  onSubmit() {
    this.isLoading = true;
    this.offset = 0;
    setTimeout(() => {
      Object.keys(this.filterForm.controls).forEach((key) => {
        let controlValue = this.filterForm.get(key)?.value;
        if (typeof controlValue == 'string') {
                    controlValue = controlValue.trim().toUpperCase();      
          this.filterForm
            .get(key)
            ?.setValue(controlValue, { emitEvent: false });
        }
      });

            this.syncBasicAndAdvanceFilters();
 this.filterClause = this.buildFilterClause();
      Promise.all([this.fetchTable(), this.fetchGrandTotal()]).finally(() => {
        this.isLoading = false;
      });
      this.filtersSubmitted = true;
    }, 200);
  }
private syncBasicAndAdvanceFilters(): void {
    if (!this.filterForm || !this.advance_filter || !this.selectedOption) return;

    const basicField = this.selectedOption.field;
    const basicValue = this.searchTerm?.trim().toUpperCase(); // 🔹 Convert to UPPERCASE

    if (!basicField) return;

    const control = this.filterForm.get(basicField);


    if (basicValue && control && control.value?.toUpperCase() !== basicValue) {
      control.setValue(basicValue, { emitEvent: false });
    }


    if (control && control.value && control.value.toUpperCase() !== basicValue) {
      this.searchTerm = control.value.toUpperCase();
      this.selectedOption =
        this.menuOptions.find((opt) => opt.field === basicField) || null;
    }
  }


  private buildFilterClause(): any[] {
    const filterClause: any[] = [];

    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      const filterConfig = this.advance_filter?.find(
        (filter: any) => filter.filter_col_field === key
      );

      if (filterConfig && controlValue && controlValue !== 'ALL') {
        let filterValue: string = '';
        const operator = filterConfig.filter_col_depend_operator;

        if (operator === 'wc') {
          // For "wc", find the condition based on selected value
          const selectedOption = filterConfig.filter_col_depend_value?.find(
            (opt: any) => opt.value === controlValue
          );
          filterValue = selectedOption ? selectedOption.condition : '';
        } else {
          filterValue = controlValue.toString().trim();
        }

        if (filterValue && filterValue != '') {
          filterClause.push({
            filter_col_field: filterConfig.filter_col_field,
            filter_col_depend_operator: operator,
            filter_col_value: filterValue.toUpperCase(),
            filter_col_field_alias: filterConfig.filter_col_field_alias,
          });
        }
      }
    });

    // Include search term if present
    if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
      filterClause.push({
        filter_col_field: this.selectedOption.field,
        filter_col_depend_operator: this.selectedOption.operator,
         filter_col_value: this.searchTerm.trim().toUpperCase(),
        filter_col_field_alias: this.selectedOption.alias,
      });
    }
      const uniqueFilters = Array.from(
    new Map(
      filterClause.map((item) => [item.filter_col_field, item])
    ).values()
  );

  return uniqueFilters;
    // return filterClause;

  }


  onInput(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value.trim();
    if (inputValue.length === 0) {
      this.clearInput();
    }
  }

 getSelectedFilters() {
    const selectedFilters: { label: string; field?: string; value: string }[] = [];

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);

        if (control && control.value != null && control.value.toString().trim() !== '') {
          let label = field.filter_col_prompt;
          const dependValue = field.filter_col_depend_value?.find(
            (dv: any) => dv.value == control.value
          );
          if (dependValue?.label) {
            label = dependValue.label;
          }

          selectedFilters.push({
            label,
            field: field.filter_col_field,
            value: control.value.toString().trim(),
          });
        }

        //  if (!(field.filter_col_external === 1)) {
        //     const control = this.filterForm.get(field.filter_col_field);

        //     if (
        //       control &&
        //       control.value &&
        //       !field.filter_col_external_default_value &&
        //       control.value.toString().trim() !== ''
        //     ) {
        //       this.matchingDependValue = field.filter_col_depend_value.find(
        //         (dependValue: any) => dependValue.value === control.value
        //       );

        //       if (this.matchingDependValue) {
        //         selectedFilters.push({
        //           label: this.matchingDependValue.label,
        //           value: control.value.toString().trim(),
        //         });
        //       } else if (!this.matchingDependValue) {
        //         selectedFilters.push({
        //           label: field.filter_col_prompt,
        //           value: control.value.toString().trim(),
        //         });
        //       }
        //     }
        //   }



      });
    }

    // // Add search term filter (if applicable)
    // if (this.searchTerm && this.searchTerm.trim() !== '' && this.selectedOption) {
    //   selectedFilters.push({
    //     label: this.selectedOption.label,
    //     field: this.selectedOption.field,
    //     value: this.searchTerm.toUpperCase(),
    //   });
    // }

    return selectedFilters;
  }
// getSelectedFilters() {
//   const selectedFilters: { label: string; field?: string; value: string }[] = [];

//   if (this.advance_filter && Array.isArray(this.advance_filter)) {
//     this.advance_filter.forEach((field: any) => {
//       const control = this.filterForm.get(field.filter_col_field);

//       if (control && control.value != null && control.value.toString().trim() !== '') {
//         let label: string;

//         // If current value is the default, use prompt as label
//         if (field._isDefaultValue !== undefined && control.value === field._isDefaultValue) {
//           label = field.filter_col_prompt;
//         } 
//         // Otherwise, use depend_value label if available
//         else {
//           const dependValue = field.filter_col_depend_value?.find(
//             (dv: any) => dv.value == control.value
//           );
//           label = dependValue?.label || field.filter_col_prompt;
//         }

//         selectedFilters.push({
//           label,
//           field: field.filter_col_field,
//           value: control.value.toString().trim(),
//         });
//       }
//     });
//   }

//   return selectedFilters;
// }

  // clearFilter(index: number) {
  //   const selectedFilters = this.getSelectedFilters();
  //   const selectedFilter = selectedFilters[index];
  //   if (!selectedFilter) return;
  //   const filterToRemove = this.advance_filter.find((field: any) =>
  //     field.filter_col_depend_value?.some(
  //       (dependValue: any) => dependValue.label === selectedFilter.label
  //     )
  //   );

  //   const filterRemove = this.advance_filter.find(
  //     (field: any) => field.filter_col_prompt === selectedFilter.label
  //   );
  //   if (filterToRemove) {
  //     const control = this.filterForm.get(filterToRemove.filter_col_field);
  //     if (control) {
  //       control.reset();
  //     }
  //   } else if (filterRemove) {
  //     const control = this.filterForm.get(filterRemove.filter_col_field);
  //     if (control) {
  //       control.reset();
  //     }
  //   }
  //    if (
  //   this.searchTerm &&
  //   (this.searchTerm === selectedFilter.label ||
  //     this.searchTerm === selectedFilter.value ||
  //     this.searchTerm.toLowerCase().includes(selectedFilter.label?.toLowerCase()))
  // ) {
  //   this.searchTerm = '';
  // }

  //   this.filterClause = this.buildFilterClause();
  //   this.fetchTable();
  //   this.fetchGrandTotal();
  // }
  // clearInput() {
  //   this.searchTerm = '';
  //   this.offset = 0;
  //   this.currentPage = 1;
  //   this.filterClause = this.buildFilterClause();
  //   this.fetchTable();
  //   this.fetchGrandTotal();
  //   // this.clearAllFilters();
  // //  this.clearFilter(0);
  // }


clearFilter(index: number) {
  const selectedFilters = this.getSelectedFilters();
  const selectedFilter = selectedFilters[index];
  if (!selectedFilter) return;

  const filterToRemove = this.advance_filter.find((field: any) =>
    field.filter_col_depend_value?.some(
      (dependValue: any) => dependValue.label === selectedFilter.label
    )
  );

  const filterRemove = this.advance_filter.find(
    (field: any) => field.filter_col_prompt === selectedFilter.label
  );

  if (filterToRemove) {
    const control = this.filterForm.get(filterToRemove.filter_col_field);
    if (control) control.reset();
  } else if (filterRemove) {
    const control = this.filterForm.get(filterRemove.filter_col_field);
    if (control) control.reset();
  }

  // ✅ Normalize strings before comparing
  const search = (this.searchTerm || '').toString().trim().toLowerCase();
  const label = (selectedFilter.label || '').toString().trim().toLowerCase();
  const value = (selectedFilter.value || '').toString().trim().toLowerCase();

  if (search && (search === label || search === value || search.includes(label))) {
    this.searchTerm = '';
  }

  this.filterClause = this.buildFilterClause();
  this.fetchTable();
  this.fetchGrandTotal();
}


clearInput() {
  const previousSearch = (this.searchTerm || '').toString().trim().toLowerCase();
  this.searchTerm = '';
  this.offset = 0;
  this.currentPage = 1;

  // ✅ Find and remove any filter whose label/value matches the cleared search term
  const selectedFilters = this.getSelectedFilters();
  selectedFilters.forEach((filter, index) => {
    const label = (filter.label || '').toString().trim().toLowerCase();
    const value = (filter.value || '').toString().trim().toLowerCase();
    if (previousSearch && (previousSearch === label || previousSearch === value || label.includes(previousSearch))) {
      this.clearFilter(index);
    }
  });

  this.filterClause = this.buildFilterClause();
  this.fetchTable();
  this.fetchGrandTotal();
}

  resetFilter() {
      this.searchTerm = '';
    this.filterForm.reset();
    this.filterClause = [];
    this.selectedFilters = [];
  }



  // count of advanced filter
  getSelectedFilterCount(): number {
    let count = 0;

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        if (field.filter_col_external === 1) {
          count++;
        }
        const control = this.filterForm.get(field.filter_col_field);
        if (
          control &&
          control.value &&
          control.value.toString().trim() !== ''
        ) {
          if (field.filter_col_external === 1) {
            count;
          } else {
            count++;
          }
        }
      });
    }
    if (this.searchTerm && this.searchTerm.trim() != '') {
      count++;
    }
    return count;
  }
  // user grand total


  // user grand total
getVisibleHeaders() {
  return this.headers?.filter(h => h.visible) || [];
}

showFooter: boolean = false; 
gtdgData:any;
toggleFooter() {
  this.showFooter = !this.showFooter;
}
  private fetchGrandTotal(): void {
   // Ensure filterClause is always an array
  const userFilters = Array.isArray(this.filterClause) ? this.filterClause : [];

  // Your default filters (always applied)
  const newFilterClause = [
    {
      filter_col_field: 'quarter_no',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_quarter_no,
      filter_col_field_alias: 'a.',
    },
    {
      filter_col_field: 'tds_type_code',
      filter_col_depend_operator: '=',
      filter_col_value: this.dynaUserData.default_tds_type_code,
      filter_col_field_alias: 'a.',
    },
  ];

  // Always rebuild final filterClause fresh:
  const finalFilterClause = [
    ...newFilterClause,
    ...userFilters.filter(
      (uf: any) =>
        !newFilterClause.some((nf) => nf.filter_col_field === uf.filter_col_field)
    ),
  ];
    const sdata = this.apiService.generateSData(
      'get_gtdg_tds_traces_default_tran',
      this.localUserData,
      // this.filterClause,
      finalFilterClause,
      this.limit,
      this.offset,
      this.currentPage,
      { FYYear: this.FYYear }
    );

    this.apiService
      .getGrandTotal('/Traces/get_gtdg_tds_traces_default_tran', sdata)
      .subscribe({
        next: (response) => {
          // this.loading = false;
          this.isLoadingMore = false;
          if (response?.result?.a_proc_error == 0) {
            this.gtdgData =
    response?.result?.get_gtdg_tds_traces_default_tran?.[0] || null;

  this.usergrandtotal = this.gtdgData?.rec || null;
  this.totalcount = this.usergrandtotal;
          } else {
            this.showError(this.errorMessage);
          }
        },
        error: (error) => {
          // this.loading = false;
          this.isLoadingMore = false;
          // console.error('Error fetching vendor data:', error);
          this.showError('Something Went Wrong');
        },
      });
  }

  // Remove all filter label values
  clearAllFilters() {
    this.searchTerm = '';
    this.offset = 0;
    this.currentPage = 1;
  this.filterClause = this.buildFilterClause();
    // Check if user applied any filters different from defaults
    const hasUserAppliedFilters = this.advance_filter?.some((field: any) => {
      const control = this.filterForm.get(field.filter_col_field);
      const value = control?.value;
      const defaultVal = field._isDefaultValue ?? '';
      return JSON.stringify(value) !== JSON.stringify(defaultVal) && value !== '';
    });

    if (this.advance_filter && Array.isArray(this.advance_filter)) {
      this.advance_filter.forEach((field: any) => {
        const control = this.filterForm.get(field.filter_col_field);
        if (!control) return;

        const defaultVal = field._isDefaultValue ?? null;

        if (hasUserAppliedFilters) {
          // ✅ Keep default filters intact
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue(''); // clear user-only filters
          }
        } else {
          // ✅ If no user filters were applied — reset to defaults, not empty
          if (defaultVal !== null && defaultVal !== undefined && defaultVal !== '') {
            control.setValue(defaultVal);
          } else {
            control.setValue('');
          }
        }
      });
    }

    // ✅ Rebuild filterClause including defaults
    this.selectedFilters = this.getSelectedFilters();
    this.filterClause = this.buildFilterClause();
    this.filtercount = this.getSelectedFilterCount();

    // 🚫 Don’t treat this as a full clear for fetchTable()
    this.fetchTable();
    this.fetchGrandTotal();
  }
  selectedIdsForDeletion: number[] = [];

  getSelectedRowIds(): number[] {
    return this.paginatedList
      ?.filter((row: any) => row.selected)
      ?.map((row: any) => row.rowid_seq);
  }

  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }

  private showError(message: string) {
    this.errorMessage = message;
    this.toastService.showError(message);
  }

  // download xlfile
  exportToExcel(): void {
    this.exceldownload.downloadExcel(
      this.headers,
      this.tableBody,
      'users_data'
    );
  }

  closeDropdown(): void {
    this.openInfoId = null;
  }

  isLastChild(index: number): boolean {
    return index === this.paginatedList.length - 1;
  }


isDrawerOpen: boolean = false;
  selectedId: string | null = null;
  challan_alloc_status:string | null=null;
  clientCode:any;
  openDrawer(idTofetch?: string, clientCFeatch?:any,alloc_Status?:any) {
    this.selectedId = idTofetch ?? null;
        this.clientCode = clientCFeatch ?? null;
        this.challan_alloc_status=alloc_Status ?? null;
    this.isDrawerOpen = true;
   
  }


  closeDrawer() {
    this.selectedId = null;
    this.isDrawerOpen = false;
  }

  handleClosePopup() {
    this.isDrawerOpen = false; // or any logic to close popup
  }

  calculateRemainingHeight() {
    this.remainingHeight =
      this.fullScreenResolution.height - this.heightToSubtract;
  }

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
  }
  selectedRow: any = null;

  selectedCount() {
    return this.paginatedList?.filter((r: any) => r?.selected).length;
  }




  onClear() {
    // Uncheck all rows
    this.paginatedList?.forEach((r: any) => (r.selected = false));
  }


  



  isDateField(field: string): boolean {
    const dateFields = ['challan_date', 'tran_ref_date', 'tds_deduct_date'];
    return dateFields.includes(field);
  }
    formatDate(value: Date | string | null | undefined): string {
    return formatDatesend(value);
  }

    getDisplayValue(header: any, row: any) {
    return this.displayValueUtil.getDisplayValue(header, row, this.multiMast);
  }










}
