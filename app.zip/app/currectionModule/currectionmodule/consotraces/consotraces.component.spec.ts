import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsotracesComponent } from './consotraces.component';

describe('ConsotracesComponent', () => {
  let component: ConsotracesComponent;
  let fixture: ComponentFixture<ConsotracesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConsotracesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ConsotracesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
