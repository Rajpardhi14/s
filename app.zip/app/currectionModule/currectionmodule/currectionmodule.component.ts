import { Component } from '@angular/core';

@Component({
  selector: 'app-currectionmodule',
  standalone: true,
  imports: [],
  templateUrl: './currectionmodule.component.html',
  styleUrl: './currectionmodule.component.css'
})
export class CurrectionmoduleComponent {

}
