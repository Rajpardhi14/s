import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LdctracesComponent } from './ldctraces.component';

describe('LdctracesComponent', () => {
  let component: LdctracesComponent;
  let fixture: ComponentFixture<LdctracesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LdctracesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LdctracesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
