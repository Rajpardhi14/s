import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrectionmoduleComponent } from './currectionmodule.component';

describe('CurrectionmoduleComponent', () => {
  let component: CurrectionmoduleComponent;
  let fixture: ComponentFixture<CurrectionmoduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CurrectionmoduleComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CurrectionmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
