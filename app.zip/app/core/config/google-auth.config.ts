// Google OAuth Configuration
// IMPORTANT: You MUST replace this with your actual Google Client ID
export const GOOGLE_CLIENT_ID = '413112234611-3ak82q2rb37fh5h5rk47ec1j2a36n3mq.apps.googleusercontent.com';

// ⚠️ Current Status: NOT CONFIGURED - Google Sign-In will not work!
// 
// To fix the "401: invalid_client" error:
// 
// 1. Go to https://console.cloud.google.com/
// 2. Create a new project or select existing
// 3. Enable APIs: Google Identity Toolkit API
// 4. Go to "APIs & Services" > "Credentials"
// 5. Configure OAuth consent screen (External type)
// 6. Create OAuth 2.0 Client ID (Web application)
// 7. Add to Authorized JavaScript origins:
//    - http://localhost:4200
//    - http://localhost
// 8. Add to Authorized redirect URIs:
//    - http://localhost:4200/auth/google/callback
//    - http://localhost:4200
// 9. Copy the Client ID (format: 123456789-xxxxx.apps.googleusercontent.com)
// 10. Replace the placeholder above with your Client ID
//
// Example: 
// export const GOOGLE_CLIENT_ID = '123456789-abcdefghijk.apps.googleusercontent.com';
//
// See GOOGLE_OAUTH_SETUP.md for detailed instructions