// Microsoft OAuth Configuration
// IMPORTANT: You MUST replace this with your actual Microsoft Client ID
export const MICROSOFT_CLIENT_ID = 'YOUR_MICROSOFT_CLIENT_ID';

// Example: 'a1b2c3d4-e5f6-g7h8-i9j0-k1l2m3n4o5p6'
//
// To get your Microsoft Client ID:
// 
// 1. Go to https://portal.azure.com/
// 2. Navigate to "Azure Active Directory" > "App registrations"
// 3. Click "New registration"
// 4. Configure:
//    - Name: TDSCPC Registration
//    - Supported account types: "Accounts in any organizational directory and personal Microsoft accounts"
//    - Redirect URI: Web - http://localhost:4200/auth/microsoft/callback
// 5. After creation, copy the "Application (client) ID"
// 6. Replace the placeholder above with your Client ID
//
// For production, add: https://tdscpc.gstcpc.com/auth/microsoft/callback