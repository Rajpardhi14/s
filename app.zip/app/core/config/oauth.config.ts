import { SocialAuthServiceConfig, GoogleLoginProvider } from '@abacritt/angularx-social-login';

export function provideOAuthConfig(): SocialAuthServiceConfig {
  return {
    autoLogin: false,
    providers: [
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider(
          'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com'
        )
      }
    ],
    onError: (err) => {
      console.error('OAuth error:', err);
    }
  } as SocialAuthServiceConfig;
}
// http://localhost:4200
// OAuth Configuration Constants (Browser-safe)
export function getOAuthConfig() {
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';

  return {
    google: {
      clientId: '413112234611-3ak82q2rb37fh5h5rk47ec1j2a36n3mq.apps.googleusercontent.com',
      scope: 'profile email',
      discoveryDocs: ['https://accounts.google.com/.well-known/openid-configuration']
    },
    microsoft: {
      clientId: 'YOUR_MICROSOFT_CLIENT_ID',
      authority: 'https://login.microsoftonline.com/common',
      redirectUri: baseUrl + '/auth/microsoft/callback',
      scopes: ['openid', 'profile', 'email']
    }
  };
}
