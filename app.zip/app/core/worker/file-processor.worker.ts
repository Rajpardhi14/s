/// <reference lib="webworker" />
import * as XLSX from "xlsx";
import { SSF } from "xlsx";

addEventListener('message', async (event: MessageEvent) => {
  const { file, selectedOptionReturn, selectedOptionTemp, expectedHeaders } = event.data;
  console.log('Worker received file:', expectedHeaders);
  if (!file) {
    postMessage({ error: 'No file selected' });
    return;
  }

  const fileExtension = file.name.split('.').pop()?.toLowerCase();
  const fileSizeInMB = file.size / (1024 * 1024);

  if (fileExtension === 'xlsx' || fileExtension === 'csv') {

    processLargeExcelOrCSV(file, selectedOptionReturn, selectedOptionTemp, expectedHeaders);
  } else if (fileExtension === 'txt') {
    processTextFile(file);
  } else {
    postMessage({ error: 'Unsupported file format' });
  }
});


// Function to process .txt files
async function processTextFile(file: File) {
  const reader = new FileReader();

  reader.onload = async (e: any) => {
    const startTime = performance.now();

    const content = e.target.result; // Read file content as text
    const lines = content
      .split(/\r?\n/)
      .filter((line: any) => line.trim() !== ''); // Split into lines, remove empty ones

    const chunkSize = 50000;
    const chunks = Math.ceil(lines.length / chunkSize);

    const fileInfo = {
      sheetName: file.name,
      records: lines.length,
      chunks: chunks,
    };

    const endTime = performance.now(); // End timing
    postMessage({
      fileInfo,
      timeTaken: `${((endTime - startTime) / 1000).toFixed(2)}s`,
    });
  };

  reader.readAsText(file);
}

// async function processLargeExcelOrCSV(file: File, selectedOptionReturn: any, selectedOptionTemp: any, fileExpectedHeaders: any) {
//   const reader = new FileReader();

//   reader.onload = async (e: ProgressEvent<FileReader>) => {
//     const startTime = performance.now();
//     const arrayBuffer = e.target?.result as ArrayBuffer;
//     const data = new Uint8Array(arrayBuffer);
//     const CHUNK_SIZE = 50 * 1024 * 1024; 
//     const totalChunks = Math.ceil(data.length / CHUNK_SIZE);

//     let allBlobs: { fileName: string; blob: Blob; recordCount: number }[] = [];

//     let globalHeaders: string[] | null = null; 

//     for (let i = 0; i < totalChunks; i++) {
//       const start = i * CHUNK_SIZE;
//       const end = Math.min(start + CHUNK_SIZE, data.length);
//       const chunk = data.slice(start, end);


//       const chunkBlobs = processChunk(
//         chunk,
//         i,
//         file.name,
//         globalHeaders,
//         selectedOptionReturn,
//         selectedOptionTemp,
//         fileExpectedHeaders
//       );

//       // ✅ Set headers globally from the first chunk
//       if (!globalHeaders && chunkBlobs.length > 0 && chunkBlobs[0].headers) {
//         globalHeaders = chunkBlobs[0].headers || null;
//       }

//       allBlobs.push(...chunkBlobs);
//     }

//     const endTime = performance.now();

//     // ✅ Send all processed Blobs with record count to Angular
//     postMessage({
//       message: 'All chunks processed successfully',
//       totalChunks,
//       allBlobs,
//       timeTaken: `${((endTime - startTime) / 1000).toFixed(2)}s`,
//     });
//   };

//   reader.readAsArrayBuffer(file);
// }

// function processChunk(
//   chunk: Uint8Array,
//   chunkIndex: number,
//   fileName: string,
//   globalHeaders: string[] | null,
//   selectedOptionReturn: any,
//   selectedOptionTemp: string,
//   fileExpectedHeaders: { fieldName: string; mandatory: boolean }[]
// ) {
//   const chunkBlobs: {
//     fileName: string;
//     blob: Blob;
//     recordCount: number;
//     headers?: string[];
//   }[] = [];
//   console.log("hello World...1")
//   try {
//     // 🔹 Read workbook
//     const arrayBuffer = chunk.buffer.slice(0, chunk.byteLength);
//     // const workbook = XLSX.read(arrayBuffer, { type: "array", raw: true });

//     const workbook = XLSX.read(arrayBuffer, { type: "array" });

//     // 🔹 Required sheets
//     const requiredSheets = ["Sheet1", "TDS-TCS"];
//     const filteredSheets = workbook.SheetNames.filter((s: any) =>
//       requiredSheets.includes(s)
//     );

//     for (const sheetName of filteredSheets) {
//       const worksheet = workbook.Sheets[sheetName];
//       let sheetData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

//       // 🔹 Remove empty rows
//       sheetData = sheetData.filter(
//         (row) => Array.isArray(row) && row.some((cell) => cell != null && cell !== "")
//       );

//       // 🔹 Resolve headers
//       const headers = globalHeaders ?? findHeaderRow(sheetData, fileExpectedHeaders);
//       if (!headers) {
//         postMessage({
//           error: `Missing expected headers in sheet "${sheetName}"`,
//           sheetName,
//         });
//         continue;
//       }

//       // 🔹 Convert to key-value format
//       const formattedData = convertToKeyValueFormat(sheetData, headers);
//       const recordCount = formattedData.length;

//       // 🔹 Validate financial year
//       if (!validateFinancialYear(formattedData, selectedOptionTemp)) {
//         postMessage({
//           error: `Selected year (${selectedOptionTemp}) does not match ${sheetName} year.`,
//           sheetName,
//         });
//         continue;
//       }

//       // 🔹 Create JSON blob
//       const blob = new Blob(
//         [JSON.stringify({ sheetName, recordCount, records: formattedData })],
//         { type: "application/json" }
//       );

//       chunkBlobs.push({ fileName: sheetName, blob, recordCount, headers });
//     }
//   } catch (error) {
//     postMessage({
//       error: `Upload Correct File or Missing Column "${(error as any).missingColumns}"`,
//       missingColumns: (error as any).missingColumns || [], // fallback to empty array
//     });
//     console.error(`❌ Error processing chunk ${chunkIndex + 1}:`, error);
//   }

//   return chunkBlobs;
// }

async function processLargeExcelOrCSV(file: File, selectedOptionReturn: any, selectedOptionTemp: any, fileExpectedHeaders: any) {
  const reader = new FileReader();

  reader.onload = async (e: ProgressEvent<FileReader>) => {
    const startTime = performance.now();
    const arrayBuffer = e.target?.result as ArrayBuffer;

    try {
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });

      const allBlobs: { fileName: string; blob: Blob; recordCount: number }[] = [];
      let globalHeaders: string[] | null = null;

      for (const sheetName of workbook.SheetNames) {
        const worksheet = workbook.Sheets[sheetName];
        let sheetData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

        // Remove empty rows
        sheetData = sheetData.filter(row => Array.isArray(row) && row.some(cell => cell != null && cell !== ''));

        // Detect headers
        const headers: string[] = globalHeaders ?? findHeaderRow(sheetData, fileExpectedHeaders);

        // const headers = globalHeaders ?? findHeaderRow(sheetData, fileExpectedHeaders);
        globalHeaders = headers;

        const formattedData = convertToKeyValueFormat(sheetData, headers);
        const recordCount = formattedData.length;

        if (!validateFinancialYear(formattedData, selectedOptionTemp)) {
          postMessage({
            error: `Selected year (${selectedOptionTemp}) does not match ${sheetName} year.`,
            sheetName,
          });
          continue;
        }

        const blob = new Blob(
          [JSON.stringify({ sheetName, recordCount, records: formattedData })],
          { type: 'application/json' }
        );

        allBlobs.push({ fileName: sheetName, blob, recordCount });
      }

      const endTime = performance.now();

      postMessage({
        message: 'File processed successfully',
        totalSheets: workbook.SheetNames.length,
        allBlobs,
        timeTaken: `${((endTime - startTime) / 1000).toFixed(2)}s`,
      });
    } catch (err: any) {
      console.error('❌ Excel processing error:', err);
      postMessage({
        error: err.message || 'Error processing Excel file',
        missingColumns: err.missingColumns || [],
      });
    }
  };

  reader.readAsArrayBuffer(file);
}

function processChunk(
  chunk: Uint8Array,
  chunkIndex: number,
  fileName: string,
  globalHeaders: string[] | null,
  selectedOptionReturn: any,
  selectedOptionTemp: string,
  fileExpectedHeaders: { fieldName: string; Mandatory?: string }[]
) {
  const chunkBlobs: {
    fileName: string;
    blob: Blob;
    recordCount: number;
    headers?: string[];
  }[] = [];

  try {
    const arrayBuffer = chunk.buffer.slice(0, chunk.byteLength);
    const workbook = XLSX.read(arrayBuffer, { type: "array" });

    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      let sheetData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

      sheetData = sheetData.filter(
        (row) => Array.isArray(row) && row.some((cell) => cell != null && cell !== "")
      );

      let headers: string[] | null = globalHeaders;

      if (!headers) {
        try {
          headers = findHeaderRow(sheetData, fileExpectedHeaders);
        } catch (err: any) {
          // Skip this sheet if it doesn't contain valid headers
          continue;
        }
      }

      // Convert data
      const formattedData = convertToKeyValueFormat(sheetData, headers);
      const recordCount = formattedData.length;

      if (!validateFinancialYear(formattedData, selectedOptionTemp)) {
        postMessage({
          error: `Selected year (${selectedOptionTemp}) does not match ${sheetName} year.`,
          sheetName,
        });
        continue;
      }

      const blob = new Blob(
        [JSON.stringify({ sheetName, recordCount, records: formattedData })],
        { type: "application/json" }
      );

      chunkBlobs.push({ fileName: sheetName, blob, recordCount, headers });
    }
  } catch (error) {
    postMessage({
      error: `Upload Correct File or Missing Column "${(error as any).missingColumns}"`,
      missingColumns: (error as any).missingColumns || [],
    });
    console.error(`❌ Error processing chunk ${chunkIndex + 1}:`, error);
  }

  return chunkBlobs;
}


function convertToKeyValueFormat(sheetData: any[], headers: string[]): any[] {
  if (sheetData.length < 2) return []; // Return empty if no data

  // Compare each row to the header and exclude any that match
  return sheetData
    .slice(1)
    .map((row) => {
      // Check if the row is the same as the header row
      const isHeaderRow = headers.every(
        (header, index) => row[index] === header
      );

      // Only process rows that aren't the same as the header
      if (isHeaderRow) {
        return null; // Skip this row
      }

      let obj: any = {};
      headers.forEach((header: string, index: number) => {
        const trimmedHeader = header.replace(/\s+/g, ' ').trim(); // Normalize spaces

        // 🔥 Convert to number if header matches specific keys
        const numericHeaders = [
          'TDS Receivable Amount',
          'Doc Value',
          'Item Taxable Value',
          'IGST',
          'CGST',
          'SGST',
          'Cess Rate',
          'Reference Doc Value'
        ];

        if (numericHeaders.includes(trimmedHeader)) {
          const value = row[index];
          const numValue = typeof value === 'string' ? parseFloat(value.replace(/,/g, '')) : value;
          obj[trimmedHeader] = isNaN(numValue) ? 0 : numValue;
        } else {
          obj[trimmedHeader] = row[index] || null; // Assign value or null if missing
        }
      });

      return obj;
    })
    .filter((record) => record !== null); // Remove any `null` values which represent header rows
}


function findHeaderRow(
  sheetData: any[][],
  fileExpectedHeaders: { fieldName: string; Mandatory?: string }[]
): string[] {
  function normalizeString(str: string): string {
    return (str || "").toString().trim().replace(/\s+/g, " ").toUpperCase();
  }

  // Normalize expected headers
  const normalizedExpected = fileExpectedHeaders.map((h) => ({
    fieldName: normalizeString(h.fieldName),
    mandatory: h.Mandatory === 'Y',
  }));

  // Try to find a row in sheetData that matches all mandatory headers
  for (const row of sheetData) {
    const normalizedRow = row.map((cell: any) => normalizeString(cell));

    const missingMandatory = normalizedExpected
      .filter((h) => h.mandatory && !normalizedRow.includes(h.fieldName))
      .map((h) => h.fieldName);

    if (missingMandatory.length === 0) {
      // ✅ Valid header row found
      return row.map((cell: any) => (cell || "").toString().trim());
    }
  }

  // ❌ No valid header row found
  const allHeadersInFile = sheetData.flat().map((c: any) => normalizeString(c));

  const missingHeaders = normalizedExpected
    .filter((h) => h.mandatory && !allHeadersInFile.includes(h.fieldName))
    .map((h) => h.fieldName);
  console.log("missingHeaders : ", missingHeaders);
  throw {
    message: "Excel file is missing mandatory headers.",
    missingColumns: missingHeaders,
  };
}


function normalizeTaxPeriod(value: any): string {
  if (typeof value === 'number') {
    return SSF.format('mmm-yyyy', value).toUpperCase();
  }
  if (typeof value === 'string') {
    return value.trim().toUpperCase();
  }
  return '';
}

function normalizeDocDate(value: any): { day: number; month: number; year: number } | null {
  if (!value) return null;
  if (typeof value === 'string') {
    if (value.trim().toLowerCase() === 'posting date') return null;

    const parts = value.split('-');
    if (parts.length !== 3) return null;

    const [dayStr, monthStr, yearStr] = parts;
    const day = +dayStr, month = +monthStr, year = +yearStr;
    if (isNaN(day) || isNaN(month) || isNaN(year)) return null;

    return { day, month, year };
  }
  if (typeof value === 'number') {
    const date = new Date(Math.round((value - 25569) * 86400 * 1000));
    return { day: date.getDate(), month: date.getMonth() + 1, year: date.getFullYear() };
  }
  return null;
}

function validateFinancialYear(data: any[], selectedOptionTemp: string): boolean {
  const [startYY, endYY] = selectedOptionTemp.split('-');
  const startYear = parseInt(`20${startYY}`);
  const endYear = parseInt(`20${endYY}`);

  const isValidPeriod = (month: number, year: number) =>
    month >= 4 ? year === startYear : year === endYear;

  return data.every((record) => {
    const rawTaxPeriod = record['Tax Period'];
    const rawDocDate = record['Doc Date'];

    if (!rawDocDate || `${rawDocDate}`.trim().toLowerCase() === 'posting date') return true;

    if (rawTaxPeriod) {
      const [monthStr, yearStr] = normalizeTaxPeriod(rawTaxPeriod).split('-');
      if (!monthStr || !yearStr || isNaN(+yearStr)) return false;
      const taxYear = +yearStr;
      const monthNum = new Date(`${monthStr} 1, ${taxYear}`).getMonth() + 1;
      return isValidPeriod(monthNum, taxYear);
    }

    const normalizedDate = normalizeDocDate(rawDocDate);
    return normalizedDate ? isValidPeriod(normalizedDate.month, normalizedDate.year) : false;
  });
}


