// let Mode = 'Developement2';
let Mode = 'TDSCPC';

let BASE_API_URL = '';
let EXP_BASE_URL = '';
let NEW_BASE_URL = '';

if (Mode === 'Developement2') {
  BASE_API_URL = 'http://localhost:8088/api';
  EXP_BASE_URL = 'http://localhost:8088/api';
  NEW_BASE_URL = 'http://localhost:8088/api';

} else if (Mode === 'TDSCPC') {
  BASE_API_URL = 'https://tdscpc.gstcpc.com/api';
  EXP_BASE_URL = 'https://tdscpc.gstcpc.com/api';
  NEW_BASE_URL = 'https://tdscpc.gstcpc.com/api';
}



export { BASE_API_URL, EXP_BASE_URL, NEW_BASE_URL };
