import { TestBed } from '@angular/core/testing';

import { OutSideClickDirective } from './outside-click.directive';

describe('OutclickService', () => {
  let service: OutSideClickDirective;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OutSideClickDirective);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
