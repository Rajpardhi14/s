import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
// export class ToastService {
//   // Separate subjects for success and error messages
//   private successMessageSubject = new BehaviorSubject<string | null>(null);
//   private errorMessageSubject = new BehaviorSubject<string | null>(null);

//   successMessage$ = this.successMessageSubject.asObservable();
//   errorMessage$ = this.errorMessageSubject.asObservable();

//   showSuccess(message: string) {
//     this.successMessageSubject.next(message);
//     setTimeout(() => this.successMessageSubject.next(null), 5000);
//   }

//   showError(message: string) {
//     this.errorMessageSubject.next(message);
//     setTimeout(() => this.errorMessageSubject.next(null), 5000);
//   }

//   clearMessages() {
//     this.successMessageSubject.next(null);
//     this.errorMessageSubject.next(null);
//   }
// }


export class ToastService {
  // Separate subjects for success and error messages
  private successMessageSubject = new BehaviorSubject<string | null>(null);
  private errorMessageSubject = new BehaviorSubject<string | null>(null);
    private processingMessageSource = new BehaviorSubject<string | null>(null);
  processingMessage$ = this.processingMessageSource.asObservable();
  
 
  successMessage$ = this.successMessageSubject.asObservable();
  errorMessage$ = this.errorMessageSubject.asObservable();
 
  showSuccess(message: string) {
    this.successMessageSubject.next(message);
    setTimeout(() => this.successMessageSubject.next(null), 5000);
  }
 
  showError(message: string) {
    this.errorMessageSubject.next(message);
    setTimeout(() => this.errorMessageSubject.next(null), 5000);
  }
 
  clearMessages() {
    this.successMessageSubject.next(null);
    this.errorMessageSubject.next(null);
  }
 
    showProcessing(message: string) {
    this.processingMessageSource.next(message);
  }
 
   clearProcessing() {
    this.processingMessageSource.next(null);
  }
}
