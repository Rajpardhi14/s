import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DateservicesService {

  private validFromDate = new BehaviorSubject<string | null>(null);
  private validToDate = new BehaviorSubject<string | null>(null);

  validFromDate$ = this.validFromDate.asObservable();
  validToDate$ = this.validToDate.asObservable();

  updateValidFromDate(date: string) {
    this.validFromDate.next(date);
    this.updateValidToDate(date);
  }

  updateValidToDate(date: string) {
    this.validToDate.next(date);
  }

  getValidFromDate(): string | null {
    return this.validFromDate.value;
  }

  getValidToDate(): string | null {
    return this.validToDate.value;
  }
}
