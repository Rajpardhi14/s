import { TestBed } from '@angular/core/testing';

import { DateservicesService } from './dateservices.service';

describe('DateservicesService', () => {
  let service: DateservicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DateservicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
