import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IpService {
  private ipAddressSubject = new BehaviorSubject<string | null>(null);
  ipAddress$ = this.ipAddressSubject.asObservable(); 

  constructor(private http: HttpClient) {
    this.fetchIpAddress();
    this.getLocalIp();
  }

  private fetchIpAddress(): void {
    this.http
      .get<{ ip: string }>('https://api64.ipify.org?format=json')
      .subscribe(
        (response) => {
          this.ipAddressSubject.next(response.ip);
        },
        (error) => {
          console.error('Error fetching IP address:', error);
        }
      );
  }

  getLocalIp() {
    if (
      typeof window !== 'undefined' &&
      typeof window.RTCPeerConnection !== 'undefined'
    ) {
      const pc = new RTCPeerConnection({ iceServers: [] });
      pc.createDataChannel('');
      pc.createOffer()
        .then((offer) => pc.setLocalDescription(offer))
        .catch((e) => console.error(e));

      pc.onicecandidate = (event: any) => {
        if (event.candidate) {
          const candidate = event.candidate.candidate;

          // Adjusting the regex to match both IP and hostnames
          const ipMatch = candidate.match(/(?:\d{1,3}\.){3}\d{1,3}/); // Matches IP
          if (ipMatch) {
          } else {
          }
        }
      };
    } else {
      console.error('RTCPeerConnection is not supported in this environment.');
    }
  }
}
