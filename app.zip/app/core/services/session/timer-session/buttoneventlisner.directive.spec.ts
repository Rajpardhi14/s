import { ButtoneventlisnerDirective } from './buttoneventlisner.directive';

describe('ButtoneventlisnerDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtoneventlisnerDirective();
    expect(directive).toBeTruthy();
  });
});
