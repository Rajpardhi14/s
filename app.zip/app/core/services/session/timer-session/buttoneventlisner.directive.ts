import { Directive, HostListener } from '@angular/core';
import { EventlisnerService } from './eventlisner.service';


@Directive({
  selector: '[appButtoneventlisner]',
  standalone: true,
})
export class ButtoneventlisnerDirective {
  constructor(private eventLisnerService: EventlisnerService) {}

  @HostListener('click')
  onClick() {
    this.eventLisnerService.extendSessionWithAPI();
  }
}