import { TestBed } from '@angular/core/testing';

import { FiledOptionService } from './filed-option.service';

describe('FiledOptionService', () => {
  let service: FiledOptionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FiledOptionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
