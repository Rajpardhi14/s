import { Inject, Injectable, PLATFORM_ID } from '@angular/core';

import { BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { ToastService } from '../../toaster/toast.service';

@Injectable({
  providedIn: 'root',
})
export class FiledOptionService {
  private fetchedOptionsCache: Record<string, any[]> = {};
  private notMatchedFields: Set<string> = new Set();
  heardMaster: any;
  tranMaster: any;
  applicableAsPer: any;
  vendor_name: any;
  private sessionExpiredSource = new BehaviorSubject<boolean>(false);
  sessionExpired$ = this.sessionExpiredSource.asObservable();
  private networkExpiredSource = new BehaviorSubject<boolean>(false);
  networkExpired$ = this.networkExpiredSource.asObservable();

  constructor(
    private toastService: ToastService,
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    
  }

 


  triggerSessionExpired() {
    this.sessionExpiredSource.next(true);
  }

  resetSessionExpired() {
    this.sessionExpiredSource.next(false);
  }

  triggerNetworkIssue() {
    this.networkExpiredSource.next(true);

  }

  resetNetworkIssue() {
    this.networkExpiredSource.next(false);
  }


}