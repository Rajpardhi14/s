import {
  Inject,
  Injectable,
  Injector,
  NgZone,
  PLATFORM_ID,
} from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { ApiserviceService } from '../../componentservice/apiservice.service';
@Injectable({
  providedIn: 'root',
})
export class SessiontimerService {
  private lastApiCallTimeKey = 'lastApiCallTime';
  private sessionTimeout = 600_000;
  private sessionCheckInterval: any;
  private readonly logoutUrl = '/';
  private timer = new BehaviorSubject<number>(0);
  timertigger$ = this.timer.asObservable();
  private lastApiCallTimeSubject = new BehaviorSubject<number>(Date.now());
  lastApiCallTime$ = this.lastApiCallTimeSubject.asObservable();

  private warnWindowMs = 60_000;
  constructor(
    private router: Router,
    private ngZone: NgZone,
    private injector: Injector,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    if (isPlatformBrowser(this.platformId)) {
      this.restoreSessionState();
    }
  }

  updateSessionTime(isApiCall: boolean = true) {
    if (!isPlatformBrowser(this.platformId)) return;

    if (isApiCall) {
      const currentTime = Date.now();
      sessionStorage.setItem(this.lastApiCallTimeKey, currentTime.toString());
      this.lastApiCallTimeSubject.next(currentTime);
    }

    this.resetSessionInterval();
    this.startSessionTimeout();
  }

  private restoreSessionState() {
    if (!isPlatformBrowser(this.platformId)) return;

    const lastApiCallTime = sessionStorage.getItem(this.lastApiCallTimeKey);
    if (!lastApiCallTime) return;

    const currentTime = Date.now();
    const timeSinceLastCall = currentTime - Number(lastApiCallTime);
    const timeLeft = this.sessionTimeout - timeSinceLastCall;
    if (timeLeft <= 0) {
      this.logout();
      return;
    }

    // Show countdown only inside warn window; otherwise ensure it's hidden
    const secs = Math.ceil(timeLeft / 1000);
    this.timer.next(timeLeft <= this.warnWindowMs ? secs : 0);

    // ✅ Always start ticking so we enter the warn window later without another API call
    this.startSessionTimeout();

    // if (timeLeft <= 60000 && timeLeft > 0) {
    //   this.timer.next(Math.floor(timeLeft / 1000));
    //   this.startSessionTimeout();
    // } else if (timeLeft <= 0) {
    //   this.logout();
    // } else {
    //   this.timer.next(0);
    // }
  }

  private startSessionTimeout() {
    if (!isPlatformBrowser(this.platformId)) return;

    this.stopTimer();
    this.ngZone.runOutsideAngular(() => {
      this.sessionCheckInterval = setInterval(() => {
        const lastApiCallTime = sessionStorage.getItem(this.lastApiCallTimeKey);
        if (!lastApiCallTime) return;

        const currentTime = Date.now();
        const timeSinceLastCall = currentTime - Number(lastApiCallTime);
        const timeLeft = this.sessionTimeout - timeSinceLastCall;

        if (timeLeft <= 60000 && timeLeft > 0) {
          this.timer.next(Math.floor(timeLeft / 1000));
        } else if (timeLeft <= 0) {
          this.resetSessionInterval();
          this.stopTimer();
          this.logout();
        }
      }, 1000);
    });
  }

  private resetSessionInterval() {
    if (this.sessionCheckInterval) {
      clearInterval(this.sessionCheckInterval);
    }
  }

  logout() {
    if (!isPlatformBrowser(this.platformId)) return;

    this.stopTimer();
    this.ngZone.run(() => {
      this.router.navigate([this.logoutUrl]);
    });

    const apiservice = this.injector.get(ApiserviceService);
    apiservice.logout().catch((err) => {
      console.error('Logout API failed:', err);
    });
    localStorage.clear();
    sessionStorage.clear();
  }

  private stopTimer() {
    this.ngZone.run(() => {
      this.timer.next(0);
    });
  }
  ngOnDestroy(): void {
    this.resetSessionInterval();
  }
}
