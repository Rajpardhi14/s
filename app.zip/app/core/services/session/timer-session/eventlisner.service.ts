// import { Injectable, Injector } from '@angular/core';
// import { SessiontimerService } from '../session/sessiontimer.service';
// import { ApiserviceService } from '../apiservice/apiservice.service';

// @Injectable({
//   providedIn: 'root',
// })
// export class EventlisnerService {
//   constructor(
//     private sessionTimer: SessiontimerService,
//     private injector: Injector
//   ) {}

//   extendSessionWithAPI() {
//     this.sessionTimer.updateSessionTime();
//     const apiservice = this.injector.get(ApiserviceService);
//     setTimeout(() => {
//       apiservice.sessionExtender().catch((err) => {
//         console.error('API failed:', err);
//       });
//     }, 2000); // Add 2-second delay as you required
//   }
// }
import { Injectable, Injector } from '@angular/core';


import { SessiontimerService } from './sessiontimer.service';
import { ApiserviceService } from '../../componentservice/apiservice.service';

@Injectable({
  providedIn: 'root',
})
export class EventlisnerService {
  private lastApiCallTime: number | null = null; // track last call time

  constructor(
    private sessionTimer: SessiontimerService,
    private injector: Injector
  ) {}

  extendSessionWithAPI() {
    const now = Date.now();
    if (this.lastApiCallTime && now - this.lastApiCallTime < 10000) {
      return;
    }
    this.lastApiCallTime = now; // update last call time
    const apiservice = this.injector.get(ApiserviceService);
    // setTimeout(() => {
    this.sessionTimer.updateSessionTime(true);
    apiservice.refreshSession().catch((err) => {
      console.error('API failed:', err);
    });
    // }, 2000);
  }
}