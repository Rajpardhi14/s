import { TestBed } from '@angular/core/testing';

import { EventlisnerService } from './eventlisner.service';

describe('EventlisnerService', () => {
  let service: EventlisnerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EventlisnerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
