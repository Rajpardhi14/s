import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { UserdataService } from '../../userdata/userdata.service';
import { BASE_API_URL } from '../../../constants/endpoint';


export interface SessionData {
  sessionId: string;
  userId?: string;
  device: string;
  browser: string;
  os: string;
  ip: string;
  location: string;
  city?: string;
  country?: string;
  lastActivity: string;
  loginTime: string;
  isCurrentSession: boolean;
  userAgent?: string;
  status?: string;
}

export interface SessionResponse {
  sessions: SessionData[];
  currentSessionId?: string;
  totalCount?: number;
}

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  constructor(
    private http: HttpClient,
    private userDataService: UserdataService
  ) { }

  private getHeaders(): HttpHeaders {
    const localUserData = this.userDataService.getLocalUserData() || {};
    const authToken = sessionStorage.getItem('sessionAuthToken') || this.getCookie('Authtoken') || '';
    const userCode = sessionStorage.getItem('Usercode') || '';
    
    // Include auth token in Authorization header as per C# API
    let headers: any = {
      'Content-Type': 'application/json',
      'Usercode': userCode,
      'Firstlevel': localUserData.first_level_client_code || '',
      'Rolestr': localUserData.user_role_code || '',
      'Branchcode': localUserData.bank_branch_code || '',
    };
    
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
      headers['X-Auth-Token'] = authToken;
    }
    
    return new HttpHeaders(headers);
  }

  private getCookie(name: string): string | null {
    const match = document.cookie.match(
      new RegExp('(^| )' + name + '=([^;]+)')
    );
    return match ? decodeURIComponent(match[2]) : null;
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    
    console.error('Session API Error:', errorMessage);
    return throwError(() => new Error(errorMessage));
  }

  private parseSessionData(rawData: any): SessionData {
    // Handle the actual API response format
    return {
      sessionId: rawData.session_id || rawData.sessionId || '',
      userId: rawData.user_code || rawData.entity_code || rawData.userId || '',
      device: rawData.device_type || this.detectDevice(rawData.user_agent || rawData.userAgent || ''),
      browser: rawData.browser || this.detectBrowser(rawData.user_agent || rawData.userAgent || ''),
      os: this.detectOS(rawData.user_agent || rawData.userAgent || ''),
      ip: rawData.ip_address || rawData.ipAddress || '',
      location: rawData.location || this.formatLocation(rawData),
      city: rawData.city || '',
      country: rawData.country || '',
      lastActivity: rawData.last_activity || rawData.lastActivity || new Date().toISOString(),
      loginTime: rawData.login_time || rawData.loginTime || new Date().toISOString(),
      isCurrentSession: rawData.is_current || rawData.isCurrentSession || false,
      userAgent: rawData.user_agent || rawData.userAgent || '',
      status: rawData.is_active ? 'active' : (rawData.status || 'inactive')
    };
  }

  private detectDevice(userAgent: string): string {
    if (/Mobile|Android|iPhone/i.test(userAgent)) {
      return 'Mobile';
    } else if (/iPad|Tablet/i.test(userAgent)) {
      return 'Tablet';
    } else {
      return 'Desktop';
    }
  }

  private detectBrowser(userAgent: string): string {
    if (/Chrome\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Chrome\/([\d.]+)/)?.[1];
      return `Chrome ${version || ''}`.trim();
    } else if (/Firefox\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Firefox\/([\d.]+)/)?.[1];
      return `Firefox ${version || ''}`.trim();
    } else if (/Safari\/(\d+)/.test(userAgent) && !/Chrome/.test(userAgent)) {
      const version = userAgent.match(/Version\/([\d.]+)/)?.[1];
      return `Safari ${version || ''}`.trim();
    } else if (/Edg\/(\d+)/.test(userAgent) || /Edge\/(\d+)/.test(userAgent)) {
      const version = userAgent.match(/Ed(?:g|ge)\/([\d.]+)/)?.[1];
      return `Edge ${version || ''}`.trim();
    } else {
      return 'Unknown Browser';
    }
  }

  private detectOS(userAgent: string): string {
    if (/Windows NT 10/.test(userAgent)) {
      return 'Windows 10';
    } else if (/Windows NT 11/.test(userAgent)) {
      return 'Windows 11';
    } else if (/Mac OS X/.test(userAgent)) {
      return 'macOS';
    } else if (/Android/.test(userAgent)) {
      const version = userAgent.match(/Android (\d+)/)?.[1];
      return `Android ${version || ''}`;
    } else if (/iPhone|iPad/.test(userAgent)) {
      return 'iOS';
    } else if (/Linux/.test(userAgent)) {
      return 'Linux';
    } else {
      return 'Unknown OS';
    }
  }

  private formatLocation(data: any): string {
    const parts = [];
    if (data.city) parts.push(data.city);
    if (data.state || data.region) parts.push(data.state || data.region);
    if (data.country) parts.push(data.country);
    
    return parts.length > 0 ? parts.join(', ') : 'Unknown Location';
  }

  getCurrentSessionId(): string {
    const userData = sessionStorage.getItem('localUserData');
    if (userData) {
      const user = JSON.parse(userData);
      return user.sessionId || sessionStorage.getItem('sessionId') || '';
    }
    return '';
  }

  getActiveSessions(userId: string): Observable<SessionData[]> {
    const url = `${BASE_API_URL}/api/Session/list/${userId}`;
    
    return this.http.get<any>(url, { headers: this.getHeaders() })
      .pipe(
        map(response => {
          const currentSessionId = this.getCurrentSessionId();
          
          // Handle C# API response format
          if (response?.success && response?.data) {
            return response.data.map((session: any) => {
              const parsedSession = this.parseSessionData(session);
              parsedSession.isCurrentSession = parsedSession.sessionId === currentSessionId;
              return parsedSession;
            });
          } else if (Array.isArray(response)) {
            // Fallback for direct array response
            return response.map(session => {
              const parsedSession = this.parseSessionData(session);
              parsedSession.isCurrentSession = parsedSession.sessionId === currentSessionId;
              return parsedSession;
            });
          } else {
            console.warn('Unexpected response format:', response);
            return [];
          }
        }),
        catchError(error => {
          console.error('Error fetching sessions:', error);
          return of([]);
        })
      );
  }

  revokeSession(sessionId: string, userCode?: string): Observable<any> {
    const url = `${BASE_API_URL}/api/Session/revoke/${sessionId}`;
    
    // Get user code if not provided
    if (!userCode) {
      const userData = this.userDataService.getLocalUserData();
      userCode = userData?.user_code || userData?.entity_code || '';
    }
    
    // C# API expects user_code in request body
    const requestBody = {
      user_code: userCode
    };
    
    return this.http.delete<any>(url, { 
      headers: this.getHeaders(),
      body: requestBody
    })
      .pipe(
        map(response => {
          if (response?.success) {
            return response;
          } else {
            throw new Error(response?.message || 'Failed to revoke session');
          }
        }),
        catchError(this.handleError)
      );
  }

  revokeAllSessions(userId: string, keepCurrent: boolean = true): Observable<any> {
    const url = `${BASE_API_URL}/api/Session/revoke-all`;
    
    const requestBody = {
      user_code: userId,
      keep_current: keepCurrent.toString()
    };
    
    return this.http.delete<any>(url, { 
      headers: this.getHeaders(),
      body: requestBody
    })
      .pipe(
        map(response => {
          if (response?.success) {
            return response;
          } else {
            throw new Error(response?.message || 'Failed to revoke sessions');
          }
        }),
        catchError(this.handleError)
      );
  }

  createSession(sessionData: any): Observable<any> {
    const url = `${BASE_API_URL}/api/Session/create`;
    
    // Format location string
    let locationString = 'Unknown';
    if (sessionData.location) {
      const parts = [];
      if (sessionData.location.city && sessionData.location.city !== 'Unknown') {
        parts.push(sessionData.location.city);
      }
      if (sessionData.location.region) {
        parts.push(sessionData.location.region);
      }
      if (sessionData.location.country && sessionData.location.country !== 'Unknown') {
        parts.push(sessionData.location.country);
      }
      if (parts.length > 0) {
        locationString = parts.join(', ');
      }
    }
    
    // Format the request based on the C# API specification
    const requestBody = {
      user_code: sessionData.userId || '',
      entity_code: sessionData.userId || '',
      email_id: sessionData.email || '',
      user_agent: sessionData.userAgent,
      ip_address: sessionData.ipAddress,
      device_type: sessionData.deviceInfo?.platform || 'Desktop',
      browser: sessionData.deviceInfo?.browser || 'Unknown',
      location: locationString
    };
    
    return this.http.post<any>(url, requestBody, { headers: this.getHeaders() })
      .pipe(
        map(response => {
          // Handle the C# API response format
          if (response?.success && response?.data) {
            return {
              sessionId: response.data.session_id,
              authToken: response.data.auth_token,
              expiresIn: response.data.expires_in,
              success: true,
              message: response.message
            };
          } else if (response?.session_id) {
            // Fallback for direct response
            return {
              sessionId: response.session_id,
              authToken: response.auth_token,
              success: true
            };
          } else {
            throw new Error(response?.message || 'Failed to create session');
          }
        }),
        catchError(this.handleError)
      );
  }

  validateSession(): Observable<any> {
    const url = `${BASE_API_URL}/api/Session/validate`;
    
    // C# API validates based on auth token in headers
    return this.http.get<any>(url, { headers: this.getHeaders() })
      .pipe(
        map(response => {
          if (response?.success) {
            return {
              isValid: true,
              userCode: response.data?.user_code,
              entityCode: response.data?.entity_code,
              sessionId: response.data?.session_id
            };
          } else {
            return { isValid: false };
          }
        }),
        catchError(() => of({ isValid: false }))
      );
  }

  refreshSession(): Observable<any> {
    const url = `${BASE_API_URL}/api/Session/refresh`;
    
    return this.http.post<any>(url, {}, { headers: this.getHeaders() })
      .pipe(
        map(response => {
          if (response?.success && response?.data) {
            // Store new auth token
            const newAuthToken = response.data.auth_token;
            if (newAuthToken) {
              sessionStorage.setItem('sessionAuthToken', newAuthToken);
            }
            return {
              success: true,
              authToken: newAuthToken,
              expiresIn: response.data.expires_in,
              message: response.message
            };
          } else {
            throw new Error(response?.message || 'Failed to refresh session');
          }
        }),
        catchError(this.handleError)
      );
  }
}