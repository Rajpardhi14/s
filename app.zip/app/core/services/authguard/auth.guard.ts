import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';


export const AuthGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const loginService = inject(AuthService);

  if (typeof window !== 'undefined' && typeof sessionStorage !== 'undefined') {
    const localData = sessionStorage.getItem('localUserData');
    if (localData !== null) {
      return true;
    } else {
      router.navigateByUrl('/');
      return false;
    }
  } else {
    return false;
  }


};
