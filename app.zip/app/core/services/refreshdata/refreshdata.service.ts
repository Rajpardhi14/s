import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

// Define valid refresh keys as a type:
export type RefreshKey =
  | 'alluser'
  | 'Allclients'
  | 'Challans'
  | 'LDC'
  | 'Branch'
  | 'Regular'
  | 'Clients'
  | 'Justification'
  | 'DefaultTraces'
    | 'AllocTran' 
  | 'Allclient'
  | 'AdvancePayment'
  | 'Retention'
  | 'MiscPettyExp'
  | 'FixedAsset'
  | 'AllUsers'
  | 'UserRole'
  | 'BranchRole'
  | 'ClientLevel'
  | 'HsnMast'
  | 'ReverseChargMast'
  | 'BGL'
  | 'useractivity'
  | 'Deductee'
  | 'RentApproval'
  | 'LdcApproval'
  | 'UtilityApproval'
  | 'RegularApproval'
  | 'FixedTranApproval'
  | 'MiscPettyApproval'
  | 'AdvanceApproval'
  | 'GeneralApproval'
  | 'RetentionApproval'
  | 'Transaction'
  | 'gh15';

@Injectable({
  providedIn: 'root',
})
export class RefreshdataService {
  private refreshMap = new Map<RefreshKey, Subject<void>>();

  constructor() {}
  // refreshDataBGL: EventEmitter<void> = new EventEmitter();
  refreshDataGST: EventEmitter<void> = new EventEmitter();
  // refreshDataAlluser: EventEmitter<void> = new EventEmitter();
  // refreshDataBranch: EventEmitter<void> = new EventEmitter();
  // refreshDataLdcmast: EventEmitter<void> = new EventEmitter();
  // refreshDataRcmast: EventEmitter<void> = new EventEmitter();
  // refreshDataRole: EventEmitter<void> = new EventEmitter();
  // refreshDataHSN: EventEmitter<void> = new EventEmitter();
  // refreshDataCleintLevelMast: EventEmitter<void> = new EventEmitter();
  // refreshDataClientRoleMast: EventEmitter<void> = new EventEmitter();
  // refreshVendorMast: EventEmitter<void> = new EventEmitter();
  // refreshDataRentMast: EventEmitter<void> = new EventEmitter();
  // Use Subject instead of EventEmitter:
  // private refreshDataRentMastSubject = new Subject<void>();
  // refreshDataRentMast$ = this.refreshDataRentMastSubject.asObservable();
  // triggerRentMastRefresh() {
  //   this.refreshDataRentMastSubject.next();
  // }

  // private refreshVendorMastSubject = new Subject<void>();
  // refreshVendorMast$ = this.refreshVendorMastSubject.asObservable();
  // triggerRefreshVendorMast() {
  //   this.refreshVendorMastSubject.next();
  // }

  trigerRefresh(key: RefreshKey): void {
    if (!this.refreshMap.has(key)) {
      this.refreshMap.set(key, new Subject<void>());
    }
    this.refreshMap.get(key)!.next();
  }

  onRefresh(key: RefreshKey): Observable<void> {
    if (!this.refreshMap.has(key)) {
      this.refreshMap.set(key, new Subject<void>());
    }
    return this.refreshMap.get(key)!.asObservable();
  }


  private refreshSubject = new BehaviorSubject<boolean>(false);
  public refreshData$ = this.refreshSubject.asObservable();
  triggerRefresh() {
    this.refreshSubject.next(true);
  }

  private fySubject = new BehaviorSubject<string>('');
  fy$ = this.fySubject.asObservable();

  setFY(fy: string) {
    this.fySubject.next(fy);
  }
}
