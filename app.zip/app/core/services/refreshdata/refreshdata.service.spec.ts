import { TestBed } from '@angular/core/testing';

import { RefreshdataService } from './refreshdata.service';

describe('RefreshdataService', () => {
  let service: RefreshdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RefreshdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
