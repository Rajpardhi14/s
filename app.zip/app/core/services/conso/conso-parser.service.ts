import { Injectable } from '@angular/core';

export interface CONSOFileHeader {
  version: string;
  date: string;
  records: number;
}

export interface CONSOBatchHeader {
  tan: string;
  formType: string;
  financialYear: string;
  assessmentYear: string;
  quarter: string;
  organizationName: string;
  responsiblePerson: string;
  responsiblePersonDesignation: string;
  responsiblePersonAddress: string;
  responsiblePersonEmail: string;
  totalAmount: number;
  rrnNumber?: string;
  // Enhanced fields for complete client form mapping
  organizationPAN?: string;
  organizationAddress1?: string;
  organizationAddress2?: string;
  organizationAddress3?: string;
  organizationAddress4?: string;
  organizationCity?: string;
  organizationState?: string;
  organizationPin?: string;
  organizationPhone?: string;
  organizationStdCode?: string;
  responsiblePersonPAN?: string;
  responsiblePersonMobile?: string;
  responsiblePersonPhone?: string;
  responsiblePersonStdCode?: string;
  branchDivision?: string;
}

export interface CONSOChallanDetails {
  challanSerial: number;
  bsrCode?: string;
  challanNumber?: string;
  paymentDate: string;
  totalTax: number;
  interest: number;
  penalty: number;
  lateFee: number;
  totalAmount: number;
}

export interface CONSODeducteeRecord {
  serialNo: number;
  pan: string;
  name: string;
  deducteeCode?: string;
  tdsAmount: number;
  surcharge: number;
  educationCess: number;
  totalTaxDeducted: number;
  totalAmount: number;
  dateOfDeduction: string;
  dateOfPayment: string;
  dateOfDeposit: string;
  tdsRate: number;
  reason?: string;
  certificateNumber?: string;
}

export interface ParsedCONSOFile {
  fileHeader: CONSOFileHeader;
  batchHeader: CONSOBatchHeader;
  batchHeaderFields?: string[];  // Raw BH fields array for direct position access
  challanDetails: CONSOChallanDetails[];
  deducteeRecords: CONSODeducteeRecord[];
  summary: {
    totalDeductees: number;
    totalTDS: number;
    totalAmount: number;
    fileName: string;
    parsedDate: Date;
  };
}

@Injectable({
  providedIn: 'root'
})
export class ConsoParserService {

  constructor() { }

  /**
   * Parse CONSO TDS file - RAW version that preserves original data
   * @param fileContent - Raw content of the TDS file
   * @param fileName - Original file name
   * @param preserveRaw - If true, preserves raw values without parsing
   * @returns Parsed CONSO data
   */
  parseCONSOFileRaw(fileContent: string, fileName: string): any {
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');
    const result = {
      FH: [] as any[],  // FH records
      BH: [] as any[],  // BH records
      CD: [] as any[],  // CD records
      DD: [] as any[]   // DD records
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const parts = line.split('^');

      if (parts[0] === '1' && parts[1] === 'FH') {
        // Store FH as array of arrays (even though there's typically only one)
        result.FH.push(parts); // Push as array into array
      } else if (parts[0] === '2' && parts[1] === 'BH') {
        // Store BH as array of arrays (even though there's typically only one)
        result.BH.push(parts); // Push as array into array
      } else if (parts[0] === '3' && parts[1] === 'CD') {
        // Store each CD as array
        result.CD.push(parts);
      } else if (parts[1] === 'DD') {
        // Store each DD as array
        result.DD.push(parts);
      }
    }

    return result;
  }

  /**
   * Parse CONSO TDS file
   * @param fileContent - Raw content of the TDS file
   * @param fileName - Original file name
   * @returns Parsed CONSO data
   */
  parseCONSOFile(fileContent: string, fileName: string): ParsedCONSOFile {
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');

    if (lines.length < 3) {
      throw new Error('Invalid CONSO file: Insufficient data');
    }

    const fileHeader = this.parseFileHeader(lines[0]);
    const batchHeader = this.parseBatchHeader(lines[1]);
    const batchHeaderFields = lines[1].split('^');  // Store raw BH fields array for position-based access
    const challanDetails: CONSOChallanDetails[] = [];
    const deducteeRecords: CONSODeducteeRecord[] = [];

    // Parse remaining lines
    for (let i = 2; i < lines.length; i++) {
      const line = lines[i];
      const parts = line.split('^');

      if (parts[0] === '3' && parts[1] === 'CD') {
        // Challan Details line
        challanDetails.push(this.parseChallanDetails(line));
      } else if (parts[0] && parts[1] === 'DD') {
        // Deductee Details line
        deducteeRecords.push(this.parseDeducteeRecord(line));
      }
    }

    // Calculate summary
    const summary = {
      totalDeductees: deducteeRecords.length,
      totalTDS: deducteeRecords.reduce((sum, rec) => sum + rec.tdsAmount, 0),
      totalAmount: deducteeRecords.reduce((sum, rec) => sum + rec.totalAmount, 0),
      fileName: fileName,
      parsedDate: new Date()
    };

    return {
      fileHeader,
      batchHeader,
      batchHeaderFields,  // Include raw fields array for direct position access
      challanDetails,
      deducteeRecords,
      summary
    };
  }

  /**
   * Parse file header (FH line)
   */
  private parseFileHeader(line: string): CONSOFileHeader {
    const parts = line.split('^');
    return {
      version: parts[2] || '',
      date: this.formatDate(parts[9] || ''),
      records: parseInt(parts[8] || '0', 10)
    };
  }

  /**
   * Parse batch header (BH line)
   */
  private parseBatchHeader(line: string): CONSOBatchHeader {
    const parts = line.split('^');
    return {
      tan: parts[12] || '',  // Position 12: tanno
      formType: parts[4] || '',
      financialYear: parts[15] || '',  // Position 15: Financial Year
      assessmentYear: parts[16] || '',  // Position 16: Assessment Year
      quarter: parts[17] || '',  // Position 17: Quarter
      organizationName: parts[18] || '',  // Position 18: client_name
      responsiblePerson: parts[32] || '',  // Position 32: deductor_name
      responsiblePersonDesignation: parts[33] || '',  // Position 33: deductor_desig
      responsiblePersonAddress: `${parts[34] || ''} ${parts[35] || ''} ${parts[36] || ''} ${parts[37] || ''} ${parts[38] || ''}`.trim(),
      responsiblePersonEmail: parts[41] || '',  // Position 41: deductor_email_id
      totalAmount: this.parseAmount(parts[45] || '0'),
      rrnNumber: parts[7] || parts[8] || '',

      // Enhanced field extraction for complete mapping
      organizationPAN: parts[13] || '', // Position 13: Organization PAN
      organizationAddress1: parts[20] || '', // Position 20: add1
      organizationAddress2: parts[21] || '', // Position 21: add2
      organizationAddress3: parts[22] || '', // Position 22: add3
      organizationAddress4: parts[23] || '', // Position 23: add4
      organizationCity: parts[24] || '', // Position 24: city
      organizationState: parts[25] || '', // Position 25: state_code
      organizationPin: parts[26] || '', // Position 26: pin
      organizationPhone: parts[29] || '', // Position 29: phoneno
      organizationStdCode: parts[28] || '', // Position 28: stdcode
      responsiblePersonPAN: parts[58] || '', // Position 58: deductor_panno
      responsiblePersonMobile: parts[47] || '', // Position 47: deductor_mobileno
      responsiblePersonPhone: parts[44] || '', // Position 44: deductor_phoneno
      responsiblePersonStdCode: parts[43] || '', // Position 43: deductor_stdcode
      branchDivision: parts[19] || '' // Position 19: branch_division
    };
  }

  /**
   * Parse challan details (CD line)
   */
  private parseChallanDetails(line: string): CONSOChallanDetails {
    const parts = line.split('^');
    return {
      challanSerial: parseInt(parts[3] || '0', 10),
      bsrCode: parts[12] || '',
      challanNumber: parts[13] || '',
      paymentDate: this.formatDate(parts[17] || ''),
      totalTax: this.parseAmount(parts[21] || '0'),
      interest: this.parseAmount(parts[22] || '0'),
      penalty: this.parseAmount(parts[23] || '0'),
      lateFee: this.parseAmount(parts[24] || '0'),
      totalAmount: this.parseAmount(parts[26] || '0')
    };
  }

  /**
   * Parse deductee record (DD line)
   */
  private parseDeducteeRecord(line: string): CONSODeducteeRecord {
    const parts = line.split('^');
    const recordNo = parseInt(parts[0] || '0', 10);

    return {
      serialNo: parseInt(parts[4] || '0', 10),
      pan: parts[9] || 'PANNOTAVBL',
      name: this.extractName(parts[12] || ''),
      deducteeCode: parts[7] || '',
      tdsAmount: this.parseAmount(parts[13] || '0'),
      surcharge: this.parseAmount(parts[14] || '0'),
      educationCess: this.parseAmount(parts[15] || '0'),
      totalTaxDeducted: this.parseAmount(parts[16] || '0'),
      totalAmount: this.parseAmount(parts[21] || '0'),
      dateOfDeduction: this.formatDate(parts[22] || ''),
      dateOfPayment: this.formatDate(parts[23] || ''),
      dateOfDeposit: this.formatDate(parts[24] || ''),
      tdsRate: parseFloat(parts[25] || '0'),
      reason: parts[28] || '',
      certificateNumber: parts[11] || ''
    };
  }

  /**
   * Extract name from the name field (format: "NAME - ACCOUNT")
   */
  private extractName(nameField: string): string {
    const parts = nameField.split(' - ');
    return parts[0] || nameField;
  }

  /**
   * Parse amount string to number
   */
  private parseAmount(amountStr: string): number {
    if (!amountStr || amountStr.trim() === '') {
      return 0;
    }
    // Remove leading zeros and convert to number
    const cleanAmount = amountStr.replace(/^0+/, '') || '0';
    const amount = parseFloat(cleanAmount);
    // CONSO amounts are typically stored as whole numbers representing rupees
    // No division needed - the amounts are already in rupees
    return isNaN(amount) ? 0 : amount;
  }

  /**
   * Format date from DDMMYYYY to readable format
   */
  private formatDate(dateStr: string): string {
    if (!dateStr || dateStr.length !== 8) {
      return '';
    }

    try {
      const day = dateStr.substring(0, 2);
      const month = dateStr.substring(2, 4);
      const year = dateStr.substring(4, 8);

      // Basic validation
      const dayNum = parseInt(day, 10);
      const monthNum = parseInt(month, 10);
      const yearNum = parseInt(year, 10);

      if (dayNum < 1 || dayNum > 31 || monthNum < 1 || monthNum > 12 || yearNum < 1900) {
        return '';
      }

      return `${year}-${month}-${day}`;
    } catch (error) {
      console.warn('Invalid date format:', dateStr);
      return '';
    }
  }

  /**
   * Validate CONSO file name format
   * Expected: {TAN}_{FinYear}_{FormType}_Q{Quarter}.tds
   */
  validateFileName(fileName: string): {
    isValid: boolean;
    tan?: string;
    financialYear?: string;
    formType?: string;
    quarter?: string;
    error?: string;
  } {
    const regex = /^([A-Z]{4}\d{5}[A-Z])_(\d{6})_(27Q|26Q|24Q|27EQ)_Q(\d)\.tds$/i;
    const match = fileName.match(regex);

    if (!match) {
      return {
        isValid: false,
        error: 'Invalid file name format. Expected: TAN_YYYYMM_FormType_QQuarter.tds'
      };
    }

    return {
      isValid: true,
      tan: match[1],
      financialYear: match[2],
      formType: match[3],
      quarter: match[4]
    };
  }

  /**
   * Map CONSO data to client
   */
  mapToClient(parsedData: ParsedCONSOFile, clientMapping: any): any {
    // This will be used to map the CONSO data to specific client
    // Implementation depends on the client mapping structure
    return {
      tan: parsedData.batchHeader.tan,
      formType: parsedData.batchHeader.formType,
      financialYear: parsedData.batchHeader.financialYear,
      quarter: parsedData.batchHeader.quarter,
      organizationName: parsedData.batchHeader.organizationName,
      totalDeductees: parsedData.summary.totalDeductees,
      totalTDS: parsedData.summary.totalTDS,
      deducteeList: parsedData.deducteeRecords
    };
  }
}