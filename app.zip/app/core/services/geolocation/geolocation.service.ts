import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface LocationData {
  city?: string;
  region?: string;
  country?: string;
  countryCode?: string;
  latitude?: number;
  longitude?: number;
  timezone?: string;
  isp?: string;
}

@Injectable({
  providedIn: 'root'
})
export class GeolocationService {

  constructor(private http: HttpClient) { }

  /**
   * Get location data from IP address using multiple fallback services
   */
  getLocationFromIP(ipAddress?: string): Observable<LocationData> {
    // Try primary service first
    return this.getLocationFromIPAPI(ipAddress).pipe(
      catchError(() => {
        // Fallback to secondary service
        return this.getLocationFromIPInfo(ipAddress);
      }),
      catchError(() => {
        // Final fallback - return unknown location
        return of({
          city: 'Unknown',
          region: '',
          country: 'Unknown'
        });
      })
    );
  }

  /**
   * Primary: ip-api.com (free, no API key required, 45 requests per minute)
   */
  private getLocationFromIPAPI(ipAddress?: string): Observable<LocationData> {
    // ip-api doesn't support HTTPS on free tier, so we use HTTP
    // In production, consider using a paid service with HTTPS
    const url = ipAddress 
      ? `http://ip-api.com/json/${ipAddress}` 
      : `http://ip-api.com/json/`;
    
    return this.http.get<any>(url).pipe(
      map(response => ({
        city: response.city || 'Unknown',
        region: response.regionName || response.region || '',
        country: response.country || 'Unknown',
        countryCode: response.countryCode,
        latitude: response.lat,
        longitude: response.lon,
        timezone: response.timezone,
        isp: response.isp
      }))
    );
  }

  /**
   * Secondary: ipinfo.io (free tier: 50k requests per month)
   */
  private getLocationFromIPInfo(ipAddress?: string): Observable<LocationData> {
    const url = ipAddress 
      ? `https://ipinfo.io/${ipAddress}/json` 
      : `https://ipinfo.io/json`;
    
    return this.http.get<any>(url).pipe(
      map(response => {
        const location = response.loc ? response.loc.split(',') : [null, null];
        return {
          city: response.city || 'Unknown',
          region: response.region || '',
          country: response.country || 'Unknown',
          countryCode: response.country,
          latitude: location[0] ? parseFloat(location[0]) : undefined,
          longitude: location[1] ? parseFloat(location[1]) : undefined,
          timezone: response.timezone,
          isp: response.org
        };
      })
    );
  }

  /**
   * Alternative: ipgeolocation.io (requires API key)
   * Sign up at https://ipgeolocation.io/ for free API key (1000 requests/month)
   */
  private getLocationFromIPGeolocation(ipAddress?: string): Observable<LocationData> {
    const apiKey = 'YOUR_API_KEY_HERE'; // Replace with your API key
    const url = `https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}${ipAddress ? '&ip=' + ipAddress : ''}`;
    
    return this.http.get<any>(url).pipe(
      map(response => ({
        city: response.city || 'Unknown',
        region: response.state_prov || '',
        country: response.country_name || 'Unknown',
        countryCode: response.country_code2,
        latitude: response.latitude ? parseFloat(response.latitude) : undefined,
        longitude: response.longitude ? parseFloat(response.longitude) : undefined,
        timezone: response.time_zone?.name,
        isp: response.isp
      }))
    );
  }

  /**
   * Format location string for display
   */
  formatLocation(location: LocationData): string {
    const parts = [];
    if (location.city && location.city !== 'Unknown') {
      parts.push(location.city);
    }
    if (location.region) {
      parts.push(location.region);
    }
    if (location.country && location.country !== 'Unknown') {
      parts.push(location.country);
    }
    
    return parts.length > 0 ? parts.join(', ') : 'Unknown Location';
  }
}