import { Injectable } from '@angular/core';

import { BASE_API_URL } from '../../constants/endpoint';

import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { catchError, firstValueFrom, lastValueFrom, Observable, throwError } from 'rxjs';
import { UserdataService } from '../userdata/userdata.service';
import { ToastService } from '../toaster/toast.service';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {






  constructor(private http: HttpClient, private userlocaldataService: UserdataService, private toastService: ToastService) { }

  generateSData(
    procType: string,
    localUserData: any,
    filterClause: any,
    limit: number,
    offset: number,
    currentPage: any,
    options?: {
      clientCode?: string;
      passCode?: string,
      dashboardType?: string;
      processStatusCode?: string;
      subModuleTypeCode?: string;
      expensesFlag?: any;
      FYYear?: string;
      client_level?: string;
      client_code_flag?:string;
      client_code_level?: any,
      client_code?:any,
      iudtype?: string;
      seqnumber?: any,
      refnumber?: any;
      a_process_group?: string;
      teplateProcessType?: string;
      a_validation_error_code?: string;
      a_validation_error_review_remark?: string;
      alloc_group_str?: string;
      templateCode?: string,
      a_process_level?: number,
      import_template?: any;
    }
  ) {
    const dynamicUserData = this.userlocaldataService.getAllDynamicUserData();

    // const useDynamic = options?.FYYear === "Yes";
    const useDynamic = options?.FYYear === "Yes" || options?.client_level === "Yesss" || options?.client_code_flag==='challanClientCode';


    return {
      a_session_seqno: "",
      a_iud_seqno: "",
      a_proc_type: procType,
      a_is_pen_flag: "",
      a_login_type: "login_id",
      a_entity_code: localUserData.entity_code,



      // 🔹 Pick from dynamic if FYYear = Yes, else from local
      a_acc_year: useDynamic
        ? dynamicUserData?.default_acc_year
        : localUserData?.default_acc_year,

      a_quarter_no: useDynamic
        ? dynamicUserData?.default_quarter_no
        : localUserData?.default_quarter_no,
      a_tran_month: useDynamic
        ? dynamicUserData?.default_tran_month
        : localUserData?.default_tran_month,
      a_tran_from_date: useDynamic
        ? dynamicUserData?.default_from_date
        : localUserData?.default_from_date,
      a_tran_to_date: useDynamic
        ? dynamicUserData?.default_to_date
        : localUserData?.default_to_date,
      a_tds_type_code: useDynamic
        ? dynamicUserData?.default_tds_type_code
        : localUserData?.default_tds_type_code,


      // chnage for error processing 11/8/025 

      // a_validation_client_level: useDynamic
      //   ? dynamicUserData?.client_code_level
      //   : localUserData?.client_code_level,

      // a_client_code_level: useDynamic
      //   ? dynamicUserData?.client_code_level
      //   : localUserData?.client_code_level,


      a_validation_client_level: options?.client_code_level ??
        (useDynamic ? dynamicUserData?.client_code_level : localUserData?.client_code_level),
      a_client_code_level: options?.client_code_level ??
        (useDynamic ? dynamicUserData?.client_code_level : localUserData?.client_code_level),

      a_client_code: options?.client_code ?? (useDynamic
        ? dynamicUserData?.client_code
        : localUserData?.client_code),

      a_first_level_client_code: useDynamic
        ? dynamicUserData?.first_level_client_code
        : localUserData?.first_level_client_code,
      a_user_level: localUserData.user_level,
      // a_validation_client_level: localUserData.client_code_level,
      // a_client_code_level: localUserData.client_code_level,
      // a_first_level_client_code: localUserData.first_level_client_code,
      a_user_code: localUserData.user_code,
      a_parent_code: localUserData.first_level_client_code,


      a_filter_clause: filterClause,
      a_db_total_records: limit,
      a_pagination_count: offset,
      a_page_from: currentPage,
      a_page_to: "1",
      a_module_type_code: localUserData?.default_module_type_code || "TAXCPC",
      // a_sub_module_type_code: useDynamic
      //   ? dynamicUserData?.
      //     default_sub_module_type_code
      //   : localUserData?.
      //     default_sub_module_type_code

      a_sub_module_type_code: useDynamic
        ? dynamicUserData?.default_sub_module_type_code ?? 'R'
        : localUserData?.default_sub_module_type_code ?? 'R',

      a_dashboard_type: options?.dashboardType ?? "DB",
      a_process_status_code: options?.processStatusCode ?? "",
      a_iud_type: options?.iudtype ?? "",
      a_process_seqno: options?.seqnumber,
      a_ref_process_seqno: options?.refnumber,
      a_process_group: options?.a_process_group,
      a_template_process_type: options?.teplateProcessType,
      a_validation_error_code: options?.a_validation_error_code,
      a_alloc_group_str: options?.alloc_group_str,
      // a_template_code: options?.templateCode,
      a_template_code:
        options?.passCode && options?.passCode.trim() !== ""
          ? options.passCode
          : (options?.templateCode && options?.templateCode.trim() !== ""
            ? options.templateCode
            : ""),

      a_process_level: options?.a_process_level,
      a_validation_error_review_remark: options?.a_validation_error_review_remark,
      ...(options?.import_template
        ? { import_template: options.import_template }
        : {})
    };

  }


  private getHeaders(): HttpHeaders {
    // this.sessionTimerService.updateSessionTime();
    const localUserData = this.userlocaldataService.getLocalUserData() || {};
    const authToken = this.getCookie('Authtoken') || '';
    const userCode = sessionStorage.getItem('Usercode') || '';
    return new HttpHeaders({
      Authtoken: authToken,
      Usercode: userCode,
      Firstlevel: localUserData.first_level_client_code || '',
      Rolestr: localUserData.user_role_code || '',
      Branchcode: localUserData.bank_branch_code || '',
      'Content-Type': 'application/json',
    });
  }
  private getCookie(name: string): string | null {
    const match = document.cookie.match(
      new RegExp('(^| )' + name + '=([^;]+)')
    );
    return match ? decodeURIComponent(match[2]) : null;
  }


  private handleError(error: any): Observable<never> {
    console.error('API Error:', error);
    return throwError(() => error);
  }


  createData(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http.post<any>(
      url,
      { sdata: JSON.stringify(sdata) },
      { headers: this.getHeaders() }
    );
  }

  getTableData(endpoint: string, requestData: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(requestData) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }

  getTableDatatwo(endpoint: string, requestData: any, responseType: 'json' | 'text' = 'json'): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post(
        url,
        { sdata: JSON.stringify(requestData) },
        { headers: this.getHeaders(), responseType: responseType as 'json' }
      )
      .pipe(catchError(this.handleError));
  }


  getFilterData(endpoint: string, requestData: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,

        { sdata: JSON.stringify(requestData) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }

  getsingleDetails(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }


  getGrandTotal(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }

  updateProfile(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }

  fetchparentmastLbData(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }

  pinCodeApi(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }



  miudApi(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        { headers: this.getHeaders() }
      )
      .pipe(catchError(this.handleError));
  }


  setRedisApi(endpoint: string, body: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(url, body, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  getStatus(endpoint: string): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .get<any>(url, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }


  baseurl = "https://tdscpc.gstcpc.com/api/file-upload"
  async fileUpload(clientcode: string, usercode: string, files: File[]): Promise<any> {
    const uploadUrl = `${this.baseurl}/File_upload?clientcode=${clientcode}&usercode=${usercode}`;
    const formData = new FormData();
    files.forEach(file => formData.append('file', file));
    return lastValueFrom(this.http.post(uploadUrl, formData));
  }



  async fileDownload(filename: string): Promise<void> {
    const url = `${this.baseurl}/File_download?filename=${encodeURIComponent(filename)}`;
    const blob = await lastValueFrom(
      this.http.get(url, { responseType: 'blob' })
    );

    const a = document.createElement('a');
    const objectUrl = window.URL.createObjectURL(blob);
    a.href = objectUrl;
    a.download = filename.split('/').pop() || 'download';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(objectUrl);
    a.remove();
  }




  //REPORT FILE DOWNLOAD
  private baseURL = 'https://tdscpc.gstcpc.com/api/Comman';
  async reportFileDownload(filename: string, source: string, headerJson: any): Promise<void> {
    const url = `${this.baseURL}/File_download`;

    // Stringify headersJson correctly for the URL
    const headersJsonStr = JSON.stringify(headerJson);

    const params = new HttpParams()
      .set('filename', filename)
      .set('source', source)
      .set('headersJson', headersJsonStr); // ✅ send JSON as one parameter

    // ✅ Get the ZIP file from backend
    const blob = await lastValueFrom(
      this.http.get(url, { params, responseType: 'blob' })
    );

    // ✅ Download as ZIP
    const downloadLink = document.createElement('a');
    const objectUrl = window.URL.createObjectURL(blob);
    downloadLink.href = objectUrl;

    const baseName = filename.split('/').pop()?.split('.')[0] || 'download';
    downloadLink.download = `${baseName}.zip`;
    this.showSuccess('File downloaded sucessfully....!');

    document.body.appendChild(downloadLink);
    downloadLink.click();
    window.URL.revokeObjectURL(objectUrl);
    downloadLink.remove();
  }


  private showSuccess(message: string) {
    this.toastService.showSuccess(message);
  }



  // async uploadZipAndJson(
  //     zipBlob: Blob,
  //     jsonBlob: Blob,
  //     clientCode: string | number,
  //     userCode: string | number,
  //     apiUrl: string = 'https://tdscpc.gstcpc.com/api/dynamic-import/file_import_new'
  //   ): Promise<any> {
  //     try {
  //       const formData = new FormData();
  //       formData.append('file', new File([zipBlob], 'myFiles.zip', { type: 'application/zip' }));
  //       formData.append('validationfile', new File([jsonBlob], 'finalData.json', { type: 'application/json' }));

  //       const response = await fetch(`${apiUrl}?clientcode=${clientCode}&usercode=${userCode}`, {
  //         method: 'POST',
  //         body: formData
  //       });

  //       if (!response.ok) {
  //         const text = await response.text();
  //         throw new Error(`HTTP ${response.status}: ${text}`);
  //       }

  //       return await response.json();
  //     } catch (error) {
  //       console.error('Upload failed:', error);
  //       throw error;
  //     }
  //   }



  async uploadZipAndJson(
    zipBlob: Blob,
    jsonBlob: Blob,
    clientCode: string | number,
    userCode: string | number,
    originalFileName: string,
    apiUrl: string = 'https://tdscpc.gstcpc.com/api/dynamic-import/file_import_new'
  ): Promise<any> {
    try {
     

      const zipFileName = originalFileName.includes(".")
        ? originalFileName.replace(/\.[^/.]+$/, ".zip")
        : originalFileName + ".zip";

      const zipFile = new File([zipBlob], zipFileName, { type: "application/zip" });
      const jsonFile = new File([jsonBlob], "finalData.json", { type: "application/json" });

      // // ✅ Debug File details
      // console.log("Zip File:", zipFile);
      // console.log("JSON File:", jsonFile);

      const formData = new FormData();
      formData.append("file", zipFile);
      formData.append("validationfile", jsonFile);

      // ✅ Debug FormData content
      formData.forEach((val, key) => {
        if (val instanceof File) {
          console.log(`FormData -> ${key}: File(name=${val.name}, size=${val.size}, type=${val.type})`);
        } else {
          console.log(`FormData -> ${key}:`, val);
        }
      });

      // ✅ Debug final request URL
      const fullUrl = `${apiUrl}?clientcode=${clientCode}&usercode=${userCode}`;
      // console.log("Final Upload URL:", fullUrl);

      const response = await fetch(fullUrl, {
        method: "POST",
        body: formData
      });

      // ✅ Debug response before parsing
      // console.log("Response Status:", response.status, response.statusText);

      if (!response.ok) {
        const text = await response.text();
        // console.error("Raw Response Text:", text);
        throw new Error(`HTTP ${response.status}: ${text}`);
      }

      const result = await response.json();
      // console.log("Parsed JSON Response:", result);

      return result;
    } catch (error) {
      // console.error("Upload failed:", error);
      throw error;
    }
  }


  checkProcessStatus(usercode: number) {
    return this.http.post(
      `https://tdscpc.gstcpc.com/api/dynamic-import/file_import_process_check?usercode=${usercode}`,
      {}
    );
  }







  private basePath = 'dataimport';



  async fileDownloads(userCode: string, clientCode: string, filename: string): Promise<void> {
    console.log(userCode, clientCode, filename);

    try {
      if (!userCode || !clientCode || !filename) {
        console.error("Empty userCode or clientCode or filename");
        return;
      }

      // Clean the filename (remove # fragments and whitespace)
      filename = filename.replace(/#.*$/, '').trim();

      // Change extension to .zip if it's an Excel file
      if (/\.(xlsx?|csv)$/i.test(filename)) {
        filename = filename.replace(/\.(xlsx?|csv)$/i, '.zip');
      }

      // Construct proper formatted name for API
      const formattedFilename = `dataimport:${clientCode}_${userCode}_${filename}`;
      const url = `https://tdscpc.gstcpc.com/api/file-upload/File_download?filename=${encodeURIComponent(formattedFilename)}`;

      console.log("Download URL:", url);

      // Download file as blob
      const blob = await lastValueFrom(this.http.get(url, { responseType: 'blob' }));

      // Trigger browser download
      const a = document.createElement('a');
      const objectUrl = window.URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = filename; // saves with .zip
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(objectUrl);
      a.remove();

      console.log(`✅ File "${filename}" downloaded successfully!`);
    } catch (error) {
      console.error('❌ File download failed:', error);
    }
  }



  deducteemiudApi(endpoint: string, sdata: any): Observable<any> {
    const url = `${BASE_API_URL}${endpoint}`;
    return this.http
      .post<any>(
        url,
        { sdata: JSON.stringify(sdata) },
        {
          headers: this.getHeaders(),
          observe: 'response'
        }
      )
      .pipe(catchError(this.handleError));
  }


  getMiudProcessingStatus(params?: any): Observable<any> {
    const url = `${BASE_API_URL}/Comman/get_miud_processing_status`;

    // If query params are needed, append them dynamically
    const httpParams = new HttpParams({ fromObject: params || {} });

    return this.http.get<any>(url, {
      headers: this.getHeaders(),
      params: httpParams,
      observe: 'response', // 👈 gives full response (status + headers + body)
    })
      .pipe(catchError(this.handleError));
  }





  private getAuthHeaders(): HttpHeaders {
    const token = sessionStorage.getItem('token') || '';
    const userCode = sessionStorage.getItem('Usercode') || '';
    const clientCode = sessionStorage.getItem('Clientcode') || '';

    return new HttpHeaders({
      'Content-Type': 'application/json',
      'X-Authtoken': token,
      'X-User-Code': userCode,
      'X-Client-Code': clientCode
    });
  }



  //   async validateExcelAndJson(
  //   excelFile: File,
  //   jsonBlob: Blob
  // ): Promise<any> {
  //   try {
  //     if (!excelFile) {
  //       throw new Error("Excel file is required for validation.");
  //     }

  //     if (!jsonBlob) {
  //       throw new Error("JSON metadata is required for validation.");
  //     }

  //     const url = `${BASE_API_URL}/EV/Excel-validator`;

  //     const formData = new FormData();
  //     formData.append('ExcelFile', excelFile);
  //     formData.append('JsonFile', jsonBlob, 'metadata.json');

  //     console.log("🔍 Validating Excel & JSON with API:", url);

  //     const response = await lastValueFrom(
  //       this.http.post(url, formData)
  //     );

  //     console.log("✅ Validation Response:", response);
  //     return response;

  //   } catch (error) {
  //     console.error('❌ Excel Validation Failed:', error);
  //     throw error;
  //   }
  // }



  async validateExcelAndJson(
    zipFile: File | Blob,
    jsonBlob: Blob
  ): Promise<any> {
    try {
      if (!zipFile) {
        throw new Error("ZIP file is required for validation.");
      }

      if (!jsonBlob) {
        throw new Error("JSON metadata is required for validation.");
      }

      const url = `${BASE_API_URL}/EV/Excel-validator`;

      const formData = new FormData();
      formData.append('ExcelFile', zipFile, 'data.zip');
      formData.append('JsonFile', jsonBlob, 'metadata.json');

     

      const response = await lastValueFrom(
        this.http.post(url, formData)
      );

      return response;

    } catch (error) {
     
      throw error;
    }
  }






  // async refreshSession(): Promise<any> {
  //   const headers = this.getAuthHeaders();

  //   try {
  //     const response = await firstValueFrom(
  //       this.http.post(`${BASE_API_URL}/Auth/refreshsession`, {}, { headers })
  //     );
  //     console.log('✅ Session refreshed successfully:', response);
  //     return response;
  //   } catch (error) {
  //     console.error('❌ Session refresh failed:', error);
  //     throw error;
  //   }
  // }

  async refreshSession(): Promise<any> {
    const headers = this.getAuthHeaders();

    // Prepare JSON payload
    const payload = {
      usercode: sessionStorage.getItem('Usercode') || '',
      clientcode: sessionStorage.getItem('Clientcode') || '',
      token: sessionStorage.getItem('token') || ''
    };

    try {
      const response = await firstValueFrom(
        this.http.post(`${BASE_API_URL}/Auth/refreshsession`, payload, { headers })
      );

      // console.log('✅ Session refreshed successfully:', response);
      return response;
    } catch (error) {
      // console.error('❌ Session refresh failed:', error);
      throw error;
    }
  }











  logout(): Promise<any> {
    const headers = new HttpHeaders({
      'X-Authtoken': sessionStorage.getItem('token') || '',
      'X-User-Code': sessionStorage.getItem('Usercode') || '',
      'X-Client-Code': sessionStorage.getItem('Clientcode') || '',
    });

    return firstValueFrom(
      this.http.delete(
        `${BASE_API_URL}/Auth/removesession`,
        { headers }
      )
    );
  }

}
