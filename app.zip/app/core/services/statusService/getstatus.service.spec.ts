import { TestBed } from '@angular/core/testing';

import { GetstatusService } from './getstatus.service';

describe('GetstatusService', () => {
  let service: GetstatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetstatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
