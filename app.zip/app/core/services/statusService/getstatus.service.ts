import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { interval, Subscription, switchMap } from 'rxjs';
import { ToastService } from '../toaster/toast.service';
import { ApiserviceService } from '../componentservice/apiservice.service';

@Injectable({
  providedIn: 'root'
})
export class GetstatusService {

    private pollingSubscription?: Subscription;
  private pollingActive = false;

  constructor(
    private apiService: ApiserviceService,   // ✅ use ApiService
    private toastService: ToastService
  ) {}

  /** ✅ Starts polling the backend every 10 seconds */
  startPolling() {
    if (this.pollingActive) return;
    this.pollingActive = true;

    this.checkStatus(); // initial one-time check

    this.pollingSubscription = interval(10000)
      .pipe(switchMap(() => this.apiService.getStatus('/dynamic-import/get_data_status')))
      .subscribe({
        next: (response) => {
          console.log('Polling response:', response);
          if (response.status == 200 || response.status == '200') {
            this.toastService.showSuccess(response.message || 'Processing completed successfully.');
            this.stopPolling();
          }
        },
        error: (err) => {
          console.error('Error during polling:', err);
        }
      });
  }

  /** ✅ Single API check before interval starts */
  private checkStatus() {
    this.apiService.getStatus('/dynamic-import/get_data_status').subscribe({
      next: (response) => {
        console.log('Initial status:', response);
        if (response.status == 200 || response.status == '200') {
          this.toastService.showSuccess(response.message || 'Processing completed successfully.');
          this.stopPolling();
        }
      },
      error: (err) => {
        console.error('Initial status check failed:', err);
      }
    });
  }

  /** ✅ Stop polling */
  stopPolling() {
    if (this.pollingSubscription) {
      this.pollingSubscription.unsubscribe();
      this.pollingSubscription = undefined;
    }
    this.pollingActive = false;
  }

  /** ✅ Cleanup when destroyed */
  ngOnDestroy() {
    this.stopPolling();
  }
}
