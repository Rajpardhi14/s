import { Injectable, Inject, PLATFORM_ID, Optional } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SocialAuthService, GoogleLoginProvider, SocialUser } from '@abacritt/angularx-social-login';
import { Observable, from, of, Subject } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { GOOGLE_CLIENT_ID } from '../../config/google-auth.config';
import { MICROSOFT_CLIENT_ID } from '../../config/microsoft-auth.config';

declare const google: any;

@Injectable({
  providedIn: 'root'
})
export class OauthService {
  private user: SocialUser | null = null;

  constructor(
    @Optional() private socialAuthService: SocialAuthService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    if (isPlatformBrowser(this.platformId) && this.socialAuthService) {
      this.socialAuthService.authState.subscribe((user) => {
        this.user = user;
      });
    }
  }

  // Google Sign In using Google Identity Services
  signInWithGoogle(): Observable<any> {
    if (!isPlatformBrowser(this.platformId)) {
      return of(null);
    }

    const subject = new Subject<any>();

    // Check if Google Identity Services is loaded
    if (typeof google === 'undefined' || !google.accounts) {
      console.error('Google Identity Services not loaded');
      setTimeout(() => {
        subject.next(null);
        subject.complete();
      }, 0);
      return subject.asObservable();
    }

    // Initialize Google Identity Services
    const client = google.accounts.oauth2.initTokenClient({
      client_id: GOOGLE_CLIENT_ID,
      scope: 'email profile openid',
      callback: (tokenResponse: any) => {
        // Fetch user info using the access token
        fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: {
            Authorization: `Bearer ${tokenResponse.access_token}`
          }
        })
        .then(response => response.json())
        .then(userInfo => {
          const user = {
            id: userInfo.id,
            email: userInfo.email,
            firstName: userInfo.given_name || '',
            lastName: userInfo.family_name || '',
            name: userInfo.name,
            photoUrl: userInfo.picture,
            provider: 'GOOGLE',
            idToken: tokenResponse.access_token
          };
          console.log('Google user info:', user);
          subject.next(user);
          subject.complete();
        })
        .catch(error => {
          console.error('Error fetching user info:', error);
          subject.next(null);
          subject.complete();
        });
      }
    });

    // Request access token
    client.requestAccessToken();

    return subject.asObservable();
  }

  // Alternative: Google Sign In using One Tap
  signInWithGoogleOneTap(): Observable<any> {
    if (!isPlatformBrowser(this.platformId)) {
      return of(null);
    }

    const subject = new Subject<any>();

    if (typeof google === 'undefined' || !google.accounts) {
      console.error('Google Identity Services not loaded');
      setTimeout(() => {
        subject.next(null);
        subject.complete();
      }, 0);
      return subject.asObservable();
    }

    google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: (response: any) => {
        // Decode JWT token to get user info
        const userInfo = this.decodeJWT(response.credential);
        const user = {
          id: userInfo.sub,
          email: userInfo.email,
          firstName: userInfo.given_name || '',
          lastName: userInfo.family_name || '',
          name: userInfo.name,
          photoUrl: userInfo.picture,
          provider: 'GOOGLE',
          idToken: response.credential
        };
        console.log('Google One Tap user:', user);
        subject.next(user);
        subject.complete();
      }
    });

    google.accounts.id.prompt();

    return subject.asObservable();
  }

  // Microsoft Sign In (using popup flow with implicit grant)
  signInWithMicrosoft(): Observable<any> {
    if (!isPlatformBrowser(this.platformId)) {
      return of(null);
    }

    const subject = new Subject<any>();
    
    // Microsoft OAuth configuration for implicit flow
    const clientId = MICROSOFT_CLIENT_ID;
    const redirectUri = window.location.origin + '/auth/microsoft/callback';
    const scope = 'openid profile email';
    const responseType = 'id_token token'; // Implicit flow for client-side
    const nonce = this.generateState();
    
    const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?` +
      `client_id=${clientId}&` +
      `response_type=${encodeURIComponent(responseType)}&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}&` +
      `scope=${encodeURIComponent(scope)}&` +
      `nonce=${nonce}&` +
      `response_mode=fragment`;

    // Open popup window
    const width = 500;
    const height = 600;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;
    
    const popup = window.open(
      authUrl,
      'Microsoft Sign In',
      `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no`
    );

    if (!popup) {
      console.error('Popup blocked. Please allow popups for this site.');
      subject.next(null);
      subject.complete();
      return subject.asObservable();
    }

    // Listen for messages from popup
    const checkPopup = setInterval(() => {
      try {
        if (popup.closed) {
          clearInterval(checkPopup);
          subject.next(null);
          subject.complete();
          return;
        }

        // Check if popup has redirected to callback URL
        if (popup.location.href.includes('/auth/microsoft/callback')) {
          const hash = popup.location.hash;
          clearInterval(checkPopup);
          popup.close();

          // Parse the token from URL fragment
          const params = new URLSearchParams(hash.substring(1));
          const idToken = params.get('id_token');
          const accessToken = params.get('access_token');

          if (idToken) {
            // Decode the ID token to get user info
            const userInfo = this.decodeJWT(idToken);
            const user = {
              id: userInfo.oid || userInfo.sub,
              email: userInfo.email || userInfo.preferred_username,
              firstName: userInfo.given_name || '',
              lastName: userInfo.family_name || '',
              name: userInfo.name,
              photoUrl: '', // Microsoft doesn't provide photo in token
              provider: 'MICROSOFT',
              idToken: idToken,
              accessToken: accessToken
            };
            
            console.log('Microsoft user info:', user);
            subject.next(user);
          } else {
            console.error('No ID token received from Microsoft');
            subject.next(null);
          }
          subject.complete();
        }
      } catch (e) {
        // Cross-origin error is expected until redirect happens
      }
    }, 500);

    // Timeout after 2 minutes
    setTimeout(() => {
      clearInterval(checkPopup);
      if (popup && !popup.closed) {
        popup.close();
      }
      subject.next(null);
      subject.complete();
    }, 120000);

    return subject.asObservable();
  }

  // Handle Microsoft callback
  handleMicrosoftCallback(code: string, state: string): Observable<any> {
    // Verify state to prevent CSRF attacks
    if (isPlatformBrowser(this.platformId)) {
      const storedState = sessionStorage.getItem('oauth_state');
      if (state !== storedState) {
        console.error('State mismatch - possible CSRF attack');
        return of(null);
      }
      sessionStorage.removeItem('oauth_state');
    }

    // Exchange code for token (this should be done on your backend)
    // For now, return the code to be sent to your backend
    return of({ code, provider: 'microsoft' });
  }

  // Sign out
  signOut(): Observable<void> {
    if (!isPlatformBrowser(this.platformId) || !this.socialAuthService) {
      return of(undefined);
    }

    return from(this.socialAuthService.signOut()).pipe(
      map(() => {
        this.user = null;
        console.log('User signed out');
      }),
      catchError(error => {
        console.error('Sign out error:', error);
        return of(undefined);
      })
    );
  }

  // Get current user
  getCurrentUser(): SocialUser | null {
    return this.user;
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return this.user !== null;
  }

  // Generate random state for OAuth
  private generateState(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }

  // Decode JWT token
  private decodeJWT(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(jsonPayload);
    } catch (error) {
      console.error('Error decoding JWT:', error);
      return {};
    }
  }
}