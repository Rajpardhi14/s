import { Injectable, signal, computed } from '@angular/core';
import { interval, of, throwError } from 'rxjs';
import { concatMap, takeWhile, tap, finalize, catchError } from 'rxjs/operators';
import { ApiserviceService } from '../componentservice/apiservice.service';
import { ToastService } from '../toaster/toast.service';


@Injectable({ providedIn: 'root' })
export class KillProcessService {
  private _isProcessing = signal(false);
  private _isDeleting = signal(false);

  isProcessing = computed(() => this._isProcessing());
  isDeleting = computed(() => this._isDeleting());

  private currentProcess: any = null; // store process info for state persistence

  constructor(private api: ApiserviceService, private toast: ToastService) {}

  runKillSequence(context: any) {
    if (this._isProcessing()) return; // prevent duplicate calls

    this._isProcessing.set(true);
    this._isDeleting.set(true);

    this.currentProcess = {
      seqno: context.a_process_seqno,
      status: 'running',
    };

    const { FYYear, processStatusCode, myCodeforDelete, iudtypeError } = context;

    const sdataKill = this.api.generateSData(
      'get_tiud_import_tran',
      context.localUserData,
      context.filterClause,
      context.limit,
      context.offset,
      context.currentPage,
      {
        FYYear,
        iudtype: 'PROCESS_STATUS_UPDATE',
        processStatusCode,
        seqnumber: context.a_process_seqno,
      }
    );

    const sdataTemplate = this.api.generateSData(
      'get_tiud_import_template_excel_tdsb',
      context.localUserData,
      context.filterClause,
      context.limit,
      context.offset,
      context.currentPage,
      {
        FYYear,
        iudtype: iudtypeError,
        processStatusCode: myCodeforDelete,
        refnumber: context.a_process_seqno,
      }
    );

    const sdataFinalCancel = this.api.generateSData(
      'get_tiud_import_tran',
      context.localUserData,
      context.filterClause,
      context.limit,
      context.offset,
      context.currentPage,
      {
        FYYear,
        iudtype: 'PROCESS_CANCEL',
        processStatusCode: myCodeforDelete,
        seqnumber: context.a_process_seqno,
      }
    );

    // Helper methods
    const getProcError = (res: any) => {
      if (!res?.result) return 1;
      if (Array.isArray(res.result))
        return Number(res.result[0]?.a_proc_error || 1);
      if (typeof res.result === 'object')
        return Number(res.result.a_proc_error || 1);
      return 1;
    };

    const getProcErrorMsg = (res: any, defaultMsg: string) => {
      if (!res?.result) return defaultMsg;
      if (Array.isArray(res.result))
        return res.result[0]?.a_proc_error_message || defaultMsg;
      return res.result?.a_proc_error_message || defaultMsg;
    };

    this.api
      .miudApi('/Transaction/get_tiud_import_tran', sdataKill)
      .pipe(
        concatMap((killRes) => {
          if (getProcError(killRes) !== 0)
            return throwError(() => new Error(getProcErrorMsg(killRes, 'Kill failed')));
          return this.getProceseq$(context);
        }),
        concatMap(() =>
          this.api.miudApi('/dynamic-import/get_tiud_import_template_excel_tdsb', sdataTemplate)
        ),
        concatMap(() =>
          this.api.miudApi('/Transaction/get_tiud_import_tran', sdataFinalCancel)
        ),
        concatMap(() => {
          let attempts = 0;
          const maxAttempts = 12;
          const pollInterval = 5000;

          return interval(pollInterval).pipe(
            concatMap(() => this.getProceseq$(context)),
            takeWhile((seq) => {
              attempts++;
              const code =
                seq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
                seq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;
              const isComplete = !code || ['ZK', 'TC', 'TF', 'TG'].includes(code);
              return !isComplete && attempts < maxAttempts;
            }, true),
            tap((finalSeq) => {
              const code =
                finalSeq?.result?.get_tiud_import_tran?.[0]?.process_status_code ??
                finalSeq?.result?.proc_utilf_get_process_seqno_status?.[0]?.process_status_code;

              if (!code || ['ZK', 'TC', 'TF', 'TG'].includes(code)) {
                this.toast.showSuccess('Process deleted successfully.');
              } else if (attempts >= maxAttempts) {
                this.toast.showError('Process did not complete within expected time.');
              }
            }),
            finalize(() => {
              this._isProcessing.set(false);
              this._isDeleting.set(false);
              this.currentProcess = null;
            }),
            catchError((err) => {
              this.toast.showError(err?.message || 'Sequence failed');
              this._isProcessing.set(false);
              this._isDeleting.set(false);
              this.currentProcess = null;
              return of(null);
            })
          );
        })
      )
      .subscribe();
  }

  getProceseq$(context: any) {
    const sdata = this.api.generateSData(
      'proc_utilf_get_process_seqno_status',
      context.localUserData,
      context.filterClause,
      context.limit,
      context.offset,
      context.currentPage,
      {
        FYYear: context.FYYear,
        iudtype: 'get_tiud_import_tran',
        processStatusCode: context.myCodeforDelete,
      }
    );
    return this.api.getTableData('/dynamic-import/proc_utilf_get_process_seqno_status', sdata);
  }

  // Allow component to know if the process is running
  isProcessAlive() {
    return this._isProcessing();
  }
}
