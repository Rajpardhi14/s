import { TestBed } from '@angular/core/testing';

import { KillProcessService } from './kill-process.service';

describe('KillProcessService', () => {
  let service: KillProcessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KillProcessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
