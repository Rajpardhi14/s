import { TestBed } from '@angular/core/testing';

import { SaveloadingService } from './saveloading.service';

describe('SaveloadingService', () => {
  let service: SaveloadingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SaveloadingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
