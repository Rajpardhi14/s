import { Injectable, signal } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
export interface ProcessState {
  isRunning: boolean;
  status: string | null;
  message: string;
  lastStep: number;
}

@Injectable({
  providedIn: 'root'
})
export class SaveloadingService {
  isProcessing = signal(false);
  ongoingProcess$?: Observable<any>;
}
