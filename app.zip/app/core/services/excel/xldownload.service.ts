import { Injectable } from '@angular/core';
import * as ExcelJS from 'exceljs';

@Injectable({
  providedIn: 'root',
})
export class XldownloadService {
  private readonly EXCEL_TYPE =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  private readonly EXCEL_EXTENSION = '.xlsx';

  constructor() { }

  downloadExcel(
    headers: any[],
    data: any[],
    fileName: string = 'exported_data'
  ): void {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Data');

    // Filter only visible headers
    const visibleHeaders = headers.filter((header) => header.visible);
    const headerNames = visibleHeaders.map((header) => header.headerName);

    // Enable sorting on headers
    worksheet.autoFilter = {
      from: { row: 1, column: 1 },
      to: { row: 1, column: visibleHeaders.length },
    };



    // Add header row with styling
    const headerRow = worksheet.addRow(headerNames);
    this.styleHeaderRow(headerRow);

    const inrFields = ['rent_yearly_amt', 'adv_rent_payment'];

    // Add data rows
    data.forEach((item) => {
      const rowData = visibleHeaders.map((header) => {
        const value = item[header.field];


        // ✅ Properly handle the 'attach_file_name' field
        if (
          header.field === 'attach_file_name' ||
          header.field === 'upload_file_name'
        ) {
          try {
            if (Array.isArray(value)) {
              // Extract only fileName from each object
              return value.map((file) => file.fileName).join(', ');
            } else if (typeof value === 'string') {
              // In case value is a JSON string, parse it first
              const parsed = JSON.parse(value);
              if (Array.isArray(parsed)) {
                return parsed.map((file) => file.fileName).join(', ');
              }
            }
          } catch (error) {
            console.warn('Invalid attach_file_name format', error);
            return '';
          }
        } else if (header.field === 'status') {
          if (value === 'A') return 'Active';
          else if (value === 'S') return 'Suspended';
          else if (value === 'I') return 'InActive';
          else if (value === 'REJECTED') return 'REJECTED';
          else if (value === 'APPROVED') return 'APPROVED';
          else if (value === 'PENDING') return 'PENDING';
          else return value ?? '';
        }



        // ✅ Handle 'rent_appl_flag' and 'tds_appl_flag'  --- BGL Master
        else if (
          header.field === 'rent_appl_flag' ||
          header.field === 'tds_appl_flag'
        ) {
          if (value === 'Y') return 'Yes';
          else if (value === 'N') return 'No';
          else return value ?? '';
        }

        // rev charge Master
        else if (header.field === 'itc_flag') {
          if (value === 'A') return 'Availed';
          else if (value === 'B') return 'Blocked';
          else return value ?? '';
        } else if (header.field === 'approved_status') {
          if (value === 'A') return 'Approved';
          else if (value === 'R') return 'Rejected';
          else return value ?? 'Pending';
        }

        // rev charge Master
        else if (header.field === 'rc_appl_date_flag') {
          if (value === 'ID') return 'Invoice Date';
          else if (value === 'TD') return 'Transaction Date';
          else return value ?? '';
        }
        // GENERAL PURCHASE ORDER 
        else if (header.field === 'po_status_flag') {
          if (value === 'A') return 'ACTIVE';
          else return value ?? '';
        }
        else if (header.field === 'flag') {
          if (value === 'P') return 'PAN';
          else if (value === 'G') return 'GSTIN';
          else if (value === 'U') return 'UNREGISTERED';
          else return value ?? '';
        }
        else if (header.field === 'state_code') {
          const stateMap: { [key: string]: string } = {
            '01': 'Jammu & Kashmir',
            '1': 'Jammu & Kashmir',
            '02': 'Himachal Pradesh',
            '2': 'Himachal Pradesh',
            '03': 'Punjab',
            '3': 'Punjab',
            '04': 'Chandigarh',
            '4': 'Chandigarh',
            '05': 'Uttarakhand',
            '5': 'Uttarakhand',
            '06': 'Haryana',
            '6': 'Haryana',
            '07': 'Delhi',
            '7': 'Delhi',
            '08': 'Rajasthan',
            '8': 'Rajasthan',
            '09': 'Uttar Pradesh',
            '9': 'Uttar Pradesh',
            '10': 'Bihar',
            '11': 'Sikkim',
            '12': 'Arunachal Pradesh',
            '13': 'Nagaland',
            '14': 'Manipur',
            '15': 'Mizoram',
            '16': 'Tripura',
            '17': 'Meghalaya',
            '18': 'Assam',
            '19': 'West Bengal',
            '20': 'Jharkhand',
            '21': 'Odisha',
            '22': 'Chhattisgarh',
            '23': 'Madhya Pradesh',
            '24': 'Gujarat',
            '25': 'Daman & Diu',
            '26': 'Dadra & Nagar Haveli',
            '27': 'Maharashtra',
            '28': 'Andhra Pradesh (Old)',
            '29': 'Karnataka',
            '30': 'Goa',
            '31': 'Lakshadweep',
            '32': 'Kerala',
            '33': 'Tamil Nadu',
            '34': 'Puducherry',
            '35': 'Andaman & Nicobar Islands',
            '36': 'Telangana',
            '37': 'Andhra Pradesh',
            '97': 'Other Territory'
          };


          return stateMap[value] ?? value;
        }
        else if (header.field === 'vendor_status') {
          if (value === 'A') return 'ACTIVE';
          else if (value === 'I') return 'INACTIVE';
          else return value ?? '';
        }
          else if (header.field === 'incremental_clause') {
          if (value === 'N') return 'NO';
          else if (value === 'Y') return 'YES';
          else return value ?? '';
        }
          else if (header.field === 'rent_frequency_flag') {
          if (value === 'M') return 'MONTHLY';
          else if (value === 'Y') return 'YEARLY';
          else if (value === 'Q') return 'QUATERLY';
          else return value ?? '';
        }
            // ✅ Format date for incremental_clause
    else if (header.field === 'incremental_date'  && typeof value === 'string') {
      try {
        // Remove the "T00:00:00" part and parse the date
        const datePart = value.split('T')[0];
        const dateObj = new Date(datePart);

        // Format to DD-MMM-YYYY
        const day = String(dateObj.getDate()).padStart(2, '0');
        const month = dateObj.toLocaleString('en-US', { month: 'short' });
        const year = dateObj.getFullYear();

        return `${day}-${month}-${year}`;
      } catch (err) {
        console.warn('Invalid incremental_clause date:', value);
        return value ?? '';
      }
    }

    
const normalizeArrayField = (val: any): string => {
  // if already an array
  if (Array.isArray(val)) {
    const filtered = val
      .filter(v => v !== null && v !== undefined && String(v).trim() !== '' && String(v).toLowerCase() !== 'null')
      .map(v => String(v).trim());
    return filtered.length ? filtered.join(',') : '';
  }

  // if JSON string containing an array e.g. '["A","B"]'
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (!trimmed) return '';
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        const filtered = parsed
          .filter((v: any) => v !== null && v !== undefined && String(v).trim() !== '' && String(v).toLowerCase() !== 'null')
          .map((v: any) => String(v).trim());
        return filtered.length ? filtered.join(',') : '';
      }
    } catch {
      // not a JSON array string — fallthrough
    }
    // literal "null" or empty
    if (trimmed.toLowerCase() === 'null') return '';
    return trimmed;
  }

  // other types (null, undefined, numbers etc.)
  if (val == null) return '';
  return String(val);
};



      // Format as INR with Indian numbering
    if (inrFields.includes(header.field) && !isNaN(value)) {
     return Number(value); // Keep as number
    // If you want the ₹ symbol, use:
    // return `₹ ${Number(value).toLocaleString('en-IN')}`;
     }
     else if(header.field === 'tanno_str'){
      return normalizeArrayField(value);
     }
     

        else if (header.field === 'po_utilized_flag') {
          if (value === 'PC') return 'Partialy Consumed';
          else if (value === 'NC') return 'Not Consumed';
          else if (value === 'C') return 'Consumed';
          else return value ?? '';
        }
        return value ?? '';
      });

const newRow = worksheet.addRow(rowData);


  // ✅ Apply Excel number formatting & right alignment
  inrFields.forEach(field => {
    const colIndex = visibleHeaders.findIndex(h => h.field === field);
    if (colIndex !== -1) {
      const cell = newRow.getCell(colIndex + 1);
      cell.numFmt = '#,##,##0'; // Indian numbering format
      cell.alignment = { vertical: 'middle', horizontal: 'right' };
    }
  });

// 🔍 Index for vendor_status
const vendorStatusIndex = visibleHeaders.findIndex(
  (header) => header.field === 'vendor_status'
);
if (vendorStatusIndex !== -1) {
  const cell = newRow.getCell(vendorStatusIndex + 1);
  applyStatusStyling(cell, cell.value);
    // 📐 Alignment
  cell.alignment = { vertical: 'middle', horizontal: 'center' };
}

// 🔍 Index for status
const statusIndex = visibleHeaders.findIndex(
  (header) => header.field === 'status'
);
if (statusIndex !== -1) {
  const cell = newRow.getCell(statusIndex + 1);
if (typeof cell.value === 'string') {
  applyStatusStyling(cell, cell.value);
}
  // 📐 Alignment
  cell.alignment = { vertical: 'middle', horizontal: 'center' };
}

// ✅ Center align multiple specific headers
const centerAlignHeaders = ['status', 'vendor_status','incremental_clause']; // add more keys here

centerAlignHeaders.forEach(field => {
  const colIndex = visibleHeaders.findIndex(h => h.field === field);
  if (colIndex !== -1) {
    headerRow.getCell(colIndex + 1).alignment = {
      vertical: 'middle',
      horizontal: 'center'
    };
  }
});


// ✅ Right align multiple specific headers
const RightAlignHeaders = ['rent_yearly_amt', 'pin',"paying_rent_date",'adv_rent_payment']; // add more keys here

RightAlignHeaders.forEach(field => {
  const colIndex = visibleHeaders.findIndex(h => h.field === field);
  if (colIndex !== -1) {
    headerRow.getCell(colIndex + 1).alignment = {
      vertical: 'middle',
      horizontal: 'right'
    };
  }
});


// 🔍 Index for Approval Status
const ApprovalStatusIndex = visibleHeaders.findIndex(
  (header) => header.field === 'approval_rights_remark'
);
if (ApprovalStatusIndex !== -1) {
  const cell = newRow.getCell(ApprovalStatusIndex + 1);
if (typeof cell.value === 'string') {
  applyStatusStyling(cell, cell.value);
}
}

// 🔍 Index for Incremental Clause

const incrementalClauseIndex = visibleHeaders.findIndex(
  (header) => header.field === 'incremental_clause'
);
if (incrementalClauseIndex !== -1) {
  const cell = newRow.getCell(incrementalClauseIndex + 1);
if (typeof cell.value === 'string') {
  applyStatusStyling(cell, cell.value);
}
  // 📐 Alignment
  cell.alignment = { vertical: 'middle', horizontal: 'center' };
}


// ✅ Reusable styling function
function applyStatusStyling(cell: any, value: any) {
  if (value === 'INACTIVE' || value === 'REJECTED' || value === 'NO') {

      cell.font = {
    color: { argb: 'FFFF0000' }, // White text
  };

  } else if (value === 'ACTIVE' || value === 'APPROVED' || value === 'YES') {

      cell.font = {
    color: { argb: 'FF00B050' }, // White text
  };

  } else if (value === 'PENDING' || value === 'PENDING WITH ZONE OFFICE  CHECKER' || 'PENDING WITH HEAD OFFICE CHECKER') {

      cell.font = {
    color: { argb: 'FFD6A300' }, // White text
  };
  }

  // ✏️ Font color

  // 📏 Border style
  // cell.border = {
  //   bottom: { style: 'thin', color: { argb: 'FFF2F2F2' } },
  // };


}

    });

    // Auto-adjust column widths
    this.autoFitColumns(worksheet, visibleHeaders.length);
    // Generate Excel file and trigger download
    workbook.xlsx
      .writeBuffer()
      .then((buffer) => this.saveAsExcelFile(buffer, fileName));
  }

  private styleHeaderRow(headerRow: ExcelJS.Row): void {

  headerRow.font = {
    bold: true,
    color: { argb: 'FFFFFFFF' }, // white text
  };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF0070C0' }, // blue background
  };
  }

  private autoFitColumns(
    worksheet: ExcelJS.Worksheet,
    columnCount: number
  ): void {
    for (let i = 1; i <= columnCount; i++) {
      const column = worksheet.getColumn(i);
      let maxLength = 10;
      column.eachCell({ includeEmpty: true }, (cell:any) => {
        const length = cell.value?.toString().length || 0;
        if (length > maxLength) maxLength = length;
      });
      column.width = Math.min(maxLength + 2, 50);
    }
  }



  private saveAsExcelFile(buffer: any, baseFileName: string): void {
    const now = new Date();
    const date = now.getDate();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const formattedDate = `${date}.${month}.${year}`;
    const formattedTime = `${hours}.${minutes}.${ampm}`;
    const fullFileName = `${baseFileName}${formattedDate}${formattedTime}.${this.EXCEL_EXTENSION}`;
    const blob = new Blob([buffer], { type: this.EXCEL_TYPE });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fullFileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

}
