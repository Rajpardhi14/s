import { TestBed } from '@angular/core/testing';

import { XldownloadService } from './xldownload.service';

describe('XldownloadService', () => {
  let service: XldownloadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(XldownloadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
