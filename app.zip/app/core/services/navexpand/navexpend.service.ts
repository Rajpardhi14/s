import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavexpendService {

  private collapsedState = new BehaviorSubject<boolean>(false);
  isCollapsed$ = this.collapsedState.asObservable();

  // getter
  get isCollapsed(): boolean {
    return this.collapsedState.value;
  }

  // toggle
  toggleSidebar() {
    this.collapsedState.next(!this.collapsedState.value);
  }

  // set explicitly
  setSidebar(state: boolean) {
    this.collapsedState.next(state);
  }
}
