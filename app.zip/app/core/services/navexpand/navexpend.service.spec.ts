import { TestBed } from '@angular/core/testing';

import { NavexpendService } from './navexpend.service';

describe('NavexpendService', () => {
  let service: NavexpendService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NavexpendService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
