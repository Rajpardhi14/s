import { Injectable } from '@angular/core';
import { HostListener } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class ScreensizeService {
  screenWidth: number = window.innerWidth;
  screenHeight: number = window.innerHeight;

  // Correct initialization for fullScreenResolution
  fullScreenResolution: { width: number; height: number } = {
    width: 0,
    height: 0,
  };
  constructor() {
    this.updateScreenSize();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.updateScreenSize();
  }

  private updateScreenSize() {
    this.screenWidth = window.innerWidth;
    this.screenHeight = window.innerHeight;

  }

  // Optional: Add a method to get the device type (e.g., desktop, laptop, mobile)
  getDeviceType(): string {
    if (this.screenWidth > 1920) {
      return 'Extra Large Desktop'; // Ultra-wide or 4K monitors
    } else if (this.screenWidth > 1600) {
      return 'Very Large Desktop'; // Screens between 1600px and 1920px
    } else if (this.screenWidth > 1400) {
      return 'Large Desktop'; // Screens between 1400px and 1600px
    } else if (this.screenWidth > 1200) {
      return 'Medium Desktop'; // Screens between 1200px and 1400px
    } else if (this.screenWidth >= 1024) {
      return 'Small Desktop'; // Screens between 1024px and 1200px
    } else if (this.screenWidth >= 768) {
      return 'Laptop'; // Screens between 768px and 1024px
    } else if (this.screenWidth >= 576) {
      return 'Tablet'; // Screens between 576px and 768px
    } else if (this.screenWidth >= 480) {
      return 'Small Tablet / Large Mobile'; // Screens between 480px and 576px
    } else {
      return 'Mobile'; // Screens smaller than 480px
    }
  }

  getFullScreenResolution(): { width: number; height: number } {
    this.fullScreenResolution = {
      width: window.screen.width,
      height: window.screen.height,
    };
    return this.fullScreenResolution;
  }
}
