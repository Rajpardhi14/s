import { TestBed } from '@angular/core/testing';

import { DarklightthemeService } from './darklighttheme.service';

describe('DarklightthemeService', () => {
  let service: DarklightthemeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DarklightthemeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
