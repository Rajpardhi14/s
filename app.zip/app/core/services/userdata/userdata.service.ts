import { Injectable, signal, effect } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {
  private _localUserData: any;              
  private _dynamicUserData = signal<any>({}); 


  dynamicUserData = this._dynamicUserData.asReadonly();

  constructor() {
    this.loadLocalUserData();
    this.loadDynamicUserData();
  }

  // -------- Local User Data (static) --------
  private loadLocalUserData() {
    if (typeof window !== 'undefined') {
      const storedData = sessionStorage.getItem('localUserData');
      if (storedData) this._localUserData = JSON.parse(storedData);
    }
  }

  getLocalUserData() {
    return this._localUserData;
  }

  setLocalUserData(userData: any) {
    this._localUserData = userData;
    sessionStorage.setItem('localUserData', JSON.stringify(userData));
  }

  // -------- Dynamic User Data (reactive signal) --------
  private loadDynamicUserData() {
    if (typeof window !== 'undefined') {
      const storedData = sessionStorage.getItem('dynamicUserData');
      if (storedData) {
        this._dynamicUserData.set(JSON.parse(storedData));
      }
    }
  }

  getDynamicUserData(key: string) {
    return this._dynamicUserData()[key] ?? null;
  }

  setDynamicUserData(key: string, value: any) {
    const current = this._dynamicUserData();
    if (current[key] === value) return;

    const updated = { ...current, [key]: value };
    this._dynamicUserData.set(updated);
    sessionStorage.setItem('dynamicUserData', JSON.stringify(updated));
  }

  setDynamic(userData: any) {
    const updated = { ...this._dynamicUserData(), ...userData };
    this._dynamicUserData.set(updated);
    sessionStorage.setItem('dynamicUserData', JSON.stringify(updated));
  }

  getAllDynamicUserData() {
    return this._dynamicUserData();
  }

  clearLocalUserData() {
    this._localUserData = null;
    this._dynamicUserData.set({});
    sessionStorage.removeItem('localUserData');
    sessionStorage.removeItem('dynamicUserData')
    sessionStorage.removeItem('Authtoken');
    sessionStorage.removeItem('Usercode');
    sessionStorage.removeItem('multimast');
    sessionStorage.removeItem('user_permissions');
    sessionStorage.removeItem('loginSuccess');
  }

    resetAllUserData() {
    this._localUserData = null;
    this._dynamicUserData.set({});
    // localStorage.clear();
    sessionStorage.clear();
  }
}
