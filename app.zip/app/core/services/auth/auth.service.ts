// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { BASE_API_URL } from '../../constants/endpoint';
// import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
// import { IpService } from '../ipaddress/ip.service';
// import { UserdataService } from '../userdata/userdata.service';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   // varibles
//   ipAddress: string | null = null;
//   constructor(private http: HttpClient, private ipService: IpService, private userlocaldataService: UserdataService) { }

//   ngOnInit(): void {
//     this.ipService.ipAddress$.subscribe((ip) => {
//       this.ipAddress = ip;
//     });
//   }

//   // Signup
//   signup(userData: any): Observable<any> {
//     return this.http.post(
//       `${BASE_API_URL}/Login/get_miud_client_mast_proposal`,
//       userData
//     );
//   }

//   signotp(userData: any): Observable<any> {
//     return this.http.post(`${BASE_API_URL}/Login/send-otp`, userData);
//   }

//   checkEmail(userData: any): Observable<any> {
//     return this.http.post(`${BASE_API_URL}/Login/get_gmdt_user_mast_email_id`, userData);
//   }


//   verifyotp(userData: any): Observable<any> {
//     return this.http.post(`${BASE_API_URL}/Login/verify-otp`, userData);
//   }

//   changepassword(userData: any): Observable<any> {
//     return this.http.post(`${BASE_API_URL}/Login/get_miud_user_mast`, userData);
//   }

//   // Verify 2FA code during login
//   verify2FA(verifyRequest: any): Observable<any> {
//     return this.http.post(`${BASE_API_URL}/api/login/verify-2fa`, verifyRequest);
//   }

//   forgetPassword(email: string): Observable<any> {
//     const body = {

//       email_id: email



//     };



//     return this.http.post<any>(`${BASE_API_URL}/Login/forget-pass`, body);
//   }

//   private getCookie(name: string): string | null {
//     const match = document.cookie.match(
//       new RegExp('(^| )' + name + '=([^;]+)')
//     );
//     return match ? decodeURIComponent(match[2]) : null;
//   }

//   validateLogin(
//     loginId: string,
//     localIPAddress: any,
//     Login: string,
//     enteredPassword: any
//   ): Observable<HttpResponse<any>> {
//     const requestData = {
//       sdata: JSON.stringify({
//         a_session_seqno: "",
//         a_iud_seqno: "",
//         a_iud_type: 'login_id',
//         a_proc_type: 'get_gmdt_login_id',
//         a_in_parameter_json: [
//           {
//             a_module_type_code: 'TAXCPC',
//             a_login_id: loginId,
//             a_login_password: enteredPassword,
//             a_os_ip_address: localIPAddress,
//           },
//         ],
//       }),
//     };
//     const headers = new HttpHeaders({
//       Login: Login,
//     });
//     // this.sessionTimerService.updateSessionTime();
//     // return this.http.post<any>(this.loginapiUrl, requestData, {
//     //   headers,
//     //   observe: 'response',
//     //   withCredentials: false,
//     // });


//     return this.http.post<any>(
//       `${BASE_API_URL}/Login/get_gmdt_login_id`,
//       requestData,
//       {
//         headers,
//         observe: 'response',
//         withCredentials: false,
//       }
//     );
//   }
//   fetchMultiMastData(requestData: any): Observable<HttpResponse<any>> {
//     // this.sessionTimerService.updateSessionTime();
//     const localUserData = this.userlocaldataService.getLocalUserData() || {};
//     const authToken = this.getCookie('Authtoken') || '';

//     const headers = {
//       Authtoken: authToken,
//       Usercode: sessionStorage.getItem('Usercode') || '',
//       Rolestr: localUserData?.user_role_code || '',
//       Branchcode: localUserData?.bank_branch_code || '',
//       'Content-Type': 'application/json',
//     };

//     return this.http.post<any>(
//       `${BASE_API_URL}/Login/get_mmtx_multi_mast`,
//       requestData,
//       {
//         observe: 'response',
//         withCredentials: false,
//         headers: headers,
//       }
//     );
//   }



//   changePassword(sdata: any): Observable<any> {
//     return this.http.post(
//       `${BASE_API_URL}/businesssetting/get_miud_vc_user_mast`,
//       { sdata: JSON.stringify(sdata) }
//       // { headers: this.getHeaders() }
//     );
//   }



//   // Get TDS Rate
//   getTdsRate(sdata: any[]): Observable<HttpResponse<any>> {
//     const localUserData = this.userlocaldataService.getLocalUserData() || {};
//     const authToken = this.getCookie('Authtoken') || '';

//     const headers = {
//       Authtoken: authToken,
//       Usercode: sessionStorage.getItem('Usercode') || '',
//       Rolestr: localUserData?.user_role_code || '',
//       Branchcode: localUserData?.bank_branch_code || '',
//       'Content-Type': 'application/json',
//     };

//     const requestBody = {
//       sdata: JSON.stringify(sdata)
//     };

//     return this.http.post<any>(
//       `${BASE_API_URL}/Transaction/get_tds_rate`,
//       requestBody,
//       {
//         observe: 'response',
//         withCredentials: false,
//         headers: headers
//       }
//     );
//   }

//   // Get PAN Master Data
//   getPanMasterData(panNumber: string): Observable<HttpResponse<any>> {
//     const localUserData = this.userlocaldataService.getLocalUserData() || {};
//     const authToken = this.getCookie('Authtoken') || '';

//     const headers = {
//       Authtoken: authToken,
//       Usercode: sessionStorage.getItem('Usercode') || '',
//       Rolestr: localUserData?.user_role_code || '',
//       Branchcode: localUserData?.bank_branch_code || '',
//       'Content-Type': 'application/json',
//     };

//     const requestBody = {
//       sdata: JSON.stringify(["PANMAST_NAME", panNumber])
//     };

//     return this.http.post<any>(
//       `${BASE_API_URL}/Transaction/get_pan_mast`,
//       requestBody,
//       {
//         observe: 'response',
//         withCredentials: false,
//         headers: headers
//       }
//     );
//   }


//   getPanValidationData(panNumber: string): Observable<any> {
//     const url = `${BASE_API_URL}/Transaction/get_pan_details?panNo=${encodeURIComponent(panNumber)}`;
//     return this.http.post(url, {}, { observe: 'response' });
//   }

// }


import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BASE_API_URL } from '../../constants/endpoint';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { IpService } from '../ipaddress/ip.service';
import { UserdataService } from '../userdata/userdata.service';
import { SessiontimerService } from '../session/timer-session/sessiontimer.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // varibles
  ipAddress: string | null = null;
  constructor(private http: HttpClient, private ipService: IpService, private userlocaldataService: UserdataService , private sessionTimerService : SessiontimerService) { }

  ngOnInit(): void {
    this.ipService.ipAddress$.subscribe((ip) => {
      this.ipAddress = ip;
    });
  }

  // Signup
  signup(userData: any): Observable<any> {
    return this.http.post(
      `${BASE_API_URL}/Login/get_miud_client_mast_proposal`,
      userData
    );
  }

  signotp(userData: any): Observable<any> {
    return this.http.post(`${BASE_API_URL}/Login/send-otp`, userData);
  }

  checkEmail(userData: any): Observable<any> {
    return this.http.post(`${BASE_API_URL}/Login/get_gmdt_user_mast_email_id`, userData);
  }


  verifyotp(userData: any): Observable<any> {
    return this.http.post(`${BASE_API_URL}/Login/verify-otp`, userData);
  }

  changepassword(userData: any): Observable<any> {
    return this.http.post(`${BASE_API_URL}/Login/get_miud_user_mast`, userData);
  }

  // Verify 2FA code during login
  verify2FA(verifyRequest: any): Observable<any> {
    return this.http.post(`${BASE_API_URL}/api/login/verify-2fa`, verifyRequest);
  }

  forgetPassword(email: string): Observable<any> {
    const body = {

      email_id: email



    };



    return this.http.post<any>(`${BASE_API_URL}/Login/forget-pass`, body);
  }

  private getCookie(name: string): string | null {
    const match = document.cookie.match(
      new RegExp('(^| )' + name + '=([^;]+)')
    );
    return match ? decodeURIComponent(match[2]) : null;
  }

  validateLogin(
    loginId: string,
    localIPAddress: any,
    Login: string,
    enteredPassword: any
  ): Observable<HttpResponse<any>> {
    const requestData = {
      sdata: JSON.stringify({
        a_session_seqno: "",
        a_iud_seqno: "",
        a_iud_type: 'login_id',
        a_proc_type: 'get_gmdt_login_id',
        a_in_parameter_json: [
          {
            a_module_type_code: 'TAXCPC',
            a_login_id: loginId,
            a_login_password: enteredPassword,
            a_os_ip_address: localIPAddress,
          },
        ],
      }),
    };
    const headers = new HttpHeaders({
      Login: Login,
    });
    this.sessionTimerService.updateSessionTime();
    // return this.http.post<any>(this.loginapiUrl, requestData, {
    //   headers,
    //   observe: 'response',
    //   withCredentials: false,
    // });


    return this.http.post<any>(
      `${BASE_API_URL}/Login/get_gmdt_login_id`,
      requestData,
      {
        headers,
        observe: 'response',
        withCredentials: false,
      }
    );
  }
  fetchMultiMastData(requestData: any): Observable<HttpResponse<any>> {
    // this.sessionTimerService.updateSessionTime();
    const localUserData = this.userlocaldataService.getLocalUserData() || {};
    const authToken = this.getCookie('Authtoken') || '';

    const headers = {
      Authtoken: authToken,
      Usercode: sessionStorage.getItem('Usercode') || '',
      Rolestr: localUserData?.user_role_code || '',
      Branchcode: localUserData?.bank_branch_code || '',
      'Content-Type': 'application/json',
    };

    return this.http.post<any>(
      `${BASE_API_URL}/Login/get_mmtx_multi_mast`,
      requestData,
      {
        observe: 'response',
        withCredentials: false,
        headers: headers,
      }
    );
  }



  changePassword(sdata: any): Observable<any> {
    return this.http.post(
      `${BASE_API_URL}/businesssetting/get_miud_vc_user_mast`,
      { sdata: JSON.stringify(sdata) }
      // { headers: this.getHeaders() }
    );
  }



  // Get TDS Rate
  getTdsRate(sdata: any[]): Observable<HttpResponse<any>> {
    const localUserData = this.userlocaldataService.getLocalUserData() || {};
    const authToken = this.getCookie('Authtoken') || '';

    const headers = {
      Authtoken: authToken,
      Usercode: sessionStorage.getItem('Usercode') || '',
      Rolestr: localUserData?.user_role_code || '',
      Branchcode: localUserData?.bank_branch_code || '',
      'Content-Type': 'application/json',
    };

    const requestBody = {
      sdata: JSON.stringify(sdata)
    };

    return this.http.post<any>(
      `${BASE_API_URL}/Transaction/get_tds_rate`,
      requestBody,
      {
        observe: 'response',
        withCredentials: false,
        headers: headers
      }
    );
  }

  // Get PAN Master Data
  getPanMasterData(panNumber: string): Observable<HttpResponse<any>> {
    const localUserData = this.userlocaldataService.getLocalUserData() || {};
    const authToken = this.getCookie('Authtoken') || '';

    const headers = {
      Authtoken: authToken,
      Usercode: sessionStorage.getItem('Usercode') || '',
      Rolestr: localUserData?.user_role_code || '',
      Branchcode: localUserData?.bank_branch_code || '',
      'Content-Type': 'application/json',
    };

    const requestBody = {
      sdata: JSON.stringify(["PANMAST_NAME", panNumber])
    };

    return this.http.post<any>(
      `${BASE_API_URL}/Transaction/get_pan_mast`,
      requestBody,
      {
        observe: 'response',
        withCredentials: false,
        headers: headers
      }
    );
  }


  getPanValidationData(panNumber: string): Observable<any> {
    const url = `${BASE_API_URL}/Transaction/get_pan_details?panNo=${encodeURIComponent(panNumber)}`;
    return this.http.post(url, {}, { observe: 'response' });
  }

}
