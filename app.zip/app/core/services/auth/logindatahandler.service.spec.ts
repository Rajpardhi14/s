import { TestBed } from '@angular/core/testing';

import { LogindatahandlerService } from './logindatahandler.service';

describe('LogindatahandlerService', () => {
  let service: LogindatahandlerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LogindatahandlerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
