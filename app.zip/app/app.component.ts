import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SuccesstoastComponent } from "./shared/components/toaster/successtoast/successtoast.component";
import { ErrortoastComponent } from "./shared/components/toaster/errortoast/errortoast.component";
import { OverlayService } from './core/services/LoaderService/overlay.service';
import { CommonModule } from '@angular/common';
import { SessionexpairedComponent } from "./shared/components/sessionexpaired/sessionexpaired.component";
import { UserdataService } from './core/services/userdata/userdata.service';
import { SessionService } from './core/services/session/session/session.service';
import { FiledOptionService } from './core/services/session/timer-session/filed-option.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, SuccesstoastComponent, ErrortoastComponent, CommonModule, SessionexpairedComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  localUserData:any
  sessionExpired = false;
  isLoading = false;  
  title = 'tdscpc';
    constructor(private loaderService: OverlayService,
      private userlocaldataService: UserdataService,
      private sessionService: FiledOptionService,
    ) {}

    ngOnInit() {

     this.sessionService.sessionExpired$.subscribe((expired) => {
      this.sessionExpired = expired;
    });

    this.loaderService.loading$.subscribe(val => {
      this.isLoading = val;
    });



 

  }
}
